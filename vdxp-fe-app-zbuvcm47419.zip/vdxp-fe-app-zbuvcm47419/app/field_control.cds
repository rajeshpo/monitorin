using {zbuvcm47419Service} from '../srv/zbuvcm47419service';

annotate zbuvcm47419Service.PFC_List {
    BpSFrom    @Common: {FieldControl: fieldControl};
    ProdId     @Common: {FieldControl: fieldControl};
    BpSTo      @Common: {FieldControl: fieldControl};
    PlantSFrom @Common: {FieldControl: fieldControl};
    PlantSTo   @Common: {FieldControl: fieldControl};
    PfDesc     @Common: {FieldControl: fieldControl};
    ArchType   @Common: {FieldControl: fieldControl};
    ErSFrom    @Common: {FieldControl: fieldControl};
    ErSTo      @Common: {FieldControl: fieldControl};
     // ***** JGHJ-71574 ***** R2.2 START *****
    UasId      @Common: {FieldControl: fieldControl};
     // ***** JGHJ-71574 ***** R2.2 END *****

}

annotate zbuvcm47419Service.Items {
    Matnr     @Common: {FieldControl: MatnrFeildControl};
    MatDesc   @Common: {FieldControl: MatDescFeildControl};
    MatType   @Common: {FieldControl: MatTypeFeildControl};
    MatBrand  @Common: {FieldControl: MatBrandFeildControl};
    VFrom     @Common: {FieldControl: VFromFeildControl};
    FApprover @Common: {FieldControl: fieldControl};
    ApprDate  @Common: {FieldControl: fieldControl};
    VTo       @Common: {FieldControl: vToFieldControl};
    // Block     @Common: {FieldControl: rFeildControl};
    Status    @Common: {FieldControl: rFeildControl};
    pFStatus  @Common: {FieldControl: fieldControl};
    Comment  @Common: {FieldControl: CommentFeildControl}
};

annotate zbuvcm47419Service.Ventities {
    BPartner @Common: {FieldControl: fieldControl};
    ArchType @Common: {FieldControl: fieldControl};
    SeqNum   @Common: {FieldControl: fieldControl};
    Plant    @Common: {FieldControl: fieldControl};
}
