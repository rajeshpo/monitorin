using zbuvcm47419Service as service from '../../srv/zbuvcm47419service';
using from '../../db/zbuvcm47419schema';
using from '../field_control';
using from '../../db/zbuvcm47419attachment';


annotate service.PFC_List with @(
    Capabilities.DeleteRestrictions: {Deletable: false},
    UI.Facets                      : [
        {
            $Type : 'UI.CollectionFacet',
            Label : 'Product Flow Header Details',
            ID    : 'ProductFlowHeader',
            Facets: [
                {
                    $Type : 'UI.ReferenceFacet',
                    Label : 'Product Flow',
                    Target: '@UI.FieldGroup#ProductFlow'
                },
                {
                    $Type : 'UI.ReferenceFacet',
                    Label : 'From',
                    Target: '@UI.FieldGroup#From'
                },
                {
                    $Type : 'UI.ReferenceFacet',
                    Label : 'To',
                    Target: '@UI.FieldGroup#To'
                }
            ]
        },
        {
            $Type : 'UI.ReferenceFacet',
            Label : '{i18n>VirtualEntities}',
            ID    : 'i18nVirtualEntities',
            Target: 'Ventities/@UI.LineItem#i18nVirtualEntities',
        },
        {
            $Type : 'UI.ReferenceFacet',
            Label : '{i18n>MaterialDetails}',
            ID    : 'i18nMaterialDetails',
            Target: 'Items/@UI.LineItem#i18nMaterialDetails',
        },
        {
            $Type : 'UI.ReferenceFacet',
            Label : 'Attachments',
            ID    : 'Attachments',
            Target: 'attachments/@UI.LineItem#Attachments1',
        },
        {
            $Type : 'UI.ReferenceFacet',
            Label : 'Comments',
            ID : 'Comments',
            Target : '@UI.FieldGroup#Comments',
        },


    ],

    UI.FieldGroup #ProductFlow     : {
        Label: 'Product Flow',
        Data : [
            {
                Value: CatId,
                Label: '{i18n>ProductFlowCatalogId}'
            },
            {
                Value: ProdId,
                Label: '{i18n>ProductFlowId}',
            },
            {
                Value: PfDesc,
                Label: '{i18n>ProductFlowDescription}'
            },
            {Value: createdAt},
            {Value: createdBy},

            // ***** JGHJ-71574 ***** R2.2 START *****

            {
                $Type : 'UI.DataField',
                Value : UasId,
                Label : '{i18n>UniqueAutomationSequence}',
            },

            // ***** JGHJ-71574 ***** R2.2 END *****
        
            {
                $Type : 'UI.DataField',
                Value : SId,
                Label : '{i18n>ScenarioId}',
            },
        ]
    },
    UI.FieldGroup #From            : {
        Label: 'From',
        Data : [
            {
                Value: BpSFrom,
                Label: '{i18n>ShipfromBp}'
            },
            {
                Value: PlantSFrom,
                Label: '{i18n>ShipfromPlant}'
            },
            {
                Value: ErSFrom,
                Label: '{i18n>EconomicRegionShip1}'
            },
        ]
    },
    UI.FieldGroup #To              : {
        Label: 'To',
        Data : [
            {
                Value: BpSTo,
                Label: '{i18n>ShiptoBp}'
            },
            {
                Value: PlantSTo,
                Label: '{i18n>ShiptoPlant}'
            },
            {
                Value: ErSTo,
                Label: '{i18n>EconomicRegionShip2}'
            },
            {
                $Type : 'UI.DataField',
                Value : ArchType,
                Label : '{i18n>ShiptoArchtype}',
            },
        ]
    },

    UI.HeaderInfo                  : {
        Title         : {
            $Type: 'UI.DataField',
            Value: CatId,
            Label: '{i18n>ProductFlowCatalogId}'
        },
        TypeName      : '',
        TypeNamePlural: '',
    },
    UI.Identification              : [{
        $Type : 'UI.DataFieldForAction',
        Action: 'zbuvcm47419Service.Copy',
        Label : 'Copy',
    },
     // ***** JGHJ-71574 ***** R2.2 START *****

        {
            $Type : 'UI.DataFieldForAction',
            Action : 'zbuvcm47419Service.Simulate',
            Label : 'Simulate',
        },

     // ***** JGHJ-71574 ***** R2.2 END *****

    ],
    UI.FieldGroup #Comments : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Value : comments,
                Label : '{i18n>Comments}',
            },
        ],
    },
    
    UI.LineItem #tableMacro : [
        {
            $Type : 'UI.DataField',
            Value : BpSFrom,
        },
        {
            $Type : 'UI.DataField',
            Value : CatId,
        },
        {
            $Type : 'UI.DataField',
            Value : BpSTo,
        },
        {
            $Type : 'UI.DataField',
            Value : ArchType,
            Label : 'ArchType',
        },
        {
            $Type : 'UI.DataField',
            Value : ErSFrom,
        },
        {
            $Type : 'UI.DataField',
            Value : ErSTo,
        },
        {
            $Type : 'UI.DataField',
            Value : SId,
            Label : 'SId',
        },
        {
            $Type : 'UI.DataField',
            Value : UasId,
            Label : 'UasId',
        },
        {
            $Type : 'UI.DataField',
            Value : Items.Matnr,
        },
        {
            $Type : 'UI.DataField',
            Value : Items.MatBrand,
        },
        {
            $Type : 'UI.DataField',
            Value : Items.MatDesc,
        },
         {
            $Type : 'UI.DataField',
            Value : Items.MatType,
        },
    ],
    UI.SelectionFields #filterBarMacroDrafts : [
        BpSFrom,
        BpSTo,
        PlantSFrom,
        PlantSTo,
        // Items.ApprStatus,
        // Items.ApprDate,
        ProdId,
        createdAt,
        createdBy,
        Items.Matnr,
        Items.MatBrand,
        Items.MatDesc,
        Items.MatType,
        
    ],
);


annotate service.PFC_ListView with {
    createdBy @(

        Common.Label                   : '{i18n>CreatedBy}',
        )
};


annotate service.PFC_ListView with @(
    Capabilities.SearchRestrictions   : {Searchable: false},
    UI.SelectionFields #filterBarMacro: [
        CatId,
        MatDesc,
        MatBrand,
        Matnr,
        MatType,
        BpSFrom,
        BpSTo,
        PlantSFrom,
        PlantSTo,
        // Items.ApprStatus,
        // Items.ApprDate,
        ProdId,
        ApprStatus,
        createdAt,
        createdBy,
        Status,
        UasId,
    ],
    UI.LineItem #tableMacro           : [
        {
            $Type: 'UI.DataField',
            Value: CatId,
            Label: '{i18n>ProductFlowCatalogId}',
        },
        {
            $Type: 'UI.DataField',
            Value: BpSFrom,
            Label: '{i18n>ShipfromBp}',
        },
        {
            $Type: 'UI.DataField',
            Value: BpSTo,
            Label: '{i18n>ShiptoBp}',
        },
        {
            $Type: 'UI.DataField',
            Value: MatBrand,
            Label: '{i18n>MaterialProfitCenter1}',
        },
        {
            $Type: 'UI.DataField',
            Value: MatDesc,
            Label: '{i18n>MaterialDescription}',
        },
        {
            $Type: 'UI.DataField',
            Value: Matnr,
            Label: '{i18n>MaterialNumber}',
        },
        {
            $Type: 'UI.DataField',
            Value: PlantSFrom,
            Label: '{i18n>ShipfromPlant}',
        },
        {
            $Type: 'UI.DataField',
            Value: PlantSTo,
            Label: '{i18n>ShiptoPlant}',
        },
        {
            $Type: 'UI.DataField',
            Value: ProdId,
            Label: '{i18n>ProductFlowId1}',
        },
        {
            $Type : 'UI.DataField',
            Value : ErSFrom,
        },
        {
            $Type : 'UI.DataField',
            Value : BpSFrom,
        },
        {
            $Type: 'UI.DataField',
            Value: ErSTo,
            Label: '{i18n>15Economic}',
        },
        {
            $Type: 'UI.DataField',
            Value: ID,
            Label: 'ID',
            ![@UI.Hidden],
        },
        {
            $Type: 'UI.DataField',
            Value: matID,
            Label: 'matID',
            ![@UI.Hidden],
        },
        {
            $Type : 'UI.DataField',
            Value : ApprStatus,
            Criticality : criticality,
            
        },
        {
            $Type : 'UI.DataField',
            Value : PfDesc,
        },
        {
            $Type : 'UI.DataField',
            Value : VFrom,
            Label : '{i18n>ValidFrom}',
        },
        {
            $Type : 'UI.DataField',
            Value : VTo,
            Label : '{i18n>ValidTo1}',
        },
        {
            $Type : 'UI.DataField',
            Value : createdAt,
        },
        {
            $Type : 'UI.DataField',
            Value : createdBy,
        },
        {
            $Type : 'UI.DataField',
            Value : Status,
            Label : 'Status',
        },
        // {
        //     $Type : 'UI.DataField',
        //     Value : createdAt
        // },
        // {
        //     $Type : 'UI.DataField',
        //     Value : createdBy
        // },
    ],
);

annotate service.PfcEcoRegions with @(UI.LineItem: [
    {
        $Type: 'UI.DataField',
        Value: CountryCode,
        Label: '{i18n>CountryCode}',
    },
    {
        $Type: 'UI.DataField',
        Value: EcoRegCode,
        Label: '{i18n>EcoRegCode}',
    },
    {
        $Type: 'UI.DataField',
        Value: EcoRegName,
        Label: '{i18n>EcoRegName}',
    }
]);

annotate service.PfcWorkFlowApprover with @(UI.LineItem: [
    {
        $Type: 'UI.DataField',
        Value: EcoRCode,
        Label: '{i18n>EcoRegCode}',
    },
    {
        $Type: 'UI.DataField',
        Value: Dl_list,
        Label: '{i18n>Dl_list}',
    },
    {
        $Type: 'UI.DataField',
        Value: Btp_list,
        Label: '{i18n>EcoRegName}',
    }
]);

annotate service.PFC_ListView with {
    CatId @(

        Common.Label                   : '{i18n>ProductFlowCatalogId}',
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'Catalog_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: CatId,
                ValueListProperty: 'CatId',
            }, ],
            Label         : '{i18n>ProductFlowCatalogId}',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.PFC_ListView with {
    MatDesc @(
        Common.Label                   : '{i18n>MaterialDescription}',
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'MatDesc_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: MatDesc,
                ValueListProperty: 'MatDesc',
            }, ],
            Label         : '{i18n>MaterialDescription2}',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.PFC_ListView with {
    MatBrand @(
        Common.Label                   : '{i18n>MaterialProfitCenter1}',
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_CreateMat_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: MatBrand,
                ValueListProperty: 'ProfitCenter',
            },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'ProductName',
                }, ],
            Label         : '{i18n>MaterialBrand1}',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.PFC_ListView with {
    Matnr @(
        Common.Label                   : '{i18n>MaterialNumber}',
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_CreateMat_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: Matnr,
                ValueListProperty: 'Product',
            },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'ProductName',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'ProfitCenter',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'Plant',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'ProductType',
                }, ],
            Label         : 'Material number',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.I_BP_VH with {
    BusinessPartnerName @Common.Label:'{i18n>BusinessPartnerName}';
    EcoRegCode @Common.Label: '{i18n>EcoRegCode}'
};

annotate service.PFC_List with {  
    BpSTo @(
        Common.ValueListForValidation  : BpSTo,
        
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_BP_VH',
            Parameters    : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : BpSTo,
                    ValueListProperty : 'BusinessPartner',
                },
                {
                    $Type : 'Common.ValueListParameterInOut',
                    ValueListProperty : 'Plant',
                    LocalDataProperty : PlantSTo,
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'BusinessPartnerName',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'CountryCode',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'EcoRegCode',
                },
            ],
            Label         : '{i18n>ShiptoBp}',
        },
        Common.ValueListWithFixedValues: false,
    // Common.FieldControl : #Mandatory,
    )
};

annotate service.PFC_List with {
    PlantSFrom @(
        Common.ValueListForValidation  : PlantSFrom,
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_P_VH',
            Parameters    : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: PlantSFrom,
                    ValueListProperty: 'Plant',
                },
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    ValueListProperty: 'BusinessPartner',
                    LocalDataProperty: BpSFrom,
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'PlantName',
                },
            ],
            Label         : '{i18n>ShipfromPlant}',
        },
        Common.ValueListWithFixedValues: false,
    // Common.FieldControl : #Mandatory,
    )
};

annotate service.PFC_List with {
    PlantSTo @(
        Common.ValueListForValidation  : PlantSTo,

        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_P_VH',
            Parameters    : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: PlantSTo,
                    ValueListProperty: 'Plant',
                },
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    ValueListProperty: 'BusinessPartner',
                    LocalDataProperty: BpSTo,
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'PlantName',
                },
            ],
            Label         : 'Shp-To plant',
        },
        Common.ValueListWithFixedValues: false
    )
};

annotate service.PFC_List with {
    BpSFrom @(
        Common.ValueListForValidation  : BpSFrom,
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_BP_VH',
            Parameters    : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : BpSFrom,
                    ValueListProperty : 'BusinessPartner',
                },
                {
                    $Type : 'Common.ValueListParameterInOut',
                    ValueListProperty : 'Plant',
                    LocalDataProperty : PlantSFrom,
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'BusinessPartnerName',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'EcoRegCode',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'CountryCode',
                },
            ],
            Label         : '{i18n>ShipFromBp}',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.Items with @(UI.LineItem #i18nMaterialDetails: [
    {
        $Type: 'UI.DataField',
        Value: Matnr,
        Label: '{i18n>MaterialNumber}',
    },
    {
        $Type: 'UI.DataField',
        Value: MatBrand,
        Label: '{i18n>MaterialProfitCenter1}',

    },
    {
        $Type: 'UI.DataField',
        Value: VFrom,
        Label: '{i18n>ValidFrom}',
    },
    {
        $Type: 'UI.DataField',
        Value: VTo,
        Label: '{i18n>ValidTo}',
    },
    // {
    //     $Type: 'UI.DataField',
    //     Value: Block,
    //     Label: '{i18n>Block}',
    // },
    {
        $Type: 'UI.DataField',
        Value: MatType,
        Label: '{i18n>MaterialType}',
    },
    {
        $Type: 'UI.DataField',
        Value: MatDesc,
        Label: '{i18n>MaterialDescription}',
    },
    {
        $Type: 'UI.DataField',
        Value: Status,
        Label: '{i18n>Status}',
    },
    {
        $Type: 'UI.DataField',
        Value: ApprDate,
        Label: '{i18n>ProductFlowApprovalDate}',
    },
    {
        $Type      : 'UI.DataField',
        Value      : ApprStatus,
        Label      : '{i18n>ProductFlowStatus}',
        Criticality: criticality,
    },
    {
        $Type: 'UI.DataField',
        Value: FApprover,
        Label: '{i18n>ProductFlowApprover}',
    },
    {
        $Type : 'UI.DataField',
        Value : pFStatus,
        Label : '{i18n>ProductFlowStatusComment}',
    },
     {
        $Type : 'UI.DataField',
        Value : Comment,
        Label : '{i18n>ApComments}',
    },
    
]);

annotate service.Ventities with @(
    // Capabilities.DeleteRestrictions : {Deletable: false},
    // Capabilities.InsertRestrictions : {Insertable: false},
    UI.LineItem #i18nVirtualEntities: [
        {
            $Type: 'UI.DataField',
            Value: ArchType,
            Label: 'ArchType'
        },
        {
            $Type: 'UI.DataField',
            Value: BPartner,
            Label: '{i18n>Vebusinesspartner1}',
        },
        {
            $Type: 'UI.DataField',
            Value: Plant,
            Label: '{i18n>Veplant1}',
        },
        {
            $Type: 'UI.DataField',
            Value: LegalEntity,
            Label: '{i18n>LegalEntity}',
        },
    ]
);


annotate service.PFC_ListView with {
    BpSTo @(
        Common.Label                   : '{i18n>ShiptoBp}',
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_BP_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: BpSTo,
                ValueListProperty: 'BusinessPartner',
            },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'BusinessPartnerName',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'Plant',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'CountryCode',
                }, ],
            Label         : '{i18n>ShiptoBp}',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.PFC_ListView with {
    PlantSFrom @(
        Common.Label                   : '{i18n>ShipfromPlant}',
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_P_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: PlantSFrom,
                ValueListProperty: 'Plant',
            },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'PlantName',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'BusinessPartner',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'CountryCode',
                }, ],
            Label         : '{i18n>ShipfromPlant}',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.PFC_ListView with {
    PlantSTo @(
        Common.Label                   : '{i18n>ShiptoPlant}',
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_P_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: PlantSTo,
                ValueListProperty: 'Plant',
            },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'PlantName',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'BusinessPartner',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'CountryCode',
                }, ],
            Label         : '{i18n>ShiptoPlant1}',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.Items with {
    ApprStatus @(
        Common.Label                   : '{i18n>ProductFlowApprovalStatus}',
        Common.FieldControl            : #ReadOnly,
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_AprStatus_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: ApprStatus,
                ValueListProperty: 'Desc',
            }, ],
            Label         : '{i18n>ProductFlowApprovalStatus2}',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.Items with {
    ApprDate @(
        Common.Label       : '{i18n>ProductFlowApprovalDate}',
        Common.FieldControl: #ReadOnly,
    )
};

annotate service.I_ER_VH with {
    EcoRegCode @Common.Label:'{i18n>EcoRegCode}';
    EcoRegName @Common.Label: '{i18n>EcoRegName}';
    CountryCode @Common.Label: '{i18n>CountryCode}'
};

annotate service.PFC_List with {
    ErSFrom @(
        Common.ValueListForValidation  : ErSFrom,
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_ER_VH',
            Parameters    : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : ErSFrom,
                    ValueListProperty : 'EcoRegCode',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'EcoRegName',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'CountryCode',
                },
            ],
            Label         : '{i18n>EconomicRegionShip4}',
        },
        Common.ValueListWithFixedValues: false
    )
};

annotate service.PFC_List with {
    ErSTo @(
        Common.ValueListForValidation  : ErSTo,
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_ER_VH',
            Parameters    : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : ErSTo,
                    ValueListProperty : 'EcoRegCode',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'EcoRegName',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'CountryCode',
                },
            ],
            Label         : '{i18n>EconomicRegionShip5}',
        },
        Common.ValueListWithFixedValues: false
    )
};

annotate service.Items with {
    FApprover @Common.FieldControl: #ReadOnly
};




annotate service.Ventities with {
    BPartner @(
        Common.ValueListForValidation  : BPartner,
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_BP_VH',
            Parameters    : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: BPartner,
                    ValueListProperty: 'BusinessPartner',
                },
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    ValueListProperty: 'Plant',
                    LocalDataProperty: Plant,
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'BusinessPartnerName',
                },
            ],
            Label         : '{i18n>Vebusinesspartner1}',
        },
        Common.ValueListWithFixedValues: false
    )
};

annotate service.Ventities with {
    Plant @(
        Common.ValueListForValidation  : Plant,
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_P_VH',
            Parameters    : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: Plant,
                    ValueListProperty: 'Plant',
                },
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    ValueListProperty: 'BusinessPartner',
                    LocalDataProperty: BPartner,
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'PlantName',
                },
            ],
            Label         : '{i18n>Veplant}',
        },
        Common.ValueListWithFixedValues: false
    )
};

annotate service.Ventities with {
    ArchType @(
        Common.ValueListForValidation  : ArchType,
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_AR_VH',
            Parameters    : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: ArchType,
                    ValueListProperty: 'ArchType',
                }
               
            ],
            Label         : '{i18n>ArchType}',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.PFC_ListView with {
    BpSFrom @(
        Common.Label                   : '{i18n>ShipFromBp}',
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_BP_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: BpSFrom,
                ValueListProperty: 'BusinessPartner',
            },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'BusinessPartnerName',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'Plant',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'CountryCode',
                }, ],
            Label         : '{i18n>ShipFromBp}',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.PFC_ListView with {
    ProdId @(
        Common.Label                   : '{i18n>ProductFlowId1}',
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'ProdId_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: ProdId,
                ValueListProperty: 'ProdId',
            }, ],
            Label         : '{i18n>ProductFlowId1}',
        },
        Common.ValueListWithFixedValues: false,
    )
};


annotate service.ExcelUpload with @(
    Capabilities.DeleteRestrictions:{Deletable:false},
    UI.Facets        : [{
        $Type : 'UI.ReferenceFacet',
        Label : 'Upload Attachments',
        ID    : 'UploadAttachments',
        Target: 'attachments/@UI.LineItem#UploadAttachments',
    }, ],
    UI.HeaderInfo    : {
        TypeName      : 'Mass Upload',
        TypeNamePlural: 'Mass Upload',
    },
    UI.Identification: [{
        $Type        : 'UI.DataFieldForAction',
        Action       : 'zbuvcm47419Service.CreateProductFlowfromExcel',
        Label        : '{i18n>LoadProductFlow}',
        ![@UI.Hidden]: isValidated,
    }, ],
);

annotate service.ExcelUpload.attachments with @(UI.LineItem #UploadAttachments: [
    {
        $Type            : 'UI.DataField',
        Value            : note,
        Label : '{i18n>Status}',
        ![@UI.Importance]: #High,
    },
    {
        $Type: 'UI.DataField',
        Value: filename,
    },
    {
        $Type: 'UI.DataField',
        Value: content,
    },
]);

annotate service.ExcelUpload.attachments with {
    note  @UI.MultiLineText: true  @Common.FieldControl: #ReadOnly
};


annotate service.Items with {
    Matnr @(
        Common.ValueListForValidation  : Matnr,
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_CreateMat_VH',
            Parameters    : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: Matnr,
                    ValueListProperty: 'Product',
                },
                {
                    $Type            : 'Common.ValueListParameterOut',
                    ValueListProperty: 'ProductName',
                    LocalDataProperty: MatDesc,
                },
                {
                    $Type            : 'Common.ValueListParameterOut',
                    ValueListProperty: 'ProfitCenter',
                    LocalDataProperty: MatBrand,
                },
                {
                    $Type            : 'Common.ValueListParameterOut',
                    ValueListProperty: 'ProductType',
                    LocalDataProperty: MatType,
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'Plant',
                },
            ],
            Label         : 'Materials',
        },
        Common.ValueListWithFixedValues: false
    )
};

annotate service.PFC_List.attachments with @(
    UI.LineItem #Attachments : [
        {
            $Type: 'UI.DataField',
            Value: filename,
        },
        {
            $Type: 'UI.DataField',
            Value: content,
        },
        {
            $Type: 'UI.DataField',
            Value: createdAt,
        },
        {
            $Type: 'UI.DataField',
            Value: createdBy,
        },
        {
            $Type: 'UI.DataField',
            Value: note,
        },
    ],
    UI.LineItem #Attachments1: [
        {
            $Type: 'UI.DataField',
            Value: filename,
        },
        {
            $Type: 'UI.DataField',
            Value: content,
        },
        {
            $Type: 'UI.DataField',
            Value: modifiedBy,
        },
        {
            $Type: 'UI.DataField',
            Value: note,
        },
    ],
);

annotate service.PFC_ListView with {
    ID @Common.Label: 'ID'
};

annotate service.PFC_ListView with {
    matID @Common.Label: 'matID'
};

annotate service.PFC_List with {
    comments @UI.MultiLineText: true
};

annotate service.PFC_List with {
    ArchType @(
        Common.ValueListForValidation  : ArchType,
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_AR_VH',
            Parameters    : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: ArchType,
                    ValueListProperty: 'ArchType',
                }
            ],
            Label         : 'ArchType',
        },
        Common.ValueListWithFixedValues: false,
    )
};
annotate service.Items with {
    pFStatus @Common.FieldControl : #ReadOnly
};

annotate service.Changelog with @(
    UI.LineItem #i18nChangeLog : [
        {
            $Type : 'UI.DataField',
            Value : Matnr,
            Label : 'Matnr',
        },
        {
            $Type : 'UI.DataField',
            Value : MatBrand,
            Label : 'MatBrand',
        },
        {
            $Type : 'UI.DataField',
            Value : PrevVTo,
            Label : 'PrevVTo',
        },
        {
            $Type : 'UI.DataField',
            Value : CurrVTo,
            Label : 'CurrVTo',
        },
        {
            $Type : 'UI.DataField',
            Value : modifiedAt,
        },
        {
            $Type : 'UI.DataField',
            Value : modifiedBy,
        },
    ]
);

annotate service.Items with {
    Status @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'I_Block_Status_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : Status,
                    ValueListProperty : 'Status',
                },
            ],
            Label : 'Status',
        },
        Common.ValueListWithFixedValues : true,
)};



annotate service.PFC_ListView with {
    ApprStatus @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'I_MatStatus_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : ApprStatus,
                    ValueListProperty : 'Desc',
                },
            ],
            Label : '{i18n>ProductFlowApprovalStatus2}',
        },
        Common.ValueListWithFixedValues : true,
)};

annotate service.PFC_ListView with {
    Status @(
        Common.Label : '{i18n>Status}',
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'I_Block_Status_VH1',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : Status,
                    ValueListProperty : 'Status',
                },
            ],
            Label : '{i18n>Status}',
        },
        Common.ValueListWithFixedValues : true,
    )
};


     // ***** JGHJ-71574 ***** R2.2 START *****

annotate service.PFC_List with @(
Capabilities: {
   NavigationRestrictions : {
       $Type : 'Capabilities.NavigationRestrictionsType',
       RestrictedProperties : [
           {
               $Type : 'Capabilities.NavigationPropertyRestriction',
               NavigationProperty : DraftAdministrativeData,
               FilterRestrictions : {
                   $Type : 'Capabilities.FilterRestrictionsType',
                   Filterable : false,
               },
           },
       ],
   },
});

     // ***** JGHJ-71574 ***** R2.2 END *****



annotate service.PFC_ListView with {
    UasId @(
        Common.Label : '{i18n>UasId}',
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'UasId_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : UasId,
                    ValueListProperty : 'UasId',
                },
            ],
            Label : '{i18n>UasId}',
        },
        Common.ValueListWithFixedValues : false,
    )
};

annotate service.PFC_ListView with {
    MatType @(
        Common.Label : '{i18n>MaterialType}',
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'I_MatType_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : ProductType,
                    ValueListProperty : 'ProductType',
                },
            ],
            Label : '{i18n>MaterialType}',
        },
        Common.ValueListWithFixedValues : false,
    )
};

annotate service.Items with {
    MatBrand @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'I_CreateMat_VH1',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : MatBrand,
                    ValueListProperty : 'ProfitCenter',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'ProfitCenterDescription',
                },
            ],
            Label : '{i18n>MaterialBrand2}',
        },
        Common.ValueListWithFixedValues : false,
)};

annotate service.Items with {
    MatType @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'I_MatType_VH1',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : MatType,
                    ValueListProperty : 'MaterialType',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'MaterialDescription',
                },
            ],
            Label : '{i18n>MaterialType}',
        },
        Common.ValueListWithFixedValues : false,
)};