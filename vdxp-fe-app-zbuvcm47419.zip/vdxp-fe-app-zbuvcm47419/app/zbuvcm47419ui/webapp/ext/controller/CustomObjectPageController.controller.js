sap.ui.define(['sap/ui/core/mvc/ControllerExtension', 'sap/ui/model/json/JSONModel', "sap/m/Text",
  "sap/m/Button",
  "sap/m/MessageToast",
  "sap/m/MessageBox",
  "sap/m/library",
  "sap/fe/core/library"
],

  /**
        * @param {typeof sap.ui.core.mvc.Controller} Controller
        * @class
        * @param {object} MessageToast - typeof sap.m.MessageToast
        * @param {object} MessageBox - typeof sap.m.MessageBox
        * @param {object} library - typeof sap.m.library 
        * @param {object} library - typeof sap.fe.core.library
        * @public
        * @since v0.0.1
        * @name jnj.com.zbuvcm47419ui.controller.CustomObjectPageController
      */

  function (ControllerExtension, JSONModel, Text, Button, MessageToast, MessageBox, library, coreLibrary) {
    'use strict';

    return ControllerExtension.extend('zbuvcm47419ui.ext.controller.CustomObjectPageController', {
      // this section allows to extend lifecycle hooks or hooks provided by Fiori elements

      override: {

        /**
                   * Attaching _onObjectMatched for setting Process Flow dynamic data and hide or show Process Flow
                   * @public
                   
              */

        onInit: async function () {
          const oRouter = this.base.getAppComponent().getRouter();
          oRouter.getRoute('PFC_ListObjectPage').attachPatternMatched(this._onObjectMatched, this);
          // ***** JGHJ-71574 ***** R2.2 START *****
          oRouter.getRoute('PFC_ListDraftObjectPage').attachPatternMatched(this._onObjectMatched, this);
          // ***** JGHJ-71574 ***** R2.2 END *****

          this._attachPressOnHover()
          const oHandler = this.extensionAPI.getExtensionController("zbuvcm47419ui.ext.fragment.ProcessFlow");
          if (oHandler && oHandler.setView) {
            oHandler.setView(this.getView());
          }

        },

        editFlow: {
          // onAfterEdit: function (oEvent) {
          //   const sPath = oEvent?.context?.sPath || "";
          //   const bIsDraft = sPath.includes("IsActiveEntity=false"); // check if you're in draft mode

          //   const oAddBtn = sap.ui.getCore().byId(
          //     "zbuvcm47419ui::PFC_ListObjectPage--fe::table::Ventities::LineItem::i18nVirtualEntities::StandardAction::Create"
          //   );
          //   const oDeleteBtn = sap.ui.getCore().byId(
          //     "zbuvcm47419ui::PFC_ListObjectPage--fe::table::Ventities::LineItem::i18nVirtualEntities::StandardAction::Delete"
          //   );

          //   if (bIsDraft) {
          //     oAddBtn?.setEnabled(false);
          //     oDeleteBtn?.setEnabled(false);
          //     // create?.setEnabled(false)



          //     oAddBtn?.addStyleClass("transparentButton");
          //     oDeleteBtn?.addStyleClass("transparentButton");
          //     // create?.addStyleClass("transparentButton")

          //   } else {
          //     oAddBtn?.setEnabled(true);
          //     oDeleteBtn?.setEnabled(true);
          //     // create?.setEnabled(false)

          //     // create?.addStyleClass("transparentButton")

          //     oAddBtn?.removeStyleClass("transparentButton");
          //     oDeleteBtn?.removeStyleClass("transparentButton");
          //   }
          // },
          onBeforeSave: function (mParameters) {
            //asynchronous access to several property values. Non cached values are requested from the backend
            return mParameters?.context.requestProperty(["ID"]).then((result) => {
              return result[0] ? this.openDialog(result[1], true) : null;
            });
          },
          onAfterSave: function (mParameters) {
            let ProductFlowSaved = this.getView().getModel("i18n").getResourceBundle().getText("productFlowSaved")
            let savedSuccessfully = this.getView().getModel("i18n").getResourceBundle().getText("savedSuccessfully")
            //
            mParameters.context.refresh();
            //asynchronous access to complete data the context points to
            mParameters.context.requestObject().then((contextData) => {
              return MessageBox.success(
                ProductFlowSaved + " " + contextData.CatId + " " + savedSuccessfully
              );
            });
            const oExtensionAPI = this.base.getExtensionAPI();
            if (!oExtensionAPI) {
              console.error("ExtensionAPI not available");
              return;
            }
          // ***** JGHJ-71574 ***** R2.2 START *****
            const copy = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::DataFieldForAction::zbuvcm47419Service.Copy")
            copy.setVisible(true)
            oExtensionAPI.navigateToTarget("PFC_ListViewMain");
          // ***** JGHJ-71574 ***** R2.2 END *****

          },

          onBeforeCreate: function (mParameters) {

            return new Promise(function (resolve, reject) {
              if (mParameters.contextPath === 'Ventities' || mParameters.contextPath === 'Items' || mParameters.contextPath === 'Attachments') {
                resolve(null)
              }
            });
          },
          // ***** JGHJ-71574 ***** R2.2 START *****
          onAfterActionExecution: async function (mParameters) {

            if (mParameters.includes("Simulate")) {
              const oExtensionAPI = this.base.getExtensionAPI();
              if (!oExtensionAPI) {
                console.error("ExtensionAPI not available");
                return;
              }


              const oContext = oExtensionAPI.getBindingContext();
              const oObject = await oContext.requestObject();

              const sDraftId =
                oObject.ID;

              const oModel = this.base.getView().getModel();

              const oBinding = oModel.bindContext("/getProcessFlowData(...)");
              oBinding.setParameter("ID", sDraftId);
              oBinding.setParameter("DRAFT", true);

              await oBinding.invoke();

              const response = oBinding.getBoundContext().getObject().value;

              console.log(response)
              response.Ventities.sort((a, b) => Number(a.SeqNum) - Number(b.SeqNum));
   
              let draft="true"
              const create = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::FooterBar::StandardAction::Save")

              create.setVisible(true)

              this._loadProcessFlow(response,draft)
            }

          },
          onAfterDiscard: function (mParameters) {
            const copy = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::DataFieldForAction::zbuvcm47419Service.Copy")
            copy.setVisible(true)
          }

          // ***** JGHJ-71574 ***** R2.2 END *****

        }

      },

  
      // _onObjectMatched: async function (oEvent) {

      //   this._attachPressOnHover()
      //   let dbCall = "/getProcessFlowData(...)"

      //   // ***** JGHJ-71574 ***** R2.2 START *****
      //   const simulate = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::DataFieldForAction::zbuvcm47419Service.Simulate")
      //     // ***** JGHJ-71574 ***** R2.2 END *****

      //   const create = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::FooterBar::StandardAction::Save")
      //   const copy = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::DataFieldForAction::zbuvcm47419Service.Copy")
      //   sap.ui.getCore()
      //     .byId("zbuvcm47419ui::PFC_ListObjectPage--fe::table::Items::LineItem::i18nMaterialDetails::StandardAction::Create")
      //     .setText("Add");

      //   sap.ui.getCore()
      //     .byId("zbuvcm47419ui::PFC_ListObjectPage--fe::table::Ventities::LineItem::i18nVirtualEntities::StandardAction::Create")
      //     .setText("Add");

      //     const oAddBtn = sap.ui.getCore().byId(
      //       "zbuvcm47419ui::PFC_ListObjectPage--fe::table::Ventities::LineItem::i18nVirtualEntities::StandardAction::Create"
      //     );
      //      const oDeleteBtn = sap.ui.getCore().byId(
      //       "zbuvcm47419ui::PFC_ListObjectPage--fe::table::Ventities::LineItem::i18nVirtualEntities::StandardAction::Delete"
      //     );

      //     const matDeletBtn = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::table::Items::LineItem::i18nMaterialDetails::StandardAction::Delete")

      //   if (oAddBtn) {
      //     oAddBtn.setVisible(false)
      //   }
      //   if (oDeleteBtn) {
      //     oDeleteBtn.setVisible(false)
      //   }

      //   if (matDeletBtn) {
      //     matDeletBtn.setVisible(false)
      //   }

      //   const params = oEvent.getParameter("arguments");
      //   const draft =
      //     params.PFC_ListKey?.split(",")[1]?.split("=")[1] === "false";
      //   let catId = params.PFC_ListKey?.split(",")[0].split("=")[1];

      //   let data = { text: "", formVisible: false };
      //   let dialogModel = new JSONModel(data);

      //   this.getView().setModel(dialogModel, "dialog");

      //   const odataModel = this.getView().getModel();

      //   let oModelBindingContext = odataModel.bindContext(dbCall);
      //     // ***** JGHJ-71574 ***** R2.2 START *****
      //   oModelBindingContext.setParameter("ID", catId);
      //   oModelBindingContext.setParameter("DRAFT", draft);

      //   await oModelBindingContext.invoke();

      //   const response = oModelBindingContext.getBoundContext().getObject().value;
      //   if (response.CatId === 'New Product Flow' && draft) {
          
      //     if(oDeleteBtn){
      //       oDeleteBtn.setVisible(true)
      //     }
      //    if(matDeletBtn){
      //      matDeletBtn.setVisible(true)
      //    }
      //     if(oAddBtn){
      //       oAddBtn.setVisible(true)
      //     }

      //   } else if (response.CatId !== 'New Product Flow' && draft) {
      //     if(oDeleteBtn){
      //       oDeleteBtn.setVisible(false)
      //     }
      //    if(matDeletBtn){
      //      matDeletBtn.setVisible(false)
      //    }
      //     if(oAddBtn){
      //       oAddBtn.setVisible(false)
      //     }
      //   }
      //   else {
      //   if(matDeletBtn){
      //      matDeletBtn.setVisible(false)
      //    }

      //      if(oDeleteBtn){
      //       oDeleteBtn.setVisible(false)
      //     }
        
      //     if(oAddBtn){
      //       oAddBtn.setVisible(false)
      //     }
      //   }


      //   if ((response.simulation === "false"||response.simulation === null) && draft) {
      //     copy.setVisible(false)
      //     create.setVisible(false)
      //   }
      //   if (!draft) {
      //     simulate.setVisible(false)
      //   } else {
      //     simulate.setVisible(true)
      //   }

      //   if (response.simulation === "true" && draft) {
      //     copy.setVisible(false)
      //     create.setVisible(true)

      //   }

      //   if (response?.Ventities?.length > 0) {
      //     const add = this.base.byId(
      //       "zbuvcm47419ui::PFC_ListObjectPage--fe::table::Ventities::LineItem::i18nVirtualEntities::StandardAction::Create"
      //     );
      //     add.setEnabled(false);
      //   }

      //   this._loadProcessFlow(response,draft)
      //   // ***** JGHJ-71574 ***** R2.2 END *****

      // },

      _onObjectMatched: async function (oEvent) {
 
        this._attachPressOnHover()
        let dbCall = "/getProcessFlowData(...)"
 
        // ***** JGHJ-71574 ***** R2.2 START *****
        const simulate = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::DataFieldForAction::zbuvcm47419Service.Simulate")
          // ***** JGHJ-71574 ***** R2.2 END *****
 
        const create = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::FooterBar::StandardAction::Save")
        const copy = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::DataFieldForAction::zbuvcm47419Service.Copy")
        sap.ui.getCore()
          .byId("zbuvcm47419ui::PFC_ListObjectPage--fe::table::Items::LineItem::i18nMaterialDetails::StandardAction::Create")
          .setText("Add");
 
        sap.ui.getCore()
          .byId("zbuvcm47419ui::PFC_ListObjectPage--fe::table::Ventities::LineItem::i18nVirtualEntities::StandardAction::Create")
          .setText("Add");
 
          const oAddBtn = sap.ui.getCore().byId(
            "zbuvcm47419ui::PFC_ListObjectPage--fe::table::Ventities::LineItem::i18nVirtualEntities::StandardAction::Create"
          );
           const oDeleteBtn = sap.ui.getCore().byId(
            "zbuvcm47419ui::PFC_ListObjectPage--fe::table::Ventities::LineItem::i18nVirtualEntities::StandardAction::Delete"
          );
 
          const matDeletBtn = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::table::Items::LineItem::i18nMaterialDetails::StandardAction::Delete")

 
        const params = oEvent.getParameter("arguments");
        const draft =
          params.PFC_ListKey?.split(",")[1]?.split("=")[1] === "false";
        let catId = params.PFC_ListKey?.split(",")[0].split("=")[1];
 
        let data = { text: "", formVisible: false };
        let dialogModel = new JSONModel(data);
 
        this.getView().setModel(dialogModel, "dialog");
 
        const odataModel = this.getView().getModel();
 
        let oModelBindingContext = odataModel.bindContext(dbCall);
          // ***** JGHJ-71574 ***** R2.2 START *****
        oModelBindingContext.setParameter("ID", catId);
        oModelBindingContext.setParameter("DRAFT", draft);
 
       
        try {
         await oModelBindingContext.invoke();
         const response = oModelBindingContext.getBoundContext().getObject().value;
         if (response.CatId === 'New Product Flow' && draft) {
           
          setTimeout(()=>{
             if(oDeleteBtn){
             oDeleteBtn.setVisible(true)
           }
          if(matDeletBtn){
            matDeletBtn.setVisible(true)
          }
           if(oAddBtn){
             oAddBtn.setVisible(true)
           }
          },400)
 
         }
         else if (response.CatId !== 'New Product Flow' && draft) {
           if ((response.Items.length === response.Items.filter(a => a.ApprStatus === "Reworked" && a.Status === "New").length && draft)) {
             setTimeout(() => {
               if (oDeleteBtn) {
                 oDeleteBtn.setVisible(false)
               }
               if (matDeletBtn) {
                 matDeletBtn.setVisible(false)
               }
               if (oAddBtn) {
                 oAddBtn.setVisible(true)
               }
             }, 400);
           } else {
             setTimeout(() => {
               if (oDeleteBtn) {
                 oDeleteBtn.setVisible(false)
               }
               if (matDeletBtn) {
                 matDeletBtn.setVisible(false)
               }
               if (oAddBtn) {
                 oAddBtn.setVisible(false)
               }
             }, 400);
           }

         }
         else {
           setTimeout(() => {
             if (matDeletBtn) {
               matDeletBtn.setVisible(false)
             }

             if (oDeleteBtn) {
               oDeleteBtn.setVisible(false)
             }

             if (oAddBtn) {
               oAddBtn.setVisible(false)
             }
           }, 400);
         }
 
 
         if ((response.simulation === "false"||response.simulation === null) && draft) {
          setTimeout(()=>{
             copy.setVisible(false)
           create.setVisible(true)
          },200)
         }
         if (!draft) {
          setTimeout(()=>{
             simulate.setVisible(false)
          },200)
         } else {
          setTimeout(()=>{
             simulate.setVisible(true)
          },200)
         }
 
         if (response.simulation === "true" && draft) {
           setTimeout(()=>{
            copy.setVisible(false)
           create.setVisible(true)
           },200)
 
         }
 
        //  if (response?.Ventities?.length > 0) {
        //    const add = this.base.byId(
        //      "zbuvcm47419ui::PFC_ListObjectPage--fe::table::Ventities::LineItem::i18nVirtualEntities::StandardAction::Create"
        //    );
        //    add.setEnabled(false);
        //  }
 
         this._loadProcessFlow(response,draft)
       } catch (error) {
         setTimeout(() => {
           if (matDeletBtn) {
             matDeletBtn.setVisible(false)
           }
 
           if (oDeleteBtn) {
             oDeleteBtn.setVisible(false)
           }
 
           if (oAddBtn) {
             oAddBtn.setVisible(false)
           }
         }, 200);
       }
        // ***** JGHJ-71574 ***** R2.2 END *****
 
      },
 
     // ***** JGHJ-71574 ***** R2.2 START *****

  help: function () {
        var oView = this.base.getView();
        
        let i18n = this.getView().getModel("i18n").getResourceBundle();
        let ProductFlowID = i18n.getText("ProductFlowID");
        let ShipFromBP=i18n.getText("ShipFromBP")
        let ShipFromPlant=i18n.getText("ShipFromPlant")
        let ShipToBP=i18n.getText("ShipToBP")
        let ShipToPlant=i18n.getText("ShipToPlant")
        let Archetype=i18n.getText("Archetype")
        let ArchetypeShipTo=i18n.getText("ArchetypeShipTo")
        let EconomicRegionShipFrom=i18n.getText("EconomicRegionShipFrom")
        let EconomicRegionShipTo=i18n.getText("EconomicRegionShipTo")
        let MaterialNumber=i18n.getText("MaterialNumber")
        let MaterialProfitCenter=i18n.getText("MaterialProfitCenter")
        let MaterialType=i18n.getText("MaterialType")
        let ProductFlowStatus=i18n.getText("ProductFlowStatus")
        let VirtualEntityBP=i18n.getText("VirtualEntityBP")
        let VirtualEntityPlant=i18n.getText("VirtualEntityPlant")
        let Overview= i18n.getText("Overview")
        let Mass_upload= i18n.getText("Mass_upload")

        //help feilds

        // -------- Help Texts --------
        let ProductFlowID_Help         = i18n.getText("ProductFlowID_Help");
        let ShipFromBP_Help            = i18n.getText("ShipFromBP_Help");
        let ShipFromPlant_Help         = i18n.getText("ShipFromPlant_Help");
        let ShipToBP_Help              = i18n.getText("ShipToBP_Help");
        let ShipToPlant_Help           = i18n.getText("ShipToPlant_Help");
        let Archetype_Help             = i18n.getText("Archetype_Help");
        let ArchetypeShipTo_Help       = i18n.getText("ArchetypeShipTo_Help");
        let EconomicRegionShipFrom_Help= i18n.getText("EconomicRegionShipFrom_Help");
        let EconomicRegionShipTo_Help  = i18n.getText("EconomicRegionShipTo_Help");
        let MaterialNumber_Help        = i18n.getText("MaterialNumber_Help");
        let MaterialProfitCenter_Help  = i18n.getText("MaterialProfitCenter_Help");
        let MaterialType_Help          = i18n.getText("MaterialType_Help");
        let ProductFlowStatus_Help     = i18n.getText("ProductFlowStatus_Help");
        let VirtualEntityBP_Help       = i18n.getText("VirtualEntityBP_Help");
        let VirtualEntityPlant_Help    = i18n.getText("VirtualEntityPlant_Help");
        let Overview_Help=i18n.getText("Overview_Help")
        let Mass_upload_Help=i18n.getText("Mass_upload_Help")

        if (!this._oDetailsDialog) {
          sap.ui.core.Fragment.load({
            id: oView.getId(),
            name: "zbuvcm47419ui.ext.fragment.Help",
            controller: this
          }).then(function (oDialog) {
            this._oDetailsDialog = oDialog;
            oView.addDependent(oDialog);

            var oModel = new sap.ui.model.json.JSONModel({
              details: [
                {
                  srNo: 1,
                  fieldName: i18n.getText(ProductFlowID),
                  help: i18n.getText(ProductFlowID_Help)
                },
                {
                  srNo: 2,
                  fieldName: i18n.getText(ShipFromBP),
                  help: i18n.getText(ShipFromBP_Help)
                },
                {
                  srNo: 3,
                  fieldName: i18n.getText(ShipFromPlant),
                  help: i18n.getText(ShipFromPlant_Help)
                },
                {
                  srNo: 4,
                  fieldName: i18n.getText(ShipToBP),
                  help: i18n.getText(ShipToBP_Help)
                },
                {
                  srNo: 5,
                  fieldName: i18n.getText(ShipToPlant),
                  help: i18n.getText(ShipToPlant_Help)
                },
                {
                  srNo: 6,
                  fieldName: i18n.getText(Archetype),
                  help: i18n.getText(Archetype_Help)
                },
                {
                  srNo: 7,
                  fieldName: i18n.getText(ArchetypeShipTo),
                  help: i18n.getText(ArchetypeShipTo_Help)
                },
                {
                  srNo: 8,
                  fieldName: i18n.getText(EconomicRegionShipFrom),
                  help: i18n.getText(EconomicRegionShipFrom_Help)
                },
                {
                  srNo: 9,
                  fieldName: i18n.getText(EconomicRegionShipTo),
                  help: i18n.getText(EconomicRegionShipTo_Help)
                },
                {
                  srNo: 10,
                  fieldName: i18n.getText(MaterialNumber),
                  help: i18n.getText(MaterialNumber_Help)
                },
                {
                  srNo: 11,
                  fieldName: i18n.getText(MaterialProfitCenter),
                  help: i18n.getText(MaterialProfitCenter_Help)
                },
                {
                  srNo: 12,
                  fieldName: i18n.getText(MaterialType),
                  help: i18n.getText(MaterialType_Help)
                },
                {
                  srNo: 13,
                  fieldName: i18n.getText(ProductFlowStatus),
                  help: i18n.getText(ProductFlowStatus_Help)
                },
                {
                  srNo: 14,
                  fieldName: i18n.getText(VirtualEntityBP),
                  help: i18n.getText(VirtualEntityBP_Help)
                },
                {
                  srNo: 15,
                  fieldName: i18n.getText(VirtualEntityPlant),
                  help: i18n.getText(VirtualEntityPlant_Help)
                },
                {
                  srNo: 16,
                  fieldName: i18n.getText(Overview),
                  help: i18n.getText(Overview_Help)
                },
                {
                  srNo: 17,
                  fieldName: i18n.getText(Mass_upload),
                  help: i18n.getText(Mass_upload_Help)
                }

              ]

            });

            oDialog.setModel(oModel);
            oDialog.open();
          }.bind(this));
        } else {
          this._oDetailsDialog.open();
        }
      },
      onCloseDetailsDialog: function () {
        this._oDetailsDialog.close();
      },

      _attachPressOnHover: function () {
        // Replace with your actual Button ID
        // var oButton = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomAction::help");

        // if (!oButton || oButton._hoverPressAttached) {
        //   return;
        // }
        // oButton._hoverPressAttached = true;

        // // Use jQuery to attach hover listener
        // // 
        // oButton.attachBrowserEvent("mouseenter", function () {
        //   oButton.firePress(); // programmatic press
        // });

        var oButton = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomAction::help");

        if (!oButton || oButton._clickAttached) {
          return;
        }
        oButton._clickAttached = true;

        // Attach to the UI5 'press' event and open help
        oButton.attachPress(function (oEvent) {
          // call your help handler here
          if (typeof openHelp === "function") {
            openHelp(oEvent);
          } 
        });

      },

      _loadProcessFlow: async function (response, draft) {

        let i18n = this.getView().getModel("i18n").getResourceBundle();
        let shipFromBP = i18n.getText("shipFromBP");
        let virtualEntity = i18n.getText("virtualEntity");
        let shipToBP = i18n.getText("shipToBP");
        let failedLoadProcessSteps=i18n.getText('failedLoadProcessSteps')

        // Defect JGHJ-94334
        const shipFromTitle = response.BpSFrom
          ? `${response.BpSFrom}${response.BpSFromName ? ` (${response.BpSFromName})` : ""}`
          : response.PlantSFrom
            ? `${response.PlantSFrom}${response.PlantSFromName ? ` (${response.PlantSFromName})` : ""}`
            : response.ErSFrom
              ? `${response.ErSFrom}${response.ErSFromName ? ` (${response.ErSFromName})` : ""}`
              : "";

        // Defect JGHJ-94334
        const shipToTitle = response.BpSTo
          ? `${response.BpSTo}${response.BpSToName ? ` (${response.BpSToName})` : ""}`
          : response.PlantSTo
            ? `${response.PlantSTo}${response.PlantSToName ? ` (${response.PlantSToName})` : ""}`
            : response.ErSTo
              ? `${response.ErSTo}${response.ErSToName ? ` (${response.ErSToName})` : ""}`
              : "";

        response.Ventities.sort((a, b) => Number(a.SeqNum) - Number(b.SeqNum));

        // === Dynamic lanes ===
        const lanes = [];

        // Ship From BP lane
        lanes.push({
          id: "0",
          icon: "sap-icon://factory",
          label: shipFromBP,
          position: 0
        });

        // VEntities lanes
        response.Ventities.forEach((ve, idx) => {
          lanes.push({
            id: (idx + 1).toString(),
            icon: "sap-icon://building",
            label: `${virtualEntity} ${idx + 1}`,
            position: idx + 1
          });
        });

        // Ship To BP lane
        lanes.push({
          id: (response.Ventities.length + 1).toString(),
          icon: "sap-icon://factory",
          label: shipToBP,
          position: response.Ventities.length + 1
        });

        // === Dynamic nodes & connections === 
        const nodes = [];

        // Ship From node
        let prevId = 1;
        nodes.push({
          id: prevId.toString(),
          lane: "0",
          title: shipFromTitle,
          titleAbbreviation: shipFromTitle,
          type: "Single",
          children: [],
          stateText: null,
          focused: false,
          texts: [],
          highlighted: false
        });

        // VEntities nodes + connections
        response.Ventities.forEach((ve, idx) => {
          const veId = idx + 2; // Node ID
          const laneId = idx + 1;

          // Defect JGHJ-94334
          const veTitle = ve.BPartner
            ? `${ve.BPartner}${ve.BPartnerName ? ` (${ve.BPartnerName})` : ""}`
            : ve.Plant
              ? `${ve.Plant}${ve.PlantName ? ` (${ve.PlantName})` : ""}`
              : ve.BPartnerName || ve.PlantName || "";

          // Add VE node
          nodes.push({
            id: veId.toString(),
            lane: laneId.toString(),
            title: veTitle,
            titleAbbreviation: veTitle,
            type: "Single",
            children: [],
            state: "Neutral",
            stateText: ve.PlantName || ve.Plant,
            focused: false,
            texts: [],
            highlighted: false
          });

          // Connection label logic (between ShipFrom → VE and VE → VE)
          let connLabel = ve.ArchType;

          // Create connection
          const prevNode = nodes.find(n => n.id === prevId.toString());
          if (prevNode) {
            prevNode.children.push({
              nodeId: veId,
              connectionLabel: {
                id: `id${prevId}To${veId}`,
                text: connLabel,
                enabled: true
              }
            });
          }

          prevId = veId;
        });

        // Ship To node
        const shipToId = prevId + 1;
        nodes.push({
          id: shipToId.toString(),
          lane: lanes[lanes.length - 1].id,
          title: shipToTitle,
          titleAbbreviation: shipToTitle,
          type: "Single",
          children: null,
          stateText: null,
          focused: false,
          texts: [],
          highlighted: false
        });

        // Final connection: from last VE → ShipTo (always use response.ArchType)
        const lastVENode = nodes.find(n => n.id === prevId.toString());
        if (lastVENode) {
          lastVENode.children.push({
            nodeId: shipToId,
            connectionLabel: {
              id: `id${prevId}To${shipToId}`,
              text: response.ArchType,   // Fixed here
              enabled: true
            }
          });
        }

        // Final processFlowFinalData
        const processFlowFinalData = { nodes, lanes };

        // Set the model
        const oModel3 = this.getView().getModel("processFlowFinalData");
        if (oModel3) {
          oModel3.setData(processFlowFinalData);
          oModel3.refresh(true);
        } else {
          this.getView().setModel(new JSONModel(processFlowFinalData), "processFlowFinalData");
        }

        // Force re-render if needed
        const pf = this.getView().byId("processflow4");
        if (pf) {
          pf.invalidate();
        }

        // PROCESS FLOW STEPS
        try {
          const odataModel = this.getView().getModel();
          const oModelProcessFlowStepsBindingContext =
            odataModel.bindContext("/ProcessFlowSteps(...)");

            let sendId=draft?response.ID:response.CatId
            
          oModelProcessFlowStepsBindingContext.setParameter("CatId",sendId);
          oModelProcessFlowStepsBindingContext.setParameter("draft",draft);


          await oModelProcessFlowStepsBindingContext.invoke();

          const processFlowStep =
            oModelProcessFlowStepsBindingContext.getBoundContext().getObject().value;

          const oModelProcessFlowSteps = this.getView().getModel("processFlowStepModel");

          if (oModelProcessFlowSteps) {
            oModelProcessFlowSteps.setData(processFlowStep);
            oModelProcessFlowSteps.refresh(true);
          } else {
            this.getView().setModel(new JSONModel(processFlowStep), "processFlowStepModel");
          }
          this._getUserRoles();
        } catch (error) {
          this.getView().setModel(new JSONModel({}), "processFlowStepModel");
          console.error(failedLoadProcessSteps, error);
        }
      },
      // ***** JGHJ-71574 ***** R2.2 END *****

      _getUserRoles: async function () {
        try {
          let i18n = this.getView().getModel("i18n").getResourceBundle();
          let shipFromBP = i18n.getText("shipFromBP");
          const odataModel = this.getView().getModel();
          let oModelBindingContext = odataModel.bindContext(
            "/userInfo(...)"
          );

          // oModelBindingContext.setParameter("ID", catId);
          await oModelBindingContext.invoke();

          const response = oModelBindingContext
            .getBoundContext()
            .getObject().value;
          console.log(response)
          this._handleUserRoles(response.roles);

        } catch (error) {
          console.error(Errorfetchinguserroles, error);
        }
      },
      _handleUserRoles: function (roles) {
        const editButton = this.getView().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::StandardAction::Edit");
        const copyButton = this.getView().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::DataFieldForAction::zbuvcm47419Service.Copy");


        // 1. Check if the user has either restricted role
        if (roles["XS2-VCM-PFC-MAS-MNT"] || roles["XS3-VCM-PFC-DSP"]) {

          // 2. ONLY disable if they do NOT have the ALL-MNT role
          if (!roles["XS2-VCM-PFC-ALL-MNT"]) {
            editButton.setEnabled(false);
            copyButton.setEnabled(false);
          }
        }
      },
      openDialog: function (text, formVisible, fnAction) {
        return new Promise(
          function (resolve, reject) {
            let dialogModel = this.getView().getModel("dialog"),
              data = dialogModel.getData();
            data.text = text;
            data.formVisible = formVisible ? formVisible : false;
            dialogModel.setData(data);
            //use building blocks in an XML fragment using the loadFragment method from the SAP Fiori elements ExtensionAPI
            this.base
              .getExtensionAPI()
              .loadFragment({
                name: "zbuvcm47419ui.ext.fragment.Dialog",
                controller: this
              })
              .then(function (approveDialog) {
                //Dialog Continue button
                approveDialog.getBeginButton().attachPress(function () {
                  approveDialog.close();
                  if (fnAction) {
                    fnAction();
                  }
                  resolve(null);
                });
                //Dialog Cancel button
                approveDialog.getEndButton().attachPress(function () {
                  approveDialog.close().destroy();
                  reject(null);
                });
                //consider dialog closing with Escape
                approveDialog.attachAfterClose(function () {
                  approveDialog.destroy();
                  reject(null);
                });
                approveDialog.open();
              });
          }.bind(this)
        );
      },
    });
  });
