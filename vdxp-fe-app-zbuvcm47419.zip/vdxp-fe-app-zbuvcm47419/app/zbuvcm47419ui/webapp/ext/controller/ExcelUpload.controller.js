sap.ui.define([
	'sap/ui/core/mvc/ControllerExtension',
	'sap/ui/core/Fragment',
	'sap/m/MessageToast',
	"sap/ui/export/Spreadsheet",
], function (ControllerExtension, Fragment, MessageToast, Spreadsheet) {
	'use strict';

	return ControllerExtension.extend('zbuvcm47419ui.ext.controller.ExcelUpload', {

		_oExcelInputDialog: null,
		_virtualEntityCount: null,

		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf zbuvcm47419ui.ext.controller.ExcelUpload
			 */
			onInit: function () {
				if (Spreadsheet && Spreadsheet.prototype) {
                Spreadsheet.prototype._showExportWarningDialog = function () {
                    // Always return true to simulate clicking "Export anyway"
                    return Promise.resolve(true);
                };
            }
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				var oModel = this.base.getExtensionAPI().getModel();
				this.base.byId("zbuvcm47419ui::ExcelUpload--fe::EditableHeaderSubSection").setVisible(false)
				sap.ui.getCore().attachInit(function () {
					sap.m.MessageToast.show = function () { };
				});
			},
			onPageReady: function () {
				const oSaveBtn = this.getView().byId(
					"zbuvcm47419ui::ExcelUpload--fe::FooterBar::StandardAction::Save"
				);
				if (oSaveBtn) {
					oSaveBtn.setText("Validate");
				}

				const oCreateBtn = this.getView().byId(
					"zbuvcm47419ui::ExcelUpload--fe::FooterBar::StandardAction::Create"
				);
				if (oCreateBtn) {
					oCreateBtn.setText("Validate");
				}

				const oCancelBtn = this.getView().byId(
					"zbuvcm47419ui::ExcelUpload--fe::FooterBar::StandardAction::Cancel"
				);
				if (oCancelBtn) {
					oCancelBtn.setText("Cancel");
				}
			}
		},
		refreshTable: function () {
			console.log("refreshTable");
			this.getView().byId("zbuvcm47419ui::ExcelUpload--fe::table::attachments::LineItem::UploadAttachments").getRowBinding().refresh();
		},
		// downloadTemplate: function () {
		// 	const names = this._excelName || "Default_Template";
		// 	console.log(names)
		// 	const sUrl = jQuery.sap.getModulePath("zbuvcm47419ui.utils", "/PFC_NEW_Template.xlsx");

		// 	// Trigger download
		// 	const link = document.createElement("a");
		// 	link.href = sUrl;
		// 	link.download = "ProductFlowTemplate.xlsx";
		// 	document.body.appendChild(link);
		// 	link.click();
		// 	document.body.removeChild(link);
		// },
		// ExcelInput: function (oEvent) {
		// 	console.log("Hiiii")
		// }

		// ------------------------------------------------------------------
		// 🔵 BUTTON: ExcelInput → Open fragment
		// ------------------------------------------------------------------
		ExcelInput: async function () {
			if (!this._oExcelInputDialog) {
				this._oExcelInputDialog = await Fragment.load({
					name: "zbuvcm47419ui.ext.fragment.ExcelInputDialog",
					controller: this
				});
				this.getView().addDependent(this._oExcelInputDialog);
			}
			this._oExcelInputDialog.open();
		},

		generateOutputColumns: function (veCount) {
			const baseColumns = [
				"Product Flow ID",
				"Flow Description",
				"Ship From Business Partner",
				"Ship From Plant",
				"Economic Region Ship From",
				"Ship To Arch Type",
				"Ship To Business Partner",
				"Ship To Plant",
				"Economic Region Ship To",
				"Material Type",
				"Material Profit Center",
				"Material Number",
				"Valid From",
				"Valid To"
			];

			// Dynamic VE columns
			const veColumns = [];
			for (let i = 1; i <= veCount; i++) {
				veColumns.push(
					`Arch Type ${i}`,
					`Business Partner V${i}`,
					`Plant V${i}`
				);
			}

			// Final column
			const finalColumns = ["Product Flow Comments"];

			return [...baseColumns, ...veColumns, ...finalColumns];
		},


		onExcelInputConfirm: function () {
			const sValue = sap.ui.getCore().byId("virtualInput").getValue();

			if (!sValue) {
				MessageToast.show("Please enter a number");
				return;
			}

			const outputColumns = this.generateOutputColumns(Number(sValue));
			const exportColumns = outputColumns.map(col => {
				return {
					label: col,
					property: col.replace(/\s+/g, "_"), // property name (must be unique)
					type: "String"
				};
			});

			const settings = {
				workbook: {
					columns: exportColumns
				},
				dataSource: [ {} ], // blank template
				fileName: "ProductFlow_Template.xlsx",
				worker: false,
				count: 0,
			};

			
const sheet = new sap.ui.export.Spreadsheet(settings);

            // ---------------------------------------------------------
            // 🟢 FIX: Override the warning dialog for THIS instance only
            // ---------------------------------------------------------
            sheet._showExportWarningDialog = function () {
                // Return a resolved Promise(true) to simulate clicking "Export anyway"
                return Promise.resolve(true);
            };
			sheet.build()
				.then(() => {
					sap.m.MessageToast.show("Excel downloaded");
				})
				.finally(() => sheet.destroy());


			// const sUrl = jQuery.sap.getModulePath("zbuvcm47419ui.utils", "/PFC_NEW_Template.xlsx");

			// const link = document.createElement("a");
			// link.href = sUrl;
			// link.download = "ProductFlowTemplate.xlsx";
			// document.body.appendChild(link);
			// link.click();
			// document.body.removeChild(link);

			this._oExcelInputDialog.close();

			MessageToast.show("Saved: " + this._virtualEntityCount);
		},

		onExcelInputCancel: function () {
			this._oExcelInputDialog.close();
		},
	});
});
