sap.ui.define([
    'jquery.sap.global',
    'sap/suite/ui/commons/library',
    'sap/m/library',
    'sap/ui/model/json/JSONModel',
    'sap/ui/Device',
    'sap/m/MessageToast',
    'sap/suite/ui/commons/ProcessFlowConnectionLabel',
    'sap/m/StandardListItem',
    'sap/m/Button',
    'sap/m/List',
    'sap/m/ResponsivePopover',
    'sap/ui/core/Core',
    'sap/ui/core/Element',
    "sap/ui/export/Spreadsheet",
], function (
    jQuery, SuiteLibrary, MobileLibrary, JSONModel, Device,
    MessageToast, ProcessFlowConnectionLabel, StandardListItem,
    Button, List, ResponsivePopover, Core, Element, Spreadsheet
) {
    'use strict';

    var aConnections = null;
    var sContainerId = "";

    function createListEntryObject(oConnection) {
        return {
            title: oConnection.label.getText(),
            // info: oConnection.sourceNode.getNodeId() + "-" + oConnection.targetNode.getNodeId(),
            type: "Active"
        };
    }

    function getListData() {
        var aNavigation = aConnections.map(createListEntryObject);
        return { navigation: aNavigation };
    }

    var SelectedKey = "";

    // 🔹 Define the handler object first
    var ProcessFlowHandler = {
        onLabelPress: function (oEvent) {
            aConnections = oEvent.getParameter("connections");
            sContainerId = oEvent.getSource().getId().split("-")[2];
            var oSelectedLabel = oEvent.getParameter("selectedLabel");

            var oListData = getListData();

            var oItemTemplate = new StandardListItem({
                title: "{title}",
                // info: "{info}"
            });

            var oList = new List({
                mode: MobileLibrary.ListMode.SingleSelectMaster,

                selectionChange: ProcessFlowHandler.onListItemPress
            });

            oList.setModel(new JSONModel(oListData));
            oList.bindAggregation("items", "/navigation", oItemTemplate);

            var oResponsivePopover;

            // var oBeginButton = new Button({
            //     text: "Action1",
            //     type: MobileLibrary.ButtonType.Reject,
            //     press: function () {
            //         oResponsivePopover.setShowCloseButton(true);
            //     }
            // });

            // var oEndButton = new Button({
            //     text: "Action2",
            //     type: MobileLibrary.ButtonType.Accept,
            //     press: function () {
            //         oResponsivePopover.setShowCloseButton(true);
            //     }
            // });

            oResponsivePopover = Element.getElementById("__popover") || new ResponsivePopover("__popover", {
                placement: MobileLibrary.PlacementType.Auto,
                // title: "Paths[" + aConnections.length + "]",

                content: [oList],
                showCloseButton: true,
                afterClose: function () {
                    oResponsivePopover.destroy();
                    Core.byId(sContainerId).setFocusToLabel(oSelectedLabel);
                },
                // beginButton: oBeginButton,
                // endButton: oEndButton
            });

            if (Device.system.phone) {
                oResponsivePopover.setShowCloseButton(true);
            }

            oResponsivePopover.openBy(oSelectedLabel);
            oResponsivePopover.setShowCloseButton(true);
        },
        // onChange: function (oEvent) {
        //     var oSelect = oEvent.getSource();

        //      // Get the selected key
        //      var sSelectedKey = oSelect.getSelectedKey();
        //     if(sSelectedKey === "PO"){
        //      this.getView().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTable-listUl").setVisible(true);

        //      this.getView().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTable1-listUl").setVisible(false);
        //     }else if (sSelectedKey === "SO")
        //      {

        //       this.getView().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTable-listUl").setVisible(false);

        //         this.getView().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTable1-listUl").setVisible(true);

        //      }

        //     // MessageToast.show("change event fired! \n Selected Item id: " + oEvent.getParameters().selectedItem.sId
        //     // + "\n Previously Selected Item id: " + oEvent.getParameters().previousSelectedItem.sId);
        // },

        onNodePress: function (event) {
            console.log(event.getParameters(), "event.getParameters()")
            MessageToast.show(event.getParameters()?.mProperties?.title);
        },
        // onChange: function (oEvent) {
        //     var oSelect = oEvent.getSource();
        //     var sSelectedKey = oSelect.getSelectedKey();
        //     SelectedKey = sSelectedKey
        //     var productTablePOPUSH = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTablePOPUSH");
        //     var productTablePOPULL = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTablePOPULL");
        //     var productTableSOAT = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTableSOAT");
        //     var productTable_SOPUSH = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTable_SOPUSH");
        //     var productTable_SOPULL = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTable_SOPULL");

        //     if (sSelectedKey === "PO") {
        //         oPO.setVisible(true);
        //         oSO.setVisible(false);
        //     } else if (sSelectedKey === "SO") {
        //         oPO.setVisible(false);
        //         oSO.setVisible(true);
        //     }
        // },

        //  onChange: function (oEvent) {
        //     var oSelect = oEvent.getSource();
        //     var sSelectedKey = oSelect.getSelectedKey();
        //     SelectedKey = sSelectedKey
        //     var productTablePOPUSH = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTablePOPUSH");
        //     var productTablePOPULL = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTablePOPULL");
        //     var productTableSOAT = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTableSOAT");
        //     var productTable_SOPUSH = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTable_SOPUSH");
        //     var productTable_SOPULL = sap.ui.getCore().byId("zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTable_SOPULL");
 
        //     if (sSelectedKey === "PO") {
        //         oPO.setVisible(true);
        //         oSO.setVisible(false);
        //     } else if (sSelectedKey === "SO") {
        //         oPO.setVisible(false);
        //         oSO.setVisible(true);
        //     }
        // },

        onChange: function (oEvent) {
    var sSelectedKey = oEvent.getSource().getSelectedKey();

    // Get tables
    var oPOPUSH = sap.ui.getCore().byId(
        "zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTablePOPUSH"
    );
    var oPOPULL = sap.ui.getCore().byId(
        "zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTablePOPULL"
    );
    var oSOAT = sap.ui.getCore().byId(
        "zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTableSOAT"
    );
    var oSOPUSH = sap.ui.getCore().byId(
        "zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTable_SOPUSH"
    );
    var oSOPULL = sap.ui.getCore().byId(
        "zbuvcm47419ui::PFC_ListObjectPage--fe::CustomSubSection::ProcessFlow--productTable_SOPULL"
    );

    // Hide all first
    oPOPUSH.setVisible(false);
    oPOPULL.setVisible(false);
    oSOAT.setVisible(false);
    oSOPUSH.setVisible(false);
    oSOPULL.setVisible(false);

    SelectedKey = sSelectedKey;
    // Show based on selected key
    switch (sSelectedKey) {
        
        case "PO_PUSH":
            oPOPUSH.setVisible(true);
            break;

        case "PO_PULL":
            oPOPULL.setVisible(true);
            break;

        case "SO_AT":
            oSOAT.setVisible(true);
            break;

        case "SO_PUSH":
            oSOPUSH.setVisible(true);
            break;

        case "SO_PULL":
            oSOPULL.setVisible(true);
            break;
    }
}
,
     // ***** JGHJ-71574 ***** R2.2 START *****
         onDownloadStepsExcel: function () {
            const oView = this._view;
            const selectedKey = SelectedKey||"PO_PUSH";
            console.log("Selected Key:", selectedKey);

            const oData = oView.getModel('processFlowStepModel').getData();



            const data = oData[selectedKey]; // This fetches oData.PO or oData.SO


            if (!data || data.length === 0) {
                MessageToast.show("No steps available");
                return;
            }

            // ---------- Columns Definition ----------
            const aColumns = [
                {
                    label: "Sequence",
                    property: "Sequence",
                    type: "string"
                },
                {
                    label: "Document",
                    property: "Steps",
                    type: "string"
                },
                {
                    label: "Entity",
                    property: "Entity",
                    type: "string"
                },
                {
                    label: "Legal Entity",
                    property: "LegalEntity",
                    type: "string"
                }
            ];

            // ---------- Create Spreadsheet Object ----------
            const oSettings = {
                workbook: {
                    columns: aColumns
                },
                dataSource: data,
                fileName: 'SO' + "_ProcessFlowSteps.xlsx"
            };

            const oSheet = new Spreadsheet(oSettings);
            oSheet.build()
                .then(() => {
                    MessageToast.show("Excel Downloaded");
                })
                .finally(function () {
                    oSheet.destroy();
                });
        },

        // Needed because fragment uses require: handler
        setView: function (view) {
            this._view = view;
        },
     // ***** JGHJ-71574 ***** R2.2 END *****


        // formatConnectionLabels: function(childrenData) {
        //     var aChildren = [];
        //     for (var i = 0; childrenData &&  i < childrenData.length; i++) {
        //         if (childrenData[i].connectionLabel && childrenData[i].connectionLabel.id) {
        //             var oConnectionLabel = Element.getElementById(childrenData[i].connectionLabel.id);
        //             if (!oConnectionLabel) {
        //                 oConnectionLabel = new ProcessFlowConnectionLabel({
        //                     id: childrenData[i].connectionLabel.id,
        //                     text: childrenData[i].connectionLabel.text,
        //                     enabled: childrenData[i].connectionLabel.enabled,
        //                     icon: childrenData[i].connectionLabel.icon,
        //                     state: childrenData[i].connectionLabel.state,
        //                     priority: childrenData[i].connectionLabel.priority
        //                 });
        //             }
        //             aChildren.push({
        //                 nodeId: childrenData[i].nodeId,
        //                 connectionLabel: oConnectionLabel
        //             });
        //         } else if (jQuery.type(childrenData[i]) === 'number'){
        //             aChildren.push(childrenData[i]);
        //         }
        //     }
        //     return aChildren;
        // },

        formatConnectionLabels: function (childrenData) {
            var aChildren = [];
            for (var i = 0; childrenData && i < childrenData.length; i++) {
                if (childrenData[i].connectionLabel && childrenData[i].connectionLabel.id) {
                    var oConnectionLabel = Element.getElementById(childrenData[i].connectionLabel.id);
                    if (!oConnectionLabel) {
                        oConnectionLabel = new ProcessFlowConnectionLabel({
                            id: childrenData[i].connectionLabel.id
                        });
                    }

                    //  Always update props to reflect latest JSON
                    oConnectionLabel.setText(childrenData[i].connectionLabel.text);
                    oConnectionLabel.setEnabled(childrenData[i].connectionLabel.enabled);
                    oConnectionLabel.setState(childrenData[i].connectionLabel.state);
                    oConnectionLabel.setPriority(childrenData[i].connectionLabel.priority);

                    aChildren.push({
                        nodeId: childrenData[i].nodeId,
                        connectionLabel: oConnectionLabel
                    });
                } else if (jQuery.type(childrenData[i]) === 'number') {
                    aChildren.push(childrenData[i]);
                }
            }
            return aChildren;
        },

        onListItemPress: function (oEvent) {
            var selectedItem = oEvent.getParameter("listItem");
            var aSourceTarget = selectedItem.getInfo().split("-");
            var sSourceId = aSourceTarget[0];
            var sTargetId = aSourceTarget[1];

            aConnections.forEach(function (conn) {
                if (
                    conn.sourceNode.getNodeId() === sSourceId &&
                    conn.targetNode.getNodeId() === sTargetId
                ) {
                    Core.byId(sContainerId).setSelectedPath(sSourceId, sTargetId);
                }
            });
        }
    };

    // ✅ Export the named object
    return ProcessFlowHandler;
});