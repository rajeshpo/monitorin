sap.ui.define(
    [
        'sap/fe/core/PageController',
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageToast",
        "sap/ui/model/Sorter",
        "sap/ushell/Container",
    ],

    /**
            * @param {typeof sap.ui.core.mvc.Controller} Controller
            * @public
            * @since v0.0.1
            * @name jnj.com.zbuvcm47419ui.controller.Main
          */

    function (PageController, JSONModel, MessageToast, Sorter, Container) {
        'use strict';

        return PageController.extend('zbuvcm47419ui.ext.main.Main', {

            /**
                        * Initial screen.
                        * @public
                        */

            onInit: function () {

                PageController.prototype.onInit.apply(this, arguments); // needs to be called to properly initialize the page controller
                const router = this.getAppComponent().getRouter();
                router.getRoute("PFC_ListViewMain").attachPatternMatched(this._onObjectMatched, this);

            },
            beforerebind: function (oEvent) {
                var oBindingParams = oEvent.getParameter("collectionBindingInfo").collectionBindingInfo;

                // create a Sorter on the grouping property
                // arguments: (path, descending, group)
                var oGroupSorter = new Sorter("CatId", /*bDescending=*/ true, /*bGroup=*/ true);

                // prepend it so grouping happens first
                oBindingParams.sorter = [oGroupSorter].concat(oBindingParams.sorter || []);
            },

            _onObjectMatched: function () {
                // this.getExtensionAPI().refresh()
                var oTable = this.byId("Table");
                oTable?.refresh()
                this.getView().byId('zbuvcm47419ui::PFC_ListViewMain--Table-content-copy')?.setVisible(false)
                this._getUserRoles();
                // if (oTable && oTable.getBinding("items")) {
                //     oTable.getBinding("items").refresh();
                // }
                // if(this._createDone) {
                //     if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
                //         var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation"); 
                //         oCrossAppNav.toExternal({
                //             target: {
                //                 shellHash: "#"                                
                //             }
                //         });
                //     }
                // } else {
                //     this._createDone = true;
                //     const listBinding = this.getAppComponent().getModel().bindList("/Catalog");

                //     this.editFlow.createDocument(listBinding, {
                //         creationMode: "NewPage"
                //     });  
                // }
            },
            _getUserRoles: async function () {
                try {
                    const odataModel = this.getView().getModel();
                    let oModelBindingContext = odataModel.bindContext(
                        "/userInfo(...)"
                    );

                    // oModelBindingContext.setParameter("ID", catId);
                    await oModelBindingContext.invoke();

                    const response = oModelBindingContext
                        .getBoundContext()
                        .getObject().value;
                    this._handleUserRoles(response.roles);

                } catch (error) {
                    console.error("Error fetching user roles:", error);
                }
            },
            _handleUserRoles: function (roles) {
                var createButton = this.getView().byId("zbuvcm47419ui::PFC_ListViewMain--Table-content::CustomAction::create")
                var massUploadButton = this.getView().byId("zbuvcm47419ui::PFC_ListViewMain--Table-content::CustomAction::upload")
                if (roles["XS3-VCM-PFC-DSP"]) {
                    if (!roles["XS2-VCM-PFC-MAS-MNT"] && !roles["XS2-VCM-PFC-ALL-MNT"]) {
                        createButton.setEnabled(false);
                        massUploadButton.setEnabled(false);
                    }
                }
            },
            create: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/PFC_List");


                this.editFlow.createDocument(listBinding, {
                    creationMode: "NewPage"
                });
            },
             // ***** JGHJ-71574 ***** R2.2 START *****

            drafts: function () {

                const oRouter = this.getAppComponent().getRouter();

                oRouter.navTo("PFC_ListDrafts");

            },
            // ***** JGHJ-71574 ***** R2.2 END *****
           
            rowpress: function (oEvent) {
                var id = oEvent.getParameter("bindingContext").sPath.match(/ID=([a-f0-9-]+)/i)?.[1]

                const router = this.getAppComponent().getRouter();
                router.navTo('PFC_ListObjectPage', {
                    PFC_ListKey: `ID=${id},IsActiveEntity=true`
                })
            },
            // ***** JGHJ-71574 ***** R2.2 START *****

              onDraftRowPress: function (oEvent) {
                const oContext = oEvent.getParameter("bindingContext");
                if (!oContext) return;

                const oObj = oContext.getObject();
                const sId = oObj.ID;

                const oRouter = this.getAppComponent().getRouter();

                 oRouter.navTo("PFC_ListDraftObjectPage", {
                        PFC_ListKey: `ID=${sId},IsActiveEntity=false`
                    });
            },
            // ***** JGHJ-71574 ***** R2.2 END *****
          
            // To navigate to UI Maintenance route

            showUIMaintenance: function (oEvent) {
                // MessageToast.show("Custom handler invoked.");
                PageController.prototype.onInit.apply(this, arguments);
                const oRouter = this.getAppComponent().getRouter();
                oRouter.navTo("ShowUIMaintenanceScreen");
            },

            //To go back one step from UI Maintenance Tables page

            onNavBack: function () {
                window.history.go(-1);
            },
            upload: async function () {
                const oModel = this.getAppComponent().getModel();

                try {
                    const oListBinding = oModel.bindList("/ExcelUpload", undefined, undefined, undefined, { $$groupId: "$auto" });

                    const aContexts = await oListBinding.requestContexts(0, 1);

                    if (aContexts.length > 0) {

                        const context = aContexts[0];
                        await this.editFlow.editDocument(context);
                    } else {

                        const listBinding = oModel.bindList("/ExcelUpload");
                        this.editFlow.createDocument(listBinding, {
                            creationMode: "NewPage"
                        });
                    }

                } catch (err) {
                    sap.m.MessageToast.show("Upload failed: " + err.message);
                    console.error(err);
                }
            }

        });
    }
);
