// // --------------------------------------------------------------------------------------------------------------------*
// // Application Name : Product Flow Catalog
// // Object Id       : ZBUVCM47419
// // Release         : 1
// // Version         : 0.01
// // Description     : Validation module for Product Flow Catalog Application
// // ----------------------------------------------------------------------------*
// // Descriptions: it will have all thevalidations at the time of create Screen
// // ----------------------------------------------------------------------------*
// // Change Log:
// //    Date     |       Author        |   Change Id   |   Change Description
// 26-03-2026      RChitike@its.jnj.com     50440096        TIME-FIN-DEV-PFCEnhanceme-Developement
// // ----------------------------------------------------------------------------*
const constants = require('../config/constant');
const cds = require('@sap/cds');
const onDbOps = require('../operation/dbOps.js')

async function validateData(data, bundle,ZSD_VCM_PRODUCTFLOW) {
  const errors = [];
  let validData = [];
  validData.push(data);

  const uniqueBPs = new Set();
  const uniquePlants = new Set();
  const uniqueMats = new Set();


  validData.forEach(item => {
    // Validation for ArchType
    if (!item.ArchType) {
      errors.push(bundle.getText("errorItem") + " " + bundle.getText("archTypeError"));
    }


    // Validate ProdId only if it's not empty
    if (item.ProdId && !item.ProdId.startsWith("PFL")) {
      errors.push(bundle.getText("errorItem") + " " + bundle.getText("prodIdMustStartWithPFL"));
    }

    // Validation for BpSFrom and PlantSFrom
    if (!item.BpSFrom && !item.PlantSFrom && !item.ErSFrom) {
      errors.push(bundle.getText("errorItem") + " " + bundle.getText("shipFromBpOrPlantRequired"));
    }

    // Validation for either entering ShipFrom BP or EcoRegion
    if ((item.BpSFrom || item.PlantSFrom) && item.ErSFrom) {
      errors.push(bundle.getText("errorItem") + " " + bundle.getText("EitherBpOrEcoRegionInSFrom"));
    }

    // Validation for either entering ShipFrom BP or EcoRegion
    if ((item.BpSTo || item.PlantSTo) && item.ErSTo) {
      errors.push(bundle.getText("errorItem") + " " + bundle.getText("EitherBpOrEcoRegionInSTo"));
    }

    // Validation for BpSTo and PlantSTo
    if (!item.BpSTo && !item.PlantSTo && !item.ErSTo) {
      errors.push(bundle.getText("errorItem") + " " + bundle.getText("shipToBpOrPlantRequired"));
    }

    if (item.Items?.length === 0) {
      errors.push(bundle.getText("errorItem") + " " + bundle.getText("noMaterails"));
    }

    if (item.BpSFrom) uniqueBPs.add(item.BpSFrom);
    if (item.BpSTo) uniqueBPs.add(item.BpSTo);
    if (item.PlantSFrom) uniquePlants.add(item.PlantSFrom);
    if (item.PlantSTo) uniquePlants.add(item.PlantSTo);

     let itemRecords = new Set();

    // Validation for Items node
     itemRecords = new Set(); // To keep track of unique records
    item.Items.forEach((itemDetail, i) => {
      // Validation for MatBrand and Matnr and MatType
      // if (!itemDetail.MatBrand && !itemDetail.Matnr) {
      //   errors.push(bundle.getText("errorItem") + " " + bundle.getText("materialNumberBrand"));
      // }

      if(itemDetail.Matnr && !itemDetail.MatBrand){
        errors.push(bundle.getText("errorItem") + " " + bundle.getText("MatBrandNeccessary"))
      }

       if(itemDetail.Matnr && itemDetail.MatBrand && !itemDetail.MatType){
        errors.push(bundle.getText("errorItem") + " " + bundle.getText("MatTypeNeccessary"))
      }

      if(!itemDetail.Matnr && itemDetail.MatBrand && !itemDetail.MatType){
        errors.push(bundle.getText("errorItem") + " " + bundle.getText("MatTypeOnlyNeccessary"))

      }

      // if(!itemDetail.Matnr && !itemDetail.MatBrand && itemDetail.MatType){
      //   errors.push(bundle.getText("errorItem") + " " + bundle.getText("MatBrandTypeNeccessary"))

      // }



      // Validate uniqueness of MatBrand, Matnr,MatType combination within the same Product Flow
      const uniqueKey = `${itemDetail.MatBrand}-${itemDetail.Matnr}-${itemDetail.MatType}`;
      if (itemRecords.has(uniqueKey) && itemDetail.ApprStatus!=='Approved'&& itemDetail.Status!=='Inactive') {
        if(itemDetail.ApprStatus!=='New'&& itemDetail.Status!=='New'){
         errors.push(bundle.getText("errorItem") + bundle.getText("duplicateBrand") + `${itemDetail.MatBrand}, ${bundle.getText("Matnr")}: ${itemDetail.Matnr} ,${bundle.getText("MatType")}: ${itemDetail.MatType}`);
        }
       
      } else {
        itemRecords.add(uniqueKey);
      }

      if (itemDetail.Matnr) uniqueMats.add(itemDetail.Matnr);
    });

    item.Ventities.forEach((ventity, i) => {
      if (!ventity.BPartner && !ventity.Plant) {
        errors.push(bundle.getText("errorItem") + " " + bundle.getText("bpOrPlantForVE"));
      }

      if (!ventity.ArchType) {
        errors.push(bundle.getText("errorItem") + " " + `Arch Type value is mandatory in Virtual Entity`);

      }
      if (ventity.BPartner) uniqueBPs.add(ventity.BPartner);
      if (ventity.Plant) uniquePlants.add(ventity.Plant);
    });
  });


  const filterBPs = [...uniqueBPs].map(bp => String(bp).trim());
  const filterPlants = [...uniquePlants].map(p => String(p).trim());
  const filterMats = [...uniqueMats].map(m => String(m).trim());

  let bpList = [];
  let plantList = [];
  let materialList = [];

  if (filterBPs.length) {
    bpList = await ZSD_VCM_PRODUCTFLOW.run(
      SELECT.from('Massbpplantcntrykey').where({ BusinessPartner: filterBPs })
    );
  }

  // if (filterPlants.length) {
  //   plantList = await ZSD_VCM_PRODUCTFLOW.run(
  //     SELECT.from('Massplantbpcntrykey').where({ Plant: filterPlants })
  //   );
  // }
   async function fetchAllPages(query, pageSize = 100) {
        let skip = 0;
        let allResults = [];

        while (true) {
          const page = await ZSD_VCM_PRODUCTFLOW.run(
            query.limit(pageSize, skip)
          );

          allResults = allResults.concat(page);

          if (page.length < pageSize) break; // last page reached
          skip += pageSize;
        }

        return allResults;
      }

      if (filterPlants) {
        const chunkSize = 100; // avoid URL length issues on filter
        const chunks = [];
        for (let i = 0; i < filterPlants.length; i += chunkSize) {
          chunks.push(filterPlants.slice(i, i + chunkSize));
        }

        const results = await Promise.all(
          chunks.map(chunk =>
            fetchAllPages(
              SELECT.from('Massplantbpcntrykey').where({ Plant: chunk })
            )
          )
        );

        plantList = results.flat();
      }

  // if (filterMats.length) {
  //   materialList = await ZSD_VCM_PRODUCTFLOW.run(
  //     SELECT.from('Material').where({ Product: filterMats })
  //   );
  // }
   async function fetchAllPages(query, pageSize = 100) {
        let skip = 0;
        let allResults = [];

        while (true) {
          const page = await ZSD_VCM_PRODUCTFLOW.run(
            query.limit(pageSize, skip)
          );

          allResults = allResults.concat(page);

          if (page.length < pageSize) break; // last page reached
          skip += pageSize;
        }

        return allResults;
      }

      if (filterMats) {
        const chunkSize = 100; // avoid URL length issues on filter
        const chunks = [];
        for (let i = 0; i < filterMats.length; i += chunkSize) {
          chunks.push(filterMats.slice(i, i + chunkSize));
        }

        const results = await Promise.all(
          chunks.map(chunk =>
            fetchAllPages(
              SELECT.from('Material').where({ Product: chunk })
            )
          )
        );

        materialList = results.flat();
      }

  // ================= NEW: INVALID VALUE CHECK =================

  const validBPs = new Set(bpList.map(b => b.BusinessPartner));
  const validPlants = new Set(plantList.map(p => p.Plant));
  const validMats = new Set(materialList.map(m => m.Product));

  filterBPs.forEach(bp => {
    if (!validBPs.has(bp)) {
      errors.push(bundle.getText("errorItem") + ` Invalid Business Partner: ${bp}`);
    }
  });

  filterPlants.forEach(plant => {
    if (!validPlants.has(plant)) {
      errors.push(bundle.getText("errorItem") + ` Invalid Plant: ${plant}`);
    }
  });

  filterMats.forEach(mat => {
    if (!validMats.has(mat)) {
      errors.push(bundle.getText("errorItem") + ` Invalid Material: ${mat}`);
    }
  });

  return errors.length > 0 ? errors : "Validation passed";
}

function matDuplicateChk(flag, inputMatDetail, dbPfcList) {
  // Handle case where dbPfcList might have a 'value' property (OData format)
  const dbRecords = dbPfcList.value || dbPfcList;
  let inputData = [];
  inputData.push(inputMatDetail);


  //Creating a lookup Hash map with physical flow as key 
  // Key format: "BpSFrom|BpSTo|PlantSFrom|PlantSTo"
  const dbLookupMap = new Map();

  for (const dbRecord of dbRecords) {
    // Handle null values explicitly for consistent key creation
    const bpsFrom = dbRecord.BpSFrom  ?dbRecord.BpSFrom: 'NULL';
    const bpsTo = dbRecord.BpSTo  ? dbRecord.BpSTo:'NULL' ;
    const plantFrom = dbRecord.PlantSFrom  ?dbRecord.PlantSFrom: 'NULL' ;
    const plantTo = dbRecord.PlantSTo  ? dbRecord.PlantSTo:'NULL';
    const ecsFrom = dbRecord.ErSFrom  ? dbRecord.ErSFrom:'NULL' ;
    const ecsTo = dbRecord.ErSTo  ? dbRecord.ErSTo:'NULL';

    const key = `${bpsFrom}|${bpsTo}|${plantFrom}|${plantTo}|${ecsFrom}|${ecsTo}`;
    
    if (!dbLookupMap.has(key)) {
      dbLookupMap.set(key, []);
    }
    dbLookupMap.get(key).push(dbRecord);
  }

  const result = [];

  // Process input records
  for (const inputRecord of inputData) {
    // Skip if no items
    if (!inputRecord.Items?.length) continue;

    // Create lookup key with same null handling
    const bpsFrom = inputRecord.BpSFrom  ?inputRecord.BpSFrom: 'NULL';
    const bpsTo = inputRecord.BpSTo  ? inputRecord.BpSTo:'NULL' ;
    const plantFrom = inputRecord.PlantSFrom  ?inputRecord.PlantSFrom: 'NULL' ;
    const plantTo = inputRecord.PlantSTo  ? inputRecord.PlantSTo:'NULL';
    const ecsFrom = inputRecord.ErSFrom  ? inputRecord.ErSFrom:'NULL' ;
    const ecsTo = inputRecord.ErSTo  ? inputRecord.ErSTo:'NULL';

    const lookupKey = `${bpsFrom}|${bpsTo}|${plantFrom}|${plantTo}|${ecsFrom}|${ecsTo}`;


    //Checking if with same ShipFrom ShipTo exists or not
    const matchingDbRecords = dbLookupMap.get(lookupKey);

    if (matchingDbRecords) {
      // Process all combinations efficiently
      for (const inputItem of inputRecord.Items) {
        for (const dbRecord of matchingDbRecords) {
          let matchingDbItem = null;
          if (flag === 'CREATE') {

            // Check if this input item exists in the db record's items
            const normalize = v => (v === null || v === undefined || v === "" ? null : v);

            matchingDbItem = dbRecord.Items?.find(dbItem =>
              normalize(dbItem.Matnr) === normalize(inputItem.Matnr) &&
              normalize(dbItem.MatBrand) === normalize(inputItem.MatBrand)
              && normalize(dbItem.MatType) === normalize(inputItem.MatType)
              && normalize(dbItem.ApprStatus) !=="Rejected" && normalize(dbItem.Status) !== "Inactive"
            );

          }
          else if (flag === 'UPDATE') {
            // Check if this input item exists in the db record's items
            if (inputItem.CatId === null) {
              const normalize = v => (v === null || v === undefined || v === "" ? null : v);

              matchingDbItem = dbRecord.Items?.find(dbItem =>
                normalize(dbItem.Matnr) === normalize(inputItem.Matnr) &&
                normalize(dbItem.MatType) === normalize(inputItem.MatType) &&
                normalize(dbItem.MatBrand) === normalize(inputItem.MatBrand)
                && normalize(dbItem.ApprStatus) !=="Rejected" && normalize(dbItem.Status) !== "Inactive"
              );
            }
          }


          // Only add to result if both Matnr and MatBrand match
          if (matchingDbItem) {
            result.push({
              CatId: dbRecord.CatId,
              MatBrand: inputItem.MatBrand,
              Matnr: inputItem.Matnr,
              MatType:inputItem.MatType
            });
          }
        }
      }
    }
  }

  return result;
}

function transformExcelRowToPF(row) {

  function norm(v) {
    return (v ?? '').toString().trim();
  }

  const ventities = [];

  // Excel supports V1–V6
  for (let i = 1; i <= 6; i++) {
    const bp = norm(row[`Business Partner V${i}`]);
    const plant = norm(row[`Plant V${i}`]);
    const arch = norm(row[`Arch Type ${i}`]);

    if (bp || plant || arch) {
      ventities.push({
        BPartner: bp,
        Plant: plant,
        ArchType: arch
      });
    }
  }

  return {
    BpSFrom: norm(row["Ship From Business Partner"]),
    PlantSFrom: norm(row["Ship From Plant"]),
    ErSFrom: norm(row["Economic Region Ship From"]),
    BpSTo: norm(row["Ship To Business Partner"]),
    PlantSTo: norm(row["Ship To Plant"]),
    ErSTo: norm(row["Economic Region Ship To"]),
    ArchType: norm(row["Ship To Arch Type"]),
    Ventities: ventities
  };
}

async function checkMatchingProductFlowsMassUpload(excelRow) {

  const transformedData = transformExcelRowToPF(excelRow);

  const existingDuplicates = await checkMatchingProductFlows(transformedData);

  if (existingDuplicates.length > 0) {
    return [{
      row: 1,
      productFlowIds: existingDuplicates
    }];
  }

  return [];
}

async function checkMatchingProductFlows(data, ID=null) {

  function norm(v) {
    return (v ?? '').toString().trim();
  }

  function buildSignature(header, ves) {
    return {
      shipFrom: `${norm(header.BpSFrom)}|${norm(header.PlantSFrom)}|${norm(header.ErSFrom)}`,
      shipTo: `${norm(header.BpSTo)}|${norm(header.PlantSTo)}|${norm(header.ErSTo)}`,
      shipToArch: norm(header.ArchType),

      ves: (ves || [])
        .map(v => ({
          key: `${norm(v.BPartner)}|${norm(v.Plant)}`,
          arch: norm(v.ArchType)
        }))
        .sort((a, b) =>
          (a.key + a.arch).localeCompare(b.key + b.arch)
        )

    };
  }

  const duplicates = []
  const inputSignature = buildSignature(data, data.Ventities,data.Items);

  /* Fetch existing Product Flows (ACTIVE ONLY) */
  const query = SELECT.from("jnj.com.zbuvcm47419.PfcHeaders", a => {
    a`.*`,
      a.Ventities(c => {
        c`.*`;
      });
      a.Items(i => {
      i`Status`,
      i`ApprStatus`;
    });
  });

  // Exclude current record during update
  if (ID) {
    query.where({
      ID: { '!=': ID }
    });
  }

  // Fetch existing Product Flows
  const existingPFs = await cds.run(query);

  // for (const pf of existingPFs) {

  //   const dbSignature = buildSignature(pf, pf.Ventities);

  //   const isDuplicate =
  //     inputSignature.shipFrom === dbSignature.shipFrom
  //     &&
  //     inputSignature.shipTo === dbSignature.shipTo
  //   &&
  //   inputSignature.shipToArch === dbSignature.shipToArch &&
  //     JSON.stringify(inputSignature.ves) === JSON.stringify(dbSignature.ves) && dbSignature;

  //   if (isDuplicate) {

  //     duplicates.push(pf.CatId)
  //   }
  // }
  for (const pf of existingPFs) {
 
  const dbSignature = buildSignature(pf, pf.Ventities);
 
  const isDuplicate =
    inputSignature.shipFrom === dbSignature.shipFrom &&
    inputSignature.shipTo === dbSignature.shipTo &&
    inputSignature.shipToArch.toLowerCase() === dbSignature.shipToArch.toLowerCase() &&
    JSON.stringify(inputSignature.ves) === JSON.stringify(dbSignature.ves);
 
  if (!isDuplicate) {
    continue;
  }
 
  // Check if all items are Inactive + Approved
  const skipValidation = (pf.Items || []).every(item =>
    (norm(item.Status).toLowerCase() === "inactive" &&
    norm(item.ApprStatus).toLowerCase() === "approved") || (norm(item.Status).toLowerCase() === "new" &&
    norm(item.ApprStatus).toLowerCase() === "rejected")
  );
 
  // Ignore this duplicate
  if (skipValidation) {
    continue;
  }
 
  // Otherwise, duplicate exists
  duplicates.push(pf.CatId);
}

  return duplicates
}

function errorMessages(duplicateRecords, bundle) {
  // Input validation
  if (!Array.isArray(duplicateRecords)) {
    return "";
  }

  if (duplicateRecords.length === 0) {
    return "";
  }

  // Filter out invalid records and remove duplicates
  const validRecords = duplicateRecords.filter(record =>
    record &&
    typeof record === 'object' &&
    (record.MatBrand || record.Matnr || record.CatId)
  );

  const uniqueRecords = removeDuplicateErrors(validRecords);

  if (uniqueRecords.length === 0) {
    return "";
  }

  const errorLines = uniqueRecords.map((record, index) => {
    const lineNumber = index + 1;
    const materialBrand = record.MatBrand || "N/A";
    const materialNumber = record.Matnr || "N/A";
     const materialtYPE = record.MatType || "N/A";
    const catId = record.CatId || "N/A";

    return `${lineNumber}) ${bundle.getText("materialBrand")}: ${materialBrand} ${bundle.getText("and")} ${bundle.getText("materialNumber")}: ${materialNumber} ${bundle.getText("and")} ${bundle.getText("materialtYPE")}: ${materialtYPE} ${bundle.getText("alreadyExists")}${catId}`;
  });

  return bundle.getText("errorItem") + errorLines.join('\n');
}

function removeDuplicateErrors(records) {
  const seen = new Set();
  return records.filter(record => {
    const key = `${record.MatBrand}|${record.Matnr}|${record.CatId}|${record.MatType}`;
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
}



async function InitiateWorkFLow(context, req) {
  const workflow = await cds.connect.to("workflowService");

  const response = await workflow.tx(req).post(constants.workflowURL, {
    "definitionId": constants.definitionId,
    "context": context
  })


  return response;
}

async function setEcoRegion(req, odataConnect, SfBp, SfPlant, StBp, StPlant) {
  let bpCountryKeyList = [];
  let plantCountryKeyList = [];
  let EcSf = '';
  let EcSt = '';
  let cfkey = '';
  let ctkey = '';
  if (SfPlant || StPlant) {
    plantCountryKeyList = await odataConnect.tx(req).get('/countryplantkey');
    if (SfPlant) {
      cfkey = plantCountryKeyList.filter((item) => { return item.Plant === String(SfPlant) });
      if (cfkey.length > 0) {
        EcSf = await onDbOps.getEcoRegionDetail(cfkey[0].Country);

      }
    }
    if (StPlant) {
      ctkey = plantCountryKeyList.filter((item) => { return item.Plant === String(StPlant) });
      if (ctkey.length > 0) {
        EcSt = await onDbOps.getEcoRegionDetail(ctkey[0].Country);

      }
    }
  } else {
    bpCountryKeyList = await odataConnect.tx(req).get('/countrybpkey');
    if (SfBp) {
      cfkey = bpCountryKeyList.filter((item) => { return item.BusinessPartner === String(SfBp) });
      if (cfkey.length > 0) {
        EcSf = await onDbOps.getEcoRegionDetail(cfkey[0].Country);


      }
    }
    if (StBp) {
      ctkey = bpCountryKeyList.filter((item) => { return item.BusinessPartner === String(StBp) });
      if (ctkey.length > 0) {
        EcSt = await onDbOps.getEcoRegionDetail(ctkey[0].Country);

      }
    }
  }

  return {
    EcSf, EcSt
  }


}




async function updateWorkFlowId(req, ID, Catid, context, items, bundle) {

  const updatedRecord = [];

  const savedMaterialList = await cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcItems').where({
    'CatId': Catid
  }));

  const newItemsList = items.filter((item) => item.ApprStatus==='New');

  let existingrecfromItems = items.filter((item) => item.ApprStatus!=='New');

  const savedMatLookUp = new Map();
  if (savedMaterialList) {
    for (let record of savedMaterialList) {
      const key = `${record.CatId}|${record.Matnr}|${record.MatBrand}`;
      if (!savedMatLookUp.has(key)) {
        savedMatLookUp.set(key, []);
      }
      savedMatLookUp.get(key).push(record);
    }

    for (let record of existingrecfromItems) {
      const key = `${record.CatId}|${record.Matnr}|${record.MatBrand}`;

      const matchedRecord = savedMatLookUp.get(key);
      if (matchedRecord) {
        // || record.Block !== matchedRecord[0].Block
        if (record.VTo !== matchedRecord[0].VTo || record.Status !== matchedRecord[0].Status || record.ApprStatus==='Reworked') {
          updatedRecord.push({
            CatId: record.CatId,
            MatBrand: record.MatBrand,
            Matnr: record.Matnr,
            Status: record.Status,
            StatusChanged: (record.ApprStatus === 'Reworked' || record.Status !== matchedRecord[0].Status) ? true : false

          });
        }

      }
      if(!matchedRecord && record.ApprStatus==='Reworked'){
          updatedRecord.push({
            CatId: record.CatId,
            MatBrand: record.MatBrand,
            Matnr: record.Matnr,
            Status: record.Status,
            StatusChanged: (record.ApprStatus === 'Reworked' || record.Status !== matchedRecord[0].Status) ? true : false,
            reworked:record.ApprStatus === 'Reworked' 
        });
      }
    }

    if (updatedRecord.length > 0) {
      const workflowResponse = await InitiateWorkFLow(context, req);
      const { id } = workflowResponse;
      if (id) {

        for (let record of updatedRecord) {
          req.data.Items.forEach(item => {
            if (item.CatId === record.CatId && item.Matnr === record.Matnr && item.MatBrand === record.MatBrand) {
              item.WorkfInstId = id;
              item.vToFieldControl = 1;
              item.MatnrFeildControl = 1;
              item.MatDescFeildControl = 1;
              item.MatTypeFeildControl = 1;
              item.MatBrandFeildControl = 1;
              item.VFromFeildControl = 1;
              item.rFeildControl = 1;
              item.criticality = 2;
              // ***** Defect - JGHJ-75797 ****** START *****
              item.pFStatus = record.StatusChanged
                ? (record.Status === "Block" || record?.reworked ? "Change In The Flow" : "")
                : "";
              // ***** Defect - JGHJ-75797 ****** END *****

              item.Status = record.Status
              item.ApprStatus = bundle.getText("pendingForApproval");
            }
          })
        }

        req.data.Items.forEach(item => {
          if (item.ApprStatus === 'New') {
            item.WorkfInstId = id;
            item.vToFieldControl = 1;
            item.MatnrFeildControl = 1;
            item.MatDescFeildControl = 1;
            item.MatTypeFeildControl = 1;
            item.MatBrandFeildControl = 1;
            item.VFromFeildControl = 1;
            item.rFeildControl = 1;
            item.criticality = 2;
            item.ApprStatus = bundle.getText("pendingForApproval");
          }
        });

      }
    }



    if (newItemsList.length > 0 && updatedRecord.length === 0) {
      const workflowResponse = await InitiateWorkFLow(context, req);
      const { id } = workflowResponse;

      req.data.Items.forEach(item => {
        if (item.ApprStatus === 'New') {
          item.WorkfInstId = id;
          item.vToFieldControl = 1;
          item.rFeildControl = 1;
          item.MatnrFeildControl = 1;
          item.MatDescFeildControl = 1;
          item.MatTypeFeildControl = 1;
          item.MatBrandFeildControl = 1;
          item.VFromFeildControl = 1;
          item.ApprStatus = bundle.getText("pendingForApproval");
          item.criticality = 2;
        }
      });

    }


  }


}

async function checkEcoValid(eco, Bp, Plant, odata) {
  let ctryKey;

  if (Bp) {
    const queryData = { BusinessPartner: Bp };
    const result = await odata.run(
      SELECT.columns('Country').from('Massbpplantcntrykey').where(queryData)
    );
    ctryKey = result?.[0]?.Country;
  } else if (Plant) {
    const result = await odata.run(
      SELECT.columns('Country').from('Massbpplantcntrykey').where({ Plant })
    );
    ctryKey = result?.[0]?.Country;
  }

  if (!ctryKey) {
    throw new Error(`No country found for BP: ${Bp || ''}, Plant: ${Plant || ''}`);
  }

  const ecoRegionResult = await cds.run(
    SELECT.from('jnj.com.zbuvcm47419.PfcEcoRegions').where({ CountryCode: ctryKey })
  );

  const ecoCode = ecoRegionResult?.[0]?.EcoRegCode;

  if (ecoCode !== eco) {
    throw new Error(`${eco} is not valid eco region for entered Businness partner or Plant, please enter correct eco region`);
  }
}


module.exports = { checkMatchingProductFlowsMassUpload,checkEcoValid, checkMatchingProductFlows, validateData, matDuplicateChk, errorMessages, InitiateWorkFLow, setEcoRegion, updateWorkFlowId }