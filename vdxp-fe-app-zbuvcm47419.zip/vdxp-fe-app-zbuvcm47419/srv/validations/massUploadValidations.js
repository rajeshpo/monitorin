// // --------------------------------------------------------------------------------------------------------------------*
// // Application Name : Product Flow Catalog
// // Object Id       : ZBUVCM47419
// // Release         : 1
// // Version         : 0.01
// // Description     : Validation module for Product Flow Catalog Application
// // ----------------------------------------------------------------------------*
// // Descriptions: it will have all the validations at the time of mass upload screen
// // ----------------------------------------------------------------------------*
// // Change Log:
// //    Date     |       Author        |   Change Id   |   Change Description
// 26-03-2026      RChitike@its.jnj.com     50440096        TIME-FIN-DEV-PFCEnhanceme-Developement
// // -----------------------------------------------------------------------------



const BASE_KEYS = [
  "Product Flow ID",
  // "Flow ID",
  "Ship From Business Partner",
  "Ship From Plant",
  "Economic Region Ship From",
  "Ship To Business Partner",
  "Ship To Plant",
  "Economic Region Ship To",
  "Ship To Arch Type"
];

const VE_KEYS = Array.from({ length: 6 }, (_, i) => [
  `Plant V${i + 1}`,
  `Business Partner V${i + 1}`,
  `Arch Type ${i + 1}`
]).flat();

const GROUP_KEYS = [...BASE_KEYS, ...VE_KEYS];

function getGroupingKey(entry) {

  return GROUP_KEYS.map((key) => entry[key] || "").join("||");
}

function groupProductFlows(data) {
  const groupMap = new Map();
  let idCounter = 1;

  for (const entry of data) {
    const key = getGroupingKey(entry);
    if (!groupMap.has(key)) {
      groupMap.set(key, {
        vcaId: `VCA${String(idCounter).padStart(3, "0")}`,
        entries: []
      });
      idCounter++;
    }
    groupMap.get(key).entries.push(entry);
  }

  // Grouping result with VCA ID
  const grouped = [];
  for (const group of groupMap.values()) {
    for (const entry of group.entries) {
      grouped.push({
        ...entry,
        "Group ID": group.vcaId
      });
    }
  }

  // Optional: Print group counts
  // console.log("\nGroup counts:");
  for (const [_, group] of groupMap) {
    // console.log(`${group.vcaId}: ${group.entries.length} records`);
  }

  return grouped;
}

const DUPLICATE_KEYS = [
  "Ship From Business Partner",
  "Ship From Plant",
  "Economic Region Ship From",
  "Ship To Business Partner",
  "Ship To Plant",
  "Economic Region Ship To",
  "Material Number",
  "Material Profit Center",
  "Material Type"
];

function normalize(value) {
  return (value || '').toString().trim().toUpperCase();
}

function getDuplicateKey(entry) {
  return DUPLICATE_KEYS.map((key) => normalize(entry[key])).join('||');
}

function checkExcelDuplicates(data) {
  const seen = new Map();
  const duplicates = [];

  data.forEach((entry, index) => {
    const key = getDuplicateKey(entry);
    if (seen.has(key)) {
      duplicates.push({ row: index + 1, duplicateOf: seen.get(key) + 1 });
    } else {
      seen.set(key, index);
    }
  });

  return duplicates;
}

function checkAgainstDatabaseForMassUpload(uploadedData, dbRecords) {
  const dbKeys = new Set();

  dbRecords.forEach(header => {
    header.Items.forEach(item => {
      const dbKey = [
        header.BpSFrom,
        header.PlantSFrom,
        header.ErSFrom,
        header.BpSTo,
        header.PlantSTo,
        header.ErSTo,
        item.Matnr,
        item.MatBrand,
        item.MatType
      ].map(normalize).join('||');
      dbKeys.add(dbKey);
    });
  });

  const duplicates = [];
  const duplicateRow=[];
  uploadedData.forEach((header, headerIndex) => {
    header.Items.forEach((item, itemIndex) => {
      const entryKey = [
        header.BpSFrom,
        header.PlantSFrom,
        header.ErSFrom,
        header.BpSTo,
        header.PlantSTo,
        header.ErSTo,
        item.Matnr,
        item.MatBrand,
        item.MatType
      ].map(normalize).join('||');

      if (dbKeys.has(entryKey)) {
        duplicates.push({
          row: headerIndex + 1,
          item: itemIndex + 1
        });

         let existingRecord = findExistingRecord(entryKey, dbRecords);
         existingRecord.row = headerIndex + 1;

        duplicateRow.push(existingRecord);
      }
    });
  });

  return {duplicates,duplicateRow};
}


function findExistingRecord(entryKey, dbRecords) {
  for (const header of dbRecords) {
    for (const item of header.Items) {

      const dbKey = [
        header.BpSFrom,
        header.PlantSFrom,
        header.ErSFrom,
        header.BpSTo,
        header.PlantSTo,
        header.ErSTo,
        item.Matnr,
        item.MatBrand,
        item.MatType
      ].map(normalize).join('||');

      if (dbKey === entryKey) {
        return item;
      }
    }
  }
  return null;
}

function findMatchingRecords(entryKey, dbRecords) {
  const matches = [];

  for (const header of dbRecords) {
    for (const item of header.Items) {
      const dbKey = [
        header.BpSFrom,
        header.PlantSFrom,
        header.ErSFrom,
        header.BpSTo,
        header.PlantSTo,
        header.ErSTo,
        item.Matnr,
        item.MatBrand,
        item.MatType
      ].map(normalize).join('||');

      if (dbKey === entryKey) {
        matches.push(item);
      }
    }
  }

  return matches; // [] if no matches
}

function checkAgainstDatabase(uploadedData, dbRecords) {
  const dbKeys = new Set();

  dbRecords.forEach((header) => {
    header.Items.forEach((item) => {
      const dbKey = [
        header.BpSFrom,
        header.PlantSFrom,
        header.ErSFrom,
        header.BpSTo,
        header.PlantSTo,
        header.ErSTo,
        item.Matnr,
        item.MatBrand,
        item.MatType
      ].map(normalize).join('||');

      dbKeys.add(dbKey);
    });
  });

  const duplicates = [];
  let duplicateRow=[]

  uploadedData.forEach((entry, index) => {
    const entryKey = getDuplicateKey(entry);

    if (dbKeys.has(entryKey)) {
      duplicates.push({ row: index + 1 });
      const existingRecord = findMatchingRecords(entryKey, dbRecords);
      // existingRecord.row = index + 1;
      // duplicateRow.push(existingRecord);
      if (existingRecord && existingRecord.length > 0) {
        for (const match of existingRecord) {
          const annotated = { ...match, row: index + 1 }; // clone + add row
          duplicateRow.push(annotated);
        }
      }
      
    }
  });

  return {duplicates,duplicateRow};
}



module.exports = { checkExcelDuplicates, checkAgainstDatabase, groupProductFlows, checkAgainstDatabaseForMassUpload }