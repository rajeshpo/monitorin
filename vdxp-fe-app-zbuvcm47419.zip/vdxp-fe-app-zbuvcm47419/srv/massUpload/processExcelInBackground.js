const xsenv = require("@sap/xsenv");
const { processExcelBuffer } = require("./processExcelBuffer");
const axios = require("axios");
const FormData = require("form-data");
const { REPOSITORY_ID } = process.env
/**
processes excel in background for validations in excel file and s4
*/
async function processExcelInTheBackground(data, req, token, bundle, ZSD_VCM_PRODUCTFLOW, jsonData1, sheetName, attachment,outputColumns,veCount) {
    try {
        function stripLeadingZeros(v) {
            if (v == null) return v;                  // keep null/undefined unchanged
            if (typeof v === 'number' || typeof v === 'boolean') return v; // preserve numbers/booleans
            const s = String(v).trim();
            if (s === '') return s;                   // keep empty string unchanged

            // remove leading zeros; if the string was all zeros, return "0" (safer than empty)
            const stripped = s.replace(/^0+/, '');
            return stripped === '' ? '0' : stripped;
        }

        jsonData1.forEach(row => {
            for (const key in row) {
                if (row.hasOwnProperty(key)) {
                    row[key] = stripLeadingZeros(row[key]);
                }
            }
        });
        const { buffer: modifiedBuffer, hasError } =
            await processExcelBuffer(req, ZSD_VCM_PRODUCTFLOW, bundle, jsonData1, sheetName,outputColumns,veCount);

        if (!hasError) {

            attachment.note = bundle.getText('validationSuccessful');
            data.attachments = [attachment];
            await updateExcelUploadRecord(data);
            return;
        }

        await deleteExistingFile(attachment.url, token);
        const uploadMetadata = await uploadValidatedExcel(
            data.ID,
            modifiedBuffer,
            token
        );
        await updateAttachmentData(data, uploadMetadata, true, bundle);
        await updateExcelUploadRecord(data);
    } catch (error) {
        console.error("Background Excel processing failed:", error.message);
    }
}

/**
* Retrieves the SDM service configuration from environment
* @returns {Object|null}
*/
function getSdmService() {
    try {
        return xsenv.getServices({ sdm: { tag: "sdm" } });
    } catch (error) {
        console.error(
            "[dms-service] - Please maintain the sdm service in the VCAP_SERVICES"
        );
        return null;
    }
}

/**
* Downloads an Excel file from DMS
* @param {string} url - The download URL
* @param {string} token - The OAuth token
* @returns {Promise<Buffer>}
*/
async function downloadExcelFile(url, token) {
    const response = await axios.get(url, {
        headers: { Accept: "*/*", Authorization: token },
        responseType: "arraybuffer",
    });
    return Buffer.from(response.data, "binary");
}

/**
 * Fetches an OAuth token for the SDM service
 * @param {Object} services - The SDM services object
 * @returns {Promise<string>}
 */
async function fetchOAuthToken(services) {
    const { url, clientid, clientsecret } = services.sdm.uaa;
    const tokenUrl = `${url}/oauth/token?grant_type=client_credentials&response_type=token`;
    const config = {
        headers: {
            Authorization:
                "Basic " +
                Buffer.from(`${clientid}:${clientsecret}`).toString("base64"),
        },
    };
    const response = await axios.get(tokenUrl, config);
    return response.data.access_token;
}


/**
* Updates the attachment data for an ExcelUpload record
* @param {Object} data - The ExcelUpload data object
* @param {Object} props - The DMS properties object
* @param {boolean} hasError - Whether the file has validation errors
* @returns {void}
*/
async function updateAttachmentData(data, props, hasError, bundle) {
    data.attachments = [];
    data.attachments.push({
        ID: cds.utils.uuid(),
        filename: props["cmis:contentStreamFileName"].value,
        folderId: props["sap:parentIds"].value?.[0],
        mimeType: props["cmis:contentStreamMimeType"].value,
        note: hasError
            ? bundle.getText('ReUpload')
            : bundle.getText('validationSuccessful'),
        repositoryId: `${REPOSITORY_ID}`,
        status: "Clean",
        up__ID: data.ID,
        up__user: data.user,
        url: props["cmis:objectId"].value,
    });
}

/**
* Updates the ExcelUpload record in the database
* @param {Object} data - The ExcelUpload data object
* @returns {Promise<void>}
*/
async function updateExcelUploadRecord(data) {
    await UPDATE("jnj.com.zbuvcm47419.ExcelUpload")
        .with(data)
        .where({ ID: data.ID, user: data.user });
}

/**
* Deletes an existing file from DMS
* @param {string} objectId - The object ID of the file
* @param {string} token - The OAuth token
* @returns {Promise<void>}
*/
async function deleteExistingFile(objectId, token) {
    const services = getSdmService();
    if (!services?.sdm) return;
    const repoUrl = services.sdm.uri
    const deleteUrl = `${repoUrl}browser/${REPOSITORY_ID}/root?objectId=${objectId}&cmisaction=delete`;
    await axios.post(deleteUrl, null, { headers: { Authorization: token } });
}




/**
* Uploads a validated Excel file to DMS
* @param {string} folderId - The folder ID
* @param {Buffer} buffer - The Excel file buffer
* @param {string} token - The OAuth token
* @returns {Promise<Object>}
*/
async function uploadValidatedExcel(folderId, buffer, token) {
    const form = new FormData();
    form.append("cmisaction", "createDocument");
    form.append("propertyId[0]", "cmis:name");
    form.append("propertyValue[0]", "validated.xlsx");
    form.append("propertyId[1]", "cmis:objectTypeId");
    form.append("propertyValue[1]", "cmis:document");
    form.append("_charset_", "UTF-8");
    form.append("media", buffer, {
        filename: generateValidationFileName(),
        contentType:
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const services = getSdmService();
    if (!services?.sdm) return;
    const repoUrl = services.sdm.uri
    const uploadUrl = `${repoUrl}browser/${REPOSITORY_ID}/root/${folderId}`;
    const response = await axios.post(uploadUrl, form, {
        headers: {
            ...form.getHeaders(),
            Authorization: token,
            DataServiceVersion: "2.0",
            Accept: "application/json",
        },
    });
    return response.data.properties;
}

/**
* Generates a filename for validation error Excel files
* @returns {string}
*/
function generateValidationFileName() {
    const now = new Date();
    const timestamp = now.toISOString().replace(/[-T:.Z]/g, "").slice(0, 14); // e.g. 20250628_154231
    return `Validation_Errors_${timestamp}.xlsx`;
}



module.exports = { processExcelInTheBackground, getSdmService, downloadExcelFile, fetchOAuthToken, updateExcelUploadRecord, deleteExistingFile }