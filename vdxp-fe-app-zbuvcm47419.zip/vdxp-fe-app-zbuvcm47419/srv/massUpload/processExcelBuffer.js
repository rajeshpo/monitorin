// // --------------------------------------------------------------------------------------------------------------------*
// // Application Name : Product Flow Catalog
// // Object Id       : ZBUVCM47419
// // Release         : 1
// // Version         : 0.01
// // Description     : Validation module for Product Flow Catalog Application
// // ----------------------------------------------------------------------------*
// // Descriptions: it will have all the validations at the time of mass upload screen
// // ----------------------------------------------------------------------------*
// // Change Log:
// //    Date     |       Author        |   Change Id   |   Change Description
// 26-03-2026      RChitike@its.jnj.com     50440096        TIME-FIN-DEV-PFCEnhanceme-Developement
// // -----------------------------------------------------------------------------

const cds = require('@sap/cds');
const xlsx = require("xlsx");
const { groupProductFlows, checkExcelDuplicates, checkAgainstDatabaseForMassUpload, checkAgainstDatabase } = require('../validations/massUploadValidations');
const constant = require('../config/constant');
const { checkMatchingProductFlowsMassUpload } = require('../validations/validation');
const logger = cds.log('zbuvcm47419-productFlow');
/**
* Processes the Excel buffer, runs validations, and returns the modified buffer and error status
* @param {Buffer} buffer - The Excel file buffer
* @param {Object} req - The request object
* @param {Function} groupProductFlows - Grouping function
* @param {Function} checkAgainstDatabase - DB check function
* @param {Function} checkExcelDuplicates - Excel duplicate check function
* @param {Object} ZSD_VCM_PRODUCTFLOW - CDS service
* @returns {Promise<{buffer: Buffer, hasError: boolean}>}
*/



async function processExcelBuffer(req, ZSD_VCM_PRODUCTFLOW, bundle, jsonData1, sheetName, outputColumns,veCount) {
  try {
var dateErrors=[];
    //  1) Robust converter: no throw — collect errors instead
    function convertFieldsToString(dataArray) {
  const dashRegex = /^\d{4}-\d{2}-\d{2}$/;
  const slashRegex = /^\d{4}\/\d{2}\/\d{2}$/;
  const ymd8Regex = /^\d{8}$/;

  const pad2 = (n) => String(n).padStart(2, "0");
  const daysInMonth = (y, m) => new Date(y, m, 0).getDate(); // month is 1-12

  const isValidDateParts = (y, m, d) => {
    if (m < 1 || m > 12) return false;
    const dim = daysInMonth(y, m);
    return d >= 1 && d <= dim;
  };

  return dataArray.map((obj, idx) => {
    const newObj = {};
    const fieldErrors = [];

    for (const [key, value] of Object.entries(obj)) {
      // treat null/undefined or empty-string (after trim) as empty -> return outright
      if (value == null || (typeof value === "string" && value.trim() === "")) {
        newObj[key] = "";
        continue;
      }

      if (key === "Valid From" || key === "Valid To") {
        // Case 1: Date object
        if (value instanceof Date && !isNaN(value)) {
          const yyyy = value.getFullYear();
          const mm = pad2(value.getMonth() + 1);
          const dd = pad2(value.getDate());
          newObj[key] = `${yyyy}-${mm}-${dd}`;

        // Case 2/3: string or numeric that looks like a date
        } else if (typeof value === "string" || typeof value === "number") {
          const s = String(value).trim();

          let yyyy, mm, dd, valid = false;

          if (dashRegex.test(s)) {
            [yyyy, mm, dd] = s.split("-");
            const y = Number(yyyy), mo = Number(mm), da = Number(dd);
            valid = isValidDateParts(y, mo, da);
            if (valid) newObj[key] = `${yyyy}-${pad2(mo)}-${pad2(da)}`;

          } else if (slashRegex.test(s)) {
            [yyyy, mm, dd] = s.split("/");
            const y = Number(yyyy), mo = Number(mm), da = Number(dd);
            valid = isValidDateParts(y, mo, da);
            if (valid) newObj[key] = `${yyyy}-${pad2(mo)}-${pad2(da)}`;

          } else if (ymd8Regex.test(s)) {               // YYYYMMDD
            yyyy = s.slice(0, 4);
            mm = s.slice(4, 6);
            dd = s.slice(6, 8);
            const y = Number(yyyy), mo = Number(mm), da = Number(dd);
            valid = isValidDateParts(y, mo, da);
            if (valid) newObj[key] = `${yyyy}-${pad2(mo)}-${pad2(da)}`;

          } else {
            // unknown string/number format
            fieldErrors.push(
              `${bundle.getText('Row')} ${idx + 1}: "${key}" ${bundle.getText('dateFormatError')} "${value}"`
            );
            newObj[key] = value;
          }

          if (!valid && (dashRegex.test(s) || slashRegex.test(s) || ymd8Regex.test(s))) {
            // format looked like a date but had invalid month/day (e.g., 20242212)
            fieldErrors.push(
              `${bundle.getText('Row')} ${idx + 1}: "${key}" ${bundle.getText('invalidDateParts')} "${value}"`
            );
            newObj[key] = value;
          }

        } else {
          // invalid type for date
          fieldErrors.push(
            `${bundle.getText('Row')} ${idx + 1}: "${key}" ${bundle.getText('validDateString')} ${value}`
          );
          newObj[key] = value;
        }

      } else {
        // Non-date fields → stringify safely
        newObj[key] = value != null ? String(value) : "";
      }
    }
   dateErrors = fieldErrors;
    // Append validation errors to comments
    newObj.comments = [
      obj.comments || "",
      fieldErrors.join("; ")
    ].filter(Boolean).join(" / ");

    return newObj;
  });
}


    let jsonData = convertFieldsToString(jsonData1);

    function normalize(val) {
      return (val ?? "")
        .toString()
        .toLowerCase()
        .replace(/\s+/g, " ")   // collapse multiple spaces
        .trim();
    }

    // Build lookup map once outside
    async function buildArchMapForValue(value) {
          // Query matching rows (case-insensitive)
          const rows = await cds.run(
            SELECT.from('jnj.com.zbuvcm47419.PfcArchTypeMapping')
              .columns('ArchType') // tagged template parameterizes safely
          );
        
          // rows may be an array; if your CDS returns a single object when only one row matches,
          // normalize to array form for mapping:
          const hits = Array.isArray(rows) ? rows : (rows ? [rows] : []);
        
          // Build Map: key = normalized archType, value = original archType
          const archMapL = new Map(
            hits
              .filter(r => r && r.ArchType != null)           // guard against null/undefined
               .map(r => [normalize(r.ArchType), r.ArchType])   // normalized key, original value
          );
        
          return archMapL;
        }
    const archMap = await buildArchMapForValue();
   
    async function getValidEcoRegions() {
      const { PfcEcoRegions } = cds.entities('jnj.com.zbuvcm47419');
      const ecoRegions = await cds.run(
        SELECT.from(PfcEcoRegions).columns('EcoRegCode')
      );

      return new Set(
        ecoRegions
          .map(e => e.EcoRegCode)
          .filter(Boolean)
          .map(code => code.toString().trim().toUpperCase())
      );
    }

    //  2) Main validation — same logic, adds to comments
    async function validateProductFlows(json_data) {
      let hasValidationErrors = false;

      const validEcoRegions = await getValidEcoRegions();
      const validated = json_data.map((obj) => {
        const errors = [];

        // Validate ProdId only if it's not empty
        if (obj["Product Flow ID"] && !obj["Product Flow ID"].startsWith("PFL")) {
          // if (obj["Flow ID"] && !obj["Flow ID"].startsWith("PFL")) {
          errors.push(bundle.getText("errorItem") + " " + bundle.getText("prodIdMustStartWithPFL"));
        }

        const shipToArch = obj["Ship To Arch Type"]?.toString().trim();

        if (!shipToArch) {
          errors.push(bundle.getText('requiredSFArchType'));
        } else {
          const normalizedShipToArch = shipToArch.toLowerCase();

          if (!archMap.has(normalizedShipToArch)) {
            errors.push(
              `"Ship To Arch Type" ${bundle.getText('invalidArchType')} "${shipToArch}"`
            );
          } else {

            const normalizedShipToArch = normalize(obj["Ship To Arch Type"]);
            if (normalizedShipToArch) {
              obj["Ship To Arch Type"] = normalizedShipToArch || obj["Ship To Arch Type"];

            } else {
              console.warn("No match found for:", obj["Ship To Arch Type"]);
            }
          }
        }


        if (
          !obj["Ship From Business Partner"] &&
          !obj["Ship From Plant"] &&
          !obj["Economic Region Ship From"]
        ) {
          errors.push(
            bundle.getText('requiredSf')
          );
        }

        if (
          !obj["Ship To Business Partner"] &&
          !obj["Ship To Plant"] &&
          !obj["Economic Region Ship To"]
        ) {
          errors.push(
            bundle.getText('requiredSTo')
          );
        }

        if ((obj["Ship From Business Partner"] || obj["Ship From Plant"]) && obj["Economic Region Ship From"]) {
          errors.push(bundle.getText("errorItem") + " " + bundle.getText("EitherBpOrEcoRegionInSFrom"));
        }

        if ((obj["Ship To Business Partner"] || obj["Ship To Plant"]) && obj["Economic Region Ship To"]) {
          errors.push(bundle.getText("errorItem") + " " + bundle.getText("EitherBpOrEcoRegionInSTo"));
        }

        if (obj["Economic Region Ship From"] || obj["Economic Region Ship To"]) {

          const erSF = obj["Economic Region Ship From"]
            ?.toString()
            .trim()
            .toUpperCase();

          const erST = obj["Economic Region Ship To"]
            ?.toString()
            .trim()
            .toUpperCase();

          if (erSF && !validEcoRegions.has(erSF)) {
            errors.push(
              `"Economic Region Ship From" is invalid: "${obj["Economic Region Ship From"]}"`
            );
          }

          if (erST && !validEcoRegions.has(erST)) {
            errors.push(
              `"Economic Region Ship To" is invalid: "${obj["Economic Region Ship To"]}"`
            );
          }

        }


        if (!obj["Material Number"] && !obj["Material Profit Center"] && !obj["Material Type"]) {
          errors.push(
            bundle.getText('MatTypeNeccessary')
          );
        }

        if (obj["Material Number"] && !obj["Material Profit Center"]) {
          errors.push(
            bundle.getText("MatTypeNeccessary")
          );
        }

        if (obj["Material Number"] && obj["Material Profit Center"] && !obj["Material Type"]) {
          errors.push(
            bundle.getText("MatTypeNeccessary")
          );
        }

        if (!obj["Material Number"] && obj["Material Profit Center"] && !obj["Material Type"]) {
          errors.push(
            bundle.getText("MatTypeOnlyNeccessary")
          );
        }
        
        // if (obj["Material Type"] && !obj["Material Profit Center"] && !obj["Material Number"]) {
        //   errors.push(
        //     bundle.getText("MatBrandTypeNeccessary")
        //   );
        // }

        if (obj["Valid From"] && obj["Valid To"]) {
          const fromDate = new Date(obj["Valid From"]);
          const toDate = new Date(obj["Valid To"]);
          if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime())) {
            errors.push(bundle.getText('notValidDates'));
          } else if (toDate <= fromDate) {
            errors.push(bundle.getText('validFromToError'));
          }
        }

        const validFrom = obj["Valid From"];

        if (typeof validFrom === "string" && validFrom.trim() === "") {
          obj["Valid From"] = null;
        }

        if (!obj["Valid To"]) {
          obj["Valid To"] = '9999-12-31'
        }

        // let hasAtLeastOneVE = false;
        // for (let i = 1; i <= 6; i++) {
        //   const bp = obj[`Business Partner V${i}`];
        //   const plant = obj[`Plant V${i}`];
        //   if (bp || plant) {
        //     hasAtLeastOneVE = true;
        //     break;
        //   }
        // }
        // if (!hasAtLeastOneVE) {
        //   errors.push(
        //     bundle.getText('requiredVE')
        //   );
        // }

        // ***** JGHJ-71574 ***** R2.2 START *****

        // Combined loop: ArchType + VE sequence
        let lastSeen = 0;

        for (let i = 1; i <= veCount; i++) {
          const archKey = `Arch Type ${i}`;
          const bpKey = `Business Partner V${i}`;
          const plantKey = `Plant V${i}`;

          const arch = obj[archKey]?.toString().trim();
          const bp = obj[bpKey]?.toString().trim();
          const plant = obj[plantKey]?.toString().trim();

          const hasVE = !!(arch || bp || plant);

          if (hasVE) {
            // --- ArchType validation ---
            if (!arch) {
              errors.push(
                `${bundle.getText('Row')} ${obj.RowNum || ''}: Virtual Entity ${i} ArchType is Mandatory`
              );
            } else {
              // const normalized = normalize(obj["Ship To Arch Type"]);
              const normalized = normalize(arch);
             
              if (!archMap.has(normalized)) {
                errors.push(
                  `${bundle.getText('Row')} ${obj.RowNum || ''}: "${archKey}" ${bundle.getText('invalidArchType')} "${arch}"`
                );
              } else {
                obj[archKey] = archMap.get(normalized);
              }

              if (!bp && !plant) {
                errors.push(
                  `${bundle.getText('Row')} ${obj.RowNum || ''}: Virtual Entity ${i} Business Partner or Plant is mandatory when ArchType is provided`
                );
              }
            }

            // --- VE sequence validation ---
            if (i > lastSeen + 1) {
              errors.push(`${bundle.getText('veSequenceError')}`);
            }
            lastSeen = i;
          }
        }


        if (errors.length > 0) {
          hasValidationErrors = true;
        }

        return {
          ...obj,
          comments: [obj.comments || "", errors.join("; ")].filter(Boolean).join(" / ")
        };
      });
      // ***** JGHJ-71574 ***** R2.2 END *****

      return { validated, hasValidationErrors };
    }

    const { validated, hasValidationErrors } =await validateProductFlows(jsonData);

    const groupedData = groupProductFlows(validated);
    const duplicateRows = checkExcelDuplicates(validated);

    const dbPfcList = await cds.run(
      SELECT.from("jnj.com.zbuvcm47419.PfcHeaders", (a) => {
        a`.*`,
          a.Items((b) => {
            b`.*`;
          }),
          a.Ventities((c) => {
            c`.*`;
          });
      })
    );

    const dbDuplicateRows = checkAgainstDatabase(groupedData, dbPfcList);

    // let updatedData = groupedData.map(async(row, index) => {
    //   const errorMessages = [];
    //   const excelDup = duplicateRows.find((r) => r.row === index + 1);
    //   if (excelDup) {
    //     errorMessages.push(`${bundle.getText('duplicateOfRow')} ${excelDup.duplicateOf}`);
    //   }


    //   const dbDuplicateRowsWithoutRejected= dbDuplicateRows.duplicateRow.filter(item=>item.ApprStatus!=='Rejected')
    //   const dbDup = dbDuplicateRows.duplicates.find((r) => r.row === index + 1);

    //   if (dbDup&&dbDuplicateRowsWithoutRejected) {
    //     errorMessages.push(bundle.getText('existsInDb'));
    //   }

    //   return {
    //     ...row,
    //     comments: [row.comments || "", errorMessages.join("; ")].filter(Boolean).join(" / ")
    //   };
    // });

    let updatedData = [];
    let mergedFull;
    let hasInvalid = false;
    for (let index = 0; index < groupedData.length; index++) {

      const row = groupedData[index];
      const errorMessages = [];

      const excelDup = duplicateRows.find(r => r.row === index + 1);
      if (excelDup) {
        errorMessages.push(
          `${bundle.getText('duplicateOfRow')} ${excelDup.duplicateOf}`
        );
      }

      const dbDupRecord = dbDuplicateRows?.duplicateRow?.find(
        item =>
          item.row === index + 1 &&
          item.ApprStatus !== 'Rejected' && item.Status.toLowerCase() !== "inactive"
      );

      if (dbDupRecord) {
        errorMessages.push(bundle.getText('existsInDb'));
      }

      const pfDuplicates = await checkMatchingProductFlowsMassUpload(row);

      if (pfDuplicates.length > 0) {
        const allPFIds = pfDuplicates
          .flatMap(d => d.productFlowIds);

        // errorMessages.push(`${bundle.getText('ProductFlowAlreadyexistsWiththeSameLogisticsStructure')} + ${allPFIds.join(", ")}+ ${bundle.getText('ContinuationToProductFlowAlreadyexists')}`);

      }


      if (errorMessages.length > 0) {
          hasInvalid = true;
        }

      updatedData.push({
        ...row,
        comments: [row.comments || "", errorMessages.join("; ")]
          .filter(Boolean)
          .join(" / ")
      });
    }

    //  3) S/4 Validation — wrap in try/catch, attach error to all rows if fails
    const keyMap = new Map();
    // const cleanedKeys = updatedData.map((entry) => {
    //   const newEntry = {};
    //   for (const [key, value] of Object.entries(entry)) {
    //     const newKey = key.replace(/[\s\-]/g, "");
    //     keyMap.set(newKey, key);
    //     newEntry[newKey] = value;
    //   }
    //   return newEntry;
    // });
    const cleanedKeys = updatedData.map((entry) => {

      const newEntry = {};

      for (let [key, value] of Object.entries(entry)) {

        
        let newKey = key.replace(/[\s\-]/g, "");
        
    if (newKey === "MaterialProfitCenter") {
      newKey = "MaterialBrand";
    }
        keyMap.set(newKey, key);
        newEntry[newKey] = value;

      }

      // Build VirtualEntities dynamically
      newEntry._VirtualEntities = buildVirtualEntities(newEntry, veCount);

      return newEntry;

    });
  

    function buildVirtualEntities(entry, veCount) {

      const _VirtualEntities = [];

      for (let i = 1; i <= veCount; i++) {

        const arch = entry[`ArchType${i}`];
        const bp = entry[`BusinessPartnerV${i}`];
        const plant = entry[`PlantV${i}`];
        const Material=entry[`MaterialNumber`]

        if (arch || bp || plant) {
          _VirtualEntities.push({
            ArchType: arch || "",
            BusinessPartner: bp || "",
            Plant: plant || "",
            MaterialNumber:Material||""
          });
        }

        // remove flat fields
        delete entry[`ArchType${i}`];
        delete entry[`BusinessPartnerV${i}`];
        delete entry[`PlantV${i}`];
      }

      return _VirtualEntities;
    }

    try {


      let dataToPass = {
        MassMaterial: "",
        _header: cleanedKeys,
      };

      logger.info("dataToPass", dataToPass)


      const metadata = {
        "ProductFlowID": 80,
        "FlowDescription": 60,
        "ShipFromBusinessPartner": 10,
        "ShipFromPlant": 10,
        "EconomicRegionShipFrom": 10,
        "ShipToArchType": 20,
        "ShipToBusinessPartner": 10,
        "ShipToPlant": 10,
        "EconomicRegionShipTo": 10,
        "MaterialType": 4,
        "MaterialBrand": 10,
        "MaterialNumber": 18,
        "ProductFlowComments": 400,
        "_VirtualEntities": {
          "ArchType": 20,
          "Plant": 10,
          "BusinessPartner": 10,
          "MaterialNumber": 18,

        }
      }
      const validerrors = [];
      async function validateLengths(data, metadata) {

         // helper to strip leading zeros (turns "000123" -> "123", "000" -> "0") and trim whitespace
  const stripLeadingZeros = (v) =>
  v == null ? v :                       // keep null/undefined unchanged
  String(v).trim().replace(/^0+/, '');  // '' for empty input or all-zero input

        
        for (var i = 0; i < data.length; i++) {
          const row = data[i];
          for (const [key, maxLength] of Object.entries(metadata)) {
            if (key === "_VirtualEntities") {
              // Validate each virtual entity
              if (Array.isArray(row[key])) {
                row[key].forEach((ve, veIndex) => {
                  for (const [veKey, veMaxLength] of Object.entries(maxLength)) {
                     if (ve[veKey] != null) {
                // normalize value by stripping leading zeros and updating the object in-place
                ve[veKey] = stripLeadingZeros(ve[veKey]);
                    if (ve[veKey] && ve[veKey].length > veMaxLength) {
                      validerrors.push(`Row ${i + 1}, Virtual Entity ${veIndex + 1}: "${veKey}" exceeds max length of ${veMaxLength}`);
                      row.comments = [row.comments, `Row ${i + 1}, Virtual Entity ${veIndex + 1}: "${veKey}" exceeds max length of ${veMaxLength}`].filter(Boolean).join(" / ");
                    }
                  }}
                });
              }
            } else {
               if (row[key] != null) {
          // normalize value by stripping leading zeros and updating the object in-place
          row[key] = stripLeadingZeros(row[key]);
              if (row[key] && row[key].length > maxLength) {
                validerrors.push(`Row ${i + 1}: "${key}" exceeds max length of ${maxLength}`);
                row.comments = [row.comments, `Row ${i + 1}: "${key}" exceeds max length of ${maxLength}`].filter(Boolean).join(" / ");
              }}
            }
          }

        }
        console.log(validerrors);
        return data;
      }


      const resultS4Input = await validateLengths(dataToPass._header, metadata);
      if (validerrors.length === 0 && dateErrors.length === 0) {
        let response_from_s4 = await ZSD_VCM_PRODUCTFLOW.tx(req).post(
          "/MaterialValidate",
          dataToPass
        );


        logger.info('response_from_s4', response_from_s4)

        response_from_s4._header.forEach((row) => {
          delete row.__EntityControl;
          if (row["VerifyText"] === "N") {
            hasInvalid = true;
            row.comments = [row.comments, bundle.getText('notFoundS4')].filter(Boolean).join(" / ");
          }
          if (row["Errorcheck"] === "Y") {
            hasInvalid = true;
          }
          delete row.VerifyText;
          delete row.Errorcheck;
        });
        // response_from_s4._header
        const restoredData = response_from_s4._header.map((entry) => {``
          const newEntry = {};
          for (let [key, value] of Object.entries(entry)) {
            if (key === "MaterialBrand") {
              key = "MaterialProfitCenter";
            }
            const originalKey = keyMap.get(key) || key;
            newEntry[originalKey] = value;
          }
          return newEntry;
        });
        mergedFull = updatedData.map((u, i) => {
          const restored = restoredData[i] || {};
          const { GroupID, ...restoredWithoutGroup } = restored;
         return { ...restoredWithoutGroup, ...u, comments: [String(restored.comments || '').trim(), String(u.comments || '').trim()].filter(Boolean).join(' / ') };

        });
        console.log('No length violations found. Safe to send.');
      } else {
        mergedFull = updatedData.map((u, i) => {
          const restored = resultS4Input[i] || {};
          const { GroupID, ...restoredWithoutGroup } = restored;
          return { ...restoredWithoutGroup, ...u, comments: [String(restored.comments || '').trim(), String(u.comments || '').trim()].filter(Boolean).join(' / ') };

        });;
        console.warn('Length violations found:', resultS4Input);
      }

    } catch (error) {
      if (error.message.includes("date") || error.message.includes("Date") || error.message.includes("time") || error.message.includes("Time")) {
        mergedFull = updatedData;
        hasInvalid = true;
      } else {

        mergedFull = updatedData.map((row) => ({
          ...row,
          comments: [row.comments, `${bundle.getText('callFailedS4')} ${error.message}`].filter(Boolean).join(" / "),
        }));
        hasInvalid = true;
      }


    }
    
    function stripLeadingZeros(v) {
      if (v == null) return v;                  // keep null/undefined unchanged
      if (typeof v === 'number' || typeof v === 'boolean') return v; // preserve numbers/booleans
      const s = String(v).trim();
      if (s === '') return s;                   // keep empty string unchanged

      // remove leading zeros; if the string was all zeros, return "0" (safer than empty)
      const stripped = s.replace(/^0+/, '');
      return stripped === '' ? '0' : stripped;
    }

    // function normalizeComments(val, { caseInsensitive = false } = {}) {
    //   if (val == null) return val;
    //   // turn arrays into a single string, then split by '/'
    //   const parts = (Array.isArray(val) ? val.join(' / ') : String(val))
    //     .split(/\s*\/\s*/)
    //     .map(s => s.trim())
    //     .filter(Boolean);

    //   const seen = new Set();
    //   const out = [];
    //   for (const p of parts) {
    //     const key = caseInsensitive ? p.toLowerCase() : p;
    //     if (!seen.has(key)) {
    //       seen.add(key);
    //       out.push(p);
    //     }
    //   }
    //   return out.join(' / ');
    // }

    function normalizeComments(val, { caseInsensitive = false } = {}) {
  if (val == null) return val;

  // Normalize input to a single string
  const str = Array.isArray(val) ? val.join(' / ') : String(val);

  // Split only on slashes that have whitespace around them (e.g. " / "),
  // so we don't split dates like "12/12/2024".
  const groups = str.split(/\s+\/\s+/);

  const seen = new Set();
  const out = [];

  for (const g of groups) {
    // Within each group, messages are often separated by semicolons or newlines.
    // Split on semicolon or newline, but not on plain slashes.
    const parts = g.split(/[\n;]+/).map(s => s.trim()).filter(Boolean);

    for (let p of parts) {
      // Normalize escaped quotes and remove surrounding double-quotes around tokens
      // e.g. turn "\"Row\" 1: \"Valid From\" ..." into "Row 1: Valid From ..."
      p = p.replace(/\\"/g, '"').replace(/"([^"]+)"/g, '$1').trim();

      const key = caseInsensitive ? p.toLowerCase() : p;
      if (!seen.has(key)) {
        seen.add(key);
        out.push(p);
      }
    }
  }

  // Keep original grouping delimiter for compatibility with the existing callers
  return out.join(' / ');
}


    // validate mergedFull
    if (!Array.isArray(mergedFull)) {
      throw new TypeError('mergedFull must be an array');
    }

    // process mergedFull in-place
    for (let i = 0; i < mergedFull.length; i++) {
      const obj = mergedFull[i] || {};
      mergedFull[i] = Object.fromEntries(
        Object.entries(obj).map(([k, v]) => {
          // keep explicit null/undefined/empty-string and literal "null"/"undefined" strings unchanged
          if (v === null || v === undefined || v === "" || v === "null" || v === "undefined") {
            return [k, v];
          }
          if (k === 'comments') {
            return [k, normalizeComments(v)]; // split on '/', trim, remove duplicates
          }
          return [k, stripLeadingZeros(v)];  // strip leading zeros for other props
        })
      );
    }

    const finalData = mergedFull.map((row) => {
      const orderedRow = {};
      outputColumns.forEach((col) => {
        // preserve falsy-but-valid values (e.g., 0). Use hasOwnProperty to detect missing keys.
        orderedRow[col] = Object.prototype.hasOwnProperty.call(row, col) ? row[col] : "";
      });
      return orderedRow;
    });

    // finalData is ready



    const newSheet = xlsx.utils.json_to_sheet(finalData);
    const newWorkbook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(newWorkbook, newSheet, sheetName);
    const bufferOut = xlsx.write(newWorkbook, {
      type: "buffer",
      bookType: "xlsx",
    });

    const hasError =
      duplicateRows?.length > 0 || dbDuplicateRows?.length > 0 || hasInvalid || hasValidationErrors||dateErrors?.length > 0;

    return { buffer: bufferOut, hasError };
  } catch (error) {
    console.log(error)

  }
}

module.exports = { processExcelBuffer }