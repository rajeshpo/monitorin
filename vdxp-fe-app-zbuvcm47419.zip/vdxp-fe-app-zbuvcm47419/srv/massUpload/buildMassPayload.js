// // --------------------------------------------------------------------------------------------------------------------*
// // Application Name : Product Flow Catalog
// // Object Id       : ZBUVCM47419
// // Release         : 1
// // Version         : 0.01
// // Description     : Validation module for Product Flow Catalog Application
// // ----------------------------------------------------------------------------*
// // Descriptions: it will have all the validations at the time of mass upload screen
// // ----------------------------------------------------------------------------*
// // Change Log:
// //    Date     |       Author        |   Change Id   |   Change Description
// 26-03-2026      RChitike@its.jnj.com     50440096        TIME-FIN-DEV-PFCEnhanceme-Developement
// // -----------------------------------------------------------------------------



const cds = require('@sap/cds');
const constant = require('../config/constant');


/**
 * Helper to get the best material identifier
 */
function getMaterialIdentifier(item = {}) {
  return item.Matnr?.trim() || item.MatBrand?.trim() || item.MatType?.trim();
}

/**
 * Validates Eco Region for a given Business Partner or Plant
 */


async function checkEcoValid(eco, Bp, Plant, ZSD_VCM_PRODUCTFLOW, bundle) {
  const { PfcEcoRegions } = cds.entities('jnj.com.zbuvcm47419');



  let ctryKey;

  try {
    if (Bp) {
      const result = await ZSD_VCM_PRODUCTFLOW.run(
        SELECT.columns('Country').from('Massbpplantcntrykey').where({ BusinessPartner: Bp })
      );
      ctryKey = result?.[0]?.Country;
    } else if (Plant) {
      const result = await ZSD_VCM_PRODUCTFLOW.run(
        SELECT.columns('Country').from('Massbpplantcntrykey').where({ Plant })
      );
      ctryKey = result?.[0]?.Country;
    }

    if (!ctryKey) {
      throw new Error(`${bundle.getText('noCountry')} ${Bp || ''}, ${bundle.getText('Plant')} ${Plant || ''}`);
    }

    const ecoRegionResult = await cds.run(
      SELECT.columns('EcoRegCode').from(PfcEcoRegions).where({ CountryCode: ctryKey })
    );

    const ecoCode = ecoRegionResult?.[0]?.EcoRegCode;

    if (ecoCode !== eco) {
      throw new Error(`${eco} ${bundle.getText('notValidEco')}`);
    }
  } catch (err) {
    console.error(bundle.getText('ecoFailed'), err.message);
    throw err;
  }
}


/**
 * Sets Eco Region values using existing mass-upload BP/Plant-Country mappings
 */
async function setEcoRegion(SfBp, SfPlant, StBp, StPlant, bpCountryKeyMassList, plantCountryKeyMassList) {
  const bpMap = {};
  const plantMap = {};

  // Convert BP and Plant lists to lookup maps
  bpCountryKeyMassList?.forEach(item => {
    if (item.BusinessPartner && item.Country) {
      bpMap[item.BusinessPartner] = item.Country;
    }
  });

  plantCountryKeyMassList?.forEach(item => {
    if (item.Plant && item.Country) {
      plantMap[item.Plant] = item.Country;
    }
  });

  const sfKey = SfPlant ? SfPlant.toString().trim() : (SfBp ? SfBp.toString().trim() : null);
  const stKey = StPlant ? StPlant.toString().trim() : (StBp ? StBp.toString().trim() : null);

  const sfCountry = sfKey ? (plantMap[sfKey] || bpMap[sfKey]) : null;
  const stCountry = stKey ? (plantMap[stKey] || bpMap[stKey]) : null;


  let EcSf = '';
  let EcSt = '';

  if (sfCountry) {
    const eco = await cds.run(SELECT.one.from('jnj.com.zbuvcm47419.PfcEcoRegions').where({ CountryCode: sfCountry }));
    EcSf = eco?.EcoRegCode || '';
  }

  if (stCountry) {
    const eco = await cds.run(SELECT.one.from('jnj.com.zbuvcm47419.PfcEcoRegions').where({ CountryCode: stCountry }));
    EcSt = eco?.EcoRegCode || '';
  }

  return { EcSf, EcSt };
}

// ***** Defect - JGHJ-75768 ***** START *****

function getPlantForBP(bp, bpCountryKeyMassList) {
  const match = bpCountryKeyMassList.find(e => e.BusinessPartner === bp);
  return match?.Plant || "";
}

function getBPForPlant(plant, plantCountryKeyMassList) {
  const match = plantCountryKeyMassList.find(e => e.Plant === plant);
  return match?.BusinessPartner || "";
}
// ***** Defect - JGHJ-75768 ***** END *****


// ***** Defect - JGHJ-75795 ***** START *****

function getMaterialDetails(matnr, materialList) {
  return materialList.find(m => m.Product === String(matnr)) || null;
}

// ***** Defect - JGHJ-75795 ***** END *****

function normalize(val) {
  return (val ?? "")
    .toString()
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

async function getArchType(value,value1) {
  if(value===null || value === undefined || value === "") {
    return value;
  }
  // Case-insensitive "contains" using LOWER(...) and parameter binding
const raw = normalize(value);
if (!raw) return null;

const pattern = `%${raw.toLowerCase()}%`;

const mapped = await cds.run(
  SELECT.one
    .from('jnj.com.zbuvcm47419.PfcArchTypeMapping')
    .columns('ArchType')
    .where`LOWER(ArchType) LIKE ${pattern}` // use unquoted identifier and tagged template
);

  if (!mapped) {
    throw new Error(`Invalid ArchType ${value1}: ${value}`);
  }
  return mapped.ArchType;
}

/**
 * Builds payload for mass upload with eco region fallback.
 */
// async function buildMassUploadPayload(groupedData, bpCountryKeyMassList, plantCountryKeyMassList, isAdmin, bundle) {
async function buildMassUploadPayload(groupedData, isAdmin, bundle, bpCountryKeyMassList, plantCountryKeyMassList, materialList,veCount) {

  const headersMap = new Map();
  const errorMaterials = [];
  const ZSD_VCM_PRODUCTFLOW = await cds.connect.to("ZSD_VCM_PRODUCTFLOW");

  for (const row of groupedData) {
    const groupId = row["Group ID"];

    if (!headersMap.has(groupId)) {
      headersMap.set(groupId, {
        ID: cds.utils.uuid(),
        ProdId: row["Product Flow ID"] || "",
        PfDesc: row["Flow Description"] || "",
        BpSFrom: row["Ship From Business Partner"] || "",
        BpSTo: row["Ship To Business Partner"] || "",
        PlantSFrom: row["Ship From Plant"] || "",
        PlantSTo: row["Ship To Plant"] || "",
        ErSFrom: row["Economic Region Ship From"] || "",
        ErSTo: row["Economic Region Ship To"] || "",
        ArchType: await getArchType(row["Ship To Arch Type"],"ShipToArchtype"),
        fieldControl: 1,
        comments: row["Product Flow Comments"],
        Items: [],
        Ventities: [],
        _ventityKeySet: new Set() 
      });
    }

    const header = headersMap.get(groupId);

    // ***** Defect - JGHJ-75768 ***** START *****

    // --- Populate Ship From Fields ---
    if (header.BpSFrom && !header.PlantSFrom) {
      // Find Plant for this BP (from BP list)
      header.PlantSFrom = getPlantForBP(header.BpSFrom, bpCountryKeyMassList) || "";
    }

    if (header.PlantSFrom && !header.BpSFrom) {
      // Find BP for this Plant (from Plant list)
      header.BpSFrom = getBPForPlant(header.PlantSFrom, plantCountryKeyMassList) || "";
    }

    // --- Populate Ship To Fields ---
    if (header.BpSTo && !header.PlantSTo) {
      header.PlantSTo = getPlantForBP(header.BpSTo, bpCountryKeyMassList) || "";
    }

    if (header.PlantSTo && !header.BpSTo) {
      header.BpSTo = getBPForPlant(header.PlantSTo, plantCountryKeyMassList) || "";
    }

    // ***** Defect - JGHJ-75768 ***** END *****

    header.Items.push({
      MatBrand: row["Material Profit Center"] || "",
      ItemNum: "",
      Matnr: row["Material Number"] || "",
      // MatDesc: row["Material Description"] || "",
      VFrom: row["Valid From"],
      VTo: row["Valid To"],
      MatType: row["Material Type"] || "",
      ApprStatus: isAdmin ? bundle.getText('Approved') : bundle.getText('pendingForApproval'),
      pFStatus: isAdmin ? "" : bundle.getText('newFlow'),
      fieldControl: 1,
      vToFieldControl: 1,
      MatnrFeildControl: 1,
      MatDescFeildControl: 1,
      MatTypeFeildControl: 1,
      MatBrandFeildControl: 1,
      VFromFeildControl: 1,
      criticality: isAdmin?3:2,
      rFeildControl:isAdmin?7:1
    });



    // for (let i = 1; i <= 6; i++) {
    //   const plant = row[`Plant V${i}`];
    //   const bp = row[`Business Partner V${i}`];
    //   if (plant || bp) {
    //     header.Ventities.push({
    //       SeqNum: "",
    //       ArchType: row[`Arch Type ${i}`] || "",
    //       Plant: plant || "",
    //       BPartner: bp || "",
    //       fieldControl: 1,
    //     });
    //   }
    // }

    for (let i = 1; i <= veCount; i++) {
  const plant = row[`Plant V${i}`] || "";
  const bp = row[`Business Partner V${i}`] || "";
  const archType = await getArchType(row[`Arch Type ${i}`],`Virtual Arch Type ${i}`) || "";

  if (!plant && !bp) continue;

  const uniqueKey = `${plant}|${bp}|${archType}`;

  if (header._ventityKeySet.has(uniqueKey)) {
    continue; //  already added for this group
  }

  header._ventityKeySet.add(uniqueKey);

  header.Ventities.push({
    SeqNum: "",
    ArchType: archType,
    Plant: plant,
    BPartner: bp,
    fieldControl: 1
  });
}

  }

  for (const header of headersMap.values()) {
    UpdateItemNum({ data: header });
    UpdateVSeqNum({ data: header });

    const hasShipFromInfo = header.BpSFrom || header.PlantSFrom;
    const hasShipToInfo = header.BpSTo || header.PlantSTo

    // ***** Defect - JGHJ-75795 ***** START *****

    header.Items = header.Items.map(item => {
      const { Matnr } = item;

      if (Matnr) {
        const mat = getMaterialDetails(Matnr, materialList);

        if (mat) {
          item.MatDesc = item.MatDesc || mat.ProductName || "";
          item.MatBrand = item.MatBrand || mat.ProfitCenter || "";
          item.MatType = item.MatType || mat.ProductType || "";
        }
      }
      return item;
    });

    // ***** Defect - JGHJ-75795 ***** END *****


    // ***** Defect - JGHJ-75768 ***** START *****


    header.Ventities = header.Ventities.map(ve => {
      let { BPartner, Plant } = ve;

      // If BP exists but Plant missing → derive Plant
      if (BPartner && !Plant) {
        Plant = getPlantForBP(BPartner, bpCountryKeyMassList);
      }

      // If Plant exists but BP missing → derive BP
      if (Plant && !BPartner) {
        BPartner = getBPForPlant(Plant, plantCountryKeyMassList);
      }

      return {
        ...ve,
        BPartner: BPartner || "",
        Plant: Plant || ""
      };
    });

    // ***** Defect - JGHJ-75768 ***** END *****

    // if (hasShipInfo && header?.ErSFrom) {
    //   try {
    //     await checkEcoValid(header.ErSFrom, header.BpSFrom, header.PlantSFrom, ZSD_VCM_PRODUCTFLOW, bundle);
    //   } catch (e) {
    //     const ids = header.Items.map(getMaterialIdentifier);
    //     errorMaterials.push(...ids);
    //     continue;
    //   }
    // }

    // if (hasShipInfo && header?.ErSTo) {
    //   try {
    //     await checkEcoValid(header.ErSTo, header.BpSTo, header.PlantSTo, ZSD_VCM_PRODUCTFLOW, bundle);
    //   } catch (e) {
    //     const ids = header.Items.map(getMaterialIdentifier);
    //     errorMaterials.push(...ids);
    //     continue;
    //   }
    // }

    if (!hasShipFromInfo && header.ErSFrom) {
      const eco = await cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcEcoRegions'));
      const ecoMap = Object.fromEntries(
        eco.map(e => [e.CountryCode.trim(), {
          EcoRegCode: e.EcoRegCode.trim(),
          EcoRegName: e.EcoRegName.trim()
        }])
      );

      const isFromValid = ecoMap.hasOwnProperty(header.ErSFrom.trim());
      if (!isFromValid) {
        const ids = header.Items.map(getMaterialIdentifier);
        errorMaterials.push(...ids);
      }

      // Replace with EcoRegCode only
      header.ErSFrom = ecoMap[header.ErSFrom.trim()]?.EcoRegCode || header.ErSFrom;
    }

    if (!hasShipToInfo && header.ErSTo) {
      const eco = await cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcEcoRegions'));
      const ecoMap = Object.fromEntries(
        eco.map(e => [e.CountryCode.trim(), {
          EcoRegCode: e.EcoRegCode.trim(),
          EcoRegName: e.EcoRegName.trim()
        }])
      );

      const isToValid = ecoMap.hasOwnProperty(header.ErSTo.trim());
      if (!isToValid) {
        const ids = header.Items.map(getMaterialIdentifier);
        errorMaterials.push(...ids);
      }

      // Replace with EcoRegCode only
      header.ErSTo = ecoMap[header.ErSTo.trim()]?.EcoRegCode || header.ErSTo;
    }
    if (!header.PfDesc) {
      let PfDesc = header?.PfDesc || ''
      const clean = v => (v ?? '').toString().trim();

      if (header.PfDesc === null || header.PfDesc === "" || header.PfDesc === undefined) {
        const bpSet = new Set();
        const plantSet = new Set();

        // Header level
        [header.BpSFrom, header.BpSTo].forEach(bp => {
          if (clean(bp)) bpSet.add(clean(bp));
        });

        [header.PlantSFrom, header.PlantSTo].forEach(p => {
          if (clean(p)) plantSet.add(clean(p));
        });

        // // VEntities level
        (header.Ventities || []).forEach(v => {
          if (clean(v.BPartner)) bpSet.add(clean(v.BPartner));
          if (clean(v.Plant)) plantSet.add(clean(v.Plant));
        });

        const filterBPs = [...bpSet];
        const filterPlants = [...plantSet];

        // /* ------------------ call S/4 ------------------ */
        const [bpList, plantList] = await Promise.all([
          filterBPs.length
            ? ZSD_VCM_PRODUCTFLOW.run(
              SELECT.from('Massbpplantcntrykey')
                .where({ BusinessPartner: { in: filterBPs } })
            )
            : [],

          filterPlants.length
            ? ZSD_VCM_PRODUCTFLOW.run(
              SELECT.from('Massplantbpcntrykey')
                .where({ Plant: { in: filterPlants } })
            )
            : []
        ]);

        // /* ------------------ build lookup maps ------------------ */
        const bpMap = new Map();
        bpList.forEach(bp => {
          bpMap.set(
            clean(bp.BusinessPartner),
            {
              name1: bp.OrganizationBPName1,
              country: bp.Country,
              name2: bp.OrganizationBPName2
            }
          );
        });

        const plantMap = new Map();
        plantList.forEach(p => {
          plantMap.set(
            clean(p.Plant),
            {
              name1: p.Name1,
              country: p.Country,
              name2: p.Name2
            }
          );
        });


        const parts = [];
        function words(str) {
          return clean(str).split(/\s+/).filter(Boolean);
        }

        function firstWord(str) {
          return words(str)[0] || null;
        }

        function secondWord(str) {
          return words(str)[1] || null;
        }
        function resolveDisplayName({ bp, plant, bpMap, plantMap }) {
          /* ---------- BP ---------- */
          if (clean(bp) && bpMap.has(clean(bp))) {
            const { name2, name1 } = bpMap.get(clean(bp));

            // BPName2 → second word
            const bpSecond = secondWord(name2);
            if (bpSecond) return bpSecond;

            // fallback → BPName (name1) → first word
            return firstWord(name1);
          }

          /* ---------- Plant ---------- */
          if (clean(plant) && plantMap.has(clean(plant))) {
            const { name1, name2 } = plantMap.get(clean(plant));

            return name2.startsWith("VIR")
              ? secondWord(name2)
              : firstWord(name);
          }

          return null;
        }


        /*  Ship-From */
        let shipFrom = resolveDisplayName({
          bp: header.BpSFrom,
          plant: header.PlantSFrom,
          bpMap,
          plantMap
        });
        if (shipFrom === null) {
          shipFrom = header.Ventities[0]?.ArchType || ''
        }
        if (shipFrom) parts.push(shipFrom);

        (header.Ventities || []).forEach(v => {
          const veName = resolveDisplayName({
            bp: v.BPartner,
            plant: v.Plant,
            bpMap,
            plantMap
          });
          if (veName) parts.push(veName);
        });
        /* Ship-To */
        let shipTo = resolveDisplayName({
          bp: header.BpSTo,
          plant: header.PlantSTo,
          bpMap,
          plantMap
        });
        if (shipTo === null) {
          shipTo = header.ArchType
        }
        if (shipTo) parts.push(shipTo);



        /* Final String */
        PfDesc = parts.join(' ---> ');


      }
      header.PfDesc = PfDesc
    }



    // if (!header.ErSFrom || !header.ErSTo) {
    //   if (hasShipInfo) {
    //     const ecoData = await setEcoRegion(
    //       // req,
    //       // ZSD_VCM_PRODUCTFLOW,
    //       header.BpSFrom,
    //       header.PlantSFrom,
    //       header.BpSTo,
    //       header.PlantSTo,
    //       bpCountryKeyMassList,
    //       plantCountryKeyMassList
    //     );
    //     header.ErSFrom = ecoData?.EcSf || header.ErSFrom;
    //     header.ErSTo = ecoData?.EcSt || header.ErSTo;
    //   }
    // }

    // if (!header.ErSFrom || !header.ErSTo) {
    //   const ids = header.Items.map(getMaterialIdentifier);
    //   errorMaterials.push(...ids);
    // }
  }

  if (errorMaterials.length > 0) {
    const message = `${bundle.getText('ecoMissing')} ${[...new Set(errorMaterials)].join(", ")}`;
    const error = new Error(message);
    error.code = "MISSING_ECO_REGION";
    throw error;
  }


  return Array.from(headersMap.values());
}

/**
 * Assigns sequential ItemNum values (10, 20, 30, ...)
 */
function UpdateItemNum(req) {
  const { data } = req;
  if (data?.Items?.length) {
    data.Items.forEach((item, index) => {
      item.ItemNum = ((index + 1) * 10).toString();
      if (!item.Matnr) {
        item.Matnr = "";
      }
      if (!item.MatBrand) {
        item.MatBrand = "";
      }
    });
  }
}

/**
 * Assigns sequential SeqNum values (1, 2, 3, ...)
 */
function UpdateVSeqNum(req) {
  const { data } = req;
  if (data?.Ventities?.length) {
    data.Ventities.forEach((v, index) => {
      v.SeqNum = (index + 1).toString();
    });
  }
}

module.exports = { buildMassUploadPayload };
