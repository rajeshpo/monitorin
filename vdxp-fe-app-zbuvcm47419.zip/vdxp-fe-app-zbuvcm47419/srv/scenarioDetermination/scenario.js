// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Scenario Determination
// Object Id       : ZBUVCM55151
// Release         : 1
// Version         : 0.01
// Description     : Scenario Determination logic  code
// ----------------------------------------------------------------------------*
// Descriptions:Creation of Scenario ID and retrieval of END to END steps
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |         Author        |   Change Id   |  Change Description
// 26-03-2026      DSinghTo@ITS.JNJ.com    50447367      TIME-FIN-DEV-ScenarioDet-BTP
// ----------------------------------------------------------------------------*
const cds = require('@sap/cds');
const constants = require('../config/constant');


// ***** JGHJ-71574 ***** R2.2 START *****
/**
 * createSID_Drafts
 * @param {object} req : its the request object
 * @param {object} odata : its the odata service object of scenario determination service
 * @return {String} CatID : its the Scenario Id for Given Product Flow
 */
async function createSID_Drafts(req, odata, catid) {
    try {

        let checkCondition= {
            "ID": catid
        } 

        let sourceEntity = "ZBUVCM47419SERVICE_PFC_LIST_DRAFTS"

        //This will store all the legend notation of [ShipFrom, ... VEntities(multiple)...., ShipTo]
        let flowComp = [];

        // old way of  Retreving record from header table
        // const pflow = await cds.run(
        //     SELECT.from('jnj.com.zbuvcm47419.PfcHeaders')
        //         .columns('BpSFrom', 'PlantSFrom', 'BpSTo', 'PlantSTo', 'ArchType')
        //         .where({ 'CatId': catid })
        // );

        // added ecoregion column  of  Retreving record from header table
        const pflow = await cds.run(
            SELECT.from(sourceEntity)
                .columns('BpSFrom', 'ErSFrom', 'PlantSFrom', 'BpSTo', 'ErSTo', 'PlantSTo', 'ArchType')
                .where(checkCondition)
        );

        // old columns in getting physical flow details of ShipFrom , ShipTo and ArchType
        //const { BpSFrom, PlantSFrom, BpSTo, PlantSTo, ArchType } = pflow[0];

        // New change including the Eco Region in the logic
        const row = pflow[0] || {};

        const normalizedRow = Object.fromEntries(
            Object.entries(row).map(([key, value]) => [key.toLowerCase(), value])
        );

        const {
            bpsfrom,
            ersfrom,
            plantsfrom,
            bpsto,
            ersto,
            plantsto,
            archtype
        } = normalizedRow;

        let checkDraft ={ "parent_ID": catid }
        //Retreving records from virtualEntity
        let source =  "ZBUVCM47419SERVICE_VENTITIES_DRAFTS" 

        //Retreving records of  virtualEntity of product Flow
        const vflow = await cds.run(
            SELECT.from(source)
                .where(checkDraft)
                .orderBy('SeqNum')
        );

        const archtypeMappingData = await cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcArchTypeMapping'))


        let vlen = vflow.length;
        let draftArchType =  vflow[0]?.ARCHTYPE 

        //checking wheather the data is present for a given flow 
        if (pflow.length > 0) {

            // calling the bpPlantLegend function with ShipFrom data , it will check the logic 
            // with ABAP odata service and return the correct legend value and push it inside flowComp
            // array.
            if (bpsfrom || plantsfrom) {
                //flowComp.push(await bpPlantLegend(req, odata, 'ShipFrom', BpSFrom, PlantSFrom, ArchType));

                if (vflow.length > 0) {
                    // New change in changing ArchType
                    flowComp.push(await bpPlantLegend(req, odata, 'ShipFrom', bpsfrom, plantsfrom, draftArchType,archtypeMappingData))
                }
                else {
                    flowComp.push(await bpPlantLegend(req, odata, 'ShipFrom', bpsfrom, plantsfrom, archtype,archtypeMappingData))
                }
            } else {
                if (vflow.length > 0) {
                    flowComp.push(await bpPlantEcoregion(draftArchType, 'ShipFrom'))
                }
                else {
                    flowComp.push(await bpPlantEcoregion(archtype, 'ShipFrom'))
                }
            }



            // calling the bpPlantLegend function for all virtual entities  data in order , it will check the logic 
            // with ABAP odata service and return the correct legend value and push it inside flowComp
            // array.
            for (const [index,ve] of vflow.entries()) {
                // let BPartner =  ve.BPARTNER 
                // let Plant =ve.PLANT 
                // let id = await bpPlantLegendDrafts(req, odata, 'VEntity', BPartner, Plant, '');
                // flowComp.push(id);
                const { BPARTNER, PLANT,ARCHTYPE  } = ve;
                let id;
                if(index === 0){
                 id = await bpPlantLegend(req, odata, 'VEntity1', BPARTNER, PLANT, ARCHTYPE,archtypeMappingData);
                }else{
                    id = await bpPlantLegend(req, odata, 'VEntity', BPARTNER, PLANT,ARCHTYPE,archtypeMappingData);
                }
                flowComp.push(id);
            }

            // calling the bpPlantLegend function for ShipTo  data in order , it will check the logic 
            // with ABAP odata service and return the correct legend value and push it inside flowComp
            // array.
            if (bpsto || plantsto) {
                // flowComp.push(await bpPlantLegend(req, odata, 'ShipTo', BpSTo, PlantSTo, vflow[vlen - 1].ArchType));
               // flowComp.push(await bpPlantLegendDrafts(req, odata, 'ShipTo', bpsto, plantsto, archtype));
                flowComp.push(await bpPlantLegend(req, odata, 'ShipTo', bpsto, plantsto, archtype,archtypeMappingData));
            } else {
                flowComp.push(await bpPlantEcoregion(archtype, 'ShipTo'));
            }


            // Now joining all the legend Notation saved in flowComp with '-' and returning it to be updated in
            // the header table
            const ScenarioID = flowComp.join('-');


            return ScenarioID;

        } else {
            return '';
        }
    }
    catch (error) {
        req.error({
            message: error.message,
            status: 400
        });
    }
}
// ***** JGHJ-71574 ***** R2.2 END *****
async function createSID(req, odata, catid) {
    try {

        //This will store all the legend notation of [ShipFrom, ... VEntities(multiple)...., ShipTo]
        let flowComp = [];


        // added ecoregion column  of  Retreving record from header table
        const pflow = await cds.run(
            SELECT.from('jnj.com.zbuvcm47419.PfcHeaders')
                .columns('BpSFrom','ErSFrom', 'PlantSFrom', 'BpSTo','ErSTo', 'PlantSTo', 'ArchType')
                .where({ 'CatId': catid })
        );

        // New change including the Eco Region in the logic
        const { BpSFrom, PlantSFrom,ErSFrom, BpSTo,ErSTo, PlantSTo, ArchType } = pflow[0];


        //Retreving records of  virtualEntity of product Flow
        const vflow = await cds.run(
            SELECT.from('jnj.com.zbuvcm47419.PfcEntities')
                .where({ 'CatId': catid })
                .orderBy('SeqNum')
        );

        const archtypeMappingData = await cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcArchTypeMapping'))

        let vlen = vflow.length;

        //checking wheather the data is present for a given flow 
        if (pflow.length > 0) {

            // calling the bpPlantLegend function with ShipFrom data , it will check the logic 
            // with ABAP odata service and return the correct legend value and push it inside flowComp
            // array.
            if (BpSFrom || PlantSFrom) {
                //flowComp.push(await bpPlantLegend(req, odata, 'ShipFrom', BpSFrom, PlantSFrom, ArchType));

                if (vflow.length > 0){
                    // New change in changing ArchType
                    flowComp.push(await bpPlantLegend(req, odata, 'ShipFrom', BpSFrom, PlantSFrom, vflow[0]?.ArchType,archtypeMappingData))
                }
                else{
                    flowComp.push(await bpPlantLegend(req, odata, 'ShipFrom', BpSFrom, PlantSFrom,ArchType,archtypeMappingData))
                }
            } else {
                if (vflow.length > 0){
                 flowComp.push(await bpPlantEcoregion(vflow[0]?.ArchType,'ShipFrom'))
                }
                else{
                    flowComp.push(await bpPlantEcoregion(ArchType,'ShipFrom'))
                }
            }



            // calling the bpPlantLegend function for all virtual entities  data in order , it will check the logic 
            // with ABAP odata service and return the correct legend value and push it inside flowComp
            // array.
            for (const [index,ve] of vflow.entries()) {
                const { BPartner, Plant,ArchType  } = ve;
                let id;
                if(index === 0){
                 id = await bpPlantLegend(req, odata, 'VEntity1', BPartner, Plant, ArchType,archtypeMappingData);
                }else{
                    id = await bpPlantLegend(req, odata, 'VEntity', BPartner, Plant,ArchType,archtypeMappingData);
                }
                flowComp.push(id);
            }

            // calling the bpPlantLegend function for ShipTo  data in order , it will check the logic 
            // with ABAP odata service and return the correct legend value and push it inside flowComp
            // array.
            if (BpSTo || PlantSTo) {
                // flowComp.push(await bpPlantLegend(req, odata, 'ShipTo', BpSTo, PlantSTo, vflow[vlen - 1].ArchType));
                flowComp.push(await bpPlantLegend(req, odata, 'ShipTo', BpSTo, PlantSTo, ArchType,archtypeMappingData));
            } else {
                flowComp.push(await bpPlantEcoregion(ArchType, 'ShipTo'));
            }


            // Now joining all the legend Notation saved in flowComp with '-' and returning it to be updated in
            // the header table
            const ScenarioID = flowComp.join('-');


            return ScenarioID;

        } else {
            return '';
        }
    }
    catch (error) {
        req.error({
            message: error.message,
            status: 400
        });
    }
}

async function bpPlantEcoregion(atype, call) {
    switch (call) {
        case "ShipFrom":
            if (atype?.includes("Local STO") || atype?.includes("EU STO")) {
                return "SP";
            }
            else if (atype?.includes("3P Toll")) {
                return "3P";
            }
            else if (atype?.includes("IC Toll")) {
                return "AT";
            }
            else if (atype?.includes('IC Sale')) {
                return "AV";
            }
            break;
        case "ShipTo":
            if (atype === "Local STO" || atype === "IC Sale" || atype === "EU STO") {
                return "DP";
            }
            else if (atype === "Trade Sale") {
                return "3S";
            }
            break;
        default:
            throw new Error("Error entcountered while creating Scenario ID for the Product Flow")

    }
}

/**
 * createSID
 * @param {object} req : its the request object
 * @param {object} odata : its the odata service object of scenario determination service
 * @param {String} call : it is for which ShipFrom , SHipTo , VEnties this function is called 
 * @param {String} bPart : its the Business Partner value for given ShipFrom,ShipTo , virtual Entity
 * @param {String} plant : its the Plant value for given ShipFrom,ShipTo , virtual Entity
 * @param {atype} atype : its the ArchType value for given ShipFrom,ShipTo , virtual Entity
 * @return {String} Legend value for the given id 
 */
async function bpPlantLegendDrafts(req, odata, call, bPart, plant, atype) {
    try {

        let checkedData = null;
        //get call to the ABAP service 
        let S4flag = null;
        //making a affiliate or 3rd party check 
        let affiliate = null;
        if (plant) {

            const queryData = {
                Plant: plant
            };
            checkedData = await odata.run(SELECT.from('SDPLANT').where(queryData));
            const { message } = checkedData[0];
            if (message === 'IN TIME') {
                S4flag = true;
                affiliate = true;
            } else {
                S4flag = false;
                affiliate = false;
            }

        } else {

            const queryData = {
                BP: bPart
            };
            checkedData = await odata.run(SELECT.from('SDBP').where(queryData));
            const { message, BPGroupcheck } = checkedData[0];
            if (message === 'IN TIME') {
                S4flag = true;
            } else {
                S4flag = false;
            }

            if (BPGroupcheck === '3rd Party') {
                affiliate = false;
                S4flag = false; // if the Bp is 3rd Part we will treat it as external outside S\4 entity to Jnj
            } else {
                affiliate = true
            }


        }
        const tollCheck = constants.TollCheck.some((toll) => atype?.includes(toll));


        switch (call) {
            case "ShipFrom":
                // legend notation  logic for ShipFrom 
                if (affiliate) {
                    if (tollCheck) {
                        if (S4flag) {
                            return 'TP';
                        } else {
                            return 'AT'
                        }
                    } else {
                        if (S4flag) {
                            return 'SP';
                        } else {
                            return 'AV'
                        }
                    }
                } else {
                    if (tollCheck) {
                        if (!S4flag) {
                            return '3T'
                        } else {
                            throw new Error('Error entcountered wile creating Scenario ID for the Product Flow');
                        }
                    } else {
                        if (!S4flag) {
                            return '3B'
                        } else {
                            throw new Error('Error entcountered wile creating Scenario ID for the Product Flow')
                        }
                    }
                }
                break;
            case "ShipTo":
                // legend notation  logic for ShipTo
                if (affiliate) {
                    if (tollCheck) {
                        if (S4flag) {
                            return 'TP';
                        } else {
                            return 'AT'
                        }
                    } else {
                        if (S4flag) {
                            return 'DP';
                        } else {
                            return 'AC'
                        }
                    }
                } else {
                    if (tollCheck) {
                        if (!S4flag) {
                            return '3T'
                        }
                        else {
                            throw new Error('Error entcountered while creating Scenario ID for the Product Flow');
                        }
                    } else {
                        if (!S4flag) {
                            return '3S'
                        }
                        else {
                            throw new Error('Error entcountered while creating Scenario ID for the Product Flow');
                        }
                    }
                }
                break;
            case "VEntity":
                // legend notation  logic for Virtual Entities
                if (!tollCheck) {
                    if (S4flag) {
                        return 'VP';
                    } else {
                        return 'VE'
                    }
                }
                break;
            default:
                // Code to execute if no case matches
                throw new Error('Error entcountered wile creating Scenario ID for the Product Flow')
        }
    } catch (error) {
        req.error({
            message: error.message,
            status: 400
        });
    }
}



/**
 * createSID
 * @param {object} req : its the request object
 * @param {object} odata : its the odata service object of scenario determination service
 * @param {String} call : it is for which ShipFrom , SHipTo , VEnties this function is called 
 * @param {String} bPart : its the Business Partner value for given ShipFrom,ShipTo , virtual Entity
 * @param {String} plant : its the Plant value for given ShipFrom,ShipTo , virtual Entity
 * @param {atype} atype : its the ArchType value for given ShipFrom,ShipTo , virtual Entity
 * @return {String} Legend value for the given id 
 */
async function bpPlantLegend(req, odata, call, bPart, plant, atype,archtyeLegendMapping) {
    try {

        let checkedData = null;
        //get call to the ABAP service 
        let S4flag = null;
        //making a affiliate or 3rd party check 
        let affiliate = null;
        if (plant) {

            const queryData = {
                Plant: plant
            };
            checkedData = await odata.run(SELECT.from('SDPLANT').where(queryData));
            const { message } = checkedData[0];
            if (message === 'IN TIME') {
                S4flag = true;
                affiliate = true;
            } else {
                S4flag = false;
                affiliate = false;
            }

        } else {

            const queryData = {
                BP: bPart
            };
            checkedData = await odata.run(SELECT.from('SDBP').where(queryData));
            const { message, BPGroupcheck } = checkedData[0];
            if (message === 'IN TIME') {
                S4flag = true;
            } else {
                S4flag = false;
            }

            if (BPGroupcheck === '3rd Party') {
                affiliate = false;
                S4flag = false; // if the Bp is 3rd Part we will treat it as external outside S\4 entity to Jnj
            } else {
                affiliate = true
            }


        }
        const tollCheck = constants.TollCheck.some((toll) => atype?.includes(toll));




        switch (call) {
            case "ShipFrom":
                // legend notation  logic for ShipFrom 
                return archtypeBaseLegendMapping(atype, S4flag, archtyeLegendMapping, 'Sf')
                break;
            case "ShipTo":
                // legend notation  logic for ShipTo
                return archtypeBaseLegendMapping(atype, S4flag, archtyeLegendMapping, 'St')
                break;
            case "VEntity":
                // legend notation  logic for Virtual Entities
                return archtypeBaseLegendMapping(atype, S4flag, archtyeLegendMapping, 'Vir')
            case "VEntity1":
                return archtypeBaseLegendMapping(atype, S4flag, archtyeLegendMapping, 'Vir1')
            default:
                // Code to execute if no case matches
                throw new Error('Error entcountered wile creating Scenario ID for the Product Flow')
        }
    } catch (error) {
        req.error({
            message: error.message,
            status: 400
        });
    }
}

/**
 * scenarioPairSteps
 * @param {object} req : its the request object
 * @param {object} catid : its the Catalog Id
 * @param {String} typeOfOrder : it is the type of Order .
 * @param {String} call :  its the call to distinguish weather ProcessFlow called it or SBPA
 * @return {Object} scenarioSteps: its the end to end steps 
 */
async function scenarioPairSteps(req, catid, typeOfOrder, call, draft) {
    try {
        let draft1 = (draft === "false") ? false : true
        let checkCondition = draft1 ? {
            "ID": catid
        } : { "CatId": catid }

        let scenarioSteps = null;
        let sourceEntity = draft1 ? "ZBUVCM47419SERVICE_PFC_LIST_DRAFTS" : "jnj.com.zbuvcm47419.PfcHeaders"
        let data = await cds.run(
            SELECT.from(sourceEntity)
                .columns('SId', 'ArchType','PlantSTo','PlantSFrom')
                .where(checkCondition)
        );
        let sID = data[0]?.SId || data[0]?.SID;
        if (sID === null || sID === undefined || sID === '') {
            throw new Error('No ScenarioID present for given Product Flow!')
        }
        let SfArchType = data[0].ArchType;
        let checkDraft = draft1 ? { "parent_ID": catid } : { "CatId": catid }
        //Retreving records from virtualEntity
        let source = draft1 ? "ZBUVCM47419SERVICE_VENTITIES_DRAFTS" : "jnj.com.zbuvcm47419.PfcEntities"

        const archVal = await cds.run(
            SELECT.from(source)
                .columns('ArchType')
                .where(checkDraft)
                .orderBy('SeqNum')
        );


        // We have using the function for two seperate use . 
        // First is SBPA where for a particular Automation Trigger end to end steps is needed .
        // Second is ProcessFlow for which we are retireving end to end steps for all possible Automation trigger.
        if (call === 'SBPA') {

            scenarioSteps = await sIdPairSequenceRecords(sID, archVal, SfArchType, typeOfOrder)
        } else if (call === 'ProcessFlow') {
            const ZSD_VCM_PREREQAPI = await cds.connect.to("ZSD_VCM_PREREQAPI");

            const legEntityData = await ZSD_VCM_PREREQAPI.tx(req).get(`/FetchT001K`);
            function getLegalEntityFromPlant(plant, legEntityData) {
                const record = legEntityData.find(item => item.ValuationArea === plant);
                return record ? record.CompanyCode : "";
            }

            let poStepsPUSH = await sIdPairSequenceRecords(sID, archVal, SfArchType, '2','Push')
            let poStepsPULL = await sIdPairSequenceRecords(sID, archVal, SfArchType, '2','Pull')

            let soStepsAT = await sIdPairSequenceRecords(sID, archVal, SfArchType, '1','AT')
            let soStepsPUSH = await sIdPairSequenceRecords(sID, archVal, SfArchType, '1','Push')
            let soStepsPULL = await sIdPairSequenceRecords(sID, archVal, SfArchType, '1','Pull')
            
            let plants = await cds.run(
                SELECT.from(source)
                    .columns(['Plant', 'BPartner', 'SeqNum'])
                    .where(checkDraft)

            );

        

            /****************** Preparing Data for all case for UI******************* */
            
            poStepsPUSH = processFlowTranformation(poStepsPUSH,plants,legEntityData,data);
            poStepsPULL = processFlowTranformation(poStepsPULL,plants,legEntityData,data);

            soStepsAT = processFlowTranformation(soStepsAT,plants,legEntityData,data);
            soStepsPUSH = processFlowTranformation(soStepsPUSH,plants,legEntityData,data);
            soStepsPULL = processFlowTranformation(soStepsPULL,plants,legEntityData,data);

            /************************************************************************ */

            // let enrichedSOSteps = soSteps.map(step => {
            //     // find matching plant by SeqNum (Sequence=1 → VE1, Sequence=2 → VE2)
            //     const entityNum = step.Entity.match(/\d+/)?.[0]; // e.g., "2" from "VE2"
            //     const matchingPlant = plants.find(p => p.SeqNum === entityNum);

            //     if (matchingPlant) {
            //         // find company code from legalEntityData
            //         const matchingLE = legEntityData.find(le => le.ValuationArea === matchingPlant.Plant);

            //         return {
            //             ...step,
            //             LegalEntity: matchingLE ? matchingLE.CompanyCode : null

            //         };
            //     }

            //     // no plant found → return step unchanged
            //     return step;
            // });

            // let enrichedPOSteps = poSteps.map(step => {
            //     // find matching plant by SeqNum (Sequence=1 → VE1, Sequence=2 → VE2)
            //   const entityNum = step.Entity.match(/\d+/)?.[0]; // e.g., "2" from "VE2"
            //     const matchingPlant = plants.find(p => p.SeqNum === entityNum);

            //     if (matchingPlant) {
            //         // find company code from legalEntityData
            //         const matchingLE = legEntityData.find(le => le.ValuationArea === matchingPlant.Plant);

            //         return {
            //             ...step,
            //             LegalEntity: matchingLE ? matchingLE.CompanyCode : null

            //         };
            //     }

            //     // no plant found → return step unchanged
            //     return step;
            // });


            scenarioSteps = {
                SO_AT: soStepsAT,
                SO_PUSH: soStepsPUSH,
                SO_PULL:soStepsPULL,
                PO_PULL: poStepsPULL,
                PO_PUSH:poStepsPUSH
            }

        }

        return scenarioSteps;

    } catch (error) {
        req.error({
            message: error.message,
            status: 400
        });
    }
}


function processFlowTranformation(steps,plants,legEntityData,data){
    if(!steps || !Array.isArray(steps) || steps.length === 0) return [];

    let tranformedsteps =  steps.map(step => {
                // find matching plant by SeqNum (Sequence=1 → VE1, Sequence=2 → VE2)
              const entityNum = step.Entity.match(/\d+/)?.[0]; // e.g., "2" from "VE2"
        let matchingPlant = plants.find(p => p.SeqNum === entityNum);
        if (!entityNum && !matchingPlant&&step.Entity==="ST") {
            matchingPlant = data[0]?.PlantSTo
        }
        if (!entityNum && !matchingPlant&&step.Entity==="SF") {
            matchingPlant = data[0]?.PlantSFrom
        }

                if (matchingPlant) {
                    // find company code from legalEntityData
                    let matchingLE = legEntityData.find(le => le.ValuationArea === matchingPlant.Plant);

                    if(!matchingLE){
                     matchingLE=  legEntityData.find(le => le.ValuationArea ===matchingPlant )  
                    }

                    return {
                        ...step,
                        LegalEntity: matchingLE ? matchingLE.CompanyCode : null

                    };
                }

                // no plant found → return step unchanged
                return step;
            });

            return tranformedsteps;
}


async function scenarioPairStepsforSBPA(req, catid, sID, typeOfOrder,system) {

    let condition = {
                    SId: sID,
                    Variation: typeOfOrder,
                    Action: ['I/M', 'A','T'],
                    System:system
                }

        if(typeOfOrder === "2"){
            condition = {
                    SId: sID,
                    Variation: typeOfOrder,
                    Action: ['I', 'A', 'M', 'L','T'],
                    System:system
                }
        }

        if (sID === null || sID === undefined || sID === '') {
            throw new Error('No ScenarioID present for given Product Flow!')
        }

         let result = await cds.run(
            SELECT
                .columns('Pair', 'Description', 'System', 'ArchType', 'Variation', 'Sequence', 'Steps', 'Entity', 'Action','stepID')
                .from('jnj.com.zbuvcm47419.SIdPairSequence')
                .where(condition)
                .orderBy('Sequence')
        )

        return result;
}


/**
 * sIdPairSequenceRecords
 * @param {string} sId : its the scenario Id
 * @param {string} archVal : its the list for arch type values
 * @param {String} sfArchtype : it is the shipFrom Archtype value.
 * @param {String} typeOfOrder :  its the typeOfOrder 
 * @return {Object}  its the end to end steps 
 */
async function sIdPairSequenceRecords(sId, archVal, sfArchtype, typeOfOrder,system) {
/************************New code to retrieve end to end Steps ************************************* */
        let result = await cds.run(
            SELECT
                .columns('Pair', 'Description', 'System', 'ArchType', 'Variation', 'Sequence', 'Steps', 'Entity', 'Action')
                .from('jnj.com.zbuvcm47419.SIdPairSequence')
                .where({
                    SId: sId,
                    Variation: typeOfOrder,
                    Action: ['I/M', 'A', 'L', 'M', 'I','T'],
                    System:system
                })
                .orderBy('Sequence')
        )

        return result;
        /************************New code to retrieve end to end Steps ************************************* */
}

/**
 * sIdPairSequenceRecords
 * @param {string} sId : its the scenario Id
 * @param {string} archVal : its the list for arch type values
 * @param {String} sfArchtype : it is the shipFrom Archtype value.
 * @param {String} typeOfOrder :  its the typeOfOrder 
 * @return {Object}  its the end to end steps 
 */
// async function sIdPairSequenceRecordsSBPA(sId, archVal, sfArchtype, typeOfOrder,system) {
//         /************************New code to retrieve end to end Steps ************************************* */
//         let result = await cds.run(
//             SELECT
//                 .columns('Pair', 'Description', 'System', 'ArchType', 'Variation', 'Sequence', 'Steps', 'Entity', 'Action','stepsID')
//                 .from('jnj.com.zbuvcm47419.SIdPairSequence')
//                 .where({
//                     SId: sId,
//                     Variation: typeOfOrder,
//                     Action: ['I/M', 'A'],
//                     System:system
//                 })
//                 .orderBy('Sequence')
//         )

//         return result;
//         /************************New code to retrieve end to end Steps ************************************* */
// }


async function archtypeBaseLegendMapping(archType,S4Flag,archtypeMappingTable,call){
    let columnName =  S4Flag?`${call}_In_S4`:`${call}_In_NonS4`;
    const record = archtypeMappingTable?.find(item=>item.ArchType?.toString().trim().toLowerCase() === archType?.toString().trim().toLowerCase());
    const legend_value =  record?.[columnName]??null;
    if (legend_value) return legend_value.trim();
    else return legend_value;
}



module.exports = { createSID,createSID_Drafts, scenarioPairSteps, scenarioPairStepsforSBPA }