// --------------------------------------------------------------------------------------------------------------------*
// Application Name : PRODUCT FLOW CATALOG APPLICATION
// Object Id       : VCM47419
// Release         : 1
// Version         : 0.01
// Description     : Transactional tool creating product flows for material.
// --------------------------------------------------------------------------------------------------------------------*
// Descriptions: Function implementation to execute the logic for hana database calculations.
// --------------------------------------------------------------------------------------------------------------------*
// Change Log:
// //    Date     |       Author        |   Change Id   |   Change Description
// 26-03-2026      RChitike@its.jnj.com     50440096        TIME-FIN-DEV-PFCEnhanceme-Developement
// --------------------------------------------------------------------------------------------------------------------*

const cds = require('@sap/cds');

/**
 * getMatItem
 * @param {string} CatID
 * @return {object} data
 */
async function getMatItem(CatID) {
    try {
        const data = await cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcItems').where({
            'CatId': CatID
        }));

        return data;
    } catch (error) {
        throw error;
    }
}


/**
 * getVirtualEntity
 * @param {string} parentID
 * @return {object} data
 */
async function getVirtualEntity(parentID) {
    try {
        const data = await cds.run(SELECT.from('ZBUVCM47419SERVICE_VENTITIES_DRAFTS').where({ parent_ID: parentID }));
        return data;
    } catch (error) {
        throw error;
    }
}


/**
 * getCatID
 * @param {string} ID
 * @return {object} catData
 */
async function getCatID(ID) {
    try {
        const catData = await cds.run(SELECT.one.from('jnj.com.zbuvcm47419.PfcHeaders').columns('CatId').where({
            'ID': ID,
        }));

        return catData;
    } catch (error) {
        throw error;
    }
}

/**
 * updateWorkflowID
 * @param {string} workflowId
 * @param {string} ID
 * @return {object} response
 */
async function updateWorkflowID(workflowId, ID, bundle) {
    try {
        const response = await cds.run(UPDATE('jnj.com.zbuvcm47419.PfcItems').set({
            'WorkfInstId': workflowId,
            'vToFieldControl': 1,
            'MatnrFeildControl': 1,
            'MatDescFeildControl': 1,
            'MatTypeFeildControl': 1,
            'MatBrandFeildControl': 1,
            'VFromFeildControl': 1,
            'criticality': 2,
            'ApprStatus': bundle.getText("pendingForApproval")
        }).where({
            'parent': ID
        }));

        return response;
    } catch (error) {
        throw error;
    }
}




/**
 * updateWorkflowID
 * @param {string} CatID
 * @param {string} ID
 * @return {object} itemUpdate
 */
async function updateItem(CatID, ID) {
    try {
        const itemUpdate = await cds.run(UPDATE('jnj.com.zbuvcm47419.PfcItems').set({
            'CatId': CatID,
            'fieldControl': 1,

        }).where({
            'parent': ID
        }));

        return itemUpdate;
    } catch (error) {
        throw error;
    }
}

/**
 * updateVentity
 * @param {string} CatID
 * @param {string} ID
 * @return {object} entityUpdate
 */
async function updateVentity(CatID, ID) {
    try {
        const entityUpdate = await cds.run(UPDATE('jnj.com.zbuvcm47419.PfcEntities').set({
            'CatId': CatID,
            'fieldControl': 1
        }).where({
            'parent': ID
        }));

        return entityUpdate;
    } catch (error) {
        throw error;
    }
}

// ***** JGHJ-71574 ***** R2.2 START *****
/**
 * updateSID
 * @param {string} sID
 * @param {string} ID
 * @return {object} response
 */
async function updateSID(sID, ID, draft='false',prodID) {
    try {

        const uasRecord = await cds.run(
            SELECT.one
                .from('jnj.com.zbuvcm47419.UASIDDetermination')
                .where({ flowId: prodID?.trim() })
        );

        let sourceEntity=draft==="true"?"ZBUVCM47419SERVICE_PFC_LIST_DRAFTS":"jnj.com.zbuvcm47419.PfcHeaders"
        const response = await cds.run(UPDATE(sourceEntity).set({
            'SId': sID,
            'UasId': uasRecord?.UasId || 'no existing UAS'
        }).where({
            'ID': ID
        }));

        return response;

    } catch (error) {
        throw error;
    }
}
// ***** JGHJ-71574 ***** R2.2 END *****



/**
 * getSID
 * @param {string} CatID
 * @return {SStringID} SId
 */
async function getSID(CatIDs) {
    try {
        const data = await cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcHeaders').columns('CatId', 'SId').where({
            'CatId': CatIDs,
        }));

        return data;
    } catch (error) {
        throw error;
    }
}



/**
 * getPfcList
 * @param none
 * @return {object} data
 */
async function getPfcList(excludeID = null) {
    try {
        const query = SELECT.from('jnj.com.zbuvcm47419.PfcHeaders', a => {
            a`.*`,
            a.Items(b => {
                b`.*`;
            }),
            a.Ventities(c => {
                c`.*`;
            });
        });

        if (excludeID) {
            query.where({ ID: { '!=': excludeID } });
        }

        const data = await cds.run(query);
        return data;
    } catch (error) {
        throw error;
    }
}
/**
 * getSinglePfcData
 * @param none
 * @return {object} data
 */
async function getSinglePfcData(catalogId) {
    try {
        const data = await cds.run(
            SELECT.from('jnj.com.zbuvcm47419.PfcHeaders', a => {
                a`.*`,
                    a.Items(b => {
                        b`.*`
                    }),
                    a.Ventities(c => {
                        c`.*`
                    })
            }).where({CatId:catalogId})
        );

        return data;
    } catch (error) {
        throw error;
    }
}



/**
 * getMaterialDataWorkFlow
 * @param {string} Cat_ID
 * @param {string} Wf_ID
 * @return {object} materialData
 */
async function getMaterialDataWorkFlow(Cat_ID, Wf_ID) {
    try {
        const materialData = await cds.run(
            SELECT.from('jnj.com.zbuvcm47419.PfcItems')
                .columns('CatId', 'MatBrand', 'Matnr', 'VFrom', 'VTo', 'createdBy', 'createdAt', 'MatType', 'Status')
                .where({
                    "CatId": Cat_ID,
                    "WorkfInstId": Wf_ID
                }).orderBy('ItemNum')
        );

        return materialData;
    } catch (error) {
        throw error;
    }
}

/**
 * getWorkflowHistory
 * @param {string} Cat_ID
 * @return {object} historyData
 */
async function getWorkflowHistory(Cat_ID) {
    try {
        const historyData = await cds.run(
            SELECT.from('jnj.com.zbuvcm47419.PfcItemsWFHistory')
                .where({
                    "CatId": Cat_ID
                })
        );

        return historyData;
    } catch (error) {
        throw error;
    }
}

/**
 * getWorkflowHistory
 * @param {string} Cat_ID
 * @return {object} data
 */
async function getVlistforWorkflow(Cat_ID) {
    try {
        const data = await cds.run(
            SELECT.from('jnj.com.zbuvcm47419.PfcEntities').columns('SeqNum', 'ArchType', 'Plant', 'BPartner').where({ "CatId": Cat_ID }).orderBy('SeqNum') // Sort by SeqNum in ascending order
        );

        return data;
    } catch (error) {
        throw error;
    }
}

/**
 * getApprovarDetail
 * @param {string} SFEcoRegion
 * @param {string} STEcoRegion
 * @return {object} results
 */
async function getApprovarDetail(SFEcoRegion, STEcoRegion) {
    try {
        const results = await cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcWorkFlowApprover')
            .where({ "EcoRCode": [SFEcoRegion, STEcoRegion] })// Sort by SeqNum in ascending order
        );

        return results;
    } catch (error) {
        throw error;
    }
}


/**
 * getWorkflowHistory
 * @param {object} req
 * @return {string} data
 */
// async function updateWorkFlowData(req, bundle) {
//     const tx = cds.transaction(req);

//     try {
//         const materialUpdates = req.data.MatData;

//         if (!materialUpdates || materialUpdates.length === 0) {
//             return bundle.getText("noUpdatesProvided");
//         }

//         /* =====================================================
//            1️ PRE-FETCH existing items in ONE DB call
//         ===================================================== */
//         const existingItems = await tx.run(
//             SELECT.from('jnj.com.zbuvcm47419.PfcItems')
//                 .columns('WorkfInstId', 'CatId', 'Matnr', 'MatBrand','MatType','pFStatus','VTo', 'VFrom', 'Status', 'PrevStatus', 'PrevPFStatus', 'PrevVFrom', 'ApprStatus','PrevVTo')
//                 .where({
//                     WorkfInstId: { in: materialUpdates.map(m => m.WorkfInstId) },
//                     CatId: { in: materialUpdates.map(m => m.CatId) }
//                 })
//         );

//         const itemMap = new Map();
//         for (const item of existingItems) {
//             const key = `${item.WorkfInstId}|${item.CatId}|${item.Matnr || ''}|${item.MatBrand || ''}`;
//             itemMap.set(key, item);
//         }

//         let baseTime = Date.now();

//         const APPROVED = bundle.getText('Approved');
//         const REJECTED = bundle.getText('Rejected');
//         const REWORKED = bundle.getText('Reworked');
//         const PENDING = bundle.getText('pendingForApproval');

//         const normalize = v => (v === null || v === undefined) ? '' : String(v).trim();
//         const isToken = (incoming, tokenKeyOrAliases) => {
//       if (!incoming && incoming !== 0) return false;
//       const incomingStr = normalize(incoming).toLowerCase();

//       // Accept either a single token key or an array of aliases
//       const aliases = Array.isArray(tokenKeyOrAliases) ? tokenKeyOrAliases : [tokenKeyOrAliases];

//       for (const alias of aliases) {
//         if (!alias && alias !== 0) continue;
//         const aliasStr = String(alias);
//         const bundleText = normalize(bundle.getText(aliasStr)).toLowerCase();
//         // compare against alias itself (lowercased) and bundle translation (lowercased)
//         if (incomingStr === aliasStr.toLowerCase() || incomingStr === bundleText) return true;
//       }
//       return false;
//     };


//         for (let i = 0; i < materialUpdates.length; i++) {

//             const update = materialUpdates[i];

//             const {
//                 CatId,
//                 WorkfInstId,
//                 Matnr,
//                 MatBrand,
//                 MatType,
//                 ApprStatus,
//                 ApprDate,
//                 FApprover,
//                 Comment
//             } = update;

//             const key = `${WorkfInstId}|${CatId}|${Matnr || ''}|${MatBrand || ''}`;
//             const existingItem = itemMap.get(key);

//             if (!existingItem) continue;

//             // Snapshot BEFORE any logic runs — this is what gets written to Prev* columns.
//             let prevStatusValue = existingItem.Status || null;
//             let prevPFStatusValue = existingItem.pFStatus || null;
//             let prevVFromValue = existingItem.VFrom || null;
//             let prevVToValue = existingItem.VTo || null; 

//             let newStatus = existingItem.Status;
//             let newVFrom = existingItem.VFrom;
//             let newVTo =  existingItem.VTo;
//             let pFStatus = existingItem.pFStatus;
//             let newAppStatus = ApprStatus;

//             // Improve identification of incoming states (support several alias forms)
//       let incomingIsApproved = isToken(ApprStatus, ['Approved']);
//       let incomingIsRejected = isToken(ApprStatus, ['Rejected']);
//       let incomingIsReworked = isToken(ApprStatus, ['Reworked']);
//       let incomingIsPending = isToken(ApprStatus, ['pendingForApproval']);


//          /* ================= FIELD CONTROL LOGIC (cleaned up) ================= */
//       const LOCKED = 1;
//       const EDITABLE = 7;

//       const isApprovedForControls = incomingIsApproved;
//       const isReworkedForControls = incomingIsReworked;

//       // vToFieldControl: locked for rejected/pending, editable otherwise
//       let vToFieldControl = (incomingIsRejected || incomingIsPending) ? LOCKED : EDITABLE;
//       // rFeildControl: editable when approved or reworked, locked otherwise
//       let rFeildControl = (isApprovedForControls || isReworkedForControls ) ? LOCKED : EDITABLE;
//       // MatNr field control: for approved keep locked (1) per original intent, reworked -> editable
//       let MatnrFeildControl = isReworkedForControls ? EDITABLE : (isApprovedForControls ? 1 : 1);
//       // Other field controls follow same pattern (kept consistent)
//       let perFieldControl = isReworkedForControls ? EDITABLE : (isApprovedForControls ? 1 : 1);


//             /* ================= Business Logic ================= */
//             if (ApprStatus === APPROVED) {
//                 newStatus = "Active";
//                 pFStatus = '';
//                 rFeildControl = EDITABLE;
//                 vToFieldControl = EDITABLE;

//                 if (existingItem.Status === "Active" && existingItem.pFStatus === 'Change In The Flow') {
//                     newStatus = existingItem.Status;
//                 }

//                 if (existingItem.Status === "Block" && existingItem.pFStatus === 'Change In The Flow') {
//                     newStatus = existingItem.Status;
//                     pFStatus = 'Change In The Flow';
//                 }

//                 if (existingItem.Status === "InActive") {
//                     newStatus = existingItem.Status;
//                       rFeildControl = LOCKED;
//                       vToFieldControl = LOCKED;
//                 }

//                 const today = new Date();
//                 const todayUtc = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()));

//                 if (existingItem.VFrom) {
//                     const existingVFromDate = new Date(existingItem.VFrom);
//                     newVFrom =
//                         !isNaN(existingVFromDate.getTime()) && existingVFromDate.getTime() >= todayUtc.getTime()
//                             ? existingItem.VFrom
//                             : ApprDate;
//                 } else {
//                     newVFrom = ApprDate;
//                 }
//             }
//             else if (ApprStatus === REJECTED) {
//                 const prevWasRework = existingItem.ApprStatus === REWORKED;

//                 if (prevWasRework) {
//                     if (existingItem.PrevStatus) newStatus = existingItem.PrevStatus;
//                     // if (existingItem.PrevPFStatus) pFStatus = existingItem.PrevPFStatus;
//                     if (existingItem.PrevPFStatus != null) pFStatus = existingItem.PrevPFStatus;
//                     if (existingItem.PrevVFrom) newVFrom = existingItem.PrevVFrom;
//                     if (existingItem.PrevVTo) newVTo = existingItem.PrevVTo;
//                 } else {
//                     newStatus = existingItem.PrevStatus || existingItem.Status;
//                     // pFStatus = existingItem.PrevPFStatus || existingItem.pFStatus;
//                     pFStatus = existingItem.PrevPFStatus ?? existingItem.pFStatus;
//                     newVFrom = existingItem.PrevVFrom || existingItem.VFrom;
//                     newVTo = existingItem.PrevVTo || existingItem.VTo;

//                     if (existingItem.Status === "Active" || existingItem.Status === "InActive") {
//                     //     newAppStatus = APPROVED;
//                     //     pFStatus = `Status '${existingItem.Status}' Requested and 'Rejected' by approver. Product flow catalog original status unchanged`;
//                     // } else {
//                     //     pFStatus = '';
//                     //     newAppStatus = REJECTED;
//                     // }
//                     // if (newStatus === "Active" || newStatus === "InActive") {
//                         newAppStatus = APPROVED;
//                         pFStatus = `Status '${newStatus}' Requested and 'Rejected' by approver. Product flow catalog original status unchanged`;
//                         rFeildControl = EDITABLE;
//                         vToFieldControl = EDITABLE;

//                     }
//                     else {
//                         pFStatus = '';
//                         newAppStatus = REJECTED;
//                         rFeildControl = LOCKED;
//                         vToFieldControl = LOCKED;
//                     }
//                 }

//                 // FIX: a reject doesn't confirm anything new — it restores. So the Prev*
//                 // fields written to the DB must mirror the *restored* values, not the
//                 // pending/requested snapshot, or the next reject in the chain will
//                 // "restore" to the wrong thing.
//                 prevStatusValue = newStatus;
//                 prevPFStatusValue = pFStatus;
//                 prevVFromValue = newVFrom;
//                 prevVToValue = newVTo;

//             }
//             else if (ApprStatus === PENDING) {
//                 newAppStatus = PENDING;
//                 rFeildControl=1;
//                 vToFieldControl=1;
//                 // Pending: do not change status/pFStatus
//             }
//             else if (ApprStatus === REWORKED) {
//                 newAppStatus = REWORKED;
//                 rFeildControl = 7;
//                 vToFieldControl=7;
//                 // prevStatusValue = existingItem.PrevStatus;
//                 // prevPFStatusValue = existingItem.PrevPFStatus;
//                 // prevVFromValue = existingItem.PrevVFrom;
//                 // prevVToValue =  existingItem.PrevVTo;
//                 // Reworked: do not change status/pFStatus — reject-from-rework relies on this being recorded
//             }
//             else {
//                 // Unknown incoming ApprStatus: keep existing values, store raw value or fall back to pending
//                 newAppStatus = ApprStatus || PENDING;
//             }

//             /* ================= BUILD WHERE ================= */
//             let whereCondition = `WorkfInstId = '${WorkfInstId}' AND CatId = '${CatId}'`;
//             let whereClauseHeader = {CatId};


//             if (Matnr === "") {
//                 whereCondition += ` AND (Matnr = '' OR Matnr IS NULL)`;
//             } else {
//                 whereCondition += ` AND Matnr = '${Matnr}'`;
//             }

//             if (MatBrand === "") {
//                 whereCondition += ` AND (MatBrand = '' OR MatBrand IS NULL)`;
//             } else {
//                 whereCondition += ` AND MatBrand = '${MatBrand}'`;
//             }

//             /* ================= UPDATE ================= */
//             await tx.run(
//                 UPDATE('jnj.com.zbuvcm47419.PfcItems')
//                     .set({
//                         vToFieldControl,
//                         rFeildControl,

//                         MatnrFeildControl: newAppStatus === REWORKED ? 7 : 1,
//                         MatDescFeildControl: newAppStatus === REWORKED ? 7 : 1,
//                         MatTypeFeildControl: newAppStatus === REWORKED ? 7 : 1,
//                         MatBrandFeildControl: newAppStatus === REWORKED ? 7 : 1,
//                         VFromFeildControl: newAppStatus === REWORKED ? 7 : 1,

//                         criticality:
//                             newAppStatus === REJECTED
//                                 ? 1
//                                 : newAppStatus === REWORKED
//                                     ? 7
//                                     : newAppStatus === PENDING
//                                         ? 2
//                                         : 3,

//                         // FIX: compare against newAppStatus using bundle.getText consistently,
//                         // and cover every branch explicitly so "Pending" no longer gets stored as "Approved".
//                         ApprStatus:
//                             newAppStatus === REJECTED ? REJECTED :
//                                 newAppStatus === REWORKED ? REWORKED :
//                                     newAppStatus === PENDING ? PENDING :
//                                         APPROVED,

//                         PrevStatus: prevStatusValue,
//                         PrevPFStatus: prevPFStatusValue,
//                         PrevVFrom: prevVFromValue,
//                         PrevVTo:prevVToValue,

//                         VFrom: newVFrom,
//                         VTo: newVTo,
//                         pFStatus,
//                         Status: newStatus,
//                         ApprDate,
//                         FApprover,
//                         Comment
//                     })
//                     .where(whereCondition)
//             );
//             if ((newStatus === 'New' && newAppStatus === bundle.getText('Reworked'))) {
//                 await tx.run(
//                     UPDATE('jnj.com.zbuvcm47419.PfcHeaders')
//                         .set({
//                             fieldControl: 7
//                         })
//                         .where(whereClauseHeader)
//                 );
//                 await tx.run(
//                     UPDATE('jnj.com.zbuvcm47419.PfcEntities')
//                         .set({
//                             fieldControl: 7
//                         })
//                         .where(whereClauseHeader)
//                 );
//             } else {
//                 await tx.run(
//                     UPDATE('jnj.com.zbuvcm47419.PfcHeaders')
//                         .set({
//                             fieldControl: 1
//                         })
//                         .where(whereClauseHeader)
//                 );
//                 await tx.run(
//                     UPDATE('jnj.com.zbuvcm47419.PfcEntities')
//                         .set({
//                             fieldControl: 1
//                         })
//                         .where(whereClauseHeader)
//                 );
//             }


//             /* ================= HISTORY INSERT ================= */
//             const uniqueTimestamp = new Date(baseTime + i);
//             await tx.run(
//                 INSERT.into('jnj.com.zbuvcm47419.PfcItemsWFHistory').entries({
//                     ID: cds.utils.uuid(),
//                     CatId,
//                     WorkfInstId,
//                     Matnr,
//                     MatBrnd: MatBrand,
//                     ApprovalStatus: newAppStatus,
//                     Uname: FApprover,
//                     Comment,
//                     Timestamp: uniqueTimestamp,
//                     MatType: MatType,
//                     Status: newStatus
//                 })
//             );
//         }

//         await tx.commit();

//         return `${bundle.getText("workflowUpdates")} ${materialUpdates.length} ${bundle.getText("records")}`;

//     } catch (error) {
//         await tx.rollback();
//         throw error;
//     }
// }
// async function updateWorkFlowData(req, bundle) {
//     const tx = cds.transaction(req);

//     try {
//         const materialUpdates = req.data.MatData;

//         if (!materialUpdates || materialUpdates.length === 0) {
//             return bundle.getText("noUpdatesProvided");
//         }

//         /* =====================================================
//            1️ PRE-FETCH existing items in ONE DB call
//         ===================================================== */
//         const existingItems = await tx.run(
//             SELECT.from('jnj.com.zbuvcm47419.PfcItems')
//                 .columns('WorkfInstId', 'CatId', 'Matnr', 'MatBrand', 'MatType', 'pFStatus', 'VTo', 'VFrom', 'Status', 'PrevStatus', 'PrevPFStatus', 'PrevVFrom', 'ApprStatus', 'PrevVTo','PrevApprStatus')
//                 .where({
//                     WorkfInstId: { in: materialUpdates.map(m => m.WorkfInstId) },
//                     CatId: { in: materialUpdates.map(m => m.CatId) }
//                 })
//         );

//         const itemMap = new Map();
//         for (const item of existingItems) {
//             const key = `${item.WorkfInstId}|${item.CatId}|${item.Matnr || ''}|${item.MatBrand || ''}`;
//             itemMap.set(key, item);
//         }

//         let baseTime = Date.now();

//         const APPROVED = bundle.getText('Approved');
//         const REJECTED = bundle.getText('Rejected');
//         const REWORKED = bundle.getText('Reworked');
//         const PENDING = bundle.getText('pendingForApproval');

//         const normalize = v => (v === null || v === undefined) ? '' : String(v).trim();
//         const normalizeLower = v => normalize(v).toLowerCase();

//         // Generic equality helper (case-insensitive, trims)
//         const equals = (val, expected) => normalizeLower(val) === normalizeLower(expected);

//         // Reuse existing isToken for incoming token checks (handles bundle.getText aliasing)
//         const isToken = (incoming, tokenKeyOrAliases) => {
//             if (!incoming && incoming !== 0) return false;
//             const incomingStr = normalize(incoming).toLowerCase();
//             const aliases = Array.isArray(tokenKeyOrAliases) ? tokenKeyOrAliases : [tokenKeyOrAliases];

//             for (const alias of aliases) {
//                 if (!alias && alias !== 0) continue;
//                 const aliasStr = String(alias);
//                 const bundleText = normalize(bundle.getText(aliasStr)).toLowerCase();
//                 if (incomingStr === aliasStr.toLowerCase() || incomingStr === bundleText) return true;
//             }
//             return false;
//         };

//         for (let i = 0; i < materialUpdates.length; i++) {
//             const update = materialUpdates[i];
//             const {
//                 CatId, WorkfInstId, Matnr, MatBrand, MatType,
//                 ApprStatus, ApprDate, FApprover, Comment: incomingComment
//             } = update;

//             const key = `${WorkfInstId}|${CatId}|${Matnr || ''}|${MatBrand || ''}`;
//             const existingItem = itemMap.get(key);

//             if (!existingItem) continue;

//             // Capture incoming token for history/audit (preserve raw incoming action)
//             const incomingApprovalToken = ApprStatus;

//             // Snapshot BEFORE any logic runs (preserve original snapshot)
//             let prevStatusValue = existingItem.Status || null;
//             let prevPFStatusValue = existingItem.ApprStatus || null;
//             let prevVFromValue = existingItem.VFrom || null;
//             let prevVToValue = existingItem.VTo || null;

//             let newStatus = existingItem.Status;
//             let newVFrom = existingItem.VFrom;
//             let newVTo = existingItem.VTo;
//             let pFStatus = existingItem.ApprStatus;
//             let newAppStatus = ApprStatus;
//             let finalComment = incomingComment || "";

//             let incomingIsApproved = isToken(ApprStatus, ['Approved']);
//             let incomingIsRejected = isToken(ApprStatus, ['Rejected']);
//             let incomingIsReworked = isToken(ApprStatus, ['Reworked']);
//             let incomingIsPending = isToken(ApprStatus, ['pendingForApproval']);

//             /* ================= DEFAULT FIELD CONTROLS ================= */
//             const LOCKED = 1;
//             const EDITABLE = 7;

//             let vToFieldControl = LOCKED;
//             let rFeildControl = LOCKED;
//             let MatnrFeildControl = LOCKED;
//             let MatDescFeildControl = LOCKED;
//             let MatTypeFeildControl = LOCKED;
//             let MatBrandFeildControl = LOCKED;
//             let VFromFeildControl = LOCKED;
//             let headerEntityFieldControl = LOCKED;

//             /* ================= BUSINESS LOGIC ================= */
//             if (incomingIsApproved) {
//                 newAppStatus = APPROVED;
//                 pFStatus = APPROVED;

//                 if (equals(existingItem.Status, "New")) {
//                     newStatus = "Active";
//                     prevStatusValue = newStatus;
//                     rFeildControl = EDITABLE;
//                     vToFieldControl = EDITABLE;
//                 } else if (equals(existingItem.Status, "Active") && equals(existingItem.pFStatus, 'Change In The Flow')) {
//                     newStatus = existingItem.Status;
//                     rFeildControl = EDITABLE;
//                     vToFieldControl = EDITABLE;
//                 } else if (equals(existingItem.Status, "Block") && equals(existingItem.pFStatus, 'Change In The Flow')) {
//                     newStatus = existingItem.Status;
//                     rFeildControl = EDITABLE;
//                     vToFieldControl = EDITABLE;
//                 } else if (equals(existingItem.Status, "Inactive") || equals(existingItem.Status, "InActive")) {
//                     newStatus = existingItem.Status;
//                     rFeildControl = LOCKED;
//                     vToFieldControl = LOCKED;
//                 } else {
//                     newStatus = existingItem.Status;
//                     rFeildControl = EDITABLE;
//                     vToFieldControl = EDITABLE;
//                 }

//                 const today = new Date();
//                 const todayUtc = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()));
//                 if (existingItem.VFrom) {
//                     const existingVFromDate = new Date(existingItem.VFrom);
//                     newVFrom = !isNaN(existingVFromDate.getTime()) && existingVFromDate.getTime() >= todayUtc.getTime()
//                         ? existingItem.VFrom : ApprDate;
//                 } else {
//                     newVFrom = ApprDate;
//                 }

//             } else if (incomingIsRejected) {
//                 // Generate dynamic system comment
//                 if (!equals(existingItem.Status, 'New')) {
//                     let proposedStatus = existingItem.Status;
//                     let originalStatus = existingItem.PrevStatus;
//                     let proposedVTo = existingItem.VTo;
//                     let originalVTo = existingItem.PrevVTo;

//                     let isStatusChange = originalStatus && (proposedStatus !== originalStatus);
//                     let isValidityChange = originalVTo && (proposedVTo !== originalVTo);

//                     let systemComment = "";
//                     if (isStatusChange && isValidityChange) {
//                         systemComment = `Status '${proposedStatus}' and validity period change requested and rejected by approver. Product flow catalog original status and validity period remain unchanged.`;
//                     } else if (isStatusChange) {
//                         systemComment = `Status '${proposedStatus}' requested and rejected by approver. Product flow catalog original status unchanged.`;
//                     } else if (isValidityChange) {
//                         systemComment = `Status '${proposedStatus}' and validity period change requested and rejected by approver. Product flow catalog original status and validity period remain unchanged.`;
//                     } else {
//                         systemComment = `Status '${proposedStatus}' requested and rejected by approver. Product flow catalog original status unchanged.`;
//                     }

//                     finalComment = incomingComment ? `${systemComment} ${incomingComment}` : systemComment;
//                 }

//                 // Restore previous values (Status / Validity / ProductFlowStatus) for business rollback
//                 // Use token matcher to detect prior rework instead of localized equals comparison
//                 const prevWasRework = isToken(existingItem.ApprStatus, ['Reworked']);
//                 if (prevWasRework) {
//                     if (existingItem.PrevStatus) newStatus = existingItem.PrevStatus;
//                     if (existingItem.PrevPFStatus != null) pFStatus = existingItem.PrevPFStatus;
//                     if (existingItem.PrevVFrom) newVFrom = existingItem.PrevVFrom;
//                     if (existingItem.PrevVTo) newVTo = existingItem.PrevVTo;
//                 } else {
//                     newStatus = existingItem.PrevStatus || existingItem.Status;
//                     newVFrom = existingItem.PrevVFrom || existingItem.VFrom;
//                     newVTo = existingItem.PrevVTo || existingItem.VTo;

//                     if (equals(newStatus, 'New')) {
//                         pFStatus = REJECTED;
//                     } else {
//                         pFStatus = existingItem.PrevPFStatus ?? existingItem.pFStatus;
//                     }
//                 }

//                 // --- CORRECT BEHAVIOR: do not persist REJECTED on existing items ---
//                 // For brand-new items keep REJECTED; for existing items set ApprStatus to restored pFStatus
//                 if (equals(newStatus, 'New')) {
//                     newAppStatus = REJECTED;
//                 } else {
//                     newAppStatus = pFStatus; // restore previous approval state on item row
//                 }

//                 // Lock fields when rejected (scenarios indicate locked on rejection)
//                 vToFieldControl = LOCKED;
//                 rFeildControl = LOCKED;
//                 headerEntityFieldControl = LOCKED;

//             } else if (incomingIsPending) {
//                 newAppStatus = PENDING;
//                 pFStatus = PENDING;
//             } else if (incomingIsReworked) {
//                 newAppStatus = REWORKED;
//                 pFStatus = REWORKED;

//                 // preserve previous-snapshot semantics
//                 prevStatusValue = existingItem.PrevStatus || existingItem.Status;
//                 prevPFStatusValue = existingItem.PrevPFStatus || existingItem.pFStatus;
//                 prevVFromValue = existingItem.PrevVFrom || existingItem.VFrom;
//                 prevVToValue = existingItem.PrevVTo || existingItem.VTo;

//                 // Determine if this item is a newly added line (prefer explicit flag if you have it).
//                 // Fallback heuristic: PrevStatus empty/null means newly added in current flow submission.
//                 const isNewLineItem = !normalize(existingItem.PrevStatus);

//                 if (equals(existingItem.Status, 'New') || isNewLineItem) {
//                     vToFieldControl = EDITABLE; rFeildControl = EDITABLE; MatnrFeildControl = EDITABLE;
//                     MatDescFeildControl = EDITABLE; MatTypeFeildControl = EDITABLE;
//                     MatBrandFeildControl = EDITABLE; VFromFeildControl = EDITABLE;
//                     headerEntityFieldControl = EDITABLE;
//                 } else if (equals(existingItem.Status, 'Inactive') || equals(existingItem.PrevStatus, 'Inactive') || equals(existingItem.Status, 'InActive') || equals(existingItem.PrevStatus, 'InActive')) {
//                     vToFieldControl = EDITABLE; rFeildControl = EDITABLE;
//                     headerEntityFieldControl = LOCKED;
//                 } else {
//                     // existing approved flow: only newly added lines editable -> keep this item locked
//                     vToFieldControl = EDITABLE; rFeildControl = EDITABLE;
//                 }
//             } else {
//                 newAppStatus = ApprStatus || PENDING;
//             }

//             /* ================= BUILD WHERE (structured) ================= */
//             const whereClauseItem = { WorkfInstId, CatId };
//             if (Matnr === "") {
//                 whereClauseItem.or = whereClauseItem.or || [];
//                 whereClauseItem.or.push({ Matnr: '' }, { Matnr: null });
//             } else {
//                 whereClauseItem.Matnr = Matnr;
//             }
//             if (MatBrand === "") {
//                 whereClauseItem.or = whereClauseItem.or || [];
//                 whereClauseItem.or.push({ MatBrand: '' }, { MatBrand: null });
//             } else {
//                 whereClauseItem.MatBrand = MatBrand;
//             }

//             const whereClauseHeader = { CatId };

//             /* ================= UPDATE ================= */
//             await tx.run(
//                 UPDATE('jnj.com.zbuvcm47419.PfcItems')
//                     .set({
//                         vToFieldControl,
//                         rFeildControl,
//                         MatnrFeildControl,
//                         MatDescFeildControl,
//                         MatTypeFeildControl,
//                         MatBrandFeildControl,
//                         VFromFeildControl,

//                         criticality: newAppStatus === REJECTED ? 1 :
//                             newAppStatus === REWORKED ? 7 :
//                                 newAppStatus === PENDING ? 2 : 3,

//                         ApprStatus: newAppStatus,
//                         PrevStatus: prevStatusValue,
//                         PrevPFStatus: prevPFStatusValue,
//                         PrevVFrom: prevVFromValue,
//                         PrevVTo: prevVToValue,
//                         VFrom: newVFrom,
//                         VTo: newVTo,
//                         pFStatus,
//                         Status: newStatus,
//                         ApprDate,
//                         FApprover,
//                         Comment: finalComment
//                     })
//                     .where(whereClauseItem)
//             );

//             if ((equals(newStatus, 'New') && equals(newAppStatus, REWORKED)) || (newStatus === 'New' && newAppStatus === REWORKED)) {
//                 await tx.run(
//                     UPDATE('jnj.com.zbuvcm47419.PfcHeaders').set({ fieldControl: 7 }).where(whereClauseHeader)
//                 );
//                 await tx.run(
//                     UPDATE('jnj.com.zbuvcm47419.PfcEntities').set({ fieldControl: 7 }).where(whereClauseHeader)
//                 );
//             } else {
//                 await tx.run(
//                     UPDATE('jnj.com.zbuvcm47419.PfcHeaders').set({ fieldControl: 1 }).where(whereClauseHeader)
//                 );
//                 await tx.run(
//                     UPDATE('jnj.com.zbuvcm47419.PfcEntities').set({ fieldControl: 1 }).where(whereClauseHeader)
//                 );
//             }

//             /* ================= HISTORY INSERT ================= */
//             const uniqueTimestamp = new Date(baseTime + i);
//             await tx.run(
//                 INSERT.into('jnj.com.zbuvcm47419.PfcItemsWFHistory').entries({
//                     ID: cds.utils.uuid(),
//                     CatId,
//                     WorkfInstId,
//                     Matnr,
//                     MatBrnd: MatBrand,
//                     ApprovalStatus: isToken(incomingApprovalToken, ['Rejected']) ? REJECTED :
//                         isToken(incomingApprovalToken, ['Reworked']) ? REWORKED :
//                             isToken(incomingApprovalToken, ['pendingForApproval']) ? PENDING :
//                                 isToken(incomingApprovalToken, ['Approved']) ? APPROVED :
//                                     newAppStatus,
//                     Uname: FApprover,
//                     Comment: finalComment,
//                     Timestamp: uniqueTimestamp,
//                     MatType: MatType,
//                     Status: newStatus
//                 })
//             );
//         }

//         await tx.commit();
//         return `${bundle.getText("workflowUpdates")} ${materialUpdates.length} ${bundle.getText("records")}`;

//     } catch (error) {
//         await tx.rollback();
//         throw error;
//     }
// }

async function updateWorkFlowData(req, bundle) {
    const tx = cds.transaction(req);

    try {
        const materialUpdates = req.data.MatData;

        if (!materialUpdates || materialUpdates.length === 0) {
            return bundle.getText("noUpdatesProvided");
        }

        /* =====================================================
           PRE-FETCH existing items in ONE DB call
        ===================================================== */
        const existingItems = await tx.run(
            SELECT.from('jnj.com.zbuvcm47419.PfcItems')
                .columns(
                    'WorkfInstId', 'CatId', 'Matnr', 'MatBrand', 'MatType','MatDesc',
                    'pFStatus', 'VTo', 'VFrom', 'Status',
                    'PrevStatus', 'PrevPFStatus', 'PrevVFrom', 'PrevVTo',
                    'ApprStatus', 'PrevApprStatus','PrevMatnr','PrevMatDesc','PrevMatBrand','PrevMatType'
                )
                .where({
                    WorkfInstId: { in: materialUpdates.map(m => m.WorkfInstId) },
                    CatId: { in: materialUpdates.map(m => m.CatId) }
                })
        );
        
        const itemMap = new Map();
        for (const item of existingItems) {
            const key = `${item.WorkfInstId}|${item.CatId}|${item.Matnr || ''}|${item.MatBrand || ''}`;
            itemMap.set(key, item);
        }

        let baseTime = Date.now();

        const APPROVED = bundle.getText('Approved');
        const REJECTED = bundle.getText('Rejected');
        const REWORKED = bundle.getText('Reworked');
        const PENDING = bundle.getText('pendingForApproval');
        var headerControl;

        /* ── helpers ── */
        const normalize = v => (v === null || v === undefined) ? '' : String(v).trim();
        const normalizeLower = v => normalize(v).toLowerCase();
        const equals = (val, expected) => normalizeLower(val) === normalizeLower(expected);
        let headerControlFlag = new Set();   
        const isToken = (incoming, tokenKeyOrAliases) => {
            if (!incoming && incoming !== 0) return false;
            const incomingStr = normalizeLower(incoming);
            const aliases = Array.isArray(tokenKeyOrAliases) ? tokenKeyOrAliases : [tokenKeyOrAliases];
            for (const alias of aliases) {
                if (!alias && alias !== 0) continue;
                const aliasStr = String(alias);
                const bundleVal = normalizeLower(bundle.getText(aliasStr));
                if (incomingStr === aliasStr.toLowerCase() || incomingStr === bundleVal) return true;
            }
            return false;
        };

        /* ================================================================
           MAIN LOOP
        ================================================================ */
        for (let i = 0; i < materialUpdates.length; i++) {
            const update = materialUpdates[i];
            const {
                CatId, WorkfInstId, Matnr, MatBrand, MatType,
                ApprStatus, ApprDate, FApprover, Comment: incomingComment
            } = update;

            const key = `${WorkfInstId}|${CatId}|${Matnr || ''}|${MatBrand || ''}`;
            const existingItem = itemMap.get(key);
            if (!existingItem) continue;

            // Preserve incoming token for history (raw action label)
            const incomingApprovalToken = ApprStatus;

            /* ----------------------------------------------------------
               SNAPSHOT — taken BEFORE any business logic mutates values.
               FIX 6: initialise pFStatus from existingItem.pFStatus
                       (not ApprStatus, which is the approval state, not the
                        product-flow-status field).
            ---------------------------------------------------------- */
            let prevStatusValue = existingItem.PrevStatus || null;
            let prevPFStatusValue = existingItem.PrevPFStatus || null;   // FIX 6
            let prevVFromValue = existingItem.PrevVFrom || null;
            let prevVToValue = existingItem.PrevVTo || null;
            let prevApprStatus = existingItem.PrevApprStatus || null;
            let prevMatrnu = existingItem.PrevMatnr || null;
            let prevmatDec = existingItem.PrevMatDesc || null;
            let prevMatBrand = existingItem.PrevMatBrand || null;
            let pervMatType = existingItem.PrevMatType || null;

            let newMatrnu = existingItem.Matnr;
            let newmatDec = existingItem.MatDesc;
            let newMatBrand = existingItem.MatBrand;
            let newMatType = existingItem.MatType;
            let newStatus = existingItem.Status;
            let newVFrom = existingItem.VFrom;
            let newVTo = existingItem.VTo;
            let pFStatus = existingItem.pFStatus;                 // FIX 6
            let newAppStatus = ApprStatus;
            let finalComment ="";

            /* token flags */
            const incomingIsApproved = isToken(ApprStatus, ['Approved']);
            const incomingIsRejected = isToken(ApprStatus, ['Rejected']);
            const incomingIsReworked = isToken(ApprStatus, ['Reworked']);
            const incomingIsPending = isToken(ApprStatus, ['pendingForApproval', PENDING]);

            /* default field controls — all LOCKED; branches open selectively */
            const LOCKED = 1;
            const EDITABLE = 7;

            let vToFieldControl = LOCKED;
            let rFeildControl = LOCKED;
            let MatnrFeildControl = LOCKED;
            let MatDescFeildControl = LOCKED;
            let MatTypeFeildControl = LOCKED;
            let MatBrandFeildControl = LOCKED;
            let VFromFeildControl = LOCKED;
            let headerEntityFieldControl = LOCKED;

            /* ===========================================================
               BUSINESS LOGIC
            =========================================================== */

            /* ── APPROVED ─────────────────────────────────────────────── */
            if (incomingIsApproved) {
                newAppStatus = APPROVED;

                if (equals(existingItem.Status, 'New')) {
                    newStatus = 'Active';
                    prevStatusValue = newStatus;
                    prevPFStatusValue = existingItem.pFStatus;
                    prevVFromValue = existingItem.VFrom;
                    prevVToValue = existingItem.VTo;
                    prevMatrnu = existingItem.Matnr;
                    prevmatDec = existingItem.MatDesc;
                    prevMatBrand = existingItem.MatBrand;
                    pervMatType = existingItem.MatType;
                    prevApprStatus = newAppStatus;    
                    // FIX 1: do NOT overwrite prevStatusValue — snapshot must stay 'New'
                    //         so the next approval cycle can reference what it approved from.
                    rFeildControl = EDITABLE;
                    vToFieldControl = EDITABLE;

                } else if (equals(existingItem.Status, 'Active') &&
                    equals(existingItem.pFStatus, 'Change In The Flow')) {
                        
                    newStatus = existingItem.Status;
                    prevMatrnu = existingItem.Matnr;
                    prevmatDec = existingItem.MatDesc;
                    prevMatBrand = existingItem.MatBrand;
                    pervMatType = existingItem.MatType;
                    prevStatusValue = newStatus;
                    prevPFStatusValue = existingItem.pFStatus;
                    prevVFromValue = existingItem.VFrom;
                    prevVToValue = existingItem.VTo;
                    prevApprStatus = newAppStatus; 
                    rFeildControl = EDITABLE;
                    vToFieldControl = EDITABLE;


                } else if (equals(existingItem.Status, 'Block') &&
                    equals(existingItem.pFStatus, 'Change In The Flow')) {
                       
                    newStatus = existingItem.Status;
                    prevMatrnu = existingItem.Matnr;
                    prevmatDec = existingItem.MatDesc;
                    prevMatBrand = existingItem.MatBrand;
                    pervMatType = existingItem.MatType;
                    prevStatusValue = newStatus;
                    prevPFStatusValue = existingItem.pFStatus;
                    prevVFromValue = existingItem.VFrom;
                    prevVToValue = existingItem.VTo;
                    prevApprStatus = newAppStatus; 
                    // FIX BUG-C (from prior iteration): do NOT revert pFStatus back to 'Change In
                    //   The Flow'. pFStatus stays APPROVED (set above). Block is approved → Approved.
                    rFeildControl = EDITABLE;
                    vToFieldControl = EDITABLE;

                } else if (equals(existingItem.Status, 'Inactive') ||
                    equals(existingItem.Status, 'InActive')) {
                      
                    newStatus = existingItem.Status;
                    prevMatrnu = existingItem.Matnr;
                    prevmatDec = existingItem.MatDesc;
                    prevMatBrand = existingItem.MatBrand;
                    pervMatType = existingItem.MatType;
                    prevStatusValue = newStatus;
                    prevPFStatusValue = existingItem.pFStatus;
                    prevVFromValue = existingItem.VFrom;
                    prevVToValue = existingItem.VTo;
                    prevApprStatus = newAppStatus; 
                    rFeildControl = LOCKED;
                    vToFieldControl = LOCKED;

                } else {
                    newStatus = existingItem.Status;
                    prevMatrnu = existingItem.Matnr;
                    prevmatDec = existingItem.MatDesc;
                    prevMatBrand = existingItem.MatBrand;
                    pervMatType = existingItem.MatType;
                    prevStatusValue = newStatus;
                    prevPFStatusValue = existingItem.pFStatus;
                    prevVFromValue = existingItem.VFrom;
                    prevVToValue = existingItem.VTo;
                    prevApprStatus = newAppStatus; 
                    rFeildControl = EDITABLE;
                    vToFieldControl = EDITABLE;
                }

                // VFrom: preserve future-dated VFrom; otherwise stamp ApprDate
                const today = new Date();
                const todayUtc = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()));
                if (existingItem.VFrom) {
                    const existingVFromDate = new Date(existingItem.VFrom);
                    newVFrom = (!isNaN(existingVFromDate.getTime()) &&
                        existingVFromDate.getTime() >= todayUtc.getTime())
                        ? existingItem.VFrom
                        : ApprDate;
                } else {
                    newVFrom = ApprDate;
                }
            }

            /* ── REJECTED ─────────────────────────────────────────────── */
            else if (incomingIsRejected) {

                /* --- auto-generate system comment (not for brand-new flows) --- */
                if (!equals(existingItem.Status, 'New')) {
                    const proposedStatus = existingItem.Status;
                    const originalStatus = existingItem.PrevStatus;
                    const isStatusChange = originalStatus && (proposedStatus !== originalStatus);
                    const isValidityChange = existingItem.PrevVTo &&
                        (existingItem.VTo !== existingItem.PrevVTo);

                    let systemComment;
                    if (isStatusChange && isValidityChange) {
                        // systemComment = `Status '${proposedStatus}' and validity period change requested and rejected by approver. Product flow catalog original status and validity period remain unchanged.`;
                        systemComment = `Status '${proposedStatus}' requested and rejected by approver. Product flow catalog original status unchanged.`;
                    } else if (isStatusChange) {
                        systemComment = `Status '${proposedStatus}' requested and rejected by approver. Product flow catalog original status unchanged.`;
                    } else if (isValidityChange) {
                        // FIX BUG-B: validity-only change still names the current status
                        // systemComment = `Status '${proposedStatus}' and validity period change requested and rejected by approver. Product flow catalog original status and validity period remain unchanged.`;
                        systemComment = `Status '${proposedStatus}' requested and rejected by approver. Product flow catalog original status unchanged.`;
                    } else {
                        systemComment = `Status '${proposedStatus}' requested and rejected by approver. Product flow catalog original status unchanged.`;
                    }
                    finalComment = systemComment;
                }

                /* --- restore previous values ---
                   NOTE (spec): if previous ApprStatus was 'Reworked', restore to the
                   pre-rework snapshot stored in Prev* columns.                        */
                const prevWasRework = isToken(existingItem.ApprStatus, ['Reworked']);

                if (prevWasRework) {
                    // Restore to state that existed BEFORE the rework was sent
                    if (existingItem.PrevStatus) newStatus = existingItem.PrevStatus;
                    if (existingItem.PrevPFStatus != null) pFStatus = existingItem.PrevPFStatus;
                    if (existingItem.PrevVFrom) newVFrom = existingItem.PrevVFrom;
                    if (existingItem.PrevVTo) newVTo = existingItem.PrevVTo;
                    if (existingItem.PrevMatnr) newMatrnu = existingItem.PrevMatnr;
                    if (existingItem.PrevMatDesc) newmatDec = existingItem.PrevMatDesc;
                    if (existingItem.PrevMatBrand) newMatBrand = existingItem.PrevMatBrand;
                    if (existingItem.PrevMatType) newMatType = existingItem.PrevMatType;
                } else {
                    newStatus = existingItem.PrevStatus || existingItem.Status;
                    newVFrom = existingItem.PrevVFrom || existingItem.VFrom;
                    newVTo = existingItem.PrevVTo || existingItem.VTo;
                    newMatrnu = existingItem.PrevMatnr|| existingItem.Matnr;
                    newmatDec = existingItem.PrevMatDesc || existingItem.MatDesc;
                    newMatBrand = existingItem.PrevMatBrand || existingItem.MatBrand;
                    newMatType = existingItem.PrevMatType || existingItem.MatType;

                    if (equals(newStatus, 'New')) {
                        pFStatus = REJECTED;
                    } else {
                        // FIX BUG-A: use ?? so empty-string PrevPFStatus is preserved
                        pFStatus = existingItem.PrevPFStatus ?? existingItem.pFStatus;
                    }
                }

                /* FIX 2: ApprStatus after rejection
                   - Brand-new flow rejected → stays REJECTED (excluded from dup check)
                   - Existing item restored  → APPROVED (the item is now in its prior
                     live state; UI drives display via pFStatus comment)             */
                if (equals(newStatus, 'New')) {
                    newAppStatus = REJECTED;
                } else {
                    newAppStatus = APPROVED;
                }

                /* FIX 3: update Prev* to the RESTORED values so the next reject/rework
                   cycle chains correctly instead of re-restoring stale snapshots.     */
                prevStatusValue = newStatus;
                prevPFStatusValue = pFStatus;
                prevVFromValue = newVFrom;
                prevVToValue = newVTo;
                prevMatrnu = newMatrnu;
                prevmatDec = newmatDec;
                prevMatBrand = newMatBrand;
                pervMatType = newMatType;
                prevApprStatus = newAppStatus;

                /* FIX 7: field controls after rejection depend on the restored status.
                   Active/Block are live flows → rF and vTo editable.
                   New/InActive → keep all locked.                                     */
                if (equals(newStatus, 'Active') || equals(newStatus, 'Block')) {
                    vToFieldControl = EDITABLE;
                    rFeildControl = EDITABLE;
                } else {
                    vToFieldControl = LOCKED;
                    rFeildControl = LOCKED;
                }
                // headerEntityFieldControl = LOCKED;
                   headerControl = LOCKED;
            }

            /* ── PENDING ──────────────────────────────────────────────── */
            else if (incomingIsPending) {
                newAppStatus = PENDING;
                pFStatus = PENDING;
                // All field controls remain LOCKED (default)
            }

            /* ── REWORKED ─────────────────────────────────────────────── */
            else if (incomingIsReworked) {
                newAppStatus = REWORKED;
                // pFStatus     = REWORKED;

                /* Preserve pre-rework snapshot into Prev* columns so that a subsequent
                   rejection can restore to the right state.
                   FIX BUG-A applies here too: use ?? for PrevPFStatus so "" survives. */
                // prevStatusValue   = existingItem.PrevStatus  || existingItem.Status;
                // prevPFStatusValue = existingItem.PrevPFStatus ?? existingItem.pFStatus;
                // prevVFromValue    = existingItem.PrevVFrom    || existingItem.VFrom;
                // prevVToValue      = existingItem.PrevVTo      || existingItem.VTo;
                // prevApprStatus    = existingItem.PrevApprStatus      || existingItem.ApprStatus;

                /* FIX 4 & 5: field editability for rework sub-cases
                   CASE A – Brand-new flow (Status='New'): all header + item fields editable.
                   CASE B – Inactive flow: spec says "no edits possible" → all LOCKED.
                   CASE C – Existing approved flow (Active/Block):
                             rFeildControl / vToFieldControl editable so the approver can
                             adjust Status and ValidTo; item-level identity fields stay LOCKED.
                             Newly added line items are opened by a separate UI-layer check
                             (the backend cannot distinguish new lines without an explicit flag). */

                const isNewFlow = equals(existingItem.Status, 'New');
                const isInactive = equals(existingItem.Status, 'InActive') ||
                    equals(existingItem.Status, 'Inactive') ||
                    equals(existingItem.PrevStatus, 'InActive') ||
                    equals(existingItem.PrevStatus, 'Inactive');
                const uniqueKey = `${existingItem.ApprStatus}`;
                //    var headerControl;
                if (headerControlFlag.has(uniqueKey)) {
                    headerControl = LOCKED;
                } else {
                    if (existingItem.ApprStatus === "Approved") {
                        headerControl = EDITABLE;
                        headerControlFlag.add(uniqueKey);
                    }

                }
                if (isNewFlow) {
                    // CASE A: brand-new → everything editable including header entities
                    vToFieldControl = EDITABLE;
                    rFeildControl = EDITABLE;
                    MatnrFeildControl = EDITABLE;
                    MatDescFeildControl = EDITABLE;
                    MatTypeFeildControl = EDITABLE;
                    MatBrandFeildControl = EDITABLE;
                    VFromFeildControl = EDITABLE;
                    headerEntityFieldControl = headerControl;

                } else if (isInactive) {
                    // CASE B: FIX 5 — Inactive rework = no edits possible
                    vToFieldControl = EDITABLE;
                    rFeildControl = EDITABLE;
                    MatnrFeildControl = EDITABLE;
                    MatDescFeildControl = EDITABLE;
                    MatTypeFeildControl = EDITABLE;
                    MatBrandFeildControl = EDITABLE;
                    VFromFeildControl = EDITABLE;
                    headerEntityFieldControl = LOCKED;
                    // MatnrFeildControl and others remain LOCKED (default)

                } else {
                    // CASE C: existing approved Active/Block flow
                    vToFieldControl = EDITABLE;
                    rFeildControl = EDITABLE;
                    MatnrFeildControl = EDITABLE;
                    MatDescFeildControl = EDITABLE;
                    MatTypeFeildControl = EDITABLE;
                    MatBrandFeildControl = EDITABLE;
                    VFromFeildControl = EDITABLE;
                    headerEntityFieldControl = LOCKED;
                    // Item-level fields (Matnr, MatDesc, MatType, MatBrand, VFrom) stay LOCKED.
                    // Newly added line items must be unlocked by the UI layer which knows
                    // whether a given item row is newly added in this submission.
                }
            }

            /* ── UNKNOWN / FALLBACK ───────────────────────────────────── */
            else {
                newAppStatus = ApprStatus || PENDING;
            }

            /* ===========================================================
               BUILD WHERE CLAUSE
            =========================================================== */
            let whereCondition = `WorkfInstId = '${WorkfInstId}' AND CatId = '${CatId}'`;

            if (Matnr === "") {
                whereCondition += ` AND (Matnr = '' OR Matnr IS NULL)`;
            } else {
                whereCondition += ` AND Matnr = '${Matnr}'`;

            }

            if (MatBrand === "") {
                whereCondition += ` AND (MatBrand = '' OR MatBrand IS NULL)`;
            } else {
                whereCondition += ` AND MatBrand = '${MatBrand}'`;

            }

            const whereClauseHeader = { CatId };

            /* ===========================================================
               UPDATE PfcItems
            =========================================================== */
            await tx.run(
                UPDATE('jnj.com.zbuvcm47419.PfcItems')
                    .set({
                        vToFieldControl,
                        rFeildControl,
                        MatnrFeildControl,
                        MatDescFeildControl,
                        MatTypeFeildControl,
                        MatBrandFeildControl,
                        VFromFeildControl,

                        criticality:
                            newAppStatus === REJECTED ? 1 :
                                newAppStatus === REWORKED ? 2 :
                                    newAppStatus === PENDING ? 2 : 3,

                        ApprStatus: newAppStatus,

                        PrevStatus: prevStatusValue,
                        PrevPFStatus: prevPFStatusValue,
                        PrevVFrom: prevVFromValue,
                        PrevVTo: prevVToValue,
                        PrevApprStatus: prevApprStatus,
                        PrevMatnr:prevMatrnu,
                        PrevMatDesc:prevmatDec,
                        PrevMatBrand:prevMatBrand,
                        PrevMatType:pervMatType,

                        Matnr:newMatrnu,
                        MatBrand:newMatBrand,
                        MatType:newMatType,
                        MatDesc:newmatDec,
                        VFrom: newVFrom,
                        VTo: newVTo,
                        pFStatus:finalComment,
                        Status: newStatus,
                        ApprDate,
                        FApprover,
                        Comment: incomingComment
                    })
                    .where(whereCondition)
            );

            /* ===========================================================
               UPDATE PfcHeaders + PfcEntities
               Only open header/entity editing for brand-new flows in Rework.
            =========================================================== */
            const openHeaderForRework =
                equals(newStatus, 'New') && equals(newAppStatus, REWORKED);

            await tx.run(
                UPDATE('jnj.com.zbuvcm47419.PfcHeaders')
                    .set({ fieldControl: openHeaderForRework ? 7 : 1 })
                    .where(whereClauseHeader)
            );
            await tx.run(
                UPDATE('jnj.com.zbuvcm47419.PfcEntities')
                    .set({ fieldControl: openHeaderForRework ? 7 : 1 })
                    .where(whereClauseHeader)
            );

            /* ===========================================================
               HISTORY INSERT
            =========================================================== */
            const uniqueTimestamp = new Date(baseTime + i);
            await tx.run(
                INSERT.into('jnj.com.zbuvcm47419.PfcItemsWFHistory').entries({
                    ID: cds.utils.uuid(),
                    CatId,
                    WorkfInstId,
                    Matnr,
                    MatBrnd: MatBrand,
                    // History always records the raw incoming action, not the derived newAppStatus
                    ApprovalStatus: isToken(incomingApprovalToken, ['Rejected']) ? REJECTED :
                        isToken(incomingApprovalToken, ['Reworked']) ? REWORKED :
                            isToken(incomingApprovalToken, ['pendingForApproval', PENDING]) ? PENDING :
                                isToken(incomingApprovalToken, ['Approved']) ? APPROVED :
                                    newAppStatus,
                    Uname: FApprover,
                    Comment: finalComment,
                    Timestamp: uniqueTimestamp,
                    MatType,
                    Status: newStatus
                })
            );
        }

        await tx.commit();
        return `${bundle.getText("workflowUpdates")} ${materialUpdates.length} ${bundle.getText("records")}`;

    } catch (error) {
        await tx.rollback();
        throw error;
    }
}



/**
 * getEcoRegionDetail
 * @param {string} countryCode
 * @return {ecoRegion.EcoRegCode} string
 */
async function getEcoRegionDetail(countryCode) {
    try {
        const ecoRegion = await cds.run(SELECT.one.from('jnj.com.zbuvcm47419.PfcEcoRegions').columns('EcoRegName').where({
            'CountryCode': countryCode
        }));
        return ecoRegion.EcoRegCode;
    } catch (error) {
        throw error;
    }
}

/**
 * getCatidFromMaterial
 * @param {object} payload
 * @return {Catid} string
 */
async function getCatidFromMaterial(payload) {
    try {
        const { Matnr, MatBrnd, ShipFrom_BP, ShipFrom_P, ShipTo_BP, ShipTo_P, typeOfOrder } = payload[0];
        const CatData = await cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcItems')
            .columns('CatId')
            .where({
                "MatBrand": MatBrnd,
                "Matnr": Matnr
            })
            .groupBy('CatId'));

        const catIdArray = CatData.map(item => item.CatId);
        const catId = await cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcHeaders')
            .columns('CatId')
            .where({
                "BpSFrom": ShipFrom_BP,
                "BpSTo": ShipTo_BP,
                "PlantSFrom": ShipFrom_P,
                "PlantSTo": ShipTo_P,
                "CatId": catIdArray
            }));

        return catId[0].CatId;

    } catch (error) {
        throw error;
    }
}

/**
 * UpdateVSeqNum
 * @param {object} req
 * @return void
 */
async function UpdateVSeqNum(req) {
    if (req.data?.Ventities?.length > 0) {
        req.data.Ventities.forEach((entity, index) => {
            entity.SeqNum = index + 1;
        });
    }
}



/**
* UpdateItemNum
* @param {object} req
* @return void
*/

// function UpdateItemNum(req) {
//     if (req.data?.Items?.length > 0) {
//         req.data.Items.forEach((item, index) => {
//             item.ItemNum = (index + 1) * 10;
//         });
//     }
// }

function UpdateItemNum(req) {
    if (req.data?.Items?.length > 0) {
        req.data.Items.forEach((item, index) => {
            // Set item number (increments of 10)
            item.ItemNum = (index + 1) * 10;

            // Ensure Matnr is always a string (no null/undefined)
            if (!item.Matnr) {
                item.Matnr = "";
            }
            if (!item.MatBrand) {
                item.MatBrand = "";
            }
        });
    }
}




module.exports = { getSinglePfcData, getSID, UpdateVSeqNum, UpdateItemNum, getCatidFromMaterial, getEcoRegionDetail, getMatItem, getApprovarDetail, getVirtualEntity, getCatID, updateWorkflowID, updateItem, updateVentity, updateSID, getPfcList, getMaterialDataWorkFlow, getWorkflowHistory, getVlistforWorkflow, updateWorkFlowData }