/* checksum : 347d8707e337f80c6f908fc65049c3a2 */
@cds.external : true
@Aggregation.ApplySupported : { Transformations: [ 'aggregate', 'groupby', 'filter' ], Rollup: #None }
@Common.ApplyMultiUnitBehaviorForSortingAndFiltering : true
@Capabilities.FilterFunctions : [
  'eq',
  'ne',
  'gt',
  'ge',
  'lt',
  'le',
  'and',
  'or',
  'contains',
  'startswith',
  'endswith',
  'any',
  'all'
]
@Capabilities.SupportedFormats : [ 'application/json', 'application/pdf' ]
@PDF.Features : {
  DocumentDescriptionReference: '../../../../default/iwbep/common/0001/$metadata',
  DocumentDescriptionCollection: 'MyDocumentDescriptions',
  ArchiveFormat: true,
  Border: true,
  CoverPage: true,
  FitToPage: true,
  FontName: true,
  FontSize: true,
  Margin: true,
  Padding: true,
  Signature: true,
  HeaderFooter: true,
  ResultSizeDefault: 20000,
  ResultSizeMaximum: 20000
}
@Capabilities.KeyAsSegmentSupported : true
@Capabilities.AsynchronousRequestsSupported : true
service ZSD_VCM_VALUE_HELPS {};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Business partner'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_VALUE_HELPS.BusinessPartner {
  @Common.Text : BusinessPartner
  @Common.IsUpperCase : true
  @Common.Label : 'Business Partner'
  @Common.QuickInfo : 'Business Partner Number'
  key BusinessPartner : String(10) not null;
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  Plant : String(4) not null;
  Type : String(1) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'country key based on plant'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_VALUE_HELPS.countrybpkey {
  @Common.Text : BusinessPartner
  @Common.IsUpperCase : true
  @Common.Label : 'Business Partner'
  @Common.QuickInfo : 'Business Partner Number'
  key BusinessPartner : String(10) not null;
  @Common.IsUpperCase : true
  @Common.Label : 'Country/Region Key'
  Country : String(3) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'country key based on plant'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_VALUE_HELPS.countryplantkey {
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  key Plant : String(4) not null;
  @Common.IsUpperCase : true
  @Common.Label : 'Country/Region Key'
  @Common.Heading : 'C/R'
  Country : String(3) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Business partner'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_VALUE_HELPS.Massbpplantcntrykey {
  @Common.Text : BusinessPartner
  @Common.IsUpperCase : true
  @Common.Label : 'Business Partner'
  @Common.QuickInfo : 'Business Partner Number'
  key BusinessPartner : String(10) not null;
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  Plant : String(4) not null;
  Type : String(1) not null;
  @Common.IsUpperCase : true
  @Common.Label : 'Country/Region Key'
  Country : String(3) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'VH for Plant and Business Partner'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_VALUE_HELPS.Massplantbpcntrykey {
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  key Plant : String(4) not null;
  @Common.Text : BusinessPartner
  @Common.IsUpperCase : true
  @Common.Label : 'Business Partner'
  @Common.QuickInfo : 'Business Partner Number'
  BusinessPartner : String(10) not null;
  Type : String(1) not null;
  @Common.IsUpperCase : true
  @Common.Label : 'Address Number'
  @Common.Heading : 'Addr. No.'
  AddressID : String(10) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Material details with Brand'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_VALUE_HELPS.Material {
  @Common.Text : Product
  @Common.IsUpperCase : true
  @Common.Label : 'Material'
  @Common.QuickInfo : 'Material Number'
  key Product : String(18) not null;
  @Common.Label : 'Product Description'
  ProductName : String(40) not null;
  @Common.IsUpperCase : true
  @Common.Label : 'Profit Center'
  @Common.Heading : 'Profit Ctr'
  ProfitCenter : String(10) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'VH for Plant and Business Partner'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_VALUE_HELPS.Plant {
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  key Plant : String(4) not null;
  @Common.Text : BusinessPartner
  @Common.IsUpperCase : true
  @Common.Label : 'Business Partner'
  @Common.QuickInfo : 'Business Partner Number'
  BusinessPartner : String(10) not null;
  Type : String(1) not null;
};

