/* checksum : 8466ffcf3717bc94a4b60a73f7c265a6 */
@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Material type value help'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.MaterialType {
  @Common.Text : ProductType
  @Common.IsUpperCase : true
  @Common.Label : 'Product Type'
  @Common.Heading : 'PTyp'
  key ProductType : String(4) not null;
  @Common.Label : 'Product Type Description'
  @Common.QuickInfo : 'Description of product type'
  ProductTypeName : String(25) not null;
};

@cds.external : true
type ZSD_VCM_PRODUCTFLOW0001.MaterialValidateCbAControl {
  @Common.Label : 'Dynamic CbA-Control'
  @Common.Heading : 'Dynamic Create by Association Control'
  @Common.QuickInfo : 'Dynamic Create via Association Control Property'
  _header : Boolean not null;
};

@cds.external : true
type ZSD_VCM_PRODUCTFLOW0001.MaterialValidateChildCbAControl {
  @Common.Label : 'Dynamic CbA-Control'
  @Common.Heading : 'Dynamic Create by Association Control'
  @Common.QuickInfo : 'Dynamic Create via Association Control Property'
  _VirtualEntities : Boolean not null;
};

@cds.external : true
type ZSD_VCM_PRODUCTFLOW0001.EntityControl {
  @Common.Label : 'Dyn. Method Control'
  @Common.Heading : 'Dynamic Method Control'
  @Common.QuickInfo : 'Dynamic Method Property'
  Deletable : Boolean not null;
  @Common.Label : 'Dyn. Method Control'
  @Common.Heading : 'Dynamic Method Control'
  @Common.QuickInfo : 'Dynamic Method Property'
  Updatable : Boolean not null;
};

@cds.external : true
@Aggregation.ApplySupported.Transformations : [ 'aggregate', 'groupby', 'filter' ]
@Aggregation.ApplySupported.Rollup : #None
@Common.ApplyMultiUnitBehaviorForSortingAndFiltering : true
@Capabilities.FilterFunctions : [
  'eq',
  'ne',
  'gt',
  'ge',
  'lt',
  'le',
  'and',
  'or',
  'contains',
  'startswith',
  'endswith',
  'any',
  'all'
]
@Capabilities.SupportedFormats : [ 'application/json', 'application/pdf' ]
@PDF.Features.DocumentDescriptionReference : '../../../../default/iwbep/common/0001/$metadata'
@PDF.Features.DocumentDescriptionCollection : 'MyDocumentDescriptions'
@PDF.Features.ArchiveFormat : true
@PDF.Features.Border : true
@PDF.Features.CoverPage : true
@PDF.Features.FitToPage : true
@PDF.Features.FontName : true
@PDF.Features.FontSize : true
@PDF.Features.Margin : true
@PDF.Features.Padding : true
@PDF.Features.Signature : true
@PDF.Features.HeaderFooter : true
@PDF.Features.ResultSizeDefault : 20000
@PDF.Features.ResultSizeMaximum : 20000
@Capabilities.KeyAsSegmentSupported : true
@Capabilities.AsynchronousRequestsSupported : true
service ZSD_VCM_PRODUCTFLOW0001 {};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Business partner'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.BusinessPartner {
  @Common.Text : BusinessPartner
  @Common.IsUpperCase : true
  @Common.Label : 'Business Partner'
  @Common.QuickInfo : 'Business Partner Number'
  key BusinessPartner : String(10) not null;
  @Common.Text : BusinessPartnerName
  BusinessPartnerName : String(81) not null;
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  Plant : String(4) not null;
  @Common.Text : Type
  Type : String(1) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'country key based on plant'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.countrybpkey {
  @Common.Text : BusinessPartner
  @Common.IsUpperCase : true
  @Common.Label : 'Business Partner'
  @Common.QuickInfo : 'Business Partner Number'
  key BusinessPartner : String(10) not null;
  @Common.Text : BusinessPartnerName
  BusinessPartnerName : String(81) not null;
  @Common.Text : Country
  @Common.IsUpperCase : true
  @Common.Label : 'Country/Region Key'
  Country : String(3) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'country key based on plant'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.countryplantkey {
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  key Plant : String(4) not null;
  @Common.Text : PlantName
  @Common.Label : 'Plant Name'
  PlantName : String(30) not null;
  @Common.Text : Country
  @Common.IsUpperCase : true
  @Common.Label : 'Country/Region Key'
  @Common.Heading : 'C/R'
  Country : String(3) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Business partner'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.Massbpplantcntrykey {
  @Common.Text : BusinessPartner
  @Common.IsUpperCase : true
  @Common.Label : 'Business Partner'
  @Common.QuickInfo : 'Business Partner Number'
  key BusinessPartner : String(10) not null;
  @Common.Text : BusinessPartnerName
  BusinessPartnerName : String(81) not null;
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  Plant : String(4) not null;
  @Common.Text : Type
  Type : String(1) not null;
  @Common.Text : Country
  @Common.IsUpperCase : true
  @Common.Label : 'Country/Region Key'
  @Common.Heading : 'C/R'
  Country : String(3) not null;
  @Common.Text : OrganizationBPName1
  @Common.Label : 'Name 1'
  @Common.QuickInfo : 'Name 1 of organization'
  OrganizationBPName1 : String(40) not null;
  @Common.Text : OrganizationBPName2
  @Common.Label : 'Name 2'
  @Common.QuickInfo : 'Name 2 of organization'
  OrganizationBPName2 : String(40) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'VH for Plant and Business Partner'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.Massplantbpcntrykey {
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  key Plant : String(4) not null;
  @Common.Text : PlantName
  @Common.Label : 'Plant Name'
  PlantName : String(30) not null;
  @Common.Text : BusinessPartner
  @Common.IsUpperCase : true
  @Common.Label : 'Business Partner'
  @Common.QuickInfo : 'Business Partner Number'
  BusinessPartner : String(10) not null;
  @Common.Text : Type
  Type : String(1) not null;
  @Common.Text : Country
  @Common.IsUpperCase : true
  @Common.Label : 'Country/Region Key'
  @Common.Heading : 'C/R'
  Country : String(3) not null;
  @Common.Text : OrganizationBPName1
  @Common.Label : 'Name 1'
  @Common.QuickInfo : 'Name 1 of organization'
  OrganizationBPName1 : String(40) not null;
  @Common.Text : OrganizationBPName2
  @Common.Label : 'Name 2'
  @Common.QuickInfo : 'Name 2 of organization'
  OrganizationBPName2 : String(40) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Material details with Brand'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.Material {
  @Common.Text : Product
  key Product : String(40) not null;
  @Common.Text : ProfitCenter
  @Common.IsUpperCase : true
  @Common.Label : 'Profit Center'
  @Common.Heading : 'Profit Ctr'
  key ProfitCenter : String(10) not null;
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  key Plant : String(4) not null;
  @Common.Text : ProductName
  @Common.Label : 'Product Description'
  ProductName : String(40) not null;
  @Common.Text : ProductType
  @Common.IsUpperCase : true
  @Common.Label : 'Product Type'
  @Common.Heading : 'PTyp'
  ProductType : String(4) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Root entity to verify mass upload'
@Capabilities.NavigationRestrictions.RestrictedProperties : [
  {
    NavigationProperty: _header,
    InsertRestrictions: { Insertable: ![__CreateByAssociationControl/_header] }
  }
]
@Capabilities.SearchRestrictions.Searchable : false
@Capabilities.FilterRestrictions.NonFilterableProperties : [ '__CreateByAssociationControl', '__EntityControl' ]
@Capabilities.SortRestrictions.NonSortableProperties : [ '__CreateByAssociationControl', '__EntityControl' ]
@Capabilities.ReadRestrictions.Readable : false
@Capabilities.DeleteRestrictions.Deletable : ![__EntityControl/Deletable]
@Capabilities.UpdateRestrictions.Updatable : ![__EntityControl/Updatable]
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.MaterialValidate {
  @Core.Computed : true
  key MassMaterial : String(1) not null;
  GroupID : String(10) not null;
  @Core.Computed : true
  @UI.HiddenFilter : true
  @UI.Hidden : true
  @Common.Label : 'Dynamic CbA-Control'
  @Common.Heading : 'Dynamic Create by Association Control'
  @Common.QuickInfo : 'Dynamic Create via Association Control Property'
  __CreateByAssociationControl : ZSD_VCM_PRODUCTFLOW0001.MaterialValidateCbAControl;
  @Core.Computed : true
  @UI.HiddenFilter : true
  @UI.Hidden : true
  @Common.Label : 'Dyn. Method Control'
  @Common.Heading : 'Dynamic Method Control'
  @Common.QuickInfo : 'Dynamic Method Property'
  __EntityControl : ZSD_VCM_PRODUCTFLOW0001.EntityControl;
  @Common.Composition : true
  _header : Composition of many ZSD_VCM_PRODUCTFLOW0001.MaterialValidateChild on _header._root = $self;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Custom entity to verify material for Mass Upload'
@Capabilities.NavigationRestrictions.RestrictedProperties : [
  { NavigationProperty: _root, InsertRestrictions: { Insertable: false } },
  {
    NavigationProperty: _VirtualEntities,
    InsertRestrictions: { Insertable: ![__CreateByAssociationControl/_VirtualEntities] }
  }
]
@Capabilities.SearchRestrictions.Searchable : false
@Capabilities.FilterRestrictions.NonFilterableProperties : [ '__CreateByAssociationControl', '__EntityControl' ]
@Capabilities.SortRestrictions.NonSortableProperties : [ '__CreateByAssociationControl', '__EntityControl' ]
@Capabilities.ReadRestrictions.Readable : false
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : ![__EntityControl/Deletable]
@Capabilities.UpdateRestrictions.Updatable : ![__EntityControl/Updatable]
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.MaterialValidateChild {
  @Core.Computed : true
  @Common.IsUpperCase : true
  @Common.Label : 'Material'
  @Common.QuickInfo : 'Material Number'
  key MaterialNumber : String(18) not null;
  @Common.IsUpperCase : true
  @Common.Label : 'Profit Center'
  @Common.Heading : 'Profit Ctr'
  MaterialBrand : String(10) not null;
  MaterialType : String(4) not null;
  MaterialDescription : String(40) not null;
  VerifyText : String(1) not null;
  @Core.Computed : true
  MassMaterial : String(1) not null;
  ProductFlowID : String(80) not null;
  FlowID : String(80) not null;
  FlowDescription : String(60) not null;
  ShipFromBusinessPartner : String(10) not null;
  ShipFromPlant : String(10) not null;
  EconomicRegionShipFrom : String(10) not null;
  ShipToBusinessPartner : String(10) not null;
  ShipToPlant : String(10) not null;
  EconomicRegionShipTo : String(10) not null;
  ArchType : String(20) not null;
  Plant : String(10) not null;
  BusinessPartner : String(10) not null;
  ValidFrom : Date;
  ValidTo : Date;
  comments : String(400) not null;
  ProductFlowComments : String(400) not null;
  Errorcheck : String(1) not null;
  ShipToArchType : String(20) not null;
  GroupID : String(10) not null;
  @Core.Computed : true
  @UI.HiddenFilter : true
  @UI.Hidden : true
  @Common.Label : 'Dynamic CbA-Control'
  @Common.Heading : 'Dynamic Create by Association Control'
  @Common.QuickInfo : 'Dynamic Create via Association Control Property'
  __CreateByAssociationControl : ZSD_VCM_PRODUCTFLOW0001.MaterialValidateChildCbAControl;
  @Core.Computed : true
  @UI.HiddenFilter : true
  @UI.Hidden : true
  @Common.Label : 'Dyn. Method Control'
  @Common.Heading : 'Dynamic Method Control'
  @Common.QuickInfo : 'Dynamic Method Property'
  __EntityControl : ZSD_VCM_PRODUCTFLOW0001.EntityControl;
  _root : Association to one ZSD_VCM_PRODUCTFLOW0001.MaterialValidate on _root.MassMaterial = MassMaterial;
  @Common.Composition : true
  _VirtualEntities : Composition of many ZSD_VCM_PRODUCTFLOW0001.VirtualEntity on _VirtualEntities._massupload = $self;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'VH for Plant and Business Partner'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.Plant {
  @Common.Text : Plant
  @Common.IsUpperCase : true
  @Common.Label : 'Plant'
  @Common.Heading : 'Plnt'
  key Plant : String(4) not null;
  @Common.Text : PlantName
  @Common.Label : 'Plant Name'
  PlantName : String(30) not null;
  @Common.Text : BusinessPartner
  @Common.IsUpperCase : true
  @Common.Label : 'Business Partner'
  @Common.QuickInfo : 'Business Partner Number'
  BusinessPartner : String(10) not null;
  @Common.Text : TYPE
  TYPE : String(1) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Profit Center Value Help'
@Capabilities.SearchRestrictions.Searchable : true
@Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.ProfitCenter {
  @Common.Text : ProfitCenter
  @Common.IsUpperCase : true
  @Common.Label : 'Profit Center'
  @Common.Heading : 'Profit Ctr'
  key ProfitCenter : String(10) not null;
  @Common.Text : ProfitCenterDescription
  @Common.Label : 'Profit Center Name'
  @Common.QuickInfo : 'Description of Profit Center'
  ProfitCenterDescription : String(20) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'custom entity for Scenario determination for BP'
@Capabilities.SearchRestrictions.Searchable : false
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.SDBP {
  key BP : String(30) not null;
  BPName : String(30) not null;
  BPGroup : String(30) not null;
  BPGroupcheck : String(30) not null;
  message : String(40) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Custom entity for scenario determination of Plant'
@Capabilities.SearchRestrictions.Searchable : false
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : false
@Capabilities.UpdateRestrictions.Updatable : false
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.SDPLANT {
  key Plant : String(4) not null;
  PlantName : String(15) not null;
  message : String(40) not null;
};

@cds.external : true
@cds.persistence.skip : true
@Common.Label : 'Custom entity for virtual entity structure'
@Capabilities.NavigationRestrictions.RestrictedProperties : [
  { NavigationProperty: _Input, InsertRestrictions: { Insertable: false } },
  {
    NavigationProperty: _massupload,
    InsertRestrictions: { Insertable: false }
  }
]
@Capabilities.SearchRestrictions.Searchable : false
@Capabilities.FilterRestrictions.NonFilterableProperties : [ '__EntityControl' ]
@Capabilities.SortRestrictions.NonSortableProperties : [ '__EntityControl' ]
@Capabilities.ReadRestrictions.Readable : false
@Capabilities.InsertRestrictions.Insertable : false
@Capabilities.DeleteRestrictions.Deletable : ![__EntityControl/Deletable]
@Capabilities.UpdateRestrictions.Updatable : ![__EntityControl/Updatable]
@Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
entity ZSD_VCM_PRODUCTFLOW0001.VirtualEntity {
  @Core.Computed : true
  @Common.IsUpperCase : true
  @Common.Label : 'Material'
  @Common.QuickInfo : 'Material Number'
  key MaterialNumber : String(18) not null;
  ArchType : String(20) not null;
  Plant : String(10) not null;
  BusinessPartner : String(10) not null;
  @Core.Computed : true
  @UI.HiddenFilter : true
  @UI.Hidden : true
  @Common.Label : 'Dyn. Method Control'
  @Common.Heading : 'Dynamic Method Control'
  @Common.QuickInfo : 'Dynamic Method Property'
  __EntityControl : ZSD_VCM_PRODUCTFLOW0001.EntityControl;
  _Input : Association to one ZSD_VCM_PRODUCTFLOW0001.MaterialValidate on _Input.MassMaterial = MaterialNumber;
  _massupload : Association to one ZSD_VCM_PRODUCTFLOW0001.MaterialValidateChild on _massupload.MaterialNumber = MaterialNumber;
};

