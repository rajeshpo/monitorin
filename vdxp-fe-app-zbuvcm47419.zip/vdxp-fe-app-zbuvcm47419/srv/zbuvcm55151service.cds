// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Product Flow Catalog App
// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Provides service definitions, data model projections, and custom actions for managing the Product Flow Catalog.
// ----------------------------------------------------------------------------*
// Descriptions: Provides service definitions, handlers, and utility functions for the Product Flow Catalog application.
//This module handles custom actions, and external API integration for managing Product Flow Catalog.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*

@path: '/zbuvcm55151'
service zbuvcm55151Service @(requires: 'authenticated-user'){


/**
 * Defines input payload structure from the SBPA call.
 */
  // type ScenarioData {
  //   Matnr       : String(20);
  //   MatBrnd     : String(40);
  //   ShipFrom_BP : String(30);
  //   ShipFrom_P  : String(60);
  //   ShipTo_P    : String(30);
  //   ShipTo_BP   : String(30);
  //   typeOfOrder : String(3);
  // }

/**
 * Defines output payload structure of end to end steps  for the SBPA call.
 */
  type ScenarioSteps{
      Pair        : String(20);
      Description : String(50);
      System      : String(50);
      ArchType    : String(30);
      Variation   : String(10);
      Sequence    : String(20);
      Steps       : String(80);
      Entity      : String(10);
      Action      : String(35);
  }


action ScenarioDeterminationAPI(Catid: String,SId : String,typeOfOrder:String,Scenario:String) returns array of ScenarioSteps;

}