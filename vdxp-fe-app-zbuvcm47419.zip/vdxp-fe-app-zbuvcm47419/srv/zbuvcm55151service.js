// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Scenario Determination
// Object Id       : ZBUVCM55151
// Release         : 1
// Version         : 0.01
// Description     : Scenario Determination API call code
// ----------------------------------------------------------------------------*
// Descriptions: Provides service to return end to end scenario steps of a scenario Id
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |          Author        |  Change Id   |       Change Description
// 26-03-2026     DSinghTo@ITS.JNJ.com     50440096            TIME-FIN-DEV-PFCEnhanceme-Developement

// ----------------------------------------------------------------------------*
const cds = require('@sap/cds');
const { scenarioPairStepsforSBPA ,createSID} = require('./scenarioDetermination/scenario');
const { getCatidFromMaterial } = require('./operation/dbOps');



module.exports = cds.service.impl(async function () {

    const ZSD_VCM_SERVICEDETERMINATION = await cds.connect.to("ZSD_VCM_SERVICEDETERMINATION");
/**
   * Service handler for ScenarioDeterminationAPI
   * it gives you end to end set of steps involved in a given Scenario ID used by SBPA
   * getCatidFromMaterial fetches you the Catalog Id from Product Flow catalog for a material 
   * scenarioPairSteps fetched you the set of end to end steps for an existing Product FLow Scenario ID
   * based on odata http request
   * URL: /zbuvcm55151/ScenarioDeterminationAPI
   */
this.on('ScenarioDeterminationAPI',async (req) =>{
    try{
    let {Catid,SId,typeOfOrder,Scenario} = req.data;
   if(!SId){
     SId = await createSID(req, ZSD_VCM_SERVICEDETERMINATION, Catid);
   }
    let callType = typeOfOrder==="SO"?"1":"2";
    if(typeOfOrder === "SO"){ //This is temporary code before Integration of PO
        Scenario = "AT"
    }
    const steps = await scenarioPairStepsforSBPA(req,Catid,SId,callType,Scenario); 
    return steps;

    }catch(error){
        req.error({
            status:400,
            message:error.message
        })
    }
});

});