// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Product Flow Catalog App
// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Provides service definitions, data model projections, and custom actions for managing the Product Flow Catalog.
// ----------------------------------------------------------------------------*
// Descriptions: Provides service definitions, handlers, and utility functions for the Product Flow Catalog application.
//This module handles custom actions, and external API integration for managing Product Flow Catalog.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author             |   Change Id           |  Change Description
// 26-03-2026      RChitike@its.jnj.com     50440096               TIME-FIN-DEV-PFCEnhanceme-Developement
// 26-03-2026      DSinghTo@ITS.JNJ.com     50447367               TIME-FIN-DEV-ScenarioDet-BTP

// ----------------------------------------------------------------------------*

using {jnj.com.zbuvcm47419 as db} from '../db/zbuvcm47419schema';
using ZSD_VCM_PRODUCTFLOW from './external/ZSD_VCM_PRODUCTFLOW';
using ZSD_VCM_PRODUCTFLOW0001 from './external/ZSD_VCM_PRODUCTFLOW0001';


@path: '/zbuvcm47419'
service zbuvcm47419Service @(requires: 'authenticated-user') {

  /*****************************Product Flow App Entites ********************************************************** */
  @cds.redirection.target
  entity PFC_List as projection on db.PfcHeaders 
    actions {
      action Copy() returns PFC_List;

    // ***** JGHJ-71574 ***** R2.2 START *****

       @(
                cds.odata.bindingparameter.name: '_it',
                Common.SideEffects             : {TargetEntities: ['_it']})
      action Simulate() returns PFC_List;
    // ***** JGHJ-71574 ***** R2.2 END *****
      
    };

  @cds.redirection.target
  entity Items               as projection on db.PfcItems;


  // ***** JGHJ-71574 ***** R2.2 START *****
  entity PFC_List_ShowDrafts as projection on db.PfcHeaders;
  // ***** JGHJ-71574 ***** R2.2 START *****



  entity Ventities        as projection on db.PfcEntities {
                               *,
                               virtual null as LegalEntity : String(10) @Core.Computed
                             }
                             order by
                               SeqNum asc;

  entity PFC_ListView        as projection on db.PFC_ListView
                                order by
                                  CatId desc;

  annotate PFC_ListView with @readonly;


  /*****************************Create screen ValueHelps ************************************************************ */

  entity I_BP_VH             as
    projection on ZSD_VCM_PRODUCTFLOW.Massbpplantcntrykey {
      key BusinessPartner,
          BusinessPartnerName,
      key Plant,
      key Country           as CountryCode,
          @Core.Computed '' as EcoRegCode : String,


    };

  entity I_P_VH              as
    projection on ZSD_VCM_PRODUCTFLOW.Massplantbpcntrykey {
      key Plant,
          PlantName,
          BusinessPartner,
          Country as CountryCode
    };

  entity I_ER_VH             as
    projection on db.PfcEcoRegions {
      key CountryCode,
          EcoRegCode,
          EcoRegName
    };

  entity I_AR_VH             as projection on db.PfcArchTypeMapping{
    key ArchType : String(10)
  };

  entity I_CreateMat_VH      as
    projection on ZSD_VCM_PRODUCTFLOW.Material {
      key Product,
          ProductName,
      key ProfitCenter,
      key Plant,
       ProductType
    };

  entity I_CreateMat_VH1      as
    projection on ZSD_VCM_PRODUCTFLOW0001.ProfitCenter {
      key ProfitCenter,
          ProfitCenterDescription
    };

  entity I_Status_VH  {
    key Status: String(10);
  }

  entity I_MatStatus_VH{
    key StatusID: Integer;
     Desc: String
  }

  entity I_MatType_VH as projection on ZSD_VCM_PRODUCTFLOW.MaterialType {
    key ProductType
  };

  entity I_MatType_VH1        as
    projection on ZSD_VCM_PRODUCTFLOW0001.MaterialType {
      key ProductType as MaterialType,
          ProductTypeName as MaterialDescription
    };

  /*****************************FILTER SCREEN VALUE HELPS START****************************************************** */

  entity ShipFromBp_VH       as projection on db.SFBPValueHelp;
  entity ShipToBp_VH         as projection on db.STBPValueHelp;
  entity SFPlant_VH          as projection on db.SFPlantValueHelp;
  entity STPlant_VH          as projection on db.STPlantValueHelp;
  entity ProdId_VH           as projection on db.ProdFIDValHelp;
  entity Catalog_VH          as projection on db.CatIdValHelp;
  entity UasId_VH         as projection on db.UasIdValHelp;
  entity Matnr_VH            as projection on db.MatnrValHelp;
  entity MatBrnd_VH          as projection on db.MatBrandValHelp;
  entity MatDesc_VH          as projection on db.MatDescValHelp;
  entity I_AprStatus_VH      as projection on db.Status;
  entity I_Block_Status_VH      as projection on db.Block_Status;
  entity I_Block_Status_VH1      as projection on db.Block_StatusV;



  /***************************** UI Maintenance Tables ************************************************************** */
 @odata.draft.enabled
  entity ApprovalWorkFlow as projection on db.PfcWorkFlowApprover;
  @odata.draft.enabled
  entity EcoRegion as projection on db.PfcEcoRegions;  


  type MatDetail {
    MatBrand : String(10);
    Matnr    : String(40);
    VFrom    : DateTime;
    VTo      : DateTime;
  }

  type VDetail {
    SeqNo    : Integer;
    ArchType : String(10);
    Ve_Plant : String(60);
    Ve_BP    : String(60);
  }

  type MaterialUpdateList {
    CatId       : String(30);
    WorkfInstId : String(200);
    Matnr       : String(40);
    MatBrand    : String(10);
    ApprStatus  : String(40);
    ApprDate    : DateTime;
    FApprover   : String(30);
    Comment     : String(120);
  }


  type ApproverInfo {
    Dl_BtpId   : String(20);
    DL_EmailId : String(60);
  }

  type ItemHistRes {
    Matnr          : String(30);
    MatBrnd        : String(50);
    ApprovalStatus : String(20);
    Uname          : String(20);
    Comment        : String(60);
    WorkfInstId    : String(60);
    Timestamp      : DateTime;
  }
 


  function ApproverDetermination(SFEcoRegion : String, STEcoRegion : String) returns String;
  function MaterialDetails(Cat_ID : String, Wf_ID : String)                  returns array of MatDetail;
  function VEntityDetails(Cat_ID : String)                                   returns array of VDetail;
  action   WorkflowUpdate(MatData : array of MaterialUpdateList)             returns LargeString;
  function InitiateWorkFLow(CatId : String)                                  returns String;
  function ProcessFlowSteps(CatId : String,draft:String)                                  returns LargeString;
  action   getProcessFlowData(ID : String, DRAFT:Boolean)                                   returns String;
  
  // ***** JGHJ-71574 ***** R2.2 START *****
   action   getSimulationState(ID : String)                                   returns String;
  // ***** JGHJ-71574 ***** R2.2 END *****

  function getPfcData() returns LargeString;
  action getSinglePfcData(CatId:String) returns String;


  action getSId(CatIDList :array of String) returns String;
  

  /***************************** Mass Upload *********************************************************************** */

  @odata.draft.enabled
  entity ExcelUpload         as projection on db.ExcelUpload
    actions {
      action CreateProductFlowfromExcel();
    };

  function userInfo()                                                        returns String;
 
/****************************************************************************************************************** */
}

/***************************** Annotations ************************************************************************ */
annotate zbuvcm47419Service.Ventities with @(
  // changelog.disable_facet,
  restrict    : [
    {
      grant: ['*'],
      to   : ['XS2-VCM-PFC-ALL-MNT'],
    },
    {
      grant: [
        'READ',
        'CREATE'
      ],
      to   : ['XS2-VCM-PFC-MAS-MNT']
    },
    {
      grant: ['READ'],
      to   : ['XS3-VCM-PFC-DSP']
    }
  ],
  Capabilities: {SearchRestrictions: {
    $Type     : 'Capabilities.SearchRestrictionsType',
    Searchable: false
  }}
);

annotate zbuvcm47419Service.Items with @(
  // changelog.disable_facet,
  restrict    : [
    {
      grant: ['*'],
      to   : ['XS2-VCM-PFC-ALL-MNT'],
    },
    {
      grant: [
        'READ',
        'CREATE'
      ],
      to   : ['XS2-VCM-PFC-MAS-MNT']
    },
    {
      grant: ['READ'],
      to   : ['XS3-VCM-PFC-DSP']
    }
  ],
  Capabilities: {SearchRestrictions: {
    $Type     : 'Capabilities.SearchRestrictionsType',
    Searchable: false
  }, }
);

annotate zbuvcm47419Service.PFC_List with @(
  // changelog.disable_facet,
  odata.draft.enabled: true,
  restrict           : [
    {
      grant: ['*'],
      to   : ['XS2-VCM-PFC-ALL-MNT'],
    },
    {
      grant: [
        'READ',
        'CREATE'
      ],
      to   : ['XS2-VCM-PFC-MAS-MNT']
    },
    {
      grant: ['READ'],
      to   : ['XS3-VCM-PFC-DSP']
    }
  ],
  Capabilities       : {SearchRestrictions: {
    $Type     : 'Capabilities.SearchRestrictionsType',
    Searchable: false
  }, }
);

annotate zbuvcm47419Service.I_BP_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.I_P_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.I_ER_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.I_AR_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.I_CreateMat_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.I_CreateMat_VH1 with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.ShipFromBp_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.ShipToBp_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.SFPlant_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.STPlant_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.ProdId_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.Catalog_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.UasId_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.Matnr_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.MatBrnd_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.MatDesc_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

annotate zbuvcm47419Service.I_AprStatus_VH with
@Capabilities: {SearchRestrictions: {
  $Type     : 'Capabilities.SearchRestrictionsType',
  Searchable: false
}};

/****************************************************************************************************************** */
