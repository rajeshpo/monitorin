// const passport = require('passport');
// const xsenv = require('@sap/xsenv');
// const JWTStrategy = require('@sap/xssec').JWTStrategy;
// //configure passport
// const xsuaaService = xsenv.getServices({ myXsuaa: { tag: 'xsuaa' } });
// const xsuaaCredentials = xsuaaService.myXsuaa;
// const jwtStrategy = new JWTStrategy(xsuaaCredentials);
// passport.use(jwtStrategy);
// const express = require('express');
// // configure express server with authentication middleware
// const app = express();
// app.use(passport.initialize());
// app.use(passport.authenticate('JWT', { session: false }));
// const https = require('https');
// // access credentials from environment variable (alternatively use xsenv)
// const VCAP_SERVICES = JSON.parse(process.env.VCAP_SERVICES)
// const CREDENTIALS = VCAP_SERVICES.jobscheduler[0].credentials
// // oauth
// const UAA = CREDENTIALS.uaa
// const OA_CLIENTID = UAA.clientid;
// const OA_SECRET = UAA.clientsecret;
// const OA_ENDPOINT = UAA.url;

// const { SUCCESS_STATUS_CODE, RESULT_STATUS_CODE, ACCEPT_STATUS_CODE } = require('../config/constant');
// const TextBundle = require('@sap/textbundle').TextBundle;
// const bundle = new TextBundle('../_i18n/i18n');

const {dummy} = require('../jobscheduler/scheduler')


/********************Set the status in Jobscheduler***********************/
const doUpdateStatus = function (headers, success, message) {
    return new Promise((resolve, reject) => {
        return fetchJwtToken(OA_CLIENTID, OA_SECRET)
            .then((jwtToken) => {
                const jobId = headers['x-sap-job-id']
                const scheduleId = headers['x-sap-job-schedule-id']
                const runId = headers['x-sap-job-run-id']
                const host = headers['x-sap-scheduler-host']
                const data = JSON.stringify({ success: success, message: JSON.stringify(message) })
                const options = {
                    host: host.replace('https://', ''),
                    path: `/scheduler/jobs/${jobId}/schedules/${scheduleId}/runs/${runId}`,
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Length': data.length,
                        Authorization: 'Bearer ' + jwtToken
                    }
                }
                const req = https.request(options, (res) => {
                    res.setEncoding('utf8')
                    const status = res.statusCode
                    if (status !== SUCCESS_STATUS_CODE && status !== RESULT_STATUS_CODE && status !== ACCEPT_STATUS_CODE) {
                        return reject(new Error(bundle.getText('updateStatusErr')))
                    }
                    res.on('data', () => {
                        console.log(bundle.getText('callJobSuccess'))
                        resolve(message)
                    })
                });
                req.on('error', (error) => {
                    console.log(bundle.getText('errCallJob'))
                    return reject({ error: error })
                });
                req.write(data)
                req.end()
            })
            .catch((error) => {
                console.log(error)
                reject(error)
            })
    })
}
/***********************JWT token required for calling REST API ***********************/
const fetchJwtToken = function (clientId, clientSecret) {
    return new Promise((resolve, reject) => {
        const options = {
            host: OA_ENDPOINT.replace('https://', ''),
            path: '/oauth/token?grant_type=client_credentials&response_type=token',
            headers: {
                Authorization: "Basic " + Buffer.from(clientId + ':' + clientSecret).toString("base64")
            }
        }
        https.get(options, res => {
            res.setEncoding('utf8')
            let response = ''
            res.on('data', chunk => {
                response += chunk
            })
            res.on('end', () => {
                try {
                    const responseAsJson = JSON.parse(response)
                    const jwtToken = responseAsJson.access_token
                    if (!jwtToken) {
                        return reject(new Error(bundle.getText('errFetchToken')))
                    }
                    resolve(jwtToken)
                } catch (error) {
                    return reject(new Error(bundle.getText('errFetchToken')))
                }
            })
        })
            .on("error", (error) => {
                console.log("Error: " + error.message);
                return reject({ error: error })
            });
    })
}

/***************************************************** */

async function handleAsyncJobs(headers, req) {
    try {
         let result = await dummy();
        if ((typeof result !== 'undefined') && (result !== null)) {
            await doUpdateStatus(headers, true, result)
            return result;
        } else {
            await dummy();
        }
    } catch (error) {
        doUpdateStatus(headers, false, error.message)
            .then(() => {
                console.log(bundle.getText('successResJob'))
            }).catch((error) => {
                console.log(bundle.getText('errResJob') + error)
            })
    }
}

module.exports = {
    handleAsyncJobs
}