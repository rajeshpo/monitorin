// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Product Flow Catalog Application
// ----------------------------------------------------------------------------*
// Descriptions:   To maintain constants for the Application 
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*

module.exports = Object.freeze({
    "MatStatus": [
        { StatusID: 1, Desc: 'Approved' },
        { StatusID: 2, Desc: 'Pending For Approval' },
        { StatusID: 3, Desc: 'Reworked' },
        { StatusID: 4, Desc: 'Rejected' }
    ],
    "ArchTypes":[
        { "ID": 1, "archValue": "Local STO" },
        { "ID": 2, "archValue": "IC Sale" },
        { "ID": 3, "archValue": "3P Toll" },
        { "ID": 4,"archValue": "Reject" },
        { "ID": 5, "archValue": "External Storage" },
        { "ID": 6, "archValue": "Internal Storage" },
        { "ID": 7, "archValue": "EU STO" },
        { "ID": 8, "archValue": "IC Toll" },
        { "ID": 9, "archValue": "3P Contract Manufacturing" },
        { "ID": 10, "archValue": "IC Contract Manufacturing" },
        { "ID": 11, "archValue": "AR Transfer" },
        { "ID": 12, "archValue": "Trade Sale" },
        {"ID": 13,"archValue" : "Pure Buy"},
        {"ID": 14,"archValue" : "3P Toll Provision"},
        {"ID": 15,"archValue" : "3P Toll Completion"},
        {"ID": 16,"archValue" : "IC Sample"},
        {"ID": 17,"archValue" : "IC FOC"},
        {"ID": 18,"archValue" : "IC Clinical"},

    ],
    "I_Block_Status_VH":[
        {"Status":"Active"},
        {"Status":"Block"},
        {"Status":"Inactive"}
    ],
     "I_Block_Status_VH1":[
        {"Status":"New"},
        {"Status":"Active"},
        {"Status":"Block"},
        {"Status":"Inactive"}
    ],
    "BpPlantError": "Please select atleast BusinessPartner or Plant Value!",
    "ERROR_STATUS_CODE": "400",
    "SUCCESS_STATUS_CODE": "200",
    "RESULT_STATUS_CODE": "201",
    "ACCEPT_STATUS_CODE": "202",
    "definitionId": "us10.jnj-im-dev-na.zvcm47419productflowapprovalproject.zVCM47419_ProductFlowApprovalProcess",
    "workflowURL":"/workflow/rest/v1/workflow-instances",
    "TollCheck":['3P Toll','IC Toll'],
    "DEFAULT_LAUNCHPAD_URL":"https://jnj-im-dev-na.launchpad.cfapps.us10.hana.ondemand.com/site?siteId=63e7676a-23f2-477c-acdc-b118febec351",
    "BTPLoging": 'BTP Logging:- ',
    "PFError":"Error connecting to PRODUCT FLOW SERVICE",
    "DBErrorFail":"Product FLow service connection failed",
    "SFError":"Error connecting to Scenario Determination Service",
    "SDErrorFail":"Error connecting SCENARIO DETERMINATION SERVICE",
    "ProcessFlow" : "Process Flow issue:- ",
    "CREATE_BEFORE ":"PFC Before Create issue:- ",
    "CREATE_AFTER" :"PFC After Create issue:- ",
    "UPDATE_BEFORE" :"PFC Before Update issue:- ",
    "UPDATE_AFTER" : "PFC After Update issue:- ",
    "MatDetail":"SBPA Material Detail service issue:- ",
    "VEntity" : "SBPA Virtual Entity service issue:- ",
    "AP": "Approver Determination Service issue:- ",
    "WFUpdate":"WorkFlow Update service issue:- ",
    "CreatePFE":"CreateProductFlowfromExcel service handler issue:- ",
    "ExUp":"Excel Upload service handle issue :- ",
    "ExDel":"Excel Upload Delete issue:- ",
    "ExUpDraft":"Excel Upload Create Delete Draft issue:- ",
    "ExUpPost":"Excel Upload Create Update Post Processing issue:- "



    

})