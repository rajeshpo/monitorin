// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Product Flow Catalog
// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Application to create new Product Flows
// ----------------------------------------------------------------------------*
// Descriptions: Provides service definitions, handlers, and utility functions for the Product Flow Catalog App application.
//This module handles custom actions, and external API integration for managing Product Flow Catalog App.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date      |     Author          |   Change Id           |  Change Description
//  7/4/2026     RChitike@its.jnj.com   JGHJ-79422(JGHJ-90239)  Changed PfDesc feild to be populated only when user not entered anything
//  10/4/2026    RChitike@its.jnj.com   JGHJ-90480              Removed dataToSend variable and replaced data variabl
//  10/4/2026    RChitike@its.jnj.com   JGHJ-90443              Virtual entity determining logic changed and Added PfDesc also in massupload if not entered
//  28/4/2026    RChitike@its.jnj.com   JGHJ-92609              Resolved shuffling of ventities and added some timeout for enablin and disabling add delete buttons
//  13/08/2026   SJaffer3@its.jnj.com   JGHJ-115907             VCM: PFC Mass Upload / Material description missing 
// ----------------------------------------------------------------------------*
const cds = require('@sap/cds');
const constants = require('./config/constant');
const { validateData, matDuplicateChk, errorMessages, InitiateWorkFLow, setEcoRegion, updateWorkFlowId, checkEcoValid, checkMatchingProductFlows } = require('./validations/validation');
const onDbOps = require('./operation/dbOps.js');
const xlsx = require("xlsx");
const logger = cds.log('zbuvcm47419-productFlow');

const xsenv = require("@sap/xsenv");
const { REPOSITORY_ID } = process.env
const { checkAgainstDatabaseForMassUpload, groupProductFlows } = require('./validations/massUploadValidations');
const { buildMassUploadPayload } = require('./massUpload/buildMassPayload.js');
const { scenarioPairSteps, createSID,createSID_Drafts } = require('./scenarioDetermination/scenario');
const textBundle = require('./_i18n/textBundle');

const { getSdmService, downloadExcelFile, fetchOAuthToken, updateExcelUploadRecord, deleteExistingFile, processExcelInTheBackground } = require('./massUpload/processExcelInBackground.js');
const { data } = require('@sap/cds/lib/dbs/cds-deploy.js');
module.exports = cds.service.impl(async function () {


  /**
   * Establishes a connection to the external service ZSD_VCM_PRODUCTFLOW
   * This service is used to handle various product flow related entity reads
   */
  let ZSD_VCM_PRODUCTFLOW = '';

  try {
    // Connect to the abap service
    ZSD_VCM_PRODUCTFLOW = await cds.connect.to("ZSD_VCM_PRODUCTFLOW");
    ZSD_VCM_PRODUCTFLOW0001 = await cds.connect.to("ZSD_VCM_PRODUCTFLOW0001");
      } catch (error) {
    logger.error(`${constants.BTPLoging}  ${constants.PFError}`, error.message);
    throw new Error(constants.DBErrorFail);
  }

  /**
   * Establishes a connection to the external service ZSD_VCM_SERVICEDETERMINATION
   * This service is used to handle various product flow related entity reads
   */
  let ZSD_VCM_SERVICEDETERMINATION = '';

  try {
    // Connect to the abap service
    ZSD_VCM_SERVICEDETERMINATION = await cds.connect.to("ZSD_VCM_SERVICEDETERMINATION");
  } catch (error) {
    logger.error(`${constants.BTPLoging}  ${constants.SFError}`, error.message);
    throw new Error(constants.SDErrorFail);
  }

  /**
   * Service handler for READ I_BP_VH
   * Forwards the query to the external service ZSD_VCM_PRODUCTFLOW
   * URL: /zbuvcm47419/I_BP_VH
   */
  this.on('READ', "I_BP_VH", (req) => ZSD_VCM_PRODUCTFLOW.run(req.query));
  this.after('READ', "I_BP_VH", async (data) => {
    var eco = await SELECT.from('jnj.com.zbuvcm47419.PfcEcoRegions')
    const ecoMap = Object.fromEntries(
      eco.map(e => [e.CountryCode.trim(), { EcoRegCode: e.EcoRegCode.trim(), EcoRegName: e.EcoRegName.trim() }])
    );

    data.forEach(bp => {
      const eco = ecoMap[bp.CountryCode];
      if (eco) {
        bp.EcoRegCode = eco.EcoRegCode;
      }
    });
  })

  
  this.after('READ', 'Ventities', async (data, req) => {
    const results = Array.isArray(data) ? data : [data];
    if (!results.length || !results[0]) return;
    try {
      const ZSD_VCM_PREREQAPI = await cds.connect.to('ZSD_VCM_PREREQAPI');
      const legEntityData = await ZSD_VCM_PREREQAPI.tx(req).get('/FetchT001K');
      const leMap = new Map(legEntityData.map(r => [r.ValuationArea, r.CompanyCode]));
      results.forEach(ve => {
        if (ve.Plant){
          ve.LegalEntity = leMap.get(ve.Plant.trim()) || '';
        } 
      });
    } catch (e) {
      logger.error('LegalEntity lookup failed', e.message);
    }
  });

  /**
   * Service handler for READ I_P_VH
   * Forwards the query to the external service ZSD_VCM_PRODUCTFLOW
   * URL: /zbuvcm47419/I_P_VH
   */
  this.on('READ', "I_P_VH", (req) => ZSD_VCM_PRODUCTFLOW.run(req.query));

  /**
   * Service handler for READ I_CreateMat_VH
   * Forwards the query to the external service ZSD_VCM_PRODUCTFLOW
   * URL: /zbuvcm47419/I_CreateMat_VH
   */
  this.on('READ', "I_CreateMat_VH", (req) => ZSD_VCM_PRODUCTFLOW.run(req.query));

  /**
   * Service handler for READ I_CreateMat_VH1
   * Forwards the query to the external service ZSD_VCM_PRODUCTFLOW0001
   * URL: /zbuvcm47419/I_CreateMat_VH1
   */
  this.on('READ', "I_CreateMat_VH1", (req) => ZSD_VCM_PRODUCTFLOW0001.run(req.query));

  /**
   * Service handler for READ I_MatType_VH
   * Forwards the query to the external service ZSD_VCM_PRODUCTFLOW
   * URL: /zbuvcm47419/I_MatType_VH
   */
  this.on('READ', "I_MatType_VH", (req) => ZSD_VCM_PRODUCTFLOW.run(req.query));

    /**
   * Service handler for READ I_MatType_VH1
   * Forwards the query to the external service ZSD_VCM_PRODUCTFLOW0001
   * URL: /zbuvcm47419/I_MatType_VH1
   */
  this.on('READ', "I_MatType_VH1", (req) => ZSD_VCM_PRODUCTFLOW0001.run(req.query));

  /**
   * Service handler for READ I_MatStatus_VH
   * Returns material status constants directly without calling external service
   * URL: /zbuvcm47419/I_MatStatus_VH
   */
  this.on('READ', 'I_MatStatus_VH', async (req) => {
    return constants.MatStatus;
  });

  this.on('READ', 'I_AR_VH', async (req) => {
    req.query.SELECT.from.ref[0]='jnj.com.zbuvcm47419.PfcArchTypeMapping'
    const archType = await cds.run(req.query);

    return archType;
    
  })
  
  this.on('READ', 'I_Block_Status_VH', async (req) => {
    return constants.I_Block_Status_VH;
  })
  this.on('READ', 'I_Block_Status_VH1', async (req) => {
    return constants.I_Block_Status_VH1;
  })

  this.on('userInfo', async (req) => {
    return req.user
  });

  this.on('READ', 'FeatureControl', async (req) => {
    const { PfcHeader_ID } = req.data;

    const header = await cds.run(
      SELECT.one.from('jnj.com.zbuvcm47419.PfcHeaders')
        .columns(p => {
          p.ID,
            p.Ventities(v => v.ID); // ensure composition exposed
        })
        .where({ ID: PfcHeader_ID })
    );

    const vCount = header?.Ventities?.length || 0;

    return [{
      ID: cds.utils.uuid(),
      PfcHeader_ID,
      disableAddDelete: vCount > 0
    }];
  });

  /**
  * Service handler for ProcessFlowSteps
  * Provides end to end steps for a product flow
  * based on odata http request
  * URL: /zbuvcm47419/ProcessFlowSteps
  */
  this.on('ProcessFlowSteps', async req => {
    try {

      const { CatId,draft } = req.data;
      const steps = await scenarioPairSteps(req, CatId, "", 'ProcessFlow',draft);

      return steps;
    } catch (error) {
      logger.error(constants.ProcessFlow, error.message);
      req.error({
        status: 400,
        message: error.message
      })
    }
  })

  /**
   * Service handler for CREATE PFC_List
   * Validates and prepares data before creating a Product Flow Catalog entry
   * based on odata http request
   * URL: /zbuvcm47419/PFC_List
   */
  this.before('CREATE', 'PFC_List', async function (req) {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {


      const data = req.data

      const errors = [];


      for (const [index, item] of data.Items.entries()) {
        const validFromDate = new Date(item.VFrom);
        const validToDate = new Date(item.VTo);

        if (isNaN(validFromDate) || isNaN(validToDate)) {
          errors.push(
            bundle.getText("errorItem") + ` ${index + 1}` + bundle.getText("errorInvalidDate")
          );
        } else if (validFromDate > validToDate) {
          errors.push(
            bundle.getText("errorItem") + ` ${bundle.getText("Item")} ${item.Matnr} ` + bundle.getText("validDateError")
          );
        }
      }

      if (errors.length > 0) {
        console.log(errors)
        console.log('check')
        throw new Error(errors.join("\n"));

      }

      //checking all the conditional null check  data in creation of product flow
      const validationResult = await validateData(data, bundle, ZSD_VCM_PRODUCTFLOW);


      const dbPfcList = await onDbOps.getPfcList();
      if (validationResult === "Validation passed") {

        //after null check is passed , checking the  material with same flow
        const duplicatechk = matDuplicateChk('CREATE', data, dbPfcList);
        if (duplicatechk.length > 0) {
          throw new Error(errorMessages(duplicatechk, bundle));
        }
        let duplicates = await checkMatchingProductFlows(data)

        if (duplicates.length) {
          throw new Error(`${bundle.getText('ProductFlowAlreadyexistsWiththeSameLogisticsStructure')}` +
            duplicates.map(id => ` • ${id}`).join('\n') + ` ${bundle.getText('ContinuationToProductFlowAlreadyexists')}`)
        }
        data.fieldControl = 1
        let PfDesc = data?.PfDesc || ''
    const clean = v => (v ?? '').toString().trim();

        if (data.PfDesc === null || data.PfDesc === "" || data.PfDesc === undefined) {
          const bpSet = new Set();
          const plantSet = new Set();

          // Header level
          [data.BpSFrom, data.BpSTo].forEach(bp => {
            if (clean(bp)) bpSet.add(clean(bp));
          });

          [data.PlantSFrom, data.PlantSTo].forEach(p => {
            if (clean(p)) plantSet.add(clean(p));
          });

          // // VEntities level
          (data.Ventities || []).forEach(v => {
            if (clean(v.BPartner)) bpSet.add(clean(v.BPartner));
            if (clean(v.Plant)) plantSet.add(clean(v.Plant));
          });

          const filterBPs = [...bpSet];
          const filterPlants = [...plantSet];

          // /* ------------------ call S/4 ------------------ */
          const [bpList, plantList] = await Promise.all([
            filterBPs.length
              ? ZSD_VCM_PRODUCTFLOW.run(
                SELECT.from('Massbpplantcntrykey')
                  .where({ BusinessPartner: { in: filterBPs } })
              )
              : [],

            filterPlants.length
              ? ZSD_VCM_PRODUCTFLOW.run(
                SELECT.from('Massplantbpcntrykey')
                  .where({ Plant: { in: filterPlants } })
              )
              : []
          ]);

          // /* ------------------ build lookup maps ------------------ */
          const bpMap = new Map();
          bpList.forEach(bp => {
            bpMap.set(
              clean(bp.BusinessPartner),
              {
                name1: bp.OrganizationBPName1,
                country: bp.Country,
                name2: bp.OrganizationBPName2
              }
            );
          });

          const plantMap = new Map();
          plantList.forEach(p => {
            plantMap.set(
              clean(p.Plant),
              {
                name1: p.Name1,
                country: p.Country,
                name2: p.Name2
              }
            );
          });


          const parts = [];
          function words(str) {
            return clean(str).split(/\s+/).filter(Boolean);
          }

          function firstWord(str) {
            return words(str)[0] || null;
          }

          function secondWord(str) {
            return words(str)[1] || null;
          }
          function resolveDisplayName({ bp, plant, bpMap, plantMap }) {
            /* ---------- BP ---------- */
            if (clean(bp) && bpMap.has(clean(bp))) {
              const { name2, name1 } = bpMap.get(clean(bp));

              // BPName2 → second word
              const bpSecond = secondWord(name2);
              if (bpSecond) return bpSecond;

              // fallback → BPName (name1) → first word
              return firstWord(name1);
            }

            /* ---------- Plant ---------- */
            if (clean(plant) && plantMap.has(clean(plant))) {
              const { name1, name2 } = plantMap.get(clean(plant));

              return name2.startsWith("VIR")
                ? secondWord(name2)
                : firstWord(name);
            }

            return null;
          }


          /*  Ship-From */
          let shipFrom = resolveDisplayName({
            bp: data.BpSFrom,
            plant: data.PlantSFrom,
            bpMap,
            plantMap
          });
          if (shipFrom === null) {
            shipFrom = data.Ventities[0]?.ArchType || ''
          }
          if (shipFrom) parts.push(shipFrom);

          (data.Ventities || []).forEach(v => {
            const veName = resolveDisplayName({
              bp: v.BPartner,
              plant: v.Plant,
              bpMap,
              plantMap
            });
            if (veName) parts.push(veName);
          });
          /* Ship-To */
          let shipTo = resolveDisplayName({
            bp: data.BpSTo,
            plant: data.PlantSTo,
            bpMap,
            plantMap
          });
          if (shipTo === null) {
            shipTo = data.ArchType
          }
          if (shipTo) parts.push(shipTo);



          /* Final String */
          PfDesc = parts.join(' ---> ');


        }
        data.PfDesc = PfDesc
        await onDbOps.UpdateItemNum(req)
        await onDbOps.UpdateVSeqNum(req)
      
      }
      else {
        throw new Error(validationResult.join("\n"));
      }

    }
    catch (error) {
      logger.error(constants.CREATE_BEFORE, error.message);
      req.error({
        message: error.message,
        status: 418
      });
    }

  });


  /**
     * Service handler for after CREATE PFC_List
     * Handles post-processing after creating a Product Flow Catalog entry
     * based on odata http request
     * URL: /zbuvcm47419/PFC_List
     */
  this.after('CREATE', 'PFC_List', async (data, req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      let ID = data.ID;
      let CatID = await onDbOps.getCatID(ID);

      CatID = CatID.CatId;



      //Creating context to intiate workflow
      const context = {
        "productFlowHeaderDetails": {
          "ShipFromLocation": data.PlantSFrom || data.BpSFrom || "",
          "ShipToLocation": data.PlantSTo || data.BpSTo || "",
          "ShipFromEcoRegion": data.ErSFrom || "",
          "ShipToEcoRegion": data.ErSTo || "",
          "ProductFlowCatalogId": CatID || "",
          "ProductFlowId": data.ProdId || "",
          "ProductFlowUuid": ID || ""
        },
        "requestorEmail": {
          "RequestorEmail": req.user.id,
          "RequestorBTPId": req.user.id,
          "RequestorFioriURL": getLaunchpadUrl(req)
        }
      }

      const workflowResponse = await InitiateWorkFLow(context, req);
      const { id } = workflowResponse;
      if (id) {
        await onDbOps.updateWorkflowID(id, ID, bundle);

      }

      // Updating generated Catid in Items
      await onDbOps.updateItem(CatID, ID)

      // Updating generated Catid in Virtual Entities
      await onDbOps.updateVentity(CatID, ID);

      const sID = await createSID(req, ZSD_VCM_SERVICEDETERMINATION, CatID);

    // ***** JGHJ-71574 ***** R2.2 START *****
      let draft='false'
      await onDbOps.updateSID(sID, ID,draft,data.ProdId);

      

      

    // ***** JGHJ-71574 ***** R2.2 END *****
    

    } catch (error) {
      logger.error(constants.CREATE_AFTER, error.message);
      req.error({
        message: error.message,
        status: 400
      });
    }
  })

  /**
   * Service handler for before UPDATE PFC_List
   * Validates and prepares data before updating a Product Flow Catalog entry
   * based on odata http request
   * URL: /zbuvcm47419/PFC_List
   */
  this.before('UPDATE', 'PFC_List', async req => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data
      let ID = data.ID;
      req.data.fieldControl=1;
      const { Items } = data;
      let CatID = await onDbOps.getCatID(ID);

      CatID = CatID.CatId;
      const dbPfcList = await onDbOps.getPfcList();

      // checking all the conditional null check  data in creation of product flow
      const validationResult =await validateData(data, bundle,ZSD_VCM_PRODUCTFLOW);

      if (validationResult === 'Validation passed') {
        const duplicatechk = matDuplicateChk('UPDATE', data, dbPfcList);
        if (duplicatechk.length > 0) {
          throw new Error(errorMessages(duplicatechk,bundle));
        }

        //Creating context to intiate workflow
        const context = {
          "productFlowHeaderDetails": {
            "ShipFromLocation": data.PlantSFrom || data.BpSFrom || "",
            "ShipToLocation": data.PlantSTo || data.BpSTo || "",
            "ShipFromEcoRegion": data.ErSFrom || "",
            "ShipToEcoRegion": data.ErSTo || "",
            "ProductFlowCatalogId": CatID,
            "ProductFlowId": data.ProdId || "",
            "ProductFlowUuid": ID
          },

          "requestorEmail": {
            "RequestorEmail": req.user.id,
            "RequestorBTPId": req.user.id,
            "RequestorFioriURL": getLaunchpadUrl(req)
          }
        }

        await updateWorkFlowId(req, ID, CatID, context, Items, bundle);

      } else {
        throw new Error(validationResult.join("\n"));
      }

    } catch (error) {
      logger.error(constants.UPDATE_BEFORE, error.message);
      req.error({
        message: error.message,
        status: 400
      });

    }
  });

  /**
   * Service handler for after UPDATE PFC_List
   * Handles post-processing after updating a Product Flow Catalog entry
   * based on odata http request
   * URL: /zbuvcm47419/PFC_List
   */
  this.after('UPDATE', 'PFC_List', async req => {
    try {
      let ID = req.ID;

      let CatID = await onDbOps.getCatID(ID);


      CatID = CatID.CatId;

      // Updating generated Catid in Items
      await onDbOps.updateItem(CatID, ID);

      // Updating generated Catid in Virtual Entities
      await onDbOps.updateVentity(CatID, ID)

    } catch (error) {
      logger.error(constants.UPDATE_AFTER, error.message);
      req.error({
        message: error.message,
        status: 400
      });
    }
  });

  /**
   * Service handler for Copy actiton on PFC_List
   * Copies a Product Flow Catalog entry and its related items/entities
   * based on odata http request
   * URL: /zbuvcm47419/PFC_List/Copy
   */

  this.on('Copy', 'PFC_List', async function (req) {
    const datatoduplicate = await cds.run(SELECT.one.from('jnj.com.zbuvcm47419.PfcHeaders', a => {
      a`.*`, a.Items(b => {
        b`.*`
      }), a.Ventities(c => {
        c`.*`
      })
    }).where({ ID: req.params[0].ID }))
    const newID = cds.utils.uuid();

    // Remove ID and ApprStatus from Items and set fieldControl to null
    datatoduplicate.Items = datatoduplicate.Items.map(({ ID, ApprStatus, fieldControl, ...rest }) => ({
      ...rest,
      fieldControl: null, // Setting fieldControl to null
      vToFieldControl: null,
      ApprStatus:'New',
      Status:"New",
      pFStatus:"New Flow",
      criticality:2,
      rFeildControl:1,
      MatnrFeildControl:null,
      MatDescFeildControl:null,
      MatTypeFeildControl:null,
      MatBrandFeildControl:null,
      VFromFeildControl:null,
      PrevStatus : null,   
      PrevPFStatus : null,
      PrevVFrom    : null,
      PrevApprStatus :null,
      PrevVTo : null,
      VTo: '9999-12-31',
      Comment:null


    }));

    // Remove ID from Ventities and set fieldControl to null
    datatoduplicate.Ventities = datatoduplicate.Ventities.map(({ ID, fieldControl, ...rest }) => ({
      ...rest,
      fieldControl: null, // Setting fieldControl to null
    }));

    // ***** JGHJ-71574 ***** R2.2 START *****

    const newEntry = {
      ...datatoduplicate, ID: newID, fieldControl: null,simulation:"false",PfDesc:""

    };
    // ***** JGHJ-71574 ***** R2.2 END *****


    const zbuvcm47419Service = await cds.connect.to("zbuvcm47419Service")
    const { PFC_List } = zbuvcm47419Service.entities;
    await zbuvcm47419Service.new(PFC_List.drafts, newEntry)
    return {
      ID: newID,
      IsActiveEntity: false
    }

  })


this.before('READ', 'PFC_List.drafts', async (req) => {

  const { ID } = req.data || req.params?.[0] || {};
  if (!ID) return;

const tx = cds.tx(req);

  const data = await tx.run(
    SELECT.one.from(this.entities.PFC_List.drafts, a => {
      a`ID`,
      a.Items(b => { b`ID`, b`ItemNum`, b`createdAt`, b`Matnr`, b`MatBrand` }),
      a.Ventities(c => { c`ID`, c`SeqNum`, c`createdAt` })
    }).where({ ID })
  );

  if (!data) return;

  /* ---------- ITEMS ---------- */
  if (data.Items?.length) {

    const sorted = [...data.Items]
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt));

    const updates = sorted.map((item, index) => {

      const newNum = (index + 1) * 10;

      if (item.ItemNum !== newNum) {
    return tx.run(
      UPDATE(this.entities.Items.drafts)
        .set({
              ItemNum: newNum,
              Matnr: item.Matnr || "",
              MatBrand: item.MatBrand || ""
        })
        .where({ ID: item.ID })
    );
      }
  });

    await Promise.all(updates.filter(Boolean));
}

  /* ---------- VENTITIES ---------- */
  if (data.Ventities?.length) {

    const sorted = [...data.Ventities]
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt));

    const updates = sorted.map((v, index) => {

    const newSeq = index + 1;

      if (v.SeqNum !== newSeq) {
    return tx.run(
      UPDATE(this.entities.Ventities.drafts)
            .set({ SeqNum: newSeq })
        .where({ ID: v.ID })
    );
      }
  });

    await Promise.all(updates.filter(Boolean));
}
});

  // ***** JGHJ-71574 ***** R2.2 START *****

 /**
 * Service handler for Simulate
 * Simulates using draft data and show in ui
 * based on odata http request
 * URL: /zbuvcm47419/Simulate
 */
  this.on('Simulate', 'PFC_List.drafts', async function (req) {

    const { ID } = req.params[0];
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);

    const clean = v => (v ?? '').toString().trim();
    try {


  let errors = []


  let dataToSend = await cds.run(SELECT.one.from(this.entities.PFC_List.drafts, a => {
      a`.*`, a.Items(b => {
        b`.*`
      }), a.Ventities(c => {
        c`.*`
      })
    }).where({ ID }))

   
      for (const [index, item] of dataToSend.Items.entries()) {
      const validFromDate = new Date(item.VFrom);
      const validToDate = new Date(item.VTo);

      if (isNaN(validFromDate) || isNaN(validToDate)) {
        errors.push(
          bundle.getText("errorItem") + ` ${index + 1}` + bundle.getText("errorInvalidDate")
        );
      } else if (validFromDate > validToDate) {
        errors.push(
          bundle.getText("errorItem") + ` ${bundle.getText("Item")} ${item.Matnr} ` + bundle.getText("validDateError")
        );
      }
    }

    if (errors.length > 0) {
      console.log(errors)
      console.log('check')
      req.warn({status:400,
          code: 'DATE_ERROR',
          message: errors.join("\n")
        });
        return;
      

    }

    //checking all the conditional null check  data in creation of product flow
    const validationResult = await validateData(dataToSend, bundle, ZSD_VCM_PRODUCTFLOW);
   const dbPfcList = await onDbOps.getPfcList(ID);// Exclude current record from duplicate check
    if (validationResult === "Validation passed") {

      //after null check is passed , checking the  material with same flow
      const duplicatechk = matDuplicateChk('CREATE', dataToSend, dbPfcList);
      if (duplicatechk.length > 0) {
        req.warn({status:400,
          code: 'MAT_DUPLICATE',
          message: errorMessages(duplicatechk, bundle)
        });
        return;
      }
    } else {
      req.warn({status:400,
          code: 'MAT_DUPLICATE',
          message: validationResult.join("\n")
        });
        return;
    }

    let duplicates = await checkMatchingProductFlows(dataToSend, ID);

    if (duplicates.length) {
      throw new Error(`${bundle.getText('ProductFlowAlreadyexistsWiththeSameLogisticsStructure')}` +
          duplicates.map(id => ` • ${id}`).join('\n') + ` ${bundle.getText('ContinuationToProductFlowAlreadyexists')}`)
    }

    let PfDesc = dataToSend?.PfDesc || ''

    if (dataToSend.PfDesc === null || dataToSend.PfDesc === "" || dataToSend.PfDesc === undefined) {
      const bpSet = new Set();
      const plantSet = new Set();

      // Header level
      [dataToSend.BpSFrom, dataToSend.BpSTo].forEach(bp => {
        if (clean(bp)) bpSet.add(clean(bp));
      });

      [dataToSend.PlantSFrom, dataToSend.PlantSTo].forEach(p => {
        if (clean(p)) plantSet.add(clean(p));
      });

      // // VEntities level
      (dataToSend.Ventities || []).forEach(v => {
        if (clean(v.BPartner)) bpSet.add(clean(v.BPartner));
        if (clean(v.Plant)) plantSet.add(clean(v.Plant));
      });

      const filterBPs = [...bpSet];
      const filterPlants = [...plantSet];

      // /* ------------------ call S/4 ------------------ */
      const [bpList, plantList] = await Promise.all([
        filterBPs.length
          ? ZSD_VCM_PRODUCTFLOW.run(
            SELECT.from('Massbpplantcntrykey')
              .where({ BusinessPartner: { in: filterBPs } })
          )
          : [],

        filterPlants.length
          ? ZSD_VCM_PRODUCTFLOW.run(
            SELECT.from('Massplantbpcntrykey')
              .where({ Plant: { in: filterPlants } })
          )
          : []
      ]);

      // /* ------------------ build lookup maps ------------------ */
      const bpMap = new Map();
      bpList.forEach(bp => {
        bpMap.set(
          clean(bp.BusinessPartner),
          {
            name1: bp.OrganizationBPName1,
            country: bp.Country,
            name2: bp.OrganizationBPName2
          }
        );
      });

      const plantMap = new Map();
      plantList.forEach(p => {
        plantMap.set(
          clean(p.Plant),
          {
            name1: p.Name1,
            country: p.Country,
            name2: p.Name2
          }
        );
      });


      const parts = [];
      function words(str) {
        return clean(str).split(/\s+/).filter(Boolean);
      }

      function firstWord(str) {
        return words(str)[0] || null;
      }

      function secondWord(str) {
        return words(str)[1] || null;
      }
      function resolveDisplayName({ bp, plant, bpMap, plantMap }) {
        /* ---------- BP ---------- */
        if (clean(bp) && bpMap.has(clean(bp))) {
          const { name2, name1 } = bpMap.get(clean(bp));

          // BPName2 → second word
          const bpSecond = secondWord(name2);
          if (bpSecond) return bpSecond;

          // fallback → BPName (name1) → first word
          return firstWord(name1);
        }

        /* ---------- Plant ---------- */
        if (clean(plant) && plantMap.has(clean(plant))) {
          const { name1, name2 } = plantMap.get(clean(plant));

          return name2.startsWith("VIR")
            ? secondWord(name2)
            : firstWord(name);
        }

        return null;
      }


      /*  Ship-From */
      let shipFrom = resolveDisplayName({
        bp: dataToSend.BpSFrom,
        plant: dataToSend.PlantSFrom,
        bpMap,
        plantMap
      });
      if (shipFrom === null) {
        shipFrom = dataToSend.Ventities[0]?.ArchType || ''
      }
      if (shipFrom) parts.push(shipFrom);

      (dataToSend.Ventities || []).forEach(v => {
        const veName = resolveDisplayName({
          bp: v.BPartner,
          plant: v.Plant,
          bpMap,
          plantMap
        });
        if (veName) parts.push(veName);
      });
      /* Ship-To */
      let shipTo = resolveDisplayName({
        bp: dataToSend.BpSTo,
        plant: dataToSend.PlantSTo,
        bpMap,
        plantMap
      });
      if (shipTo === null) {
        shipTo = dataToSend.ArchType
      }
      if (shipTo) parts.push(shipTo);



      /* Final String */
      PfDesc = parts.join(' ---> ');


    }


    let scenarioId = await createSID_Drafts(req, ZSD_VCM_SERVICEDETERMINATION, ID, "true") || ""
    await onDbOps.updateSID(scenarioId, ID, "true",dataToSend?.ProdId)

    await UPDATE(this.entities.PFC_List.drafts).set({ simulation: 'true', SId: scenarioId, PfDesc }).where({ ID })
    const dataToSend1 = await cds.run(SELECT.one.from(this.entities.PFC_List.drafts, a => {
      a`.*`, a.Items(b => {
        b`.*`
      }), a.Ventities(c => {
        c`.*`
      })
    }).where({ ID }))


    return dataToSend1
     } catch (error) {

    console.error("Simulate Action Failed:", error);

    req.reject({
      status: 500,
      code: 'SIMULATION_FAILED',
      message: error.message || 'Unexpected error during simulation'
    });
  }

  });

  // ***** JGHJ-71574 ***** R2.2 END *****

  /**
 * Service handler for getProcessFlowData
 * Retrieves process flow data for a given Product Flow Catalog entry
 * based on odata http request
 * URL: /zbuvcm47419/getProcessFlowData
 */
 

  this.on('getProcessFlowData', async (req) => {

    // ***** JGHJ-71574 ***** R2.2 START *****
    
    const { DRAFT } = req.data


    const sourceEntity = DRAFT ? 'zbuvcm47419Service.PFC_List.drafts' : "jnj.com.zbuvcm47419.PfcHeaders"
    /* ------------------ helpers ------------------ */
    const clean = v => (v ?? '').toString().trim();

    // /* ------------------ fetch header + compositions ------------------ */
    const dataToSend = await cds.run(SELECT.one.from(sourceEntity, a => {
      a`.*`, a.Items(b => {
        b`.*`
      }), a.Ventities(c => {
        c`.*`
      })
    }).where({ ID: req.data.ID }))

    if (!dataToSend) return null;

    /* ------------------ collect unique BPs & Plants ------------------ */
    const bpSet = new Set();
    const plantSet = new Set();

    //Defect JGHJ-94334
    const erSet = new Set();

    // Header level
    [dataToSend.BpSFrom, dataToSend.BpSTo].forEach(bp => {
      if (clean(bp)) bpSet.add(clean(bp));
    });

    [dataToSend.PlantSFrom, dataToSend.PlantSTo].forEach(p => {
      if (clean(p)) plantSet.add(clean(p));
    });

    //Defect JGHJ-94334
    [dataToSend.ErSFrom, dataToSend.ErSTo].forEach(er => {
      if (clean(er)) erSet.add(clean(er));
    });

    // // VEntities level
    (dataToSend.Ventities || []).forEach(v => {
      if (clean(v.BPartner)) bpSet.add(clean(v.BPartner));
      if (clean(v.Plant)) plantSet.add(clean(v.Plant));
    });

    const filterBPs = [...bpSet];
    const filterPlants = [...plantSet];

    //Defect JGHJ-94334
    const filterERs = [...erSet];

    // /* ------------------ call S/4 ------------------ */
    const [bpList, plantList, erList] = await Promise.all([
      filterBPs.length
        ? ZSD_VCM_PRODUCTFLOW.run(
          SELECT.from('Massbpplantcntrykey')
            .where({ BusinessPartner: { in: filterBPs } })
        )
        : [],

      filterPlants.length
        ? ZSD_VCM_PRODUCTFLOW.run(
          SELECT.from('Massplantbpcntrykey')
            .where({ Plant: { in: filterPlants } })
        )
        : [],

      filterERs.length
        ? cds.run(SELECT.from('jnj.com.zbuvcm47419.PfcEcoRegions')
          .where({ EcoRegCode: { in: filterERs } })
        )
        : []
    ]);

    // /* ------------------ build lookup maps ------------------ */
    const bpMap = new Map();
    bpList.forEach(bp => {
      bpMap.set(
        clean(bp.BusinessPartner),
        {
          name: bp.BusinessPartnerName,
          country: bp.Country
        }
      );
    });

    const plantMap = new Map();
    plantList.forEach(p => {
      plantMap.set(
        clean(p.Plant),
        {
          name: p.PlantName,
          country: p.Country
        }
      );
    });

    //Defect JGHJ-94334
    const erMap = new Map();
    erList.forEach(er => {
      erMap.set(
        clean(er.EcoRegCode),
        er.EcoRegName
      );
    });

    // /* ------------------ enrich HEADER ------------------ */
    dataToSend.BpSFromName = bpMap.get(clean(dataToSend.BpSFrom))?.name;
    dataToSend.BpSToName = bpMap.get(clean(dataToSend.BpSTo))?.name;

    dataToSend.PlantSFromName = plantMap.get(clean(dataToSend.PlantSFrom))?.name;
    dataToSend.PlantSToName = plantMap.get(clean(dataToSend.PlantSTo))?.name;

    //Defect JGHJ-94334
    dataToSend.ErSFromName = erMap.get(clean(dataToSend.ErSFrom));
    dataToSend.ErSToName = erMap.get(clean(dataToSend.ErSTo));

    /* ------------------ enrich VENTITIES ------------------ */
    (dataToSend.Ventities || []).forEach(v => {
      v.BPartnerName = bpMap.get(clean(v.BPartner))?.name;
      v.PlantName = plantMap.get(clean(v.Plant))?.name;
    });

  // ***** JGHJ-71574 ***** R2.2 END *****


    return dataToSend;
  });


this.after('READ', 'PFC_List', async (data, req) => {
  if (Array.isArray(data)) {
        data.forEach(item => {
            if (!item.SId) {   // If SId is null or undefined
                item.SId = '';
            }
        });
    } else if (data) {
        if (!data.SId) {
            data.SId = '';
        }
    }
});

this.on('READ', 'PFC_List', async (req, next) => {
    const isSingleRecord = req.query.SELECT.one || req.params?.length;

    if (!isSingleRecord) {
        const { PFC_List } = this.entities;
        // Redirect the list query to the drafts table
        req.query.from(PFC_List.drafts);
        
        // Optionally add the user filter if you want "Own Drafts"
        req.query.where `exists DraftAdministrativeData [InProcessByUser = ${req.user.id}]`;
    }

    return next();
});



  // MaterialDetails for SBPA WorkFlow  
  /**
 * Service handler for MaterialDetails
 * Retrieves material details and workflow history for SBPA workflow
 * based on odata http request
 * URL: /zbuvcm47419/MaterialDetails
 */
  this.on('MaterialDetails', async (req) => {
    try {
      // Extract the parameters passed in the function call
      const { Cat_ID, Wf_ID } = req.data;

      // Query the "PfcItems" table to fetch the required fields
      const materialResults = await onDbOps.getMaterialDataWorkFlow(Cat_ID, Wf_ID);

      // Fetching history records based on CatId, MatBrand, and Matnr
      const historyResults = await onDbOps.getWorkflowHistory(Cat_ID);


      // Transform the history records into the desired format and map by 'MatBrand' and 'Matnr'
      const historyMap = {};
      historyResults.forEach(history => {
        const key = `${history.MatBrnd}-${history.Matnr}`; // Create a combined key for mapping
        if (!historyMap[key]) {
          historyMap[key] = [];
        }
        historyMap[key].push({
          ApprovalStatus: history.ApprovalStatus,
          Comment: history.Comment,
          Timestamp: history.Timestamp,
          Uname: history.Uname,
          WorkfInstId: history.WorkfInstId
        });
      });

      // Combine material details with their respective history
      const result = materialResults.map(material => {
        const key = `${material.MatBrand}-${material.Matnr}`; // Combine to match history keys
        return {
          CatId: material.CatId,
          ItemNo: material.ItemNum || "",
          MatBrand: material.MatBrand || "",
          Matnr: material.Matnr || "",
          VFrom: material.VFrom,
          VTo: material.VTo,
          createdAt: material.createdAt,
          createdBy: material.createdBy,
          MatType: material.MatType,
          Status: material.Status,
          History: historyMap[key] || []  // Assign history to the material
        };
      });

      // Return the results back to the caller
      return result;
    } catch (error) {
      logger.error(constants.MatDetail, error.message);
      req.error({
        status: 400,
        message: error.message,
      });
    }
  });

  /**
   * Service handler for VEntityDetails
   * Retrieves virtual entity details for a given Product Flow Catalog entry
   * based on odata http request
   * URL: /zbuvcm47419/VEntityDetails
   */
  this.on('VEntityDetails', async (req) => {
    // Extracting the parameter passed in the function call
    try {
      const { Cat_ID } = req.data;

      // Querying the "PfcEntities" table to fetch the required fields and order by SeqNum
      const results = await onDbOps.getVlistforWorkflow(Cat_ID);

      // Return the results back to the caller
      return results;
    } catch (error) {
      logger.error(constants.VEntity, error.message);
      req.error({
        status: 400,
        message: error.message,
      });
    }
  });

  /**
   * Service handler for ApproverDetermination
   * Determines approvers for workflow based on economic regions
   * based on odata http request
   * URL: /zbuvcm47419/ApproverDetermination
   */
  this.on('ApproverDetermination', async (req) => {
    try {


      let { SFEcoRegion, STEcoRegion } = req.data;

      if (!SFEcoRegion) {
        SFEcoRegion = "ALL"
      }

      if (!STEcoRegion) {
        STEcoRegion = "ALL"
      }

      // Querying the "PfcWorkFlowApprover" table to fetch the required fields and order by SeqNum
      const results = await onDbOps.getApprovarDetail(SFEcoRegion, STEcoRegion);

      // Initialize the result object
      const response = {
        SfDlist: "",
        StDlist: "",
        SfBTPGrp: "",
        StBTPGrp: ""
      };

      const sfResults = results.filter(item => item.EcoRCode === SFEcoRegion);
      const stResults = results.filter(item => item.EcoRCode === STEcoRegion);

      if (results?.length > 0) {
        if (sfResults?.length > 0) {
          response.SfDlist = sfResults[0].Dl_list;
          response.SfBTPGrp = sfResults[0].Btp_list;
        }

        if (stResults?.length > 0) {
          response.StDlist = stResults[0].Dl_list;
          response.StBTPGrp = stResults[0].Btp_list;
        }
      }

      return response;

    } catch (error) {
      logger.error(constants.AP, error.message);
      req.error({
        status: 400,
        message: error.message,
      });
    }
  });

  /**
   * Service handler for WorkflowUpdate
   * Updates workflow status and inserts workflow history for materials
   * based on odata http request
   * URL: /zbuvcm47419/WorkflowUpdate
   */
  this.on('WorkflowUpdate', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {

      const result = await onDbOps.updateWorkFlowData(req, bundle);
      return result;

      // // Return a success message

    } catch (error) {
      logger.error(constants.WFUpdate, error.message);
      req.error({
        status: 400,
        message: error.message
      });
    }
  });

  /**
 * Service handler for Creating Product Flows through excel
 */
  this.on('CreateProductFlowfromExcel', ['ExcelUpload', 'ExcelUpload.drafts'], async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    const ExcelUpload = cds.entities['jnj.com.zbuvcm47419.ExcelUpload'];
    if (!ExcelUpload) {
      return req.error(400, bundle.getText("excelUploadMissing"));
    }

    const tx = cds.transaction(req); //  Start transaction here

    try {
      const attachment = await SELECT.one
        .from(ExcelUpload, a => {
          a`.*`,
            a.attachments(b => { b`.*`; });
        })
        .where({ user: req.user.id });

      if (!attachment) {
        return req.error(404, bundle.getText("noExcelRecordFound"));
      }

      const successAttachment = attachment.attachments?.find(att =>
        att.note?.trim().toLowerCase() === 'validation successful'
      );

      if (!successAttachment?.url) {
        return req.error(404, bundle.getText("validatedExcelNotFound"));
      }

      const services = getSdmService();
      if (!services?.sdm) {
        return req.error(500, bundle.getText("sdmNotConfigured"));
      }

      const repoUrl = services.sdm.uri;
      const token = `Bearer ${await fetchOAuthToken(services)}`;
      const downloadUrl = `${repoUrl}browser/${REPOSITORY_ID}/root?objectId=${successAttachment.url}`;

      const fileBuffer = await downloadExcelFile(downloadUrl, token);
      const workbook = xlsx.read(fileBuffer, { type: "buffer" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const jsonData = xlsx.utils.sheet_to_json(sheet);

      function stripLeadingZeros(v) {
      if (v == null) return v;                  // keep null/undefined unchanged
      if (typeof v === 'number' || typeof v === 'boolean') return v; // preserve numbers/booleans
      const s = String(v).trim();
      if (s === '') return s;                   // keep empty string unchanged

      // remove leading zeros; if the string was all zeros, return "0" (safer than empty)
      const stripped = s.replace(/^0+/, '');
      return stripped === '' ? '0' : stripped;
    }
  
      if (jsonData.length === 0) {
        return req.error(400, bundle.getText("excelEmpty"));
      }
      jsonData.forEach(row => {
      for (const key in row) {
        if (row.hasOwnProperty(key)) {
          row[key] = stripLeadingZeros(row[key]);
        }
      }
    });

      const uniqueBPs = new Set();
      const uniquePlants = new Set();
      const uniqueMats = new Set()
      // ***** Defect - JGHJ-75795 ***** START *****
      // ***** Defect - JGHJ-75768 ***** START *****


      for (const row of jsonData) {
        if (row["Ship From Business Partner"]) uniqueBPs.add(row["Ship From Business Partner"]);
        if (row["Ship To Business Partner"]) uniqueBPs.add(row["Ship To Business Partner"]);
        if (row["Business Partner V1"]) uniqueBPs.add(row["Business Partner V1"]);
        if (row["Business Partner V2"]) uniqueBPs.add(row["Business Partner V2"]);
        if (row["Business Partner V3"]) uniqueBPs.add(row["Business Partner V3"]);
        if (row["Business Partner V4"]) uniqueBPs.add(row["Business Partner V4"]);
        if (row["Business Partner V5"]) uniqueBPs.add(row["Business Partner V5"]);
        if (row["Business Partner V6"]) uniqueBPs.add(row["Business Partner V6"]);

        if (row["Ship From Plant"]) uniquePlants.add(row["Ship From Plant"]);
        if (row["Ship To Plant"]) uniquePlants.add(row["Ship To Plant"]);
        if (row["Plant V1"]) uniquePlants.add(row["Plant V1"]);
        if (row["Plant V2"]) uniquePlants.add(row["Plant V2"]);
        if (row["Plant V3"]) uniquePlants.add(row["Plant V3"]);
        if (row["Plant V4"]) uniquePlants.add(row["Plant V4"]);
        if (row["Plant V5"]) uniquePlants.add(row["Plant V5"]);
        if (row["Plant V6"]) uniquePlants.add(row["Plant V6"]);

        if (row["Material Number"]) uniqueMats.add(row["Material Number"]);



      }

      const filterBPs = Array.from(uniqueBPs).map(bp => String(bp).trim());
      const filterPlants = Array.from(uniquePlants).map(p => String(p).trim());
      const filterMats = Array.from(uniqueMats).map(p => String(p).trim());


      let bpCountryKeyMassList = [];
      let plantCountryKeyMassList = [];
      let materialList = []

      if (filterBPs) {
        const queryData = {
          BusinessPartner: filterBPs
        };
        bpCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(SELECT.from('Massbpplantcntrykey').where(queryData));
      }

      if (filterPlants) {
        const queryData = {
          Plant: filterPlants
        };
        plantCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(SELECT.from('Massplantbpcntrykey').where(queryData));
      }
       /** DEFECT START JGHJ-115907 */
       async function fetchAllPages(query, pageSize = 100) {
        let skip = 0;
        let allResults = [];

        while (true) {
          const page = await ZSD_VCM_PRODUCTFLOW.run(
            query.limit(pageSize, skip)
          );

          allResults = allResults.concat(page);

          if (page.length < pageSize) break; // last page reached
          skip += pageSize;
        }

        return allResults;
      }

      if (filterMats) {
        const chunkSize = 100; // avoid URL length issues on filter
        const chunks = [];
        for (let i = 0; i < filterMats.length; i += chunkSize) {
          chunks.push(filterMats.slice(i, i + chunkSize));
        }

        const results = await Promise.all(
          chunks.map(chunk =>
            fetchAllPages(
              SELECT.from('Material').where({ Product: chunk })
            )
          )
        );

        materialList = results.flat();
      }
    /** DEFECT END JGHJ-115907 */
      let groupedData = groupProductFlows(jsonData)

      const isAdmin = req.user.is("XS2-IT-VCM-PLW-MNT");

      // check if user has a scope
      // const isAdmin = false

      const determineVirtualEntityCount = (jsonData) => {

        if (!jsonData?.length) return 0;

        const regex = /\bV\s*(\d+)\b/i;
        let maxVeCount = 0;

        for (const row of jsonData) {

          for (let header of Object.keys(row)) {

            // normalize header
            header = header
              .replace(/\u00A0/g, " ")
              .replace(/\s+/g, " ")
              .trim();

            const match = header.match(regex);

            if (match) {
              const veNumber = Number(match[1]);
              maxVeCount = Math.max(maxVeCount, veNumber);
            }
          }
        }

        return maxVeCount;
      };


      // 1. Determine the number of VEs present in the uploaded file headers (e.g., 8)
      const veCount = determineVirtualEntityCount(jsonData);



      // const insertData = await buildMassUploadPayload(groupedData, bpCountryKeyMassList, plantCountryKeyMassList, isAdmin, bundle);
      const insertData = await buildMassUploadPayload(groupedData, isAdmin, bundle, bpCountryKeyMassList, plantCountryKeyMassList, materialList,veCount);
      // ***** Defect - JGHJ-75795 ***** END *****
      // ***** Defect - JGHJ-75768 ***** END *****


      const dbPfcList = await cds.run(
        SELECT.from('jnj.com.zbuvcm47419.PfcHeaders', a => {
          a`.*`,
            a.Items(b => { b`.*`; }),
            a.Ventities(c => { c`.*`; });
        })
      );

      var dbDuplicateRows = checkAgainstDatabaseForMassUpload(insertData, dbPfcList);
     
      if (dbDuplicateRows?.duplicates?.length > 0) {
        let RejectedDuplicate = []
        if (dbDuplicateRows?.duplicateRow) {
          RejectedDuplicate = dbDuplicateRows?.duplicateRow.filter(item => item.ApprStatus !== "Rejected" && item.Status.toLowerCase() !== "inactive")
        }
        if(dbDuplicateRows?.duplicateRow){
       const duplicateRows = dbDuplicateRows.duplicates
          .map(r => `${bundle.getText("Row")} ${r.row}, ${bundle.getText("Item")} ${r.item}`)
          .join(", ");
        }
        

        if (RejectedDuplicate?.length > 0 && dbDuplicateRows?.duplicates?.length > 0) {
          return req.error({
            status: 400,
            message: `${bundle.getText("alreadyExistsMaterials")} ${duplicateRows}`
          });
        }

      }

      // const duplicateLogisticStructureMaterials = [];

      // for (const flow of insertData) {

      //   const duplicates = await checkMatchingProductFlows(flow);

      //   if (duplicates?.length > 0) {
      //       return req.error({
      //         status: 400,
      //         message: `Already exists with Logistic Structure in Catalog(s): ${duplicates.join(", ")}`
      //       });
         
         
      //   }
      // }

      //Testing code to be executed//
//       // confirm these match your actual field/status values
// const ACTIVE_STATUS = 'active';
// const APPROVED_STATUS = 'approved';
// const MATERIAL_FIELD = ['Matnr', 'MatBrand','MatType']; // actual PfcItems material column

// function normVal(v) { return (v ?? '').toString().trim(); }

// const EXCLUDED_ITEM_FIELDS = [
//   'ID', 'parent', 'CatId',
//   'ApprStatus', 'Status', 'ApprDate', ' ',
//   'WorkfInstId', 'vToFieldControl', 'fieldControl', 'rFeildControl',
//   'MatnrFeildControl', 'MatDescFeildControl', 'MatTypeFeildControl',
//   'MatBrandFeildControl', 'VFromFeildControl', 'CommentFeildControl',
//   'criticality', 'pFStatus',
//   'PrevStatus', 'PrevPFStatus', 'PrevVFrom', 'PrevApprStatus', 'PrevVTo',
//   'PrevMatnr', 'PrevMatDesc', 'PrevMatBrand', 'PrevMatType',
//   'createdAt', 'createdBy', 'modifiedAt', 'modifiedBy'
// ];

// function getChangedFields(existingItem, incomingItem) {
//   const changed = {};
//   for (const key of Object.keys(incomingItem)) {
//     if (EXCLUDED_ITEM_FIELDS.includes(key)) continue;
//     if (normVal(incomingItem[key]) !== normVal(existingItem[key])) {
//       changed[key] = incomingItem[key];
//     }
//   }
//   return changed;
// }

// const newFlowsToInsert = [];
// const itemsToAppend = [];
// const itemsToUpdate = [];
// const duplicateCatIds = [];
// const matchedHeaderIds = new Set();

// for (const flow of insertData) {

//   const structuralMatches = await checkMatchingProductFlows(flow);

//   if (!structuralMatches?.length) {
//     newFlowsToInsert.push(flow);
//     continue;
//   }

//   const matchedHeader = dbPfcList.filter(a=>a.CatId===structuralMatches[0]);

//   // only Approved + Active existing items count as "the live catalog entry"
//   const existingByMaterial = new Map(
//     (matchedHeader[0].Items || [])
//       .filter(i =>
//         normVal(i.ApprStatus).toLowerCase() === APPROVED_STATUS.toLowerCase() &&
//         normVal(i.Status).toLowerCase() === ACTIVE_STATUS.toLowerCase()
//       )
//       .map(i => [normVal(i[MATERIAL_FIELD]), i])
//   );

//   let hasNewMaterial = false;
//   let hasChangedMaterial = false;

//   for (const item of (flow.Items || [])) {
//     const key = normVal(item[MATERIAL_FIELD]);
//     const existingItem = existingByMaterial.get(key);

//     if (!existingItem) {
//       // no approved+active existing match -> treat as new material
//       hasNewMaterial = true;
//       const { ID: _drop, ...fields } = item;
//       itemsToAppend.push({ ...fields, parent_ID: matchedHeader[0].ID, CatId: matchedHeader[0].CatId, fieldControl: 1 });
//       continue;
//     }

//     const changedFields = getChangedFields(existingItem, item);
//     if (Object.keys(changedFields).length > 0) {
//       hasChangedMaterial = true;
//       itemsToUpdate.push({ parent_ID: existingItem.ID, ...changedFields, CatId: matchedHeader[0].CatId, fieldControl: 1 });
//     }
//   }

//   if (!hasNewMaterial && !hasChangedMaterial) {
//     duplicateCatIds.push(matchedHeader[0].CatId);   // every material already exists, approved+active, unchanged
//   } else {
//     matchedHeaderIds.add(matchedHeader[0].ID);
//   }
// }

// if (duplicateCatIds.length > 0) {
//   return req.error({
//     status: 400,
//     message: `Already exists with Logistic Structure in Catalog(s): ${[...new Set(duplicateCatIds)].join(", ")}`
//   });
// }

// //  INSERT inside transaction — only genuinely new headers
// if (newFlowsToInsert.length > 0) {
//   await tx.run(
//     INSERT.into('jnj.com.zbuvcm47419.PfcHeaders').entries(newFlowsToInsert)
//   );
// }

// //  Append new materials onto matched existing headers
// if (itemsToAppend.length > 0) {
//   await tx.run(
//     INSERT.into('jnj.com.zbuvcm47419.PfcItems').entries(itemsToAppend)
//   );
// }

// //  Update changed materials on matched existing headers
// for (const { ID, ...fields } of itemsToUpdate) {
//   await tx.run(UPDATE('jnj.com.zbuvcm47419.PfcItems').set(fields).where({ ID }));
// }

// // downstream steps (Entities update, SID, workflow) run for BOTH new + matched headers
// const allHeaderIdsForDownstream = [
//   ...newFlowsToInsert.map(h => h.ID),
//   ...matchedHeaderIds
// ];

// const updatedCatIds = await tx.run(
//   SELECT.from('jnj.com.zbuvcm47419.PfcHeaders')
//     .columns('ID', 'CatId', 'ProdId', 'PlantSFrom', 'BpSFrom', 'PlantSTo', 'BpSTo', 'ErSFrom', 'ErSTo')
//     .where({ ID: { in: allHeaderIdsForDownstream } })
// );

//       //  INSERT inside transaction
//       // await tx.run(
//       //   INSERT.into('jnj.com.zbuvcm47419.PfcHeaders').entries(insertData)
//       // );

//       // const updatedCatIds = await tx.run(
//       //   SELECT.from('jnj.com.zbuvcm47419.PfcHeaders')
//       //     .columns('ID', 'CatId', 'ProdId', 'PlantSFrom', 'BpSFrom', 'PlantSTo', 'BpSTo', 'ErSFrom', 'ErSTo')
//       //     .where({ ID: { in: insertData.map(h => h.ID) } })
//       // );

//       //  UPDATE inside transaction
//       const updates = [];
//       for (const { ID, CatId } of updatedCatIds) {
//         updates.push(
//           UPDATE('jnj.com.zbuvcm47419.PfcItems').set({ CatId, fieldControl: 1 }).where({ parent: ID }),
//           UPDATE('jnj.com.zbuvcm47419.PfcEntities').set({ CatId, fieldControl: 1 }).where({ parent: ID })
//         );
//       }

//       const BATCH_SIZE = 500;
//       for (let i = 0; i < updates.length; i += BATCH_SIZE) {
//         const batch = updates.slice(i, i + BATCH_SIZE);
//         await Promise.all(batch.map(q => tx.run(q)));  //  use tx.run
//       }

//       // SID creation (kept outside DB tx as it's external)
//       const sidUpdates = [];
//       let sidFailed = false;
//       let CatIds = [];

//       for (const { ID, CatId,ProdId } of updatedCatIds) {
//         try {
//           const sID = await createSID(req, ZSD_VCM_SERVICEDETERMINATION, CatId);
//           if (sID) {
//             let draft='false'
//             sidUpdates.push(onDbOps.updateSID(sID, ID,draft,ProdId));
//           }
//         } catch (err) {
//           sidFailed = true;
//           CatIds.push(CatId);
//           logger.error(`${bundle.getText('FailedTocreateSID')} ${CatId}: ${err.message}`);
//         }
//       }

//       for (let i = 0; i < sidUpdates.length; i += BATCH_SIZE) {
//         const batch = sidUpdates.slice(i, i + BATCH_SIZE);
//         await Promise.all(batch.map(q => q));
//       }


//       if (!isAdmin) {
//         const workflowTasks = updatedCatIds?.map(header => async () => {
//           const context = {
//             productFlowHeaderDetails: {
//               ShipFromLocation: header.PlantSFrom || header.BpSFrom || "",
//               ShipToLocation: header.PlantSTo || header.BpSTo || "",
//               ShipFromEcoRegion: header.ErSFrom || "",
//               ShipToEcoRegion: header.ErSTo || "",
//               ProductFlowCatalogId: header.CatId || "",
//               ProductFlowId: header.ProdId || "",
//               ProductFlowUuid: header.ID
//             },
//             requestorEmail: {
//               RequestorEmail: req.user.id,
//               RequestorBTPId: req.user.id,
//               RequestorFioriURL: getLaunchpadUrl(req)
//             }
//           };

//           const workflowResponse = await InitiateWorkFLow(context, req);
//           const { id: wfId } = workflowResponse || {};
//           if (wfId) {
//             await tx.run(
//               UPDATE('jnj.com.zbuvcm47419.PfcItems').set({
//                 WorkfInstId: wfId,
//                 vToFieldControl: 1,
//                 criticality: 2,
//                 ApprStatus: bundle.getText('pendingForApproval')
//               }).where({ parent: header.ID })
//             );
//           }
//         });

//         for (let i = 0; i < workflowTasks.length; i += BATCH_SIZE) {
//           const batch = workflowTasks.slice(i, i + BATCH_SIZE);
//           await Promise.all(batch.map(fn => fn()));
//         }
//       }

//       await tx.commit(); //  Commit only at the end

//       return req.info(200, `${bundle.getText("dataUploaded")} ${updatedCatIds.length}"`);

/****************** */
// confirm these match your actual field/status values
const ACTIVE_STATUS = 'active';
const APPROVED_STATUS = 'approved';
const PENDING_APPROVAL = normVal(bundle.getText('pendingForApproval')).toLowerCase();
const REWORK_STATUS = 'reworked'; // CONFIRM exact stored ApprStatus value for rework

// fields the user may update ONLY when existing item is NOT in rework
const LIMITED_UPDATE_FIELDS = ['VTo', 'Status']; // CONFIRM actual "Valid To" field name

// tiered material match — tried in priority order, most specific first
const MATCH_TIERS = [
  ['Matnr', 'MatBrand', 'MatType'],
  ['MatBrand', 'MatType'],
  ['MatType']
];

function normVal(v) { return (v ?? '').toString().trim(); }

const EXCLUDED_ITEM_FIELDS = [
  'ID', 'parent', 'CatId',
  'ApprStatus', 'ApprDate', ' ',
  'WorkfInstId', 'vToFieldControl', 'fieldControl', 'rFeildControl',
  'MatnrFeildControl', 'MatDescFeildControl', 'MatTypeFeildControl',
  'MatBrandFeildControl', 'VFromFeildControl', 'CommentFeildControl',
  'criticality', 'pFStatus',
  'PrevStatus', 'PrevPFStatus', 'PrevVFrom', 'PrevApprStatus', 'PrevVTo',
  'PrevMatnr', 'PrevMatDesc', 'PrevMatBrand', 'PrevMatType',
  'createdAt', 'createdBy', 'modifiedAt', 'modifiedBy'
  // NOTE: 'Status' intentionally removed — it's user-editable (Active/Block/Inactive),
  // gated below via LIMITED_UPDATE_FIELDS instead of a blanket exclusion.
];

function getChangedFields(existingItem, incomingItem, allowedFields = null) {
  const changed = {};
  for (const key of Object.keys(incomingItem)) {
    if (EXCLUDED_ITEM_FIELDS.includes(key)) continue;
    if (allowedFields && !allowedFields.includes(key)) continue;
    if (normVal(incomingItem[key]) !== normVal(existingItem[key])) {
      changed[key] = incomingItem[key];
    }
  }
  return changed;
}

function buildKey(item, fields) {
  return fields.map(f => normVal(item[f])).join('||');
}

function buildTierMaps(items) {
  return MATCH_TIERS.map(fields => ({
    fields,
    map: new Map(items.map(i => [buildKey(i, fields), i]))
  }));
}

function findExistingMatch(item, tierMaps) {
  for (const { fields, map } of tierMaps) {
    const key = buildKey(item, fields);
    if (map.has(key)) return map.get(key);
  }
  return null;
}

const newFlowsToInsert = [];
const itemsToAppend = [];
const itemsToUpdate = [];
const duplicateCatIds = [];
const pendingApprovalConflicts = [];
const matchedHeaderIds = new Set();

for (const flow of insertData) {

  const structuralMatches = await checkMatchingProductFlows(flow);

  if (!structuralMatches?.length) {
    newFlowsToInsert.push(flow);
    continue;
  }

  const matchedHeader = dbPfcList.filter(a => a.CatId === structuralMatches[0]);

  // only Approved + Active existing items count as "the live catalog entry" for matching
  const approvedActiveItems = (matchedHeader[0].Items || []).filter(i =>
    normVal(i.ApprStatus).toLowerCase() === APPROVED_STATUS.toLowerCase() &&
    normVal(i.Status).toLowerCase() === ACTIVE_STATUS.toLowerCase()
  );
  const tierMaps = buildTierMaps(approvedActiveItems);

  let hasNewMaterial = false;
  let hasChangedMaterial = false;

  for (const item of (flow.Items || [])) {
    const existingItem = findExistingMatch(item, tierMaps);

    if (!existingItem) {
      // no match at any tier -> genuinely new material
      hasNewMaterial = true;
      const { ID: _drop, ...fields } = item;
      itemsToAppend.push({ ...fields, parent_ID: matchedHeader[0].ID, CatId: matchedHeader[0].CatId, fieldControl: 1 });
      continue;
    }

    const existingApprStatus = normVal(existingItem.ApprStatus).toLowerCase();

    // Pending for Approval -> block update entirely, surface as error
    if (existingApprStatus === PENDING_APPROVAL) {
      pendingApprovalConflicts.push({ CatId: matchedHeader[0].CatId, Matnr: existingItem.Matnr });
      continue;
    }

    // Rework -> all fields editable; any other status -> only VTo/Status editable
    const isRework = existingApprStatus === REWORK_STATUS;
    const changedFields = getChangedFields(existingItem, item, isRework ? null : LIMITED_UPDATE_FIELDS);

    if (Object.keys(changedFields).length > 0) {
      hasChangedMaterial = true;
      itemsToUpdate.push({ parent_ID: existingItem.ID, ...changedFields, CatId: matchedHeader[0].CatId, fieldControl: 1 });
    }
  }

  if (!hasNewMaterial && !hasChangedMaterial) {
    duplicateCatIds.push(matchedHeader[0].CatId);   // every material already exists, approved+active, unchanged
  } else {
    matchedHeaderIds.add(matchedHeader[0].ID);
  }
}

// block on pending-approval conflicts before any write happens
if (pendingApprovalConflicts.length > 0) {
  const details = pendingApprovalConflicts
    .map(c => `${c.CatId}${c.Matnr ? ' (' + c.Matnr + ')' : ''}`)
    .join(', ');
  return req.error({
    status: 400,
    message: `Cannot update — material already Pending for Approval: ${details}`
  });
}

if (duplicateCatIds.length > 0) {
  return req.error({
    status: 400,
    message: `Already exists with Logistic Structure in Catalog(s): ${[...new Set(duplicateCatIds)].join(", ")}`
  });
}

//  INSERT inside transaction — only genuinely new headers
if (newFlowsToInsert.length > 0) {
  await tx.run(
    INSERT.into('jnj.com.zbuvcm47419.PfcHeaders').entries(newFlowsToInsert)
  );
}

//  Append new materials onto matched existing headers
if (itemsToAppend.length > 0) {
  await tx.run(
    INSERT.into('jnj.com.zbuvcm47419.PfcItems').entries(itemsToAppend)
  );
}

//  Update changed materials on matched existing headers
for (const { ID, ...fields } of itemsToUpdate) {
  await tx.run(UPDATE('jnj.com.zbuvcm47419.PfcItems').set(fields).where({ ID }));
}

// downstream steps (Entities update, SID, workflow) run for BOTH new + matched headers
const allHeaderIdsForDownstream = [
  ...newFlowsToInsert.map(h => h.ID),
  ...matchedHeaderIds
];

const updatedCatIds = await tx.run(
  SELECT.from('jnj.com.zbuvcm47419.PfcHeaders')
    .columns('ID', 'CatId', 'ProdId', 'PlantSFrom', 'BpSFrom', 'PlantSTo', 'BpSTo', 'ErSFrom', 'ErSTo')
    .where({ ID: { in: allHeaderIdsForDownstream } })
);

//  UPDATE inside transaction
const updates = [];
for (const { ID, CatId } of updatedCatIds) {
  updates.push(
    UPDATE('jnj.com.zbuvcm47419.PfcItems').set({ CatId, fieldControl: 1 }).where({ parent: ID }),
    UPDATE('jnj.com.zbuvcm47419.PfcEntities').set({ CatId, fieldControl: 1 }).where({ parent: ID })
  );
}

const BATCH_SIZE = 500;
for (let i = 0; i < updates.length; i += BATCH_SIZE) {
  const batch = updates.slice(i, i + BATCH_SIZE);
  await Promise.all(batch.map(q => tx.run(q)));  //  use tx.run
}

// SID creation (kept outside DB tx as it's external)
const sidUpdates = [];
let sidFailed = false;
let CatIds = [];

for (const { ID, CatId, ProdId } of updatedCatIds) {
  try {
    const sID = await createSID(req, ZSD_VCM_SERVICEDETERMINATION, CatId);
    if (sID) {
      let draft = 'false';
      sidUpdates.push(onDbOps.updateSID(sID, ID, draft, ProdId));
    }
  } catch (err) {
    sidFailed = true;
    CatIds.push(CatId);
    logger.error(`${bundle.getText('FailedTocreateSID')} ${CatId}: ${err.message}`);
  }
}

for (let i = 0; i < sidUpdates.length; i += BATCH_SIZE) {
  const batch = sidUpdates.slice(i, i + BATCH_SIZE);
  await Promise.all(batch.map(q => q));
}

if (!isAdmin) {
  const workflowTasks = updatedCatIds?.map(header => async () => {
    const context = {
      productFlowHeaderDetails: {
        ShipFromLocation: header.PlantSFrom || header.BpSFrom || "",
        ShipToLocation: header.PlantSTo || header.BpSTo || "",
        ShipFromEcoRegion: header.ErSFrom || "",
        ShipToEcoRegion: header.ErSTo || "",
        ProductFlowCatalogId: header.CatId || "",
        ProductFlowId: header.ProdId || "",
        ProductFlowUuid: header.ID
      },
      requestorEmail: {
        RequestorEmail: req.user.id,
        RequestorBTPId: req.user.id,
        RequestorFioriURL: getLaunchpadUrl(req)
      }
    };

    const workflowResponse = await InitiateWorkFLow(context, req);
    const { id: wfId } = workflowResponse || {};
    if (wfId) {
      await tx.run(
        UPDATE('jnj.com.zbuvcm47419.PfcItems').set({
          WorkfInstId: wfId,
          vToFieldControl: 1,
          criticality: 2,
          ApprStatus: bundle.getText('pendingForApproval')
        }).where({ parent: header.ID })
      );
    }
  });

  for (let i = 0; i < workflowTasks.length; i += BATCH_SIZE) {
    const batch = workflowTasks.slice(i, i + BATCH_SIZE);
    await Promise.all(batch.map(fn => fn()));
  }
}

await tx.commit(); //  Commit only at the end

return req.info(200, `${bundle.getText("dataUploaded")} ${updatedCatIds.length}"`);




    } catch (error) {
      await tx.rollback(); //  rollback on error
      logger.error(constants.CreatePFE, error.message);
      return req.error(500, `${bundle.getText("failedCreation")} ${error.message}`);
    }
  });

  /**
   * Service handler for before READ ExcelUpload
   * Filters ExcelUpload records by user before reading
   * based on odata http request
   * URL: /zbuvcm47419/ExcelUpload
   */
  this.before("READ", "ExcelUpload", async (req) => {
    const userId = req.user.id;

    const whereClause = [{ ref: ["user"] }, "=", { val: userId }];

    if (!req.query.SELECT.where) {
      // If no where clause exists, set one
      req.query.SELECT.where = whereClause;
    }
  });


  /**
   * Service handler for after READ ExcelUpload, ExcelUpload.drafts
   * Post-processes ExcelUpload records after reading
   * based on odata http request
   * URL: /zbuvcm47419/ExcelUpload
   */
  this.after("READ", ["ExcelUpload", "ExcelUpload.drafts"], async (data, req) => {

    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    const ExcelUpload = cds.entities['jnj.com.zbuvcm47419.ExcelUpload'];
    if (!ExcelUpload) {
      // console.warn("[READ ExcelUpload] ExcelUpload entity not found");
      return;
    }

    try {
      const attachment = await SELECT.one
        .from(ExcelUpload, (a) => {
          a`.*`, a.attachments((b) => { b`.*`; });
        })
        .where({ user: req.user.id });

      if (data && data.length > 0) {
        attachment?.attachments?.map(att => att?.note);


        data[0].isValidated = !attachment?.attachments?.some(
          (att) => att?.note === 'Validation successful'
        );
      }
    } catch (error) {
      logger.error(constants.ExUp, error.message);
      req.error(500, error.message);
    }
  });


  /**
 * Service handler for before CREATE/UPDATE ExcelUpload.attachments.drafts
 * Handles ExcelUpload attachment cleanup before create/update
 * based on odata http request
 * URL: /zbuvcm47419/ExcelUpload.attachments.drafts
 */
  this.before(["CREATE", "UPDATE"], ["ExcelUpload.attachments.drafts"], async (req) => {
    //check if the file type is excel
    const ExcelUpload = cds.entities["jnj.com.zbuvcm47419.ExcelUpload"];
    const oldUpload = await SELECT.one
      .from(ExcelUpload, (a) => {
        a`.*`,
          a.attachments((b) => {
            b`.*`;
          });
      })
      .where({ user: req.data.up__user });

    xsenv.loadEnv();
    if (!oldUpload || !oldUpload.attachments || oldUpload.attachments.length === 0) return;
    const services = getSdmService();
    if (!services?.sdm) return;

    const token = `Bearer ${await fetchOAuthToken(services)}`;
    try {
      await deleteExistingFile(oldUpload.attachments[0].url, token);
      oldUpload.attachments = [];
      // await updateExcelUploadRecord(oldUpload);
    } catch (err) {
      logger.error(constants.ExUpDraft, err.message);
      console.log(err);

    }
  }
  );

  /**
   * Service handler for before CREATE/UPDATE ExcelUpload, ExcelUpload.drafts
   * Prepares ExcelUpload data before create/update
   * based on odata http request
   * URL: /zbuvcm47419/ExcelUpload
   */
  this.before(["CREATE", "UPDATE"], ["ExcelUpload", "ExcelUpload.drafts"], async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    const attachments = req?.data?.attachments;

    if (Array.isArray(attachments)) {
      const invalidAttachments = attachments.filter(
        (a) =>
          a?.mimeType !==
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );

      if (invalidAttachments.length > 0) {
        req.error({
          status: 400,
          code: "UNSUPPORTED_FILE_TYPE",
          message: bundle.getText('unsupportedFiles'),
          target: "attachments", // or just 'attachments' if you're not binding to field
        });
      }
    }

    const invalidNoteCount = attachments?.filter(
      (a) => a.note === null || a.note === undefined || a.note === "").length;

    if (invalidNoteCount > 1) {
      return req.error({
        code: "MULTIPLE_INVALID_FILES",
        message:
          bundle.getText("multipleFilesError"),
        target: "attachments/note",
        status: 400,
      });

    }

    if (!req.data.attachments || !Array.isArray(req.data.attachments) || req.data.attachments.length === 0) {
      return;
    }

    const nullNoteIndexes = req.data.attachments
      .map((item, index) => (item?.note == null ? index : -1))
      .filter(index => index !== -1);


    if (nullNoteIndexes.length > 0) {
      req.data.attachments[nullNoteIndexes[0]].note =
        bundle.getText("inProgressValidation");
    }
  });

  /**
* Service handler for after CREATE/UPDATE ExcelUpload, ExcelUpload.drafts
* Handles ExcelUpload post-processing after create/update
* based on odata http request
* URL: /zbuvcm47419/ExcelUpload
*/
  this.after(["CREATE", "UPDATE"], ["ExcelUpload", "ExcelUpload.drafts"], async (data, req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    if (Array.isArray(data.attachments) && data.attachments.length > 0) {


      try {
        xsenv.loadEnv();
        const services = getSdmService();
        if (!services?.sdm) {

          return;
        }
        const nullNoteIndexes = data.attachments
          .map((item, index) =>
            item.note === bundle.getText("inProgressValidation")
              ? index
              : -1
          )
          .filter((index) => index !== -1);
        const attachment = data.attachments?.[nullNoteIndexes[0]];
        if (!attachment) return;
        const repoUrl = services.sdm.uri
        const token = `Bearer ${await fetchOAuthToken(services)}`;
        const downloadUrl = `${repoUrl}browser/${REPOSITORY_ID}/root?objectId=${attachment.url}`;
        const fileBuffer = await downloadExcelFile(downloadUrl, token);

        if (fileBuffer) {

          // ***** JGHJ-71574 ***** R2.2 START *****
          
          // Helper to dynamically determine the maximum number of VEs by inspecting the headers 
          // and extracting the highest index from the 'Business Partner Vx' column name.
          const determineVirtualEntityCount = (jsonData) => {

            const regex = /Business\s*Partner\s*V\s*(\d+)/i;
            let maxVeCount = 0;

            for (const row of jsonData) {

              for (const header of Object.keys(row)) {

                const match = header.trim().match(regex);

                if (match) {
                  const currentVe = Number(match[1]);
                  if (currentVe > maxVeCount) {
                    maxVeCount = currentVe;
                  }
                }
              }
            }

            return maxVeCount;
          };

          // The helper to generate the required columns list remains the same (still needed)
          const generateServerOutputColumns = (veCount) => {
            const baseColumns = [
              "Product Flow ID", "Flow Description", "Ship From Business Partner", "Ship From Plant",
              "Economic Region Ship From", "Ship To Arch Type", "Ship To Business Partner",
              "Ship To Plant", "Economic Region Ship To", "Material Type", "Material Profit Center",
              "Material Number", "Valid From", "Valid To"
            ];

            const veColumns = [];
            for (let i = 1; i <= veCount; i++) {
              veColumns.push(`Arch Type ${i}`, `Business Partner V${i}`, `Plant V${i}`);
            }

            const finalColumns = ["Product Flow Comments", "comments"];

            return [...baseColumns, ...veColumns, ...finalColumns];
          };

        // ***** JGHJ-71574 ***** R2.2 END *****

          const workbook = xlsx.read(fileBuffer, { type: "buffer" });
          const sheetName = workbook.SheetNames[0];
          const sheet = workbook.Sheets[sheetName];
          const jsonData1 = xlsx.utils.sheet_to_json(sheet, { defval: "" });

          // 1. Determine the number of VEs present in the uploaded file headers (e.g., 8)
          const veCount = determineVirtualEntityCount(jsonData1);

          // 2. Generate the full, dynamic list of expected columns (V1 through V8)
          const outputColumns = generateServerOutputColumns(veCount);

          // 3. Set the required columns list
          const requiredColumns = outputColumns.filter(col => col !== 'comments');
          // -------------------------------------------------------------

          const uploadedHeaders = [
            ...new Set(
              jsonData1.flatMap(row => Object.keys(row))
            )
          ];
          const missingFields = requiredColumns.filter(col => !uploadedHeaders.includes(col));
          const extraFields = uploadedHeaders.filter(col => !requiredColumns.includes(col));

          if (missingFields.length > 0) {

            req.error({
              status: 400,
              code: "UNSUPPORTED_FILE_TYPE",
              message: `${bundle.getText('missingColumns')} ${missingFields.join(", ")}. ${bundle.getText('OldfileGetsDeleted')}.`,
              target: "attachments", // or just 'attachments' if you're not binding to field
            });

            return;

          }

          if (extraFields.length > 0) {
            req.error({
              status: 400,
              code: "UNSUPPORTED_FILE_TYPE",
              message: `${bundle.getText('unexpectedColumnsFound')} ${extraFields.join(", ")}.  ${bundle.getText('OldfileGetsDeleted')}`,
              target: "attachments", // or just 'attachments' if you're not binding to field
            });
            return
          }

          // Use IIFE inside setTimeout to handle async code
          setTimeout(() => {
            (async () => {
              try {
                // [AFTER CREATE/UPDATE] Starting background Excel processing after 3s delay
                await processExcelInTheBackground(data, req, token, bundle, ZSD_VCM_PRODUCTFLOW, jsonData1, sheetName, attachment, outputColumns,veCount);
              } catch (err) {
                logger.error(constants.ExUpPost, err.message);
                console.error(`${bundle.getText('AFTERCREATE_UPDATE_Error')}:", err.message`);
              }
            })();
          }, 3000);

        }



      } catch (error) {
        logger.error(constants.ExUpPost, error.message);
        console.error(`${bundle.getText('AFTER_CREATE_UPDATEError_post_processing')}`, error.message);
      }
    } else {
      logger.info(bundle.getText('NoAttachmentsFound'));
      console.log("[AFTER CREATE/UPDATE] No attachments found. Skipping background processing.");
    }
  }
  );

  /**
 * Service handler used for getting PfcData
 * based on odata http request
 * URL: /zbuvcm47419/getPfcData
 */
  this.on('getPfcData', async req => {
    try {
      const data = await onDbOps.getPfcList();
      return data;
    } catch (err) {
      console.log(err)
    }
  });

   /* Service handler used for getting PfcData
 * based on odata http request
 * URL: /zbuvcm47419/getPfcData
 */
  this.on('getSinglePfcData', async req => {
    const {CatId}=req.data
    try {
      const data = await onDbOps.getSinglePfcData(CatId);
      return data;
    } catch (err) {
      console.log(err)
    }
  });


  this.on('getSId', async req => {
    try {
      const { CatIDList } = req.data;
      const SData = await onDbOps.getSID(CatIDList);
      return SData;
    } catch (err) {
      console.log(err)
    }
  })



  function getLaunchpadUrl(req) {
    const DEFAULT_LAUNCHPAD_URL = constants.DEFAULT_LAUNCHPAD_URL;

    const origin = req?.headers?.origin || '';
    const refererUrl = req?.headers?.referer || '';
    let siteId = ''
    if (refererUrl) {
      // Parse the URL
      const urlObj = new URL(refererUrl);

      // Extract the search parameters
      const params = new URLSearchParams(urlObj.search);

      // Get the siteId
      siteId = params.get('siteId');
    }
    // Only allow origins that include "launchpad"
    if (origin.includes('launchpad')) {
      return `${origin}/site?siteId=${siteId}`;
    }

    return DEFAULT_LAUNCHPAD_URL;
  }


  this.after('READ', 'ChangeView', async data => {
    if (!Array.isArray(data)) return;

    const filtered = data.filter(d => d.modification !== 'create');

    // Modify the original array in place
    data.length = 0;
    data.push(...filtered);
  });

});
