# cf ssh zbuvcm47419-srv -L 9229:127.0.0.1:9229 -T -N
PID=$(cf ssh zbuvcm47419-srv -c "ps -aux | grep 'node /home' | grep -v grep | awk '{print \$2}'")

# Check if PID is not empty
if [ -n "$PID" ]; then  
  cf ssh zbuvcm47419-srv -c "kill -usr1 $PID"
  echo "Debugger listener started..."
  cf ssh -N -L 9229:127.0.0.1:9229 zbuvcm47419-srv
else
  echo "No PID found"
fi

# cf ssh -N -L 9229:127.0.0.1:9229 icdxmapping-srv
