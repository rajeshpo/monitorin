// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Product Flow Catalog
// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Application to create new Product Flows
// ----------------------------------------------------------------------------*
// Descriptions: Table and Views
// ----------------------------------------------------------------------------*
// Change Log:
// //    Date     |       Author        |   Change Id   |   Change Description
// 26-03-2026      RChitike@its.jnj.com     50440096        TIME-FIN-DEV-PFCEnhanceme-Developement
// ----------------------------------------------------------------------------*


using {jnj.com.zbuvcm47419 as db} from './zbuvcm47419schema';
using {Attachments} from '@cap-js/sdm';

extend db.PfcHeaders with {

    @attachments.disable_facet: true
    attachments : Composition of many Attachments @description: 'Attachments linked to the PfcHeader. Facet disabled in the UI.';

}
