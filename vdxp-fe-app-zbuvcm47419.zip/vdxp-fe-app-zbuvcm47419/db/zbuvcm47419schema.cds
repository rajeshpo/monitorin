// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Product Flow Catalog
// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Application to create new Product Flows
// ----------------------------------------------------------------------------*
// Descriptions: Table and Views
// ----------------------------------------------------------------------------*
// Change Log:
// //    Date     |       Author        |   Change Id              |   Change Description
// 26-03-2026      RChitike@its.jnj.com     50440096                 TIME-FIN-DEV-PFCEnhanceme-Developement
// 04-05-2026      ASS4@ITS.JNJ.com         JGHJ-92622(JGHJ-92487)   VCM Constant table does not capture logging
// ----------------------------------------------------------------------------*
namespace jnj.com.zbuvcm47419;

using {Attachments} from '@cap-js/sdm';
using {
  cuid,
  managed
} from '@sap/cds/common';

/**
 * Represents header-level data for a Product Flow Configuration (PFC).
 * Captures unique product flow scenarios involving business partners, plants, 
 * and economic regions. Acts as a master entity for related line items (PfcItems) 
 * and virtual entities (PfcEntities).
 */
entity PfcHeaders : managed {

  key     ID           : UUID                                   @description: 'Unique identifier for the PfcHeader record.';
          CatId        : String(16) default 'New Product Flow'  @Common.Label: '{i18n>ProductFlowCatalogId}'  @Core.Computed                                  @description: 'Automatically computed category ID for the PfcHeader.';
          ProdId       : String(80)                             @changelog                                    @Common.Label: '{i18n>ProductFlowId}'           @description: 'Product Flow ID associated with the PfcHeader.';
          BpSFrom      : String(10)                             @changelog                                    @Common.Label: '{i18n>ShipfromBp}'              @description: 'Starting business partner for the validity range.';
          BpSTo        : String(10)                             @changelog                                    @Common.Label: '{i18n>ShiptoBp}'                @description: 'Ending business partner for the validity range.';
          PlantSFrom   : String(10)                             @changelog                                    @Common.Label: '{i18n>ShipfromPlant}'           @description: 'Starting plant for the validity range.';
          PlantSTo     : String(10)                             @changelog                                    @Common.Label: '{i18n>ShiptoPlant}'             @description: 'Ending plant for the validity range.';
          ErSFrom      : String(20)                             @changelog                                    @Common.Label: '{i18n>EconomicRegionShip1}'     @description: 'Starting Econmic Region (entity/resource) for the validity range.';
          ErSTo        : String(20)                             @changelog                                    @Common.Label: '{i18n>EconomicRegionShip2}'     @description: 'Ending Economic Region (entity/resource) for the validity range.';
          SId          : String(100)                             @readonly                                     @description : 'Unique Sceneraio Determination ID. This field is read-only.';
          PfDesc       : String                             @changelog                                    @Common.Label: '{i18n>ProductFlowDescription}'  @description: 'Description for the Product Flow.';
          fieldControl : Integer                                @odata.Type  : 'Edm.Byte'                     @description : 'Controls field behavior in UI: 1=ReadOnly, 7=Mandatory.';
          Items        : Composition of many PfcItems
                           on Items.parent = $self
                                                                @description: 'Associated PfcItems linked to this PfcHeader.';
          Ventities    : Composition of many PfcEntities
                           on Ventities.parent = $self
                                                                @description: 'Associated PfcEntities linked to this PfcHeader.';
          Changelog    : Composition of many PfcChangeLogs
                           on Changelog.parent = $self
                                                                @readonly                                     @description : 'Associated PfcChangelogs linked to this PfcHeader.';
  virtual isCopy       : Boolean                                @Core.Computed                                @description : 'Indicator if the record is a copy. Computed field.';
          ArchType     : String(20)                             @changelog                                    @description : 'Architecture type or entity classification.';
          comments     : String(500)                            @changelog                                    @description : 'Comments';
     // ***** JGHJ-71574 ***** R2.2 START *****
          UasId        : String(60) @readonly                    @changelog        @description: 'Unique Automation Sequence ID';
          simulation   : String(10)                             @description: 'Simulation is used at Ui end for Simulation Mode';
     // ***** JGHJ-71574 ***** R2.2 END *****
        

}

/**
 * Represents material-level details within a Product Flow. Includes material 
 * identifiers, descriptions, types, validity dates, approval status, workflow 
 * tracking, and field control logic. Linked to a parent PfcHeader.
 */
entity PfcItems : cuid, managed {

  parent          : Association to PfcHeaders   @description: 'Reference to the parent PfcHeader record.';
  CatId           : String(16)                  @description: 'Product Flow Category ID associated with the item.';
  MatBrand        : String(10)                  @changelog                                         @Common.Label: '{i18n>MaterialBrand}'        @description: 'Material Brand identifier.';
  ItemNum         : String(10)                  @changelog @description: 'Material Number in the sequence.';
  Matnr           : String(40)                  @changelog                                         @Common.Label: '{i18n>MaterialNumber}'       @description: 'Material number.';
  MatDesc         : String(40)                  @changelog                                         @Common.Label: '{i18n>MaterialDescription}'  @description: 'Description of the material.';
  VFrom           : Date                        @changelog                                         @description : 'Validity start date for the Material.';
  VTo             : Date       default '9999-12-31'                 @changelog                                         @description : 'Validity end date for the Material.';
  MatType         : String(4)                   @changelog                                         @description : 'Material Type code.';
  ApprStatus      : String(40) default 'New'    @Common.Label: '{i18n>ProductFlowApprovalStatus}'  @description : 'Approval Status of the Material. Defaults to New.';
  Status          : String(10) default 'New' @description: 'Current status of the Material. Defaults to Block.';
  vToFieldControl : Integer                     @odata.Type  : 'Edm.Byte'                          @description : 'Field control for VTo field: 1=ReadOnly, 7=Mandatory.';
  fieldControl    : Integer                     @odata.Type  : 'Edm.Byte'                          @description : 'General field control: 1=ReadOnly, 7=Mandatory.';
  rFeildControl   : Integer  default 1          @odata.Type  : 'Edm.Byte'                          @description : 'General field control: 1=ReadOnly, 7=Mandatory.';
  MatnrFeildControl   : Integer  default 7          @odata.Type  : 'Edm.Byte'                          @description : 'General field control: 1=ReadOnly, 7=Mandatory.';
  MatDescFeildControl   : Integer  default 7          @odata.Type  : 'Edm.Byte'                          @description : 'General field control: 1=ReadOnly, 7=Mandatory.';
  MatTypeFeildControl   : Integer  default 7          @odata.Type  : 'Edm.Byte'                          @description : 'General field control: 1=ReadOnly, 7=Mandatory.';
  MatBrandFeildControl   : Integer  default 7          @odata.Type  : 'Edm.Byte'                          @description : 'General field control: 1=ReadOnly, 7=Mandatory.';
  VFromFeildControl   : Integer  default 7          @odata.Type  : 'Edm.Byte'                          @description : 'General field control: 1=ReadOnly, 7=Mandatory.';
  CommentFeildControl   : Integer  default 1          @odata.Type  : 'Edm.Byte'                          @description : 'General field control: 1=ReadOnly, 7=Mandatory.';

  ApprDate        : Date                        @description: 'Date when the Material was approved.';
  FApprover       : String(30)                  @changelog @description: 'First approver of the Material.';
  Comment         : String(800)                 @changelog @description: 'Additional comments or remarks for the Material.';
  // Block         : Boolean default true       @description: 'Flag to indicate if the Material is blocked. Defaults to true.';
  WorkfInstId     : String(200)                 @description: 'Workflow instance ID associated with the approval process.';
  criticality     : Integer default 2           @description: 'Icons for visual understanding of product flow status';
  pFStatus: String(500) default 'New Flow';
  PrevStatus   : String(20)  @description: 'Status snapshot before entering the current approval cycle.';
  PrevPFStatus : String(800)  @description: 'pFStatus snapshot before entering the current approval cycle.';
  PrevVFrom    : Date        @description: 'VFrom snapshot before entering the current approval cycle.';
  PrevApprStatus : String(40)  @description: 'ApprStatus snapshot before entering the current approval cycle.';
  PrevVTo: Date default '9999-12-31';
  PrevMatnr           : String(40);                  
  PrevMatDesc         : String(40); 
  PrevMatBrand        : String(10);                 
  PrevMatType         : String(4);
}

/**
 * Defines intermediate or logical flow steps (e.g., nodes) within a product flow. 
 * Stores plant, business partner, architecture type, and sequencing data.
 * Linked to a parent PfcHeader and supports field behavior control and auditing.
 */
entity PfcEntities : cuid, managed {

  parent       : Association to PfcHeaders @description: 'Reference to the parent PfcHeader record.';
  fieldControl : Integer                   @odata.Type: 'Edm.Byte'  @description: 'Controls field behavior: 1=ReadOnly, 7=Mandatory.';
  CatId        : String(16)                @description: 'Product Flow Category ID associated with the entity.';
  SeqNum       : String(6)                 @description: 'Sequence number of the entity.';
  ArchType     : String(20)                @changelog               @description: 'Architecture type or entity classification.';
  Plant        : String(10)                @changelog               @description: 'Plant code linked with the entity.';
  BPartner     : String(10)                @changelog               @description: 'Business partner code linked to the entity.';

}

/**
 * Defines eco-regions by country, including a unique region code and name.
 * Serves as reference data for assigning economic regions in product flows.
 */
entity PfcEcoRegions {

  key CountryCode : String(10)  @changelog @description: 'Country code for which the eco-region is defined.';
      EcoRegCode  : String(50)  @changelog @description: 'Unique code identifying the eco-region.';
      EcoRegName  : String(100) @changelog @description: 'Name or description of the eco-region.';

}

/**
 * Tracks changes in the validity end date (VTo) for materials in a Product Flow.
 * Captures previous and current VTo values by material number, brand, and category.
 * Linked to a PfcHeader via `parent`.
 */
entity PfcChangeLogs : managed {
  key parent   : Association to PfcHeaders @description: 'Reference to the parent PfcHeader record.';
  key CatId    : String(16);
  key Matnr    : String(40);
  key MatBrand : String(10);
      PrevVTo  : DateTime;
      CurrVTo  : DateTime;
}

/**
 * Stores user comments linked to specific PfcItems, including timestamp,
 * username, and related batch/item ID. Useful for tracking discussion or notes 
 * on material-level changes within a Product Flow.
 */
entity PfcItemComments : cuid, managed {
  key CommentID       : UUID;
      PfcItem_BatchID : UUID; // Foreign Key to PfcItems
      Timestamp       : DateTime;
      Uname           : String(20) @changelog;
      Comment         : String(60) @changelog;
}

/**
 * Logs approval history for materials in a Product Flow, including workflow 
 * instance ID, status, timestamp, approver, and comments. Used for tracking
 * decision-making steps in material-level workflows.
 */

 @assert.unique: {PfcItemsWFHistory_unique: [
  ID,
  CatId,
  MatBrnd,
  Timestamp
]}
entity PfcItemsWFHistory :managed {
   ID              : UUID;
  key CatId          : String(16) @description: 'Product Flow Category ID associated with the entity.';
      WorkfInstId    : String(60) @changelog @description: 'Work Flow Instance ID associated with the entity';
      Matnr          : String(30) @changelog @description: 'Material Number is defined in this enitity';
  key MatBrnd        : String(50) @changelog @description: 'Material Brand/Profit Center is defined in this entity';
  key Timestamp      : Timestamp @cds.on.insert : $now  @description: 'Timestamp is used as a combination key to distinguish';
      ApprovalStatus : String(20) @changelog @description: 'Approver status of the material is defined in the entity';
      Uname          : String(20) @changelog @description: 'Approver name is defined in this enitity';
      Comment        : String(800) @changelog @description: 'Approver Comment is maiantined in this entity';
      MatType        : String(4)  @changelog @description : 'Material Type code.';
      Status         : String(10)  @description: 'Current status of the Material. Defaults to Block.';

}

/**
 * Maps eco-region codes to designated workflow approvers via distribution (DL) 
 * and BTP user lists. Used to determine approval routing based on region.
 */
entity PfcWorkFlowApprover {
  key EcoRCode : String(8) @changelog;
      Dl_list  : String(200) @changelog;
      Btp_list : String(200) @changelog;
}

/**
 * Provides localized status descriptions for use in UIs (e.g., approval status).
 * Used as a value help or display reference; not stored in the database.
 */
@cds.persistence.skip
entity Status {
  key StatusID : Integer;
      Desc     : String(20) @Common.Label: '{i18n>ProductFlowApprovalStatus}';
}


@cds.persistence.skip
entity Block_Status {
    key  Status     : String(20) @Common.Label: 'Status';
}
@cds.persistence.skip
entity Block_StatusV {
    key  Status     : String(20) @Common.Label: 'Status';
}
/**
 * Provides a list of architecture types for UI dropdowns or value helps.
 * Used for classification in product flows; not stored in the database.
 */
@cds.persistence.skip
entity ArchType {
  key ID        : Integer;
      archValue : String(20) @changelog;
}

/**
 * Defines ordered steps for scenario ID pairs in product flow automation.
 * Captures pair ID, architecture type, system, variation (SO/PO), sequence, 
 * steps, entities, and actions for driving process logic.
 */
entity SIdPairSequence: cuid, managed {
  key SId         : String(50) @description: 'scenario ID  is maintained in this entity';
      Pair        : String(20) @changelog @description: 'scenario ID pair is maintained in this entity';
      Description : String(50) @changelog @description: 'scenario ID pair dscription is maintained in this entity';
  key System      : String(50) @changelog @description: 'scenario ID pair system info is maintained in this entity';
      ArchType    : String(30) @changelog @description: 'scenario ID pair archtype is maintained in this entity';
  key Variation   : String(10) @changelog @description: 'scenario ID pair for which Variation is maintained in this entity (1-SO and 2-PO)';
  key Sequence    : Integer @changelog @description: 'scenario ID pair sequence  is maintained in this entity';
  key Steps       : String(80) @changelog @description: 'scenario ID pair step is maintained in this entity';
      Entity      : String(10) @changelog @description: 'scenario ID pair part  is maintained in this entity';
      Action      : String(35) @changelog @description: 'scenario ID pair automation info is maintained in this entity';
  key stepID     : String(10)  @description: 'scenario ID pair step id is maintained in this entity';
}

  // ***** JGHJ-71574 ***** R2.2 START *****
entity UASIDDetermination : managed {
      sequenceId : String(8) @description: 'Sequnce ID is maintained';
      UasId      : String(60) @description: 'UAS ID';
  key flowId     : String(30) @description: 'Flow ID';
      description: String(100) @description: 'Description of flow id';
}
   // ***** JGHJ-71574 ***** R2.2 END *****

/**
 * Logs approval history for materials in a Product Flow, including workflow 
 * instance ID, status, timestamp, approver, and comments. Used for tracking
 * decision-making steps in material-level workflows.
 */
entity PfcArchTypeMapping : managed {
  key ArchType     : String(16) @changelog @description: 'Product Flow Arch Type';
      Sf_In_S4     : String(10) @changelog @description: 'Ship From in S\4';
      Sf_In_NonS4  : String(10) @changelog @description: 'Ship From in NON S\4';
      St_In_S4     : String(10) @changelog @description: 'Ship To in S\4';
      St_In_NonS4  : String(10) @changelog @description: 'Ship To in NON S\4';
      Vir_In_S4    : String(10) @changelog @description: 'Virtual in S\4';
      Vir_In_NonS4 : String(10) @changelog @description: 'Virtual in NON S\4';
      Vir1_In_S4 :String(10) @changelog @description: 'First Virtual in S\4';
      Vir1_In_NonS4 : String(10) @changelog @description: 'Virtual in NON S\4';
}

entity SeqStepsID : managed {
  key ID   : String(10);
      Step : String @changelog;
}

/**
 * Joins `PfcItems` with `PfcHeaders` to provide a combined view of material-
 * 
 * 
 */
view PFC_ListView as
  select from PfcItems as l
  inner join PfcHeaders as h
    on l.parent.ID = h.ID
  {

    @UI.Hidden
    key h.ID,             // still a key but hidden from UI

    @UI.Hidden
    key l.ID as matID,    // still a key but hidden from UI

    h.CatId,
    l.MatBrand,
    l.Matnr,
    l.MatDesc,
    l.MatType,
    l.Status,
    @Common.Label: 'Valid From'
    l.VFrom,
    @Common.Label: 'Valid To'
    l.VTo,
        l.ApprStatus,
         @UI.Hidden
        l.criticality,
        h.ProdId,
        h.BpSFrom,
        h.BpSTo,
        h.PlantSFrom,
        h.PlantSTo,
        h.ErSFrom,
        h.ErSTo,
        h.PfDesc,
       @UI.HiddenFilter:false
        h.createdBy,
        @UI.HiddenFilter:false
        h.createdAt,
        h.UasId

  }


view PfcItemsView as
  select
    CatId,
    MatBrand,
    Matnr,
    MatDesc,
    ApprStatus
  from PfcItems;

view ProdFIDValHelp as
  select distinct key ProdId from PfcHeaders
  where
    ProdId is not null;


view createdByValHelp as
  select distinct key createdBy from PfcHeaders
  where
    createdBy is not null;

view CatIdValHelp as
  select distinct key CatId from PfcHeaders
  where
    CatId is not null;

view UasIdValHelp as
  select distinct key UasId from PfcHeaders
  where
    UasId is not null;

view SFBPValueHelp as
  select distinct key BpSFrom from PfcHeaders
  where
    BpSFrom is not null;

view STBPValueHelp as
  select distinct key BpSTo from PfcHeaders
  where
    BpSTo is not null;

view SFPlantValueHelp as
  select distinct key PlantSFrom from PfcHeaders
  where
    PlantSFrom is not null;

view STPlantValueHelp as
  select distinct key PlantSTo from PfcHeaders
  where
    PlantSTo is not null;

view MatnrValHelp as
  select distinct key Matnr from PfcItemsView
  where
    Matnr is not null;

view MatBrandValHelp as
  select distinct key MatBrand from PfcItems
  where
    MatBrand is not null;

view MatDescValHelp as
  select distinct key MatDesc from PfcItems
  where
    MatDesc is not null;


entity ExcelUpload {

  key     ID          : UUID                            @description: 'Unique identifier for the Excel upload record.';
  key     user        : String                          @changelog @cds.on.insert: $user  @description: 'User ID who performed the upload. Automatically set to the current user.';
  virtual isValidated : Boolean                         @description: 'Indicates whether the uploaded data has been validated.';

          @attachments.disable_facet: true
          attachments : Composition of many Attachments @description  : 'Attachments linked to the Excel upload. Facet disabled in UI.';

}