// Application Name : VCM PreRequiste API
// Object Id       : zbuvcm55156
// Release         : 1
// Version         : 0.01
// Description     : VCM PreRequiste API
// ----------------------------------------------------------------------------*
// Descriptions: Table and Views
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
//  11-10-2025      Devansh      
// ----------------------------------------------------------------------------*
namespace jnj.com.zbuvcm55156;

using {
  cuid,
  managed
} from '@sap/cds/common';
/**
 * This entity represents the header-level data of a Shipping Request.
 * It is mapped to an existing persistence table in the database(@cds.persistence.exists).
 * It acts as the master entity controlling shipping scenarios,
 * including validation status, workflow details, and links to
 * related line items, generated documents
 */
@cds.persistence.exists
entity syn_ShippingRequest {
    key ID                                  : UUID;
    key shippingReqNo                       : String(18)  @description: 'Unique identifier for the Shipping Request (system generated)';
    key initialDocumentNo                   : String(10)  @description: 'Document number of the initial triggering document';
        initialDocumentType                 : String(10)  @description: 'Type of the initial document (e.g., Sales Order, Purchase Order)';
        referenceDocumentNo                 : String(20)  @description: 'Reference document number linked to the shipping request';
        followOnDocumentNo                  : String(20)  @description: 'Follow-on document number created during processing';
        status                              : String(11)  @description: 'Overall processing status of the Shipping Request';

        shipFromBusinessPartner             : String(10)  @description: 'Business Partner ID of the Ship-From location';
        shipFromPlant                       : String(10)  @description: 'Plant code of the Ship-From location';
        shipToBusinessPartner               : String(10)  @description: 'Business Partner ID of the Ship-To location';
        shipToPlant                         : String(10)  @description: 'Plant code of the Ship-To location';

        requestedDeliveryDate               : Date        @description: 'Requested delivery date for the shipment';
        scenarioID                          : String(20)  @description: 'Scenario identifier used for determination logic';

        masterDataStatus                    : String(20)  @description: 'Validation status of master data';
        masterDataErrorDesciption           : String      @description: 'Detailed error message for master data validation';
        masterDataErrorCreationDate         : Timestamp   @description : 'Represents when error occured for master data check';

        pfcCheckStatus                      : String(20)  @description: 'Product Flow Catalog check status';
        pfcCheckErrorDescription            : String(400) @description: 'Error message related to Product Flow Catalog validation';
        pfcCheckErrorCreationDate           : Timestamp   @description :  'Represents when pfc check error occured';

        scenarioDeterminationCheckStatus    : String(20)  @description: 'Status of scenario determination check';
        scenarioCheckStatusErrorDescription : String(400) @description: 'Error message related to scenario determination';
        scenarioCheckErrorCreationDate      : Timestamp   @description : 'Represents when scenario check error occured';
        docFlowStateCheckStatus             : String(20)  @description: 'Status of document flow state validation';
              
   
        wfInstanceId                        : String(80)  @description: 'Workflow instance ID triggered for this shipping request';
        productFlowCatalogID                : String(14)  @description: 'Identifier of the Product Flow Catalog linked to this request';
        productFlowID                       : String      @description: 'Unique Product Flow ID associated with the scenario';

        creationDate                        : Date        @description: 'Date when the shipping request was created';
        userName                            : String(9)   @description: 'User ID of the person who created the request';

        // --- Compositions ---
        items                               : Composition of many syn_ShippingRequestItem
                                                  on items.parent = $self
                                                          @description: 'List of Material details for this Shipping Request';
        entity                              : Composition of many syn_ShippingRequestEntityDocs
                                                  on entity.parent = $self
                                                          @description: 'List of documents generated for this request';

}

/**
 * Represents item-level details of a Shipping Request.
 * Captures material-specific information such as type, brand, quantity,
 * and batch. Acts as a child entity of ShippingRequest, holding
 * transactional line items for each request.
 */
@cds.persistence.exists
entity syn_ShippingRequestItem {
    key ID                  : UUID;
        parent              : Association to syn_ShippingRequest;
        followOnDocumentNo  : String(20) @description: 'Reference GR or follow-on document number';
        itemNo              : String(20) @description: 'Item number';
        materialNumber      : String     @description: 'Material Number';
        materialType        : String     @description: 'Type/category of the material';
        materialBrand       : String     @description: 'Brand associated with the material';
        materialDescription : String     @description: 'Detailed description of the material';
        quantity            : String     @description: 'Quantity of material requested/shipped';
        uom                 : String     @description: 'Unit of Measure (e.g., EA, KG, L)';
        batchNumber         : String     @description: 'Batch number for traceability of the material';

}

/**
 * Represents document-level data linked to a Shipping Request.
 * Captures follow-on documents, business entities, statuses, and errors
 * that form part of the overall shipping request process.
 * Acts as a child entity of ShippingRequest and stores transactional
 * and validation details such as error logs, document sequences,
 * and associated business partners, plants, and eco-regions.
 */
@cds.persistence.exists
entity syn_ShippingRequestEntityDocs {
    key ID                    : UUID;
        parent                : Association to syn_ShippingRequest;
        followOnDocumentNo    : String(20)  @description: 'Reference GR or follow-on document number';
        documentType          : String(30)  @description: 'Document Type (e.g., Sales Order, Purchase Order)';
        documentNumber        : String(20)  @description: 'Document Number';
        errorStatus           : String(20)  @description: 'Error Status Code';
        errorDescription      : String(255) @description: 'Document error description or remarks';
        wfInstanceId          : String(80)  @description: 'Workflow Instance ID for tracking and retriggering the flow';
        errorCreationDate     : Date        @description: 'Date when the error was created';
        creationDate           : Timestamp  @description: 'General creation date of the record';
        errorResolutionDate   : Date        @description: 'Date when the document error was resolved';
        entityType            : String(20)  @description: 'Type of business entity (e.g., SF, ST)';
        entityRank            : Integer     @description: 'Rank or order of the entity within the flow';
        documentSequence      : Integer     @description: 'Sequence of the document in the process flow';
        ecoRegion             : String(10)  @description: 'Eco region or regional code';
        businessPartnerId     : String(10)  @description: 'Business Partner ID (customer/vendor)';
        plant                 : String(10)  @description: 'Plant identifier';
        bpName                : String(20)  @description: 'Business Partner name';
        plantName             : String(20)  @description: 'Plant name';
        ecoRegionName         : String(20)  @description: 'Eco region descriptive name';
        documentYear          : Date        @description: 'Document year (used in reporting/partitioning)';
        legalEntity           : String(10)  @description: 'Legal entity';
        isAT                  : Boolean     @description: 'Flag for AT documents (if applicable)';
        isExceptionalDocument : Boolean     @Common.FieldControl: #Hidden  @description: 'Flag for exceptional documents (hidden in UI)';
         stepID                 : String;
}


/**
 * Represents error log details for a Shipping Request document.
 * Captures error status, type, and workflow instance information.
 * Acts as a child entity of ShippingRequestEntityDocs,
 * allowing multiple errors to be tracked for a single document.
 */
@cds.persistence.exists
entity syn_ShippingRequestErrors : cuid, managed {

          parent            : Association to syn_ShippingRequestEntityDocs @description: 'Reference to the parent Shipping Request Entity Document';
          vcaErrorStatus    : String                                   @description: 'Error status of the document flow (e.g., Pending, Error, Resolved)';
          vcaErrorType      : String(100)                              @description: 'Type or category of the error (e.g., Master Data, PFC Check, Scenario)';
          vcaErrorTimeStamp : Timestamp                                @description: 'Timestamp indicating when the error was logged';
          wfInstanceId      : String(80)                               @description: 'Workflow Instance ID associated with this error, if available';
  virtual Criticality       : Integer                                  @description: 'UI criticality indicator for highlighting error severity';
}