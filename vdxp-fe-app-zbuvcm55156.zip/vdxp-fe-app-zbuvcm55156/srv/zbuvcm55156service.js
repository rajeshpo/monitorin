// --------------------------------------------------------------------------------------------------------------------*
// Application Name : VCM Pre Requisite API 
// Object Id       : ZBUVCM55156
// Release         : 1
// Version         : 0.01
// Description     : Application to Perform Automation PreRequisite Checks
// ----------------------------------------------------------------------------*
// Descriptions: Provides service definitions, handlers, and utility functions for the VCM PreRequisite API application .
//This module handles custom actions, and external API integration for managing VCM PreRequisite API.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*

const cds = require('@sap/cds');
const { pfcCheck, formatSidOutputPayload,pfcCall } = require('./PreRequisiteChecks/preRequisite');
const logger = cds.log('zbuvcm55156-preRequisiteAPI');
const textBundle = require('./_i18n/textBundle');
let bundle = '';
const { updateErrorTable, retrieveErrorMessage, updateHeaderErrorTable,wrapperResponseObj,readProxyWithErrorHandling,updateLegacySo, updateQueueErrorTable } = require("./AutomationDBErrorHandling/errorHandling");
const { sendMail, convertSAPDateToISO } = require("./AutomationDBErrorHandling/errorMail");
const { error } = require('@sap/cds');
const { executeWithRetry } = require('./AutomationDBErrorHandling/executeWithRetry');
const {syn_ShippingRequestErrors, syn_ShippingRequest ,syn_ShippingRequestQueue, syn_ShippingRequestEntityDocs} = cds.entities('jnj.com.zbuvcm55156');



module.exports = cds.service.impl(async function () {


  /**
  * Establishes a connection to the external service ZSD_VCM_PRODUCTFLOW
  * This service is used to handle various product flow related entity reads
  */
  let ZSD_VCM_PRODUCTFLOW = '';
  let ZSD_VCM_MASTERDATA = '';
  const ZSD_VCM_PREREQAPI = await cds.connect.to("ZSD_VCM_PREREQAPI");
  const ZSD_VCM_MASTERDAPI = await cds.connect.to("ZSD_VCM_MASTERDATA");
  const ZAPI_OUTBOUND_DELIVERY_SRV = await cds.connect.to("ZAPI_OUTBOUND_DELIVERY_SRV");
  const ZAPI_SALES_ORDER_SRV = await cds.connect.to("ZAPI_SALES_ORDER_SRV");
  const ZAPI_SUPPLIERINVOICE_PROCESS_SRV = await cds.connect.to("ZAPI_SUPPLIERINVOICE_PROCESS_SRV");
  const PURCHASEORDER = await cds.connect.to("PURCHASEORDER");
  const ZAPI_MATERIAL_DOCUMENT_SRV = await cds.connect.to("ZAPI_MATERIAL_DOCUMENT_SRV");
  const ZSD_BATCH_NUMBER_GENERATION = await cds.connect.to("ZSD_BATCH_NUMBER_GENERATION");
  const BILLINGDOCUMENT = await cds.connect.to("BILLINGDOCUMENT");
  const ZAPI_BATCH_SRV = await cds.connect.to("ZAPI_BATCH_SRV");
  const orchrestration = await cds.connect.to("IM_ORCHESTRATION_CAP");
  const vcm_constants = await cds.connect.to("VCM_CONSTANTS");
  const ZAPI_INBOUND_DELIVERY_SRV = await cds.connect.to("ZAPI_INBOUND_DELIVERY_SRV");
  const ZSD_VCM_INSPECTIONLOTCANCEL = await cds.connect.to("ZSD_VCM_INSPECTIONLOTCANCEL");
  const ZSD_LOGIST_DEL_109  = await cds.connect.to("ZSD_LOGIST_DEL_109");
  const constants = require('./config/constants');
  const ZAPI_SALES_ORDER_WITHOUT_CHARGE_SRV = await cds.connect.to("ZAPI_SALES_ORDER_WITHOUT_CHARGE_SRV");
  const ZAPI_INSPECTIONLOT_SRV = await cds.connect.to("ZAPI_INSPECTIONLOT_SRV");
  const ZAPI_INFORECORD_PROCESS_SRV = await cds.connect.to("ZAPI_INFORECORD_PROCESS_SRV");
  const ZSD_VCM_AUTOMATION_FIN_SCN1 = await cds.connect.to("ZSD_VCM_AUTOMATION_FIN_SCN1");
  const ZAPI_PURCHASING_SOURCE_SRV = await cds.connect.to("ZAPI_PURCHASING_SOURCE_SRV");
  const ZAPI_CLFN_CHARACTERISTIC_SRV =  await cds.connect.to("ZAPI_CLFN_CHARACTERISTIC_SRV");
  const ZAPI_PURCHASECONTRACT_PROCESS_SRV = await cds.connect.to("ZAPI_PURCHASECONTRACT_PROCESS_SRV");
  const ZSD_VCM_PO_TRIGGERS = await cds.connect.to("ZSD_VCM_PO_TRIGGERS");
  const ZSD_VCM_AUTOMATIONFLW = await cds.connect.to("ZSD_VCM_AUTOMATIONFLW");
  const ZAPI_BUSINESS_PARTNER = await cds.connect.to("ZAPI_BUSINESS_PARTNER");
  const ZSD_VCM_POUNCANCELLATION = await cds.connect.to("ZSD_VCM_POUNCANCELLATION0001");
  const response = {} //maintained for wrappererrorResponse function. 


  try {
    // Connect to the abap service
    ZSD_VCM_PRODUCTFLOW = await cds.connect.to("ZSD_VCM_PRODUCTFLOW");
  } catch (error) {
    logger.error(`OData Service Issue: `, error.message);
    throw new Error(`Error occurred connecting to S4 Odata Service`);
  }


  this.on('masterdataCheck', async (req) => {
    const global_ID = req?.data.payload.ID;
    const gloabal_wfID = req?.data.payload.wfID;
    const QueueId= req?.data.payload.QueueId || null;
    logger.info(`masterdataCheck invoked - global_ID line 80: ${global_ID}, QueueId: ${QueueId}, wfID: ${gloabal_wfID}`);
    try {


      const { ID, wfID, ...data } = req?.data.payload;

      logger.info(constants.Payload_For_MasterData, JSON.stringify(data));

      // const tx = cds.tx(req)

      let response = await vcm_constants.tx(req).get('/zbuvcm55154/FilterConstant');

      let findERecord = response.value.find(item => item.ConstantVar === constants.Master_Data_Flag)

      delete data.QueueId;

      // Call external S4 API
      const response_from_s4 = await ZSD_VCM_MASTERDAPI.tx(req).post(
        "/MasterDataCheckV2",
        data
      );

      logger.info(constants.Response_for_Master_Data, JSON.stringify(response_from_s4));

      let errorMessage = null;
      const individualErrors = []; // This will store: ["US8T: error", "US8U: error"]


      if (Array.isArray(response_from_s4._header)) {
        const headerComments = (response_from_s4?.comments ?? "")
          .split(/\s*\/\s*/)
          .filter(Boolean)
          .join("\n");

        // Add separator ONLY if header comments exist
        if (headerComments?.length > 0) {
          errorMessage = headerComments;
          errorMessage += "\n\n";
        }
        for (const item of response_from_s4._header) {
          if (item.comments1 && item.comments1.trim().length > 0) {
            const formattedComments = item.comments1
              .split(/\s*\/\s*/)
              .filter(Boolean)
              .join("\n");

            if (formattedComments?.length > 0) {
              if (errorMessage === null) {
                errorMessage = ''
              }

             const formattedComments1 = item.comments1
                    .split(/\/|\n/)
                    .map(x => x.trim())
                    .filter(Boolean);

                formattedComments1.forEach(comment => {
                    individualErrors.push(`${item.VirtualEntity}: ${comment}`);
                });
              errorMessage += `${item.VirtualEntity}\n${formattedComments}\n\n`;
            }
          }
        }
      }

      logger.info(constants.Errors_Concatenated_for_Master_Data, JSON.stringify(errorMessage));

      if (errorMessage && findERecord?.Value && findERecord?.Value.toUpperCase() === constants.M_Error) {

        // const e = new Error(errorMessage.trim());
        //         e.code = constants.MASTERDATA_VALIDATION_FAILED;
        //         e.status = 400;
        // throw e;


        logger.error(constants.Master_Data_Check_failed, JSON.stringify(errorMessage.trim()));
        const data = {
          ID: global_ID,
          wfInstanceId: gloabal_wfID,
          errorDescription: errorMessage.trim(),
          errorStatus: constants.E
        }

        if (QueueId) {
          const tx = cds.tx(req);
          await tx.begin();
          const queueRow1 = await tx.run(SELECT.one.from('JNJ_COM_ZBUVCM55156_SYN_SHIPPINGREQUESTQUEUE').where({ ID: QueueId }));
          const parentPO1 = queueRow1?.PARENTPO ?? queueRow1?.parentPO;
          logger.info(`masterdataCheck M_Error Req2 UPDATE - QueueId: ${QueueId}, parentPO: ${parentPO1}`);
          if (parentPO1) {
            const sr1 = await tx.run(SELECT.one.from(syn_ShippingRequest).columns('ID').where({ initialDocumentNo: parentPO1 }));
            if (sr1?.ID) {
              const ts1 = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
              await tx.run(UPDATE(syn_ShippingRequest).set({ masterDataErrorDesciption: 'PO change triggered & partial successful. Please check change events tab for further details. (' + ts1 + ')' }).where({ ID: sr1.ID }));
            }
          }
          await tx.commit();
        } else {
          await updateHeaderErrorTable(req, data, constants.MASTERDATA, individualErrors)
        }
        return {
          status: constants.E,
          // data: new Error(errorMessage.trim())
          data: response_from_s4
        };

      }

      if (errorMessage && (!findERecord?.Value || findERecord?.Value.toUpperCase() === constants.M_Warning)) {
        response_from_s4.comments = errorMessage.trim()

        let updateJson = {
          masterDataErrorDesciption: errorMessage.trim() ? errorMessage.trim() : undefined,
          masterDataStatus: 'Warning',
          masterDataErrorCreationDate: new Date(),
          status: 'In Progress'
        }
        const errors = [];
        if (
          Array.isArray(individualErrors) &&
          individualErrors.length > 0
        ) {
          for (const err of individualErrors) {
            errors.push({
              ID: cds.utils.uuid(),
              parent_ID: global_ID,
              vcaErrorStatus: err, // Example: "US8T: Plant US8T does not exist"
              vcaErrorType: 'Warning', // You can categorize the error type if needed
              wfInstanceId: '',
              vcaErrorTimeStamp: new Date()
            });
          }
        }
        const tx = cds.tx(req)
        await tx.begin();
        await tx.run(UPDATE(syn_ShippingRequest).set(updateJson).where({ ID: global_ID }));
        await tx.run(INSERT.into(syn_ShippingRequestErrors).entries(errors));
        await tx.commit();
        return {
          status: constants.Warning,
          data: response_from_s4
        };
      }

      if (!errorMessage) {
        return {
          status: constants.Success,
          data: response_from_s4
        };
      }

    } catch (err) {
      logger.error(constants.Master_Data_Check_failed, JSON.stringify(err));
      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: err.message,
        errorStatus: constants.E
      }

      if (QueueId) {
        await updateQueueErrorTable(req, data, err, QueueId)
        const tx = cds.tx();
        await tx.begin();
        const queueRow2 = await tx.run(SELECT.one.from('JNJ_COM_ZBUVCM55156_SYN_SHIPPINGREQUESTQUEUE').where({ ID: QueueId }));
        const parentPO2 = queueRow2?.PARENTPO ?? queueRow2?.parentPO;
        logger.info(`masterdataCheck catch Req2 UPDATE - QueueId: ${QueueId}, parentPO: ${parentPO2}`);
        if (parentPO2) {
          const sr2 = await tx.run(SELECT.one.from(syn_ShippingRequest).columns('ID').where({ initialDocumentNo: parentPO2 }));
          if (sr2?.ID) {
            const ts2 = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
            await tx.run(UPDATE(syn_ShippingRequest).set({ masterDataErrorDesciption: 'PO change triggered & partial successful. Please check change events tab for further details. (' + ts2 + ')' }).where({ ID: sr2.ID }));
          }
        }
        await tx.commit();
        const OmService = await cds.connect.to("VCM_ORDERMONITORING_CAP")
        logger.info(`masterdataCheck QueueInError triggered for ShippingRequestID: ${global_ID}`)
        let op = await OmService.post('/zbuvcm55155/QueueInError', { queueId: QueueId })
        logger.info(`Response from VCM_ORDERMONITORING_CAP: ${JSON.stringify(op)}`)
      }
      else {
        await updateHeaderErrorTable(req, data, constants.MASTERDATA)
      }

      req.error({
        message: err.message,
        status: err.status
      });
    }
  });


  /**
     * Service handler for posting OutBound Delivery
     * it is the Wrapper API  called from SBPA 
     * URL: /zbuvcm55156/post_OutbDeliveryHeader
     */
  this.on('post_OutbDeliveryHeader', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.OBD_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const response = await ZAPI_OUTBOUND_DELIVERY_SRV.tx(req).post("A_OutbDeliveryHeader", {
          to_DeliveryDocumentItem: APIDetails?.to_DeliveryDocumentItem
        })
        
        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);

        return newResponse;
      }


    } catch (error) {

      logger.error(`${constants.OBD_Activity} failed from EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.OBD_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })

 
  /**
   * Service handler for posting Sales Order
   * it is the Wrapper API  called from SBPA 
   * URL: /zbuvcm55156/create_SaleOrder
   */
  this.on('create_SaleOrder', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.SO_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const response = await ZAPI_SALES_ORDER_SRV.tx(req).post("A_SalesOrder", {
          ...APIDetails,
          SalesOrderDate: convertSAPDateToISO(APIDetails.SalesOrderDate),
          to_Item: APIDetails.to_Item?.results || [],
          to_Partner: APIDetails.to_Partner?.results || []
        });

        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        return newResponse;
      }


    } catch (error) {
      logger.error(`${constants.SO_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.SO_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })



  /**
   * Service handler for posting AP Invoice
   * it is the Wrapper API  called from SBPA 
   * URL: /zbuvcm55156/create_SupplierInvoice
   */
  this.on('create_SupplierInvoice', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.APInvoice_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const payloadToSend = {
          ...APIDetails,
          PostingDate: convertSAPDateToISO(APIDetails.PostingDate),
          DocumentDate: convertSAPDateToISO(APIDetails.DocumentDate),
          CreationDate:convertSAPDateToISO(APIDetails?.CreationDate),
          // Map items
          to_SuplrInvcItemPurOrdRef: APIDetails.to_SuplrInvcItemPurOrdRef?.results.map(item => ({
            ...item
          })),
        };

        //const response = await ZAPI_SUPPLIERINVOICE_PROCESS_SRV.tx(req).post("A_SupplierInvoice", payloadToSend);
        const response = await ZAPI_SUPPLIERINVOICE_PROCESS_SRV.send('POST', "/A_SupplierInvoice", payloadToSend)
        
        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        return newResponse;
      }


    } catch (error) {
      logger.error(`${constants.APInvoice_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.APInvoice_Activity);

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })

  this.on('poUncancel', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const global_wfID = req?.data.Payload.wfID;
    const global_QueueId = req?.data.Payload.QueueId;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, APIDetails, QueueId } = payload

        logger.info(`${constants.poUncancel_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const payloadToSend = {
          ...APIDetails,
        };

        const response = await executeWithRetry(() =>
          ZSD_VCM_POUNCANCELLATION.send({ method: 'POST', path: "/POUNCANCEL", data: payloadToSend }), ID
        );

        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);
        return newResponse;
      }


    } catch (error) {
      logger.error(`${constants.poUncancel_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: global_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }

      if (global_QueueId) {
        await updateQueueErrorTable(req, data, error, global_QueueId)
        const OmService = await cds.connect.to("VCM_ORDERMONITORING_CAP")
        let op = await OmService.post('/zbuvcm55155/QueueInError', { queueId: global_QueueId })
        logger.info(`Response from VCM_ORDERMONITORING_CAP: ${JSON.stringify(op)}`)
      } else {
        await updateErrorTable(req, data, error)
      }

      await sendMail(req, error, data, orchrestration, constants.poUncancel_Activity);

      let errorResponse = wrapperResponseObj(error,constants.wrapperError);
      return errorResponse;

    }
  })



  /**
  * Service handler for posting Purchase Order
  * it is the Wrapper API  called from SBPA 
  * URL: /zbuvcm55156/create_PurchaseOrder
  */
  this.on('create_PurchaseOrder', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         


        logger.info(`${constants.PO_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(APIDetails));

        const response = await executeWithRetry(() =>
         PURCHASEORDER.tx(req).post("PurchaseOrder", APIDetails), ID
        );

        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        return newResponse;

      }


    } catch (error) {
      logger.error(`${constants.PO_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.PO_Activity);

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })



  /**
* Service handler for posting Goods Reciept
* it is the Wrapper API  called from SBPA 
* URL: /zbuvcm55156/create_GR
*/
  this.on('create_GR', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.GR_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));


        const response = await ZAPI_MATERIAL_DOCUMENT_SRV.tx(req).post("A_MaterialDocumentHeader", {
          ...APIDetails,
          PostingDate: convertSAPDateToISO(APIDetails.PostingDate),
          to_MaterialDocumentItem: APIDetails.to_MaterialDocumentItem?.results || []
        });

        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        return newResponse;

      }


    } catch (error) {

      logger.error(`${constants.GR_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.GR_Activity);

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })


  /**
  * Service handler for posting Goods Reciept Delivery
  * it is the Wrapper API  called from SBPA 
  * URL: /zbuvcm55156/post_OutbDeliveryHeader
  */
  this.on('post_IBD_GR', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.IBD_GR_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const deliveryDoc = APIDetails.DeliveryDocument;
        let ActualGoodsMovementDate = APIDetails?.ActualGoodsMovementDate;

        let getMetaData = await ZAPI_INBOUND_DELIVERY_SRV.send({
          method: "GET",
          path: `/A_InbDeliveryHeader(${deliveryDoc})`
        })


        const response = await ZAPI_INBOUND_DELIVERY_SRV.send("POST", `/PostGoodsReceipt?DeliveryDocument=${deliveryDoc}`, undefined, { "If-Match": getMetaData.$metadata.etag })
        //  const response =  await ZAPI_INBOUND_DELIVERY_SRV.send("POST", `/PostGoodsReceipt?DeliveryDocument=${deliveryDoc}`, undefined)

        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        logger.info("PostGoodsReceipt response:",newResponse);

        return newResponse;
        
      }

    } catch (error) {

      logger.error(`${constants.IBD_GR_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.IBD_GR_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })



  /**
   * Service handler for posting OutBound Delivery
   * it is the Wrapper API  called from SBPA 
   * URL: /zbuvcm55156/post_OutbDeliveryHeader
   */
  this.on('post_GoodsIssue', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.GI_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const deliveryDoc = APIDetails.DeliveryDocument;

        let getMetaData = await ZAPI_OUTBOUND_DELIVERY_SRV.send({
          method: "GET",
          path: `/A_OutbDeliveryHeader(${deliveryDoc})`
        })

        const response = await ZAPI_OUTBOUND_DELIVERY_SRV.send("POST", `/PostGoodsIssue?DeliveryDocument=${deliveryDoc}`, undefined, { "If-Match": getMetaData.$metadata.etag })
        
        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        logger.info("PostGoodsIssue response:",newResponse);

        return newResponse;

      }

    } catch (error) {

      logger.error(`${constants.GI_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.GI_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })



  /**
   * Service handler for posting AR Invoice
   * it is the Wrapper API  called from SBPA 
   * URL: /zbuvcm55156/post_ARInvoice
   */
  this.on('post_ARInvoice', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.AR_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const response = await BILLINGDOCUMENT.send({
          method: "POST",
          path: `/BillingDocument/SAP__self.CreateFromSDDocument`,
          data: APIDetails
        })
        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        logger.info("AR Invoice response:",newResponse);
        return newResponse;

      }



    } catch (error) {

      logger.error(`${constants.AR_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.AR_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })


  /**
  * Service handler for posting Materail Transfer
  * it is the Wrapper API  called from SBPA 
  * URL: /zbuvcm55156/create_MaterialDocTransfer
  */
  this.on('create_MaterialDocTransfer', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.Mt_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const response = await ZAPI_MATERIAL_DOCUMENT_SRV.send({
          method: "POST",
          path: `/A_MaterialDocumentHeader`,
          data: {
            ...APIDetails,
            to_MaterialDocumentItem: APIDetails.to_MaterialDocumentItem?.results || []
          }
        })
        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        logger.info("Material Doc Transfer response:",newResponse);
        return newResponse;
      
      }



    } catch (error) {

      logger.error(`${constants.Mt_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.Mt_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })


  /**
* Service handler for create Batch
* it is the Wrapper API  called from SBPA 
* URL: /zbuvcm55156/create_Batch
*/
  this.on('create_Batch', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

        logger.info(`${constants.Batch_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const filteredPayload = Object.fromEntries(
          Object.entries(APIDetails || {}).filter(([_, value]) =>
            value !== null &&
            value !== undefined &&
            value !== ''
          )
        );

        logger.info(`${constants.Batch_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(filteredPayload));

        const response = await ZSD_BATCH_NUMBER_GENERATION.send({
          method: "POST",
          path: `/BatchGen`,
          data: filteredPayload
        })

        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        logger.info("Create Batch response:",newResponse);

        return newResponse; 
        
      }



    } catch (error) {
      logger.error(`${constants.Batch_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));
      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.Batch_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);

      return errorResponse;



    }
  })


  /**
* Service handler for update Batch Characteristics
* it is the Wrapper API  called from SBPA 
* URL: /zbuvcm55156/update_BatchChar
*/
  this.on('update_BatchChar', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

        logger.info(`${constants.UBatch_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const { Material, BatchIdentifyingPlant, Batch, CharcValue, CharcInternalID, CharcValueDependency, CharcFromNumericValue } = APIDetails;
        const batchPayload = { CharcValue, CharcValueDependency, CharcFromNumericValue }
        const filteredPayload = Object.fromEntries(
          Object.entries(batchPayload || {}).filter(([_, value]) =>
            value !== null &&
            value !== undefined &&
            value !== ''
          )
        );
         
        // const response = await ZAPI_BATCH_SRV.send({
        //   method: "POST",
        //   path: `/BatchCharc(Material='${Material}',BatchIdentifyingPlant='${BatchIdentifyingPlant}',Batch='${Batch}',CharcInternalID='${CharcInternalID}')/to_BatchCharcValue`,
        //   data: filteredPayload
        // })

        const response = await executeWithRetry(() =>
          ZAPI_BATCH_SRV.send({
            method: "POST",
            path: `/BatchCharc(Material='${Material}',BatchIdentifyingPlant='${BatchIdentifyingPlant}',Batch='${Batch}',CharcInternalID='${CharcInternalID}')/to_BatchCharcValue`,
            data: filteredPayload
          }), ID
        );

        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);
        logger.info("Update Batch Characteristics response:", newResponse);

        return newResponse; 
      }



    } catch (error) {

      logger.error(`${constants.UBatch_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.UBatch_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);

      return errorResponse;
    }
  })


  /**
* Service handler for update Batch Manufacturing Date
* it is the Wrapper API  called from SBPA 
* URL: /zbuvcm55156/update_BatchChar
*/
  this.on('update_BatchManuDate', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;
      let response;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

        logger.info(`${constants.UBatchManu_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const { Material, BatchIdentifyingPlant, Batch, ManufactureDate,ShelfLifeExpirationDate } = APIDetails;

         
         

        let getMetaData = await ZAPI_BATCH_SRV.send({
          method: "GET",
          path: `/Batch(Material='${Material}',BatchIdentifyingPlant='${BatchIdentifyingPlant}',Batch='${Batch}')`
        })


        if (getMetaData) {
          response = await ZAPI_BATCH_SRV.send({
            method: "PATCH",
            path: `/Batch(Material='${Material}',BatchIdentifyingPlant='${BatchIdentifyingPlant}',Batch='${Batch}')`,
            data: { "ManufactureDate": convertSAPDateToISO(ManufactureDate),"ShelfLifeExpirationDate":convertSAPDateToISO(ShelfLifeExpirationDate) },
            headers: { "If-Match": getMetaData.$metadata.etag }
          })

          
        }
        const newResponse = wrapperResponseObj(response,constants.wrapperSuccess)
        logger.info("Update Batch Characteristics response:", newResponse);
        return newResponse;
      }



    } catch (error) {

      logger.error(`${constants.UBatchManu_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.UBatchManu_Activity)

      const errorResponse = wrapperResponseObj(response,constants.wrapperError)

      return errorResponse;


      


    }
  })

  /**
* Service handler for update OBD with Batch 
* it is the Wrapper API  called from SBPA 
* URL: /zbuvcm55156/update_OBDBatch
*/
  this.on('update_OBDBatch', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;
      let response = '';

      if (payload) {

        const { ID, wfID, DeliveryDocument, DeliveryDocumentItem, APIDetails } = payload

        logger.info(`${constants.OBDBatch_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        //const {Batch} = APIDetails;

         
         

        let getMetaData = await ZAPI_OUTBOUND_DELIVERY_SRV.send({
          method: "GET",
          path: `/A_OutbDeliveryItem(DeliveryDocument='${DeliveryDocument}',DeliveryDocumentItem='${DeliveryDocumentItem}')`
        })


        if (getMetaData) {
          response = await ZAPI_OUTBOUND_DELIVERY_SRV.send({
            method: "PATCH",
            path: `/A_OutbDeliveryItem(DeliveryDocument='${DeliveryDocument}',DeliveryDocumentItem='${DeliveryDocumentItem}')`,
            data: APIDetails,
            headers: { "If-Match": getMetaData.$metadata.etag }
          })
          // logger.info("Update OBD Batch/Storage Location  response:", response);
        }
        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        logger.info("Update OBD Batch/Storage Location  response:",newResponse);
        return newResponse;

      }



    } catch (error) {

      logger.error(`${constants.OBDBatch_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));
      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.OBDBatch_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })


  this.on('update_OBDHeaders', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;
      let response = '';

      if (payload) {

        const { ID, DeliveryDocument, APIDetails } = payload

        logger.info(`${constants.OBDHeader_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        //const {Batch} = APIDetails;               

        let getMetaData = await ZAPI_OUTBOUND_DELIVERY_SRV.send({
          method: "GET",
          path: `/A_OutbDeliveryHeader(DeliveryDocument='${DeliveryDocument}')`
        })


        if (getMetaData) {
          response = await ZAPI_OUTBOUND_DELIVERY_SRV.send({
            method: "PATCH",
            path: `/A_OutbDeliveryHeader(DeliveryDocument='${DeliveryDocument}')`,
            data: APIDetails,
            headers: { "If-Match": getMetaData.$metadata.etag }
          })
          // logger.info("Update OBD Batch/Storage Location  response:", response);
        }
        const newResponse =  wrapperResponseObj(response,constants.wrapperSuccess);
        logger.info("Update OBD Header  response:",newResponse);
        return newResponse;

      }



    } catch (error) {

      logger.error(`${constants.OBDBatch_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));
      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.OBDBatch_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;

    }
  })



  //     /**
  //   * Service handler for cancel inspection Lot for Remanufacturing Case
  //   * it is the Wrapper API  called from SBPA 
  //   * URL: /zbuvcm55156/cancel_InspectionLot
  //   */
  this.on('cancel_InspectionLot', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.IL_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));


        const response = await ZSD_VCM_INSPECTIONLOTCANCEL.send({
          method: "POST",
          path: `/InspectCancel`,
          data: APIDetails
        })

         if(response && response?.Message && response.Message.trim().toUpperCase() === constants.InspectionLotError){
           throw new Error(`Error  in cancelling Inspection lot for Inspection Lot: ${response?.InspectionLot},Message: ${response.Message}`);
        } 
        const newResponse = wrapperResponseObj(response,constants.wrapperSuccess);
        logger.info("Inspection Lot Cancel response:", newResponse);
         return newResponse;
      }



    } catch (error) {

      logger.error(`${constants.IL_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.IL_Activity)

      const errorResponse = wrapperResponseObj(response,constants.wrapperError);
      return errorResponse;


    }
  })





  /**
   * Service handler for update Purchase Order item
   * it is the Wrapper API  called from SBPA 
   * URL: /zbuvcm55156/update_PurchaseOrderItem
   */
  this.on('update_PurchaseOrderItem', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.UPOItem_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));


        const response = await PURCHASEORDER.send({
          method: "PATCH",
          path: `/PurchaseOrderItem/${APIDetails?.PurchaseOrder}/${APIDetails?.PurchaseOrderItem}`,
          data: { "IsCompletelyDelivered": APIDetails?.IsCompletelyDelivered }
        })
        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);
        logger.info("Update Purchase Order Item response:", newResponse);
        return newResponse;
      }



    } catch (error) {

      logger.error(`${constants.UPOItem_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.UPOItem_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
 
      return errorResponse;

      


    }
  })


  /**
   * Service handler for update Sales Order item
   * it is the Wrapper API  called from SBPA 
   * URL: /zbuvcm55156/A_SalesOrderItem
   */
  this.on('update_SalesOrderItem', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

        logger.info(`${constants.USOItem_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const response = await ZAPI_SALES_ORDER_SRV.send({
          method: "PATCH",
          path: `/A_SalesOrderItem/${APIDetails?.SalesOrder}/${APIDetails?.SalesOrderItem}`,
          data: { "SalesDocumentRjcnReason": APIDetails?.SalesDocumentRjcnReason }
        })
        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);
        logger.info("Update Sales Order Item response:", newResponse);
        return newResponse;
      }

    } catch (error) {

      logger.error(`${constants.USOItem_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.USOItem_Activity)

      let errorResponse = wrapperResponseObj(response, constants.wrapperError);

      return errorResponse;
    }
  })


  /**
    * Service handler for posting OutBound Delivery
    * it is the Wrapper API  called from SBPA 
    * URL: /zbuvcm55156/setPickQuantity
    */
  this.on('setPickQuantity', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.SP_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const deliveryDoc = APIDetails.DeliveryDocument;

        let getMetaData = await ZAPI_OUTBOUND_DELIVERY_SRV.send({
          method: "GET",
          path: `/A_OutbDeliveryHeader(${deliveryDoc})`
        })

        const response = await ZAPI_OUTBOUND_DELIVERY_SRV.send("POST", `/SetPickingQuantityWithBaseQuantity?BaseUnit=${APIDetails?.BaseUnit}&DeliveryDocument=${APIDetails?.DeliveryDocument}&DeliveryDocumentItem=${APIDetails?.DeliveryDocumentItem}&ActualDeliveredQtyInBaseUnit=${APIDetails?.ActualDeliveredQtyInBaseUnit}`, undefined, { "If-Match": getMetaData.$metadata.etag })
        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);
        console.log("setPickQuantity response:", newResponse);
        return newResponse;
      }

    } catch (error) {
      logger.error(`${constants.SP_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));
      console.log(error)
      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.SP_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
 
      return errorResponse;


    }
  })

  
   /**
    * Service handler for pfcCheck
    * it checks the weather the payload has an active Product Flow in PFC application
    * URL: /zbuvcm55156/addTimeout
    */
  this.on('addTimeout',async (req)=>{
    try{
      const {seconds} = req?.data;
      if(seconds){
        const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
        await delay(seconds * 1000);
        return `HOLD successful for ${seconds} seconds!`
      }

    }catch{
      req.error({
        message: error.message,
        status: 400
      });
    }

  })



    /**
   * Service handler for update Purchase Order Account Assignment
   * it is the Wrapper API  called from SBPA 
   * URL: /zbuvcm55156/post_PurchaseOrderAccountAssignment
   */
  this.on('post_PurchaseOrderAccountAssignment', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

         
         

        logger.info(`${constants.UPOACC_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));


        const response = await PURCHASEORDER.send({
          method: "PATCH",
          path: `/PurchaseOrderAccountAssignment/${APIDetails?.PurchaseOrder}/${APIDetails?.PurchaseOrderItem}/${APIDetails?.AccountAssignmentNumber}`,
          data: { "SalesOrder": APIDetails?.SalesOrder,"SalesOrderItem": APIDetails?.SalesOrderItem }
        })
        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);
        logger.info("Update Purchase Order Account Assignment response:", newResponse);
        return newResponse;
      }



    } catch (error) {

      logger.error(`${constants.UPOACC_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.UPOItem_Activity)

      let errorResponse = wrapperResponseObj(response,constants.wrapperError);
 
      return errorResponse;

      


    }
  })


   /**
   * Service handler for post Inbound Delivery
   * it is the Wrapper API  called from SBPA 
   * URL: /zbuvcm55156/post_IBD
   */
  this.on('post_IBD', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {

      const payload = req.data?.Payload;

      const { ID, APIDetails } = payload
      

      if (!payload) {
        throw new Error("Payload is missing in request");
      }

      if (!APIDetails) {
        throw new Error("APIDetails missing in Payload");
      }

      logger.info(`${constants.IBD_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

      const response = await ZAPI_INBOUND_DELIVERY_SRV.tx(req).post("A_InbDeliveryHeader", APIDetails)

      const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);

      return newResponse;

    } catch (error) {
      logger.error(`${constants.IBD_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.IBD_Activity)

      let errorResponse = wrapperResponseObj(response, constants.wrapperError);

      return errorResponse;

    }
  })
  /**
    * Service handler for pfcCheck
    * it checks the weather the payload has an active Product Flow in PFC application
    * URL: /zbuvcm55156/pfcCheck
    */
  this.on('pfcCheck', async req => {
    logger.info('pfcCheck',req.data)
    const global_ID = req?.data.ID;
    const gloabal_wfID = req?.data.wfID;
    try {
      const locale = req.user.locale;
      bundle = textBundle.getTextBundle(locale);
     // const pfcDest = await cds.connect.to("pfcservice");

      return await pfcCall(req,ZSD_VCM_PREREQAPI,ZSD_VCM_PRODUCTFLOW);
      // const pfcDest = await cds.connect.to("pfcservice");

      // const pfcData = await pfcDest.tx(req).get('/zbuvcm47419/getPfcData');
      // const legEntityData = await ZSD_VCM_PREREQAPI.tx(req).get(`/FetchT001K`);

      // const result = await pfcCheck(req, pfcData.value, req.data.InputPayload, ZSD_VCM_PRODUCTFLOW, pfcDest, legEntityData);

      // const invalidItems = result.filter(item => item.PfcCatId === "");

      // if (invalidItems.length > 0) {
      //   throw new Error(`${bundle.getText("pfcMessage")}`)
      // }

    } catch (error) {

      logger.error(`${bundle.getText("pfcLog")} `, error.message);
      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: constants.E
      }

      await updateHeaderErrorTable(req, data, constants.PFC)
      //throw error;
    let errorResponse = {ErrorMessage: error.message,Status:"F"}
     return errorResponse;
      // req.error({
      //   message: error.message,
      //   status: 400
      // });
    }
  });


  /**
    * Service handler for pfcCheck
    * it checks the weather the payload has an active Product Flow in PFC application
    * URL: /zbuvcm55156/pfcCheck
    */
  this.on('pfcCheckPO', async req => {
    let response;
    const global_ID = req?.data.ID;
    const gloabal_wfID = req?.data.wfID;
    try {
      const locale = req.user.locale;
      bundle = textBundle.getTextBundle(locale);
      
      return await pfcCall(req,ZSD_VCM_PREREQAPI,ZSD_VCM_PRODUCTFLOW);
      
    } catch (error) {

      logger.error(`${bundle.getText("pfcLog")} `, error.message);

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: constants.E
      }

      await updateHeaderErrorTable(req, data, constants.PFC)
      let errorResponse;
    //  if(error.message.includes("InActive Due to Date Range Failed") || error.message.includes("InActive Due to Approval Status Failed")|| error.message.includes("InActive Due to Status Not Active")){
    //     errorResponse= {ErrorMessage: error.message,Status:"F",isVCA:true}
    //  }
    //  else{
    //   errorResponse= {ErrorMessage: error.message,Status:"F",isVCA:false}
    //  }
    // Defect JGHJ-94520
      if (error.message.startsWith("Product Flow Catalog ID:")) {
        errorResponse = {
          ErrorMessage: error.message,
          Status: "F",
          isVCA: true
        };
      } else {
        errorResponse = {
          ErrorMessage: error.message,
          Status: "F",
          isVCA: false
        };
      }
      return errorResponse;
    }
  });

  /**
    * Service handler for ScenarioDeterminationCheck
    * it checks the weather the payload has an ScenarioID for a given PFC application
    * URL: /zbuvcm55156/ScenarioCheck
    */
  this.on('ScenarioCheck', async req => {
    logger.info('ScenarioCheck',req.data)
    const global_ID = req?.data.ID;
    const gloabal_wfID = req?.data.wfID;
    try {
      const locale = req.user.locale;
      bundle = textBundle.getTextBundle(locale);
      let { Payload } = req.data;
      const CatalogIDs = [...new Set(Payload.map(item => item.productFlowCatalogID))];
      const pfcDest = await cds.connect.to("pfcservice");

      const sidData = await pfcDest.tx(req).post('/zbuvcm47419/getSId', {
        CatIDList: CatalogIDs
      });

      let scenariotype;

      if(Payload[0].PlantType && (Payload[0].doctype && Payload[0].doctype==="PO")){ // LOGIC FOR PO PUSH PULL CASE
        if(Payload[0].PlantType === constants.Physical){
          scenariotype = constants.pull
        }else if(Payload[0].PlantType === constants.Virtual){
          scenariotype = constants.push
        }
      }else if(Payload[0]?.doctype && Payload[0]?.doctype==="SO"){ // LOGIC FOR EXISTING SO AT CASE
         scenariotype = constants.AT
      }


      const outputPayload = await formatSidOutputPayload(sidData?.value, Payload);
      const steps = await pfcDest.tx(req).post('/zbuvcm55151/ScenarioDeterminationAPI', {
        Catid: outputPayload[0].productFlowCatalogID,
        SId: outputPayload[0].SID,
        typeOfOrder: Payload[0].doctype,
        Scenario: scenariotype
      });
      const invalidItems = outputPayload.filter(item => item.SID === "");


      if (invalidItems.length > 0 || (Array.isArray(steps?.value) && steps?.value.length === 0)) {
        throw new Error(`${bundle.getText("scenarioMessage")}`)
      }

      let result = outputPayload.map(entry => ({
        productFlowCatalogID: entry.productFlowCatalogID,
        SID: entry.SID || "",  // fallback null if no match
        shippingReqNo: entry.shippingReqNo,
        initialDocumentNo: entry.initialDocumentNo,
        Status:"S",
        steps: steps.value
      }));
      return result;

    } catch (err) {
      logger.error(`${bundle.getText("scenarioLog")}`, err.message);

       const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: err.message,
        errorStatus: constants.E
      }

    await updateHeaderErrorTable(req, data, constants.SC)

    let errorResponse = {ErrorMessage: err.message,Status:"F"}
     return errorResponse;
      // req.error({
      //   message: err.message,
      //   status: 400
      // });
    }
  });

  this.on('READ', 'Batch', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_BATCH_SRV,
      activity: constants.Batch_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on('READ', 'A_InbDeliveryHeader', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_INBOUND_DELIVERY_SRV,
      activity: constants.InbDeliveryHeader_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  // JGHJ-87133
  this.on(['READ','UPDATE'], 'A_OutbDeliveryHeader', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_OUTBOUND_DELIVERY_SRV,
      activity: constants.OutbDeliveryHeader_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });


  this.on('READ', 'A_MaterialDocumentHeader', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_MATERIAL_DOCUMENT_SRV,
      activity: constants.MaterialDocumentHeader_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on('READ', 'A_MaterialDocumentItem', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_MATERIAL_DOCUMENT_SRV,
      activity: constants.MaterialDocumentItem_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'CquenceDetails', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZSD_LOGIST_DEL_109,
      activity: constants.CquenceDetails_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'A_SalesOrder', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_SALES_ORDER_SRV,
      activity: constants.SalesOrder_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on(['READ','UPDATE'], 'A_SalesOrderItem', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_SALES_ORDER_SRV,
      activity: constants.SalesOrderItem_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      queueID: req.headers?.queueid,
      orchrestration
    });
  });

    this.on('READ', 'A_SalesOrderHeaderPartner', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_SALES_ORDER_SRV,
      activity: constants.SalesOrderHeaderPartner_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'A_SalesOrderWithoutCharge', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_SALES_ORDER_WITHOUT_CHARGE_SRV,
      activity: constants.SalesOrderWithoutCharge_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'A_SlsOrdWthoutChrgPartner', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_SALES_ORDER_WITHOUT_CHARGE_SRV,
      activity: constants.SlsOrdWthoutChrgPartner_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on('READ', 'A_SuplrInvcItemPurOrdRef', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_SUPPLIERINVOICE_PROCESS_SRV,
      activity: constants.SuplrInvcItemPurOrdRef_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'A_InspectionLot', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_INSPECTIONLOT_SRV,
      activity: constants.InspectionLot_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'A_InspLotUsageDecision', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_INSPECTIONLOT_SRV,
      activity: constants.InspLotUsageDecision_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'A_PurchasingInfoRecord', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_INFORECORD_PROCESS_SRV,
      activity: constants.PurchasingInfoRecord_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'A_PurgInfoRecdOrgPlantData', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_INFORECORD_PROCESS_SRV,
      activity: constants.PurgInfoRecdOrgPlantData_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'FetchT001WANDADRC', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZSD_VCM_AUTOMATION_FIN_SCN1,
      activity: constants.FetchT001WANDADRC_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      queueID: req.headers?.queueid,
      orchrestration
    });
  });

    this.on('READ', 'FetchLFA1', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZSD_VCM_AUTOMATION_FIN_SCN1,
      activity: constants.FetchLFA1_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      queueID: req.headers?.queueid,
      orchrestration
    });
  });

    this.on('READ', 'FetchT001K', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZSD_VCM_AUTOMATION_FIN_SCN1,
      activity: constants.FetchT001K_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'A_PurchasingSource', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_PURCHASING_SOURCE_SRV,
      activity: constants.PurchasingSource_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      queueID: req.headers?.queueid,
      orchrestration
    });
  });

    this.on('READ', 'A_ClfnCharacteristicForKeyDate', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_CLFN_CHARACTERISTIC_SRV,
      activity: constants.ClfnCharacteristicForKeyDate_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });


    this.on('READ', 'BillingDocument', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: BILLINGDOCUMENT,
      activity: constants.BillingDocument_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'BillingDocumentItem', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: BILLINGDOCUMENT,
      activity: constants.BillingDocumentItem_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

   this.on('READ', 'A_OutbDeliveryItem', async (req) => {
     return await readProxyWithErrorHandling({
       req,
       srv: ZAPI_OUTBOUND_DELIVERY_SRV,
       activity: constants.OutbDeliveryItem_Activity,
       id: req.headers?.id,
       wfID: req.headers?.wfid,
       orchrestration
     });
   });


  this.on('READ', 'A_PurchaseContractItem', async (req) => {

    function getFilterValue(where = [], field) {
      for (let i = 0; i < where.length; i++) {
        if (where[i]?.ref?.[0] === field && where[i + 1] === '=' && where[i + 2]?.val !== undefined) {
          return where[i + 2].val;
        }
      }
      return undefined;
    }

    //JGHJ-92327: Filter parameter checks start
    logger.info("Inside A_PurchaseContractItem READ", req);
    logger.info("A_PurchaseContractItem Request Query", req?.query);
    const PurchaseContract = req.data?.PurchaseContract ?? req.params?.[0]?.PurchaseContract;
    const PurchaseContractItem = req.data?.PurchaseContractItem ?? req.params?.[0]?.PurchaseContractItem;
    logger.info("Inside A_PurchaseContractItem READ - PurchaseContract:", PurchaseContract);
    logger.info("Inside A_PurchaseContractItem READ - PurchaseContractItem:", PurchaseContractItem);

    if (
      !PurchaseContract?.trim() ||
      !PurchaseContractItem?.trim() ||
      PurchaseContract.includes('{') ||
      PurchaseContract.includes('}') ||
      PurchaseContractItem.includes('{') ||
      PurchaseContractItem.includes('}')
    ) {
      try {
        const where = req.query.SELECT?.where || [];
        const PurchaseContract = getFilterValue(where, 'PurchaseContract');
        const PurchaseContractItem = getFilterValue(where, 'PurchaseContractItem');

        if (!PurchaseContract && !PurchaseContractItem) {
          const message = constants.apiPurchaseContractItem;
          const error = new Error(message);
          error.statusCode = 500;
          const data = {
            ID: req.headers?.id,
            wfInstanceId: req.headers?.wfid,
            errorDescription: message,
            errorStatus: 500
          };
        await updateErrorTable(req, data, error);
        await sendMail(req, error, data, orchrestration, constants.Mt_Activity);
        return wrapperResponseObj(error, constants.wrapperError);
        }
      
      } catch (error) {
        logger.error(`Error while handling missing filters for ID: ${req.headers?.id} wfID: ${req.headers?.wfid} - `, error.message);
        return wrapperResponseObj(error, constants.wrapperError);
      }
    }
    //JGHJ-92327: Filter parameter checks end
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_PURCHASECONTRACT_PROCESS_SRV,
      activity: constants.PurchaseContractItem_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      queueID: req.headers?.queueid,
      orchrestration
    });
  });

  this.on(['READ','UPDATE'], 'PurchaseOrder', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: PURCHASEORDER,
      activity: constants.PurchaseOrder_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on(['READ','UPDATE','DELETE'], 'PurchaseOrderItem', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: PURCHASEORDER,
      activity: constants.PurchaseOrderItem_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      queueID: req.headers?.queueid,
      orchrestration
    });
  });

  this.on('READ', 'FetchT001W', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZSD_VCM_PO_TRIGGERS,
      activity: "GET CALL FetchT001W",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on('READ', 'FetchKNA1', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZSD_VCM_PO_TRIGGERS,
      activity: "GET CALL FetchKNA1",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on('READ', 'FetchADRC', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZSD_VCM_PO_TRIGGERS,
      activity: "GET CALL FetchKNA1",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on('READ', 'A_InbDeliveryItem', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_INBOUND_DELIVERY_SRV,
      activity: "GET CALL for InboundDeliveryItem",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on('READ', 'A_PurCtrPartners', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_PURCHASECONTRACT_PROCESS_SRV,
      activity: "GET CALL for A_PurCtrPartners",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'knvp', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZSD_VCM_AUTOMATIONFLW,
      activity: "GET CALL for knvp",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'CustomertoBP', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZSD_VCM_AUTOMATIONFLW,
      activity: "GET CALL for CustomertoBP",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

    this.on('READ', 'A_BusinessPartner', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_BUSINESS_PARTNER,
      activity: "GET CALL for A_BusinessPartner",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  // CR JIRA  JGHJ-87133 -- START ---

  this.on('READ', 'A_PurchaseContract', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_PURCHASECONTRACT_PROCESS_SRV,
      activity: "GET CALL for A_PurchaseContract",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on(['READ', 'PATCH'], 'A_SalesOrderScheduleLine', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_SALES_ORDER_SRV,
      activity: "GET CALL for A_SalesOrderScheduleLine",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      queueID: req.headers?.queueid,
      orchrestration
    });
  });

  this.on('READ', 'A_CustomerSalesArea', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_BUSINESS_PARTNER,
      activity: "GET CALL for A_CustomerSalesArea",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on(['READ', 'PATCH'], 'PurchaseOrderScheduleLine', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: PURCHASEORDER,
      activity: "GET CALL for PurchaseOrderScheduleLine",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      queueID: req.headers?.queueid,
      orchrestration
    });
  });
  // CR JIRA  JGHJ-87133 -- END ---

  this.on('READ', 'A_SupplierInvoice', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_SUPPLIERINVOICE_PROCESS_SRV,
      activity: "GET CALL for A_SupplierInvoice",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  this.on('READ', 'A_SalesOrderItemPrElement', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_SALES_ORDER_SRV,
      activity: "GET CALL for A_SalesOrderItemPrElement",
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });


   /**
     * Service handler for legacy SO update
     * it is the Wrapper API  called from Interface to update Legacy SO 
     * URL: /zbuvcm55156/post_LegacySalesOrder
     */
  this.on('post_LegacySalesOrder', async (req) => {
    const payload = req?.data
    let global_ID;
    const gloabal_wfID = req?.data.wfID;
    logger.info('Line 2211, Workflow Instance ID value:', gloabal_wfID);
    const tx = cds.tx(req)
    try {

      if (payload) {
        await tx.begin();
        const { reference_Po } = payload
        const getEntity1 = await tx.run(SELECT.one.from(syn_ShippingRequestEntityDocs).where({ documentNumber: reference_Po }));

        const getEntity = await tx.run(SELECT.one.from(syn_ShippingRequestEntityDocs).where({ stepID: 'L_ICSO', parent_ID: getEntity1?.parent_ID }));

        global_ID = getEntity?.ID;
        
        if (!payload.wfID) {
          throw new Error('Workflow ID (wfID) is mandatory but was not provided in the payload');
        }

        logger.info(`post_LegacySalesOrder Payload: `, JSON.stringify(payload));

        const result = await updateLegacySo(req, payload, tx, PURCHASEORDER, getEntity1);

        const newResponse = wrapperResponseObj(result, constants.wrapperSuccess);
        logger.info("Post Legacy Sales Order response:", newResponse);

        return newResponse;

      }
    } catch (error) {

      logger.error(`post_LegacySalesOrder failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, "Legacy Sales Order Update Failed")

      let errorResponse = wrapperResponseObj({}, constants.wrapperError);

      return errorResponse;
    }
  })


  // ---- CR - JGHJ-89833 -- START
  /**
    * Service handler for PickOneItemWithSalesQuantity
    * it is the Wrapper API  called from SBPA to PickOneItemWithSalesQuantity
    * URL: /zbuvcm55156/post_PickOneItemWithSalesQuantity
    */
  this.on('post_PickOneItemWithSalesQuantity', async (req) => {
    const global_ID = req?.data.Payload.ID;
    const gloabal_wfID = req?.data.Payload.wfID;
    try {
      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

        logger.info(`${constants.Pick_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));

        const deliveryDoc = APIDetails.DeliveryDocument;

        let getMetaData = await ZAPI_OUTBOUND_DELIVERY_SRV.send({
          method: "GET",
          path: `/A_OutbDeliveryHeader('${deliveryDoc}')`
        })

        const response = await ZAPI_OUTBOUND_DELIVERY_SRV.send("POST", `/PickOneItemWithSalesQuantity?DeliveryDocument='${APIDetails?.DeliveryDocument}'&DeliveryDocumentItem='${APIDetails?.DeliveryDocumentItem}'&ActualDeliveryQuantity=${APIDetails?.ActualDeliveryQuantity}&DeliveryQuantityUnit='${APIDetails?.DeliveryQuantityUnit}'`, undefined, { "If-Match": getMetaData.$metadata.etag })
        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);
        console.log("PickOneItemWithSalesQuantityPayload response:", newResponse);
        return newResponse;
      }

    } catch (error) {
      logger.error(`${constants.SP_Activity} failed for EntityDocumentID: ${global_ID} `, JSON.stringify(error));
      console.log(error)
      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.Pick_Activity)

      let errorResponse = wrapperResponseObj(response, constants.wrapperError);

      return errorResponse;


    }
  })
  // ---- CR - JGHJ-89833 -- END

  // --------- JGHJ-102853: Update Batch Characteristic Valualtion Wrapper API -- START

  /**
   * Service handler for Update Batch Characteristic Value
   * Wrapper API called from SBPA
   * URL: /zbuvcm55156/update_BatchCharValue
   */
  this.on("update_BatchCharValue", async (req) => {

    const global_ID = req?.data?.Payload?.ID;
    const global_wfID = req?.data?.Payload?.wfID;

    try {

      const payload = req.data?.Payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload;

        logger.info(
          `${constants.UBatchCharValue_Activity} Payload for Entity Document ${ID}: ${JSON.stringify(payload)}`
        );

        const data = {
          CharcValueDependency: APIDetails.CharcValueDependency
        };

        // Add CharcValue only if it has a non-empty value
        if (
          APIDetails.CharcValue !== undefined &&
          APIDetails.CharcValue !== null &&
          APIDetails.CharcValue.trim() !== ""
        ) {
          data.CharcValue = APIDetails.CharcValue;
        }

        // Add CharcFromNumericValue only if it has a value
        if (
          APIDetails.CharcFromNumericValue !== undefined &&
          APIDetails.CharcFromNumericValue !== null &&
          APIDetails.CharcFromNumericValue !== ""
        ) {
          data.CharcFromNumericValue = APIDetails.CharcFromNumericValue;
        }

        //Add CharcFromDecimalValue only if it has a value
        if (
          APIDetails.CharcFromDecimalValue !== undefined &&
          APIDetails.CharcFromDecimalValue !== null &&
          APIDetails.CharcFromDecimalValue !== ""
        ) {
          data.CharcFromDecimalValue = APIDetails.CharcFromDecimalValue;
        }

        const response = await ZAPI_BATCH_SRV.send({
          method: "PATCH",
          path: `/BatchCharcValue(Material='${APIDetails.Material}',BatchIdentifyingPlant='${APIDetails.BatchIdentifyingPlant}',Batch='${APIDetails.Batch}',CharcInternalID='${APIDetails.CharcInternalID}',CharcValuePositionNumber='${APIDetails.CharcValuePositionNumber}')`,
          data,
          headers: {
            "If-Match": "*"
          }
        });

        const newResponse = wrapperResponseObj(
          response,
          constants.wrapperSuccess
        );

        logger.info(
          "Update Batch Characteristic Value response:",
          newResponse
        );

        return newResponse;
      }

    } catch (error) {

      logger.error(
        `${constants.UBatchCharValue_Activity} failed for EntityDocumentID: ${global_ID}`,
        JSON.stringify(error)
      );

      const data = {
        ID: global_ID,
        wfInstanceId: global_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      };

      await updateErrorTable(req, data, error);

      await sendMail(
        req,
        error,
        data,
        orchrestration,
        constants.UBatchCharValue_Activity
      );

      const errorResponse = wrapperResponseObj(response, constants.wrapperError);

      return errorResponse;
    }

  });

  this.on('READ', 'BatchCharcValue', async (req) => {
    return await readProxyWithErrorHandling({
      req,
      srv: ZAPI_BATCH_SRV,
      activity: constants.BatchCharValue_Activity,
      id: req.headers?.id,
      wfID: req.headers?.wfid,
      orchrestration
    });
  });

  // --------- JGHJ-102853: Update Batch Characteristic Valualtion Wrapper API -- END

  this.on('PfcCheckForLineItem', async (req) => {

    const { APIDetails, ID: global_ID, wfID: gloabal_wfID, QueueId } = req.data.payload || {};
    logger.info(`PfcCheckForLineItem invoked - global_ID line 2403: ${global_ID}, QueueId: ${QueueId}, wfID: ${gloabal_wfID}`);

     try {
      const locale = req.user.locale;
      bundle = textBundle.getTextBundle(locale);
      const pfcDest = await cds.connect.to("pfcservice");
      let { material, materialBrand, catalogId,item } = APIDetails;

      const queueRowPfc = await SELECT.one.from('JNJ_COM_ZBUVCM55156_SYN_SHIPPINGREQUESTQUEUE').where({ ID: QueueId });
      const parentPOPfc = queueRowPfc?.PARENTPO ?? queueRowPfc?.parentPO;
      const srPfc = parentPOPfc
        ? await SELECT.one.from(syn_ShippingRequest).columns('shipFromBusinessPartner', 'shipToBusinessPartner').where({ initialDocumentNo: parentPOPfc })
        : null;
      logger.info(`PfcCheckForLineItem BPs - BpSFrom: ${srPfc?.shipFromBusinessPartner}, BpSTo: ${srPfc?.shipToBusinessPartner}, catalogId: ${catalogId}`);

       let InputPayload = [
         {
           BpSFrom: srPfc?.shipFromBusinessPartner,
           BpSTo: srPfc?.shipToBusinessPartner,
           MatBrand: materialBrand,
           Matnr: material
         }
       ]

      req.data.InputPayload = InputPayload;

    let pfc=  await pfcCall(req,ZSD_VCM_PREREQAPI,ZSD_VCM_PRODUCTFLOW);

    if(pfc && pfc[0].PfcCatId===catalogId){
      return pfc
    }else{
      throw new Error(`Material ${material} with Material Brand ${materialBrand} found in catalog ${pfc?.[0]?.PfcCatId} but expected catalog ${catalogId}`);
    }
      
    } catch (error) {

      logger.error(`${bundle.getText("pfcLog")} `, error.message);

       const data = {
         ID: global_ID,
         wfInstanceId: gloabal_wfID,
         errorDescription: error.message,
         errorStatus: constants.E
       }
       if (QueueId) {
         await updateQueueErrorTable(req, data, error, QueueId,constants.PFC)
         const tx = cds.tx();
         await tx.begin();
         const queueRow3 = await tx.run(SELECT.one.from('JNJ_COM_ZBUVCM55156_SYN_SHIPPINGREQUESTQUEUE').where({ ID: QueueId }));
         const parentPO3 = queueRow3?.PARENTPO ?? queueRow3?.parentPO;
         logger.info(`PfcCheckForLineItem Req2 UPDATE - QueueId: ${QueueId}, parentPO: ${parentPO3}`);
         if (parentPO3) {
           const sr3 = await tx.run(SELECT.one.from(syn_ShippingRequest).columns('ID').where({ initialDocumentNo: parentPO3 }));
           if (sr3?.ID) {
             const ts3 = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
             await tx.run(UPDATE(syn_ShippingRequest).set({
               pfcCheckErrorDescription: 'PO change triggered & partial successful. Please check change events tab for further details. (' + ts3 + ')',
               pfcCheckErrorCreationDate: new Date()
             }).where({ ID: sr3.ID }));
           }
         }
         await tx.commit();
       } else {
         await updateHeaderErrorTable(req, data, constants.PFC)
       }




     let errorResponse = {ErrorMessage: error.message,Status:"F"}
     return errorResponse;
    }
  });


  this.on('create_PurchaseOrderLineItem', async (req) => {
    const payload = req.data.payload;
    const { ID, wfID, APIDetails, QueueId } = payload
    try {

      if (payload) {

        logger.info(`${constants.PO_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(APIDetails));

        const response = await PURCHASEORDER.send({
          method: "POST",
          path: `/PurchaseOrder/${APIDetails.PurchaseOrder}/_PurchaseOrderItem`,
          data: APIDetails
        });
        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);
        return newResponse;

      }


    } catch (error) {
      logger.error(`create_PurchaseOrderLineItem failed for EntityDocumentID: ${ID} `, JSON.stringify(error));

      const data = {
        ID: ID,
        wfInstanceId: wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      if (QueueId) {
        await updateQueueErrorTable(req, data, error, QueueId)
        const OmService = await cds.connect.to("VCM_ORDERMONITORING_CAP")
        let op = await OmService.post('/zbuvcm55155/QueueInError', { queueId: QueueId })
        logger.info(`Response from VCM_ORDERMONITORING_CAP: ${JSON.stringify(op)}`)
      } else {
        await updateErrorTable(req, data, error);
      }
      await sendMail(req, error, data, orchrestration, constants.PO_Activity);

      let errorResponse = wrapperResponseObj(response, constants.wrapperError);
      return errorResponse;

    }
  })

  this.on('create_SalesOrderLineItem', async (req) => {
    const payload = req.data.payload;
    const { ID, wfID, APIDetails,QueueId } = payload
    try {

      if (payload) {

        logger.info(`${constants.PO_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(APIDetails));

        let data = { ...APIDetails }

        delete data.SalesOrder


        const response = await ZAPI_SALES_ORDER_SRV.send({
          method: "POST",
          path: `/A_SalesOrder('${APIDetails?.SalesOrder}')/to_Item`,
          data: data
        });
        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);
        return newResponse;

      }


    } catch (error) {
      logger.error(`create_PurchaseOrderLineItem failed for EntityDocumentID: ${ID} `, JSON.stringify(error));

      const data = {
        ID: ID,
        wfInstanceId: wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      if (QueueId) {
        await updateQueueErrorTable(req, data, error, QueueId)
        const OmService = await cds.connect.to("VCM_ORDERMONITORING_CAP")
        logger.info(`create_PurchaseOrderLineItem QueueInError triggered for PO: ${APIDetails?.PurchaseOrder} and Item: ${APIDetails?.PurchaseOrderItem}`)
        let op = await OmService.post('/zbuvcm55155/QueueInError', { queueId: QueueId })
        logger.info(`Response from VCM_ORDERMONITORING_CAP: ${JSON.stringify(op)}`)
      } else {
        await updateErrorTable(req, data, error);
      }

      await sendMail(req, error, data, orchrestration, constants.PO_Activity);

      let errorResponse = wrapperResponseObj(response, constants.wrapperError);
      return errorResponse;

    }
  })

  // JGHJ-87133
  this.on('create_BatchSplitItemOutbDelivery', async (req) => {
    const global_ID = req?.data.payload.ID;
    const gloabal_wfID = req?.data.payload.wfID;
    try {
      const payload = req.data?.payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

        logger.info(`${constants.OBD_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));
        const deliveryDoc = APIDetails.DeliveryDocument;
        let getMetaData = await ZAPI_OUTBOUND_DELIVERY_SRV.send({
          method: "GET",
          path: `/A_OutbDeliveryHeader('${deliveryDoc}')`
        })

        let query = `/CreateBatchSplitItem?Batch='${APIDetails.Batch}'&DeliveryDocument='${APIDetails.DeliveryDocument}'&DeliveryDocumentItem='${APIDetails.DeliveryDocumentItem}'&DeliveryQuantityUnit='${APIDetails.DeliveryQuantityUnit}'&ActualDeliveryQuantity=${APIDetails.ActualDeliveryQuantity}`

        let response = await ZAPI_OUTBOUND_DELIVERY_SRV.send({
          method: "POST",
          path: query,
          headers: { "If-Match": getMetaData.$metadata.etag }
        })

        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);

        return newResponse;
      }

    } catch (error) {

      logger.error(`${constants.OBD_Activity} failed from EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.OBD_Activity)

      let errorResponse = wrapperResponseObj(response, constants.wrapperError);
      return errorResponse;

    }
  })


   // JGHJ-87133
  this.on('create_BatchSplitItemInbDelivery', async (req) => {
    const global_ID = req?.data.payload.ID;
    const gloabal_wfID = req?.data.payload.wfID;
    try {
      const payload = req.data?.payload;

      if (payload) {

        const { ID, wfID, APIDetails } = payload

        logger.info(`${constants.IBD_Activity} Payload for Entity Document ${ID}: `, JSON.stringify(payload));
        const deliveryDoc = APIDetails.DeliveryDocument;


         let getMetaData = await ZAPI_INBOUND_DELIVERY_SRV.send({
          method: "GET",
          path: `/A_InbDeliveryHeader('${deliveryDoc}')`
        })

       let query = `/CreateBatchSplitItem?Batch='${APIDetails.Batch}'&DeliveryDocument='${APIDetails.DeliveryDocument}'&DeliveryDocumentItem='${APIDetails.DeliveryDocumentItem}'&DeliveryQuantityUnit='${APIDetails.DeliveryQuantityUnit}'&ActualDeliveryQuantity=${APIDetails.ActualDeliveryQuantity}&BatchBySupplier='${APIDetails.BatchBySupplier}'`;
        let response = await ZAPI_INBOUND_DELIVERY_SRV.send({
          method: "POST",
          path: query,
          headers: { "If-Match": getMetaData.$metadata.etag }
        })

        const newResponse = wrapperResponseObj(response, constants.wrapperSuccess);

        return newResponse;
      }

    } catch (error) {

      logger.error(`${constants.OBD_Activity} failed from EntityDocumentID: ${global_ID} `, JSON.stringify(error));

      const data = {
        ID: global_ID,
        wfInstanceId: gloabal_wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      }
      await updateErrorTable(req, data, error)

      await sendMail(req, error, data, orchrestration, constants.OBD_Activity)

      let errorResponse = wrapperResponseObj(response, constants.wrapperError);
      return errorResponse;

    }
  })

})

