/* checksum : 6eda45a10b14f101d967bb759f451eeb */
@cds.external : true
@Aggregation.ApplySupported.Transformations : [ 'aggregate', 'groupby', 'filter' ]
@Aggregation.ApplySupported.Rollup : #None
@Common.ApplyMultiUnitBehaviorForSortingAndFiltering : true
@Capabilities.FilterFunctions : [
  'eq',
  'ne',
  'gt',
  'ge',
  'lt',
  'le',
  'and',
  'or',
  'contains',
  'startswith',
  'endswith',
  'any',
  'all'
]
@Capabilities.SupportedFormats : [ 'application/json', 'application/pdf' ]
@PDF.Features.DocumentDescriptionReference : '../../../../default/iwbep/common/0001/$metadata'
@PDF.Features.DocumentDescriptionCollection : 'MyDocumentDescriptions'
@PDF.Features.ArchiveFormat : true
@PDF.Features.Border : true
@PDF.Features.CoverPage : true
@PDF.Features.FitToPage : true
@PDF.Features.FontName : true
@PDF.Features.FontSize : true
@PDF.Features.Margin : true
@PDF.Features.Padding : true
@PDF.Features.Signature : true
@PDF.Features.HeaderFooter : true
@PDF.Features.ResultSizeDefault : 20000
@PDF.Features.ResultSizeMaximum : 20000
@Capabilities.KeyAsSegmentSupported : true
@Capabilities.AsynchronousRequestsSupported : true
service ZSD_VCM_POUNCANCELLATION0001 {
  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Custom entity for PO uncancellation'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.ReadRestrictions.Readable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity POUNCANCEL {
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Purchasing Document'
    @Common.Heading : 'Pur. Doc.'
    @Common.QuickInfo : 'Purchasing Document Number'
    key PurchaseOrder : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Item'
    @Common.QuickInfo : 'Item Number of Purchasing Document'
    PurchaseOrderItem : String(5) not null;
    PurchaseOrderDeletionCode : String(1) not null;
    messageText : String(255) not null;
  };
};

