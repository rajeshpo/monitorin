/* checksum : e030afbdca701c97359d1846d52102d1 */
@cds.external : true
@Aggregation.ApplySupported.Transformations : [ 'aggregate', 'groupby', 'filter' ]
@Aggregation.ApplySupported.Rollup : #None
@Common.ApplyMultiUnitBehaviorForSortingAndFiltering : true
@Capabilities.FilterFunctions : [
  'eq',
  'ne',
  'gt',
  'ge',
  'lt',
  'le',
  'and',
  'or',
  'contains',
  'startswith',
  'endswith',
  'any',
  'all'
]
@Capabilities.SupportedFormats : [ 'application/json', 'application/pdf' ]
@PDF.Features.DocumentDescriptionReference : '../../../../default/iwbep/common/0001/$metadata'
@PDF.Features.DocumentDescriptionCollection : 'MyDocumentDescriptions'
@PDF.Features.ArchiveFormat : true
@PDF.Features.Border : true
@PDF.Features.CoverPage : true
@PDF.Features.FitToPage : true
@PDF.Features.FontName : true
@PDF.Features.FontSize : true
@PDF.Features.Margin : true
@PDF.Features.Padding : true
@PDF.Features.Signature : true
@PDF.Features.HeaderFooter : true
@PDF.Features.ResultSizeDefault : 20000
@PDF.Features.ResultSizeMaximum : 20000
@Capabilities.KeyAsSegmentSupported : true
@Capabilities.AsynchronousRequestsSupported : true
service ZSD_VCM_AUTOMATIONFLW {
  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Custom cds to get BP from Customer'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity CustomertoBP {
    @Common.Label : 'BP GUID'
    @Common.Heading : 'Business Partner GUID'
    @Common.QuickInfo : 'Business Partner GUID'
    key BusinessPartnerUUID : UUID not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer'
    @Common.QuickInfo : 'Customer Number'
    Customer : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Business Partner'
    @Common.QuickInfo : 'Business Partner Number'
    BusinessPartner : String(10) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Custom service for KNVP table'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity knvp {
    @Common.IsUpperCase : true
    @Common.Label : 'Customer'
    @Common.QuickInfo : 'Customer Number'
    key Customer : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Organization'
    @Common.Heading : 'SOrg.'
    key SalesOrganization : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Distribution Channel'
    @Common.Heading : 'DChl'
    key DistributionChannel : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Division'
    @Common.Heading : 'Dv'
    key Division : String(2) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Partner counter'
    @Common.Heading : 'ParC'
    key PartnerCounter : String(3) not null;
    key PartnerFunction : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Partner Type'
    @Common.Heading : 'NoTy.'
    @Common.QuickInfo : 'Type of partner number'
    PartnerFunctionType : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier'
    @Common.QuickInfo : 'Account Number of Supplier'
    BPCustomerNumber : String(10) not null;
    @Common.Label : 'Partner description'
    @Common.Heading : 'Part'
    @Common.QuickInfo : 'Customer description of partner (plant, storage location)'
    CustomerPartnerDescription : String(30) not null;
    @Common.Label : 'Default Partner'
    @Common.Heading : 'D'
    DefaultPartner : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier'
    @Common.QuickInfo : 'Account Number of Supplier'
    Supplier : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Personnel Number'
    @Common.Heading : 'Pers.No.'
    PersonnelNumber : String(8) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Contact Person'
    @Common.Heading : 'Partner'
    @Common.QuickInfo : 'Number of Contact Person'
    ContactPerson : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address Number'
    @Common.Heading : 'Business Partner Address Number (from BUT020)'
    @Common.QuickInfo : 'Business Partner Address Number (from BUT020)'
    AddressID : String(10) not null;
  };
};

