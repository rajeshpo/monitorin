/* checksum : e4cceda333c0bb37dfd81a937e8ff080 */
@cds.external : true
@Aggregation.ApplySupported : { Transformations: [ 'aggregate', 'groupby', 'filter' ], Rollup: #None }
@Common.ApplyMultiUnitBehaviorForSortingAndFiltering : true
@Capabilities.FilterFunctions : [
  'eq',
  'ne',
  'gt',
  'ge',
  'lt',
  'le',
  'and',
  'or',
  'contains',
  'startswith',
  'endswith',
  'any',
  'all'
]
@Capabilities.SupportedFormats : [ 'application/json', 'application/pdf' ]
@PDF.Features : {
  DocumentDescriptionReference: '../../../../default/iwbep/common/0001/$metadata',
  DocumentDescriptionCollection: 'MyDocumentDescriptions',
  ArchiveFormat: true,
  Border: true,
  CoverPage: true,
  FitToPage: true,
  FontName: true,
  FontSize: true,
  Margin: true,
  Padding: true,
  Signature: true,
  HeaderFooter: true,
  ResultSizeDefault: 20000,
  ResultSizeMaximum: 20000
}
@Capabilities.KeyAsSegmentSupported : true
@Capabilities.AsynchronousRequestsSupported : true
service ZSD_VCM_PRODUCTFLOW {
  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Material type value help'
  @Capabilities.SearchRestrictions.Searchable : true
  @Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity MaterialType {
    @Common.Text : ProductType
    @Common.IsUpperCase : true
    @Common.Label : 'Product Type'
    @Common.Heading : 'PTyp'
    key ProductType : String(4) not null;
  };

  @cds.external : true
  type MaterialValidateCbAControl {
    @Common.Label : 'Dynamic CbA-Control'
    @Common.Heading : 'Dynamic Create by Association Control'
    @Common.QuickInfo : 'Dynamic Create via Association Control Property'
    _header : Boolean not null;
  };

  @cds.external : true
  type EntityControl {
    @Common.Label : 'Dyn. Method Control'
    @Common.Heading : 'Dynamic Method Control'
    @Common.QuickInfo : 'Dynamic Method Property'
    Deletable : Boolean not null;
    @Common.Label : 'Dyn. Method Control'
    @Common.Heading : 'Dynamic Method Control'
    @Common.QuickInfo : 'Dynamic Method Property'
    Updatable : Boolean not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Business partner'
  @Capabilities.SearchRestrictions.Searchable : true
  @Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity BusinessPartner {
    @Common.Text : BusinessPartner
    @Common.IsUpperCase : true
    @Common.Label : 'Business Partner'
    @Common.QuickInfo : 'Business Partner Number'
    key BusinessPartner : String(10) not null;
    @Common.Text : BusinessPartnerName
    BusinessPartnerName : String(81) not null;
    @Common.Text : Plant
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    Plant : String(4) not null;
    @Common.Text : Type
    Type : String(1) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'country key based on plant'
  @Capabilities.SearchRestrictions.Searchable : true
  @Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity countrybpkey {
    @Common.Text : BusinessPartner
    @Common.IsUpperCase : true
    @Common.Label : 'Business Partner'
    @Common.QuickInfo : 'Business Partner Number'
    key BusinessPartner : String(10) not null;
    @Common.Text : BusinessPartnerName
    BusinessPartnerName : String(81) not null;
    @Common.Text : Country
    @Common.IsUpperCase : true
    @Common.Label : 'Country/Region Key'
    Country : String(3) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'country key based on plant'
  @Capabilities.SearchRestrictions.Searchable : true
  @Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity countryplantkey {
    @Common.Text : Plant
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    key Plant : String(4) not null;
    @Common.Text : PlantName
    @Common.Label : 'Plant Name'
    PlantName : String(30) not null;
    @Common.Text : Country
    @Common.IsUpperCase : true
    @Common.Label : 'Country/Region Key'
    @Common.Heading : 'C/R'
    Country : String(3) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Business partner'
  @Capabilities.SearchRestrictions.Searchable : true
  @Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity Massbpplantcntrykey {
    @Common.Text : BusinessPartner
    @Common.IsUpperCase : true
    @Common.Label : 'Business Partner'
    @Common.QuickInfo : 'Business Partner Number'
    key BusinessPartner : String(10) not null;
    @Common.Text : BusinessPartnerName
    BusinessPartnerName : String(81) not null;
    @Common.Text : Plant
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    Plant : String(4) not null;
    @Common.Text : Type
    Type : String(1) not null;
    @Common.Text : Country
    @Common.IsUpperCase : true
    @Common.Label : 'Country/Region Key'
    @Common.Heading : 'C/R'
    Country : String(3) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'VH for Plant and Business Partner'
  @Capabilities.SearchRestrictions.Searchable : true
  @Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity Massplantbpcntrykey {
    @Common.Text : Plant
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    key Plant : String(4) not null;
    @Common.Text : PlantName
    @Common.Label : 'Plant Name'
    PlantName : String(30) not null;
    @Common.Text : BusinessPartner
    @Common.IsUpperCase : true
    @Common.Label : 'Business Partner'
    @Common.QuickInfo : 'Business Partner Number'
    BusinessPartner : String(10) not null;
    @Common.Text : Type
    Type : String(1) not null;
    @Common.Text : Country
    @Common.IsUpperCase : true
    @Common.Label : 'Country/Region Key'
    @Common.Heading : 'C/R'
    Country : String(3) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Material details with Brand'
  @Capabilities.SearchRestrictions.Searchable : true
  @Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity Material {
    @Common.Text : Product
    key Product : String(40) not null;
    @Common.Text : ProfitCenter
    @Common.IsUpperCase : true
    @Common.Label : 'Profit Center'
    @Common.Heading : 'Profit Ctr'
    key ProfitCenter : String(10) not null;
    @Common.Text : Plant
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    key Plant : String(4) not null;
    @Common.Text : ProductName
    @Common.Label : 'Product Description'
    ProductName : String(40) not null;
    @Common.Text : ProductType
    @Common.IsUpperCase : true
    @Common.Label : 'Product Type'
    @Common.Heading : 'PTyp'
    ProductType : String(4) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Root entity to verify mass upload'
  @Capabilities.NavigationRestrictions.RestrictedProperties : [
    {
      NavigationProperty: _header,
      InsertRestrictions: { Insertable: ![__CreateByAssociationControl/_header] }
    }
  ]
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.FilterRestrictions.NonFilterableProperties : [ '__CreateByAssociationControl', '__EntityControl' ]
  @Capabilities.SortRestrictions.NonSortableProperties : [ '__CreateByAssociationControl', '__EntityControl' ]
  @Capabilities.ReadRestrictions.Readable : false
  @Capabilities.DeleteRestrictions.Deletable : ![__EntityControl/Deletable]
  @Capabilities.UpdateRestrictions.Updatable : ![__EntityControl/Updatable]
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity MaterialValidate {
    @Core.Computed : true
    key MassMaterial : String(1) not null;
    GroupID : String(10) not null;
    @Core.Computed : true
    @UI.HiddenFilter : true
    @UI.Hidden : true
    @Common.Label : 'Dynamic CbA-Control'
    @Common.Heading : 'Dynamic Create by Association Control'
    @Common.QuickInfo : 'Dynamic Create via Association Control Property'
    __CreateByAssociationControl : MaterialValidateCbAControl;
    @Core.Computed : true
    @UI.HiddenFilter : true
    @UI.Hidden : true
    @Common.Label : 'Dyn. Method Control'
    @Common.Heading : 'Dynamic Method Control'
    @Common.QuickInfo : 'Dynamic Method Property'
    __EntityControl : EntityControl;
    @Common.Composition : true
    _header : Composition of many MaterialValidateChild {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Custom entity to verify material for Mass Upload'
  @Capabilities.NavigationRestrictions.RestrictedProperties : [
    { NavigationProperty: _root, InsertRestrictions: { Insertable: false } }
  ]
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.FilterRestrictions.NonFilterableProperties : [ '__EntityControl' ]
  @Capabilities.SortRestrictions.NonSortableProperties : [ '__EntityControl' ]
  @Capabilities.ReadRestrictions.Readable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : ![__EntityControl/Deletable]
  @Capabilities.UpdateRestrictions.Updatable : ![__EntityControl/Updatable]
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity MaterialValidateChild {
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Material'
    @Common.QuickInfo : 'Material Number'
    key MaterialNumber : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Profit Center'
    @Common.Heading : 'Profit Ctr'
    MaterialBrand : String(10) not null;
    MaterialType : String(4) not null;
    MaterialDescription : String(40) not null;
    VerifyText : String(1) not null;
    @Core.Computed : true
    MassMaterial : String(1) not null;
    ProductFlowID : String(80) not null;
    FlowID : String(80) not null;
    FlowDescription : String(60) not null;
    ShipFromBusinessPartner : String(10) not null;
    ShipFromPlant : String(10) not null;
    EconomicRegionShipFrom : String(10) not null;
    ShipToBusinessPartner : String(10) not null;
    ShipToPlant : String(10) not null;
    EconomicRegionShipTo : String(10) not null;
    ArchType1 : String(20) not null;
    PlantV1 : String(10) not null;
    BusinessPartnerV1 : String(10) not null;
    ArchType2 : String(20) not null;
    PlantV2 : String(10) not null;
    BusinessPartnerV2 : String(10) not null;
    ArchType3 : String(20) not null;
    PlantV3 : String(10) not null;
    BusinessPartnerV3 : String(10) not null;
    ArchType4 : String(20) not null;
    PlantV4 : String(10) not null;
    BusinessPartnerV4 : String(10) not null;
    ArchType5 : String(20) not null;
    PlantV5 : String(10) not null;
    BusinessPartnerV5 : String(10) not null;
    ArchType6 : String(20) not null;
    PlantV6 : String(10) not null;
    BusinessPartnerV6 : String(10) not null;
    ValidFrom : Date;
    ValidTo : Date;
    comments : String(400) not null;
    ProductFlowComments : String(400) not null;
    Errorcheck : String(1) not null;
    ShipFromArchType : String(20) not null;
    GroupID : String(10) not null;
    @Core.Computed : true
    @UI.HiddenFilter : true
    @UI.Hidden : true
    @Common.Label : 'Dyn. Method Control'
    @Common.Heading : 'Dynamic Method Control'
    @Common.QuickInfo : 'Dynamic Method Property'
    __EntityControl : EntityControl;
    _root : Association to one MaterialValidate {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'VH for Plant and Business Partner'
  @Capabilities.SearchRestrictions.Searchable : true
  @Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity Plant {
    @Common.Text : Plant
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    key Plant : String(4) not null;
    @Common.Text : PlantName
    @Common.Label : 'Plant Name'
    PlantName : String(30) not null;
    @Common.Text : BusinessPartner
    @Common.IsUpperCase : true
    @Common.Label : 'Business Partner'
    @Common.QuickInfo : 'Business Partner Number'
    BusinessPartner : String(10) not null;
    @Common.Text : TYPE
    TYPE : String(1) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'custom entity for Scenario determination for BP'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity SDBP {
    key BP : String(30) not null;
    BPName : String(30) not null;
    BPGroup : String(30) not null;
    BPGroupcheck : String(30) not null;
    message : String(40) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Custom entity for scenario determination of Plant'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity SDPLANT {
    key Plant : String(4) not null;
    PlantName : String(15) not null;
    message : String(40) not null;
  };
};

