/* checksum : a699901d6e73e4fc9543bccd142a0687 */
@cds.external : true
@CodeList.CurrencyCodes : {
  Url: '../../../../default/iwbep/common/0001/$metadata',
  CollectionPath: 'Currencies'
}
@CodeList.UnitsOfMeasure : {
  Url: '../../../../default/iwbep/common/0001/$metadata',
  CollectionPath: 'UnitsOfMeasure'
}
@Aggregation.ApplySupported : { Transformations: [ 'aggregate', 'groupby', 'filter' ], Rollup: #None }
@Common.ApplyMultiUnitBehaviorForSortingAndFiltering : true
@Capabilities.FilterFunctions : [
  'eq',
  'ne',
  'gt',
  'ge',
  'lt',
  'le',
  'and',
  'or',
  'contains',
  'startswith',
  'endswith',
  'any',
  'all'
]
@Capabilities.SupportedFormats : [ 'application/json', 'application/pdf' ]
@PDF.Features : {
  DocumentDescriptionReference: '../../../../default/iwbep/common/0001/$metadata',
  DocumentDescriptionCollection: 'MyDocumentDescriptions',
  ArchiveFormat: true,
  Border: true,
  CoverPage: true,
  FitToPage: true,
  FontName: true,
  FontSize: true,
  Margin: true,
  Padding: true,
  Signature: true,
  HeaderFooter: true,
  ResultSizeDefault: 20000,
  ResultSizeMaximum: 20000
}
@Capabilities.KeyAsSegmentSupported : true
@Capabilities.AsynchronousRequestsSupported : true
service BILLINGDOCUMENT {
  @cds.external : true
  type D_BillgDocCrteFrmSDDocRefP {
    @Common.FieldControl : #Mandatory
    @Common.Label : 'SD Document'
    @Common.Heading : 'Document'
    @Common.QuickInfo : 'Sales and Distribution Document Number'
    SDDocument : String(10) not null;
    @Common.Label : 'Billing Type'
    @Common.Heading : 'BillT'
    BillingDocumentType : String(4) not null;
    @Common.Label : 'Billing Date'
    BillingDocumentDate : Date;
    @Common.Label : 'Dest. Country/Region'
    @Common.Heading : 'Dest. Ctry/Reg'
    @Common.QuickInfo : 'Destination Country/Region'
    DestinationCountry : String(3) not null;
    @Common.Label : 'Sales Organization'
    @Common.Heading : 'SOrg.'
    SalesOrganization : String(4) not null;
    @Common.Label : 'SD Document Category'
    @Common.Heading : 'Doc.Cat.'
    SDDocumentCategory : String(4) not null;
    @Common.Label : 'Sales Unit'
    @Common.Heading : 'SU'
    @Common.QuickInfo : 'Actual Invoiced Quantity'
    @Measures.Unit : ![_Item/BillingQuantityUnit]
    _Item : many D_BillgDocCrteFrmSDDocRefItemP not null;
  };

  @cds.external : true
  type D_BillgDocCrteFrmSDDocRefItemP {
    @Common.FieldControl : #Mandatory
    @Common.Label : 'Item (SD)'
    @Common.Heading : 'Item'
    @Common.QuickInfo : 'Item number of the SD document'
    SDDocumentItem : String(6) not null;
    @Measures.Unit : BillingQuantityUnit
    @Common.Label : 'Invoiced Quantity'
    @Common.QuickInfo : 'Actual Invoiced Quantity'
    BillingQuantity : Decimal(13, 3) not null;
    @Common.Label : 'Sales Unit'
    @Common.Heading : 'SU'
    BillingQuantityUnit : String(3) not null;
  };

  @cds.external : true
  type D_BillgDocCrteFrmSDDocControlP {
    @Common.Label : 'Default Billing Date'
    @Common.QuickInfo : 'Default Billing Document Date'
    DefaultBillingDocumentDate : Date;
    @Common.Label : 'Default Billing Type'
    @Common.QuickInfo : 'Default Billing Document Type'
    DefaultBillingDocumentType : String(4) not null;
    @Common.Label : 'Posting Block'
    @Common.Heading : 'FIBk'
    @Common.QuickInfo : 'Blocked for transfer to accounting'
    AutomPostingToAcctgIsDisabled : Boolean not null;
    @Common.Label : 'Billing up to'
    @Common.Heading : 'Bill up to'
    @Common.QuickInfo : 'Date up to which billing is to be carried out'
    CutOffBillingDocumentDate : Date;
  };

  @cds.external : true
  type SAP__Message {
    code : LargeString not null;
    message : LargeString not null;
    target : LargeString;
    additionalTargets : many LargeString not null;
    transition : Boolean not null;
    @odata.Type : 'Edm.Byte'
    numericSeverity : Integer not null;
    longtextUrl : LargeString;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Billing Document'
  @Common.Messages : SAP__Messages
  @Capabilities.SearchRestrictions.Searchable : true
  @Capabilities.SearchRestrictions.UnsupportedExpressions : #phrase
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.FilterRestrictions.FilterExpressionRestrictions : [
    { Property: TotalNetAmount, AllowedExpressions: 'MultiValue' },
    { Property: TotalTaxAmount, AllowedExpressions: 'MultiValue' }
  ]
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity BillingDocument {
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Billing Document'
    @Common.Heading : 'Bill. Doc.'
    key BillingDocument : String(10) not null;
    @Core.Computed : true
    @Common.Label : 'SD Document Category'
    @Common.Heading : 'Doc.Cat.'
    SDDocumentCategory : String(4) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Billing Category'
    @Common.Heading : 'BlCat'
    BillingDocumentCategory : String(1) not null;
    @Common.SAPObjectNodeTypeReference : 'BillingDocumentType'
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Billing Type'
    @Common.Heading : 'BillT'
    BillingDocumentType : String(4) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Created By'
    @Common.QuickInfo : 'Name of Person Responsible for Creating the Object'
    CreatedByUser : String(12) not null;
    @Core.Computed : true
    @Common.Label : 'Created On'
    @Common.QuickInfo : 'Record Creation Date'
    CreationDate : Date;
    @Core.Computed : true
    @Common.Label : 'Time'
    @Common.QuickInfo : 'Entry time'
    CreationTime : Time not null;
    @Core.Computed : true
    @Common.Label : 'Changed On'
    @Common.Heading : 'Chngd On'
    @Common.QuickInfo : 'Last Changed On'
    LastChangeDate : Date;
    @odata.Precision : 7
    @odata.Type : 'Edm.DateTimeOffset'
    @Common.Label : 'Time Stamp'
    @Common.QuickInfo : 'UTC Time Stamp in Long Form (YYYYMMDDhhmmssmmmuuun)'
    LastChangeDateTime : Timestamp;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Logical system'
    @Common.Heading : 'Log.System'
    LogicalSystem : String(10) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Organization'
    @Common.Heading : 'SOrg.'
    SalesOrganization : String(4) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Distribution Channel'
    @Common.Heading : 'DChl'
    DistributionChannel : String(2) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Division'
    @Common.Heading : 'Dv'
    Division : String(2) not null;
    @Common.Label : 'Billing Date'
    BillingDocumentDate : Date;
    @Core.Computed : true
    @Common.Label : 'Canceled'
    @Common.Heading : 'Can'
    @Common.QuickInfo : 'Billing document is canceled'
    BillingDocumentIsCancelled : Boolean not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Canceled Bill. Doc.'
    @Common.Heading : 'CancBillDc'
    @Common.QuickInfo : 'Number of canceled billing document'
    CancelledBillingDocument : String(10) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Combination Criteria'
    @Common.Heading : 'Combination Criteria in the Billing Doc.'
    @Common.QuickInfo : 'Combination criteria in the billing document'
    BillingDocCombinationCriteria : String(40) not null;
    @Core.Computed : true
    @Common.Label : 'Man. Invoice Maint.'
    @Common.Heading : 'InM'
    @Common.QuickInfo : 'Manual Invoice Maintenance'
    ManualInvoiceMaintIsRelevant : Boolean not null;
    @Core.Computed : true
    @Common.IsDigitSequence : true
    @Common.Label : 'Number of Pages'
    @Common.Heading : 'Pages'
    @Common.QuickInfo : 'Number of pages of invoice'
    NmbrOfPages : String(3) not null;
    @Core.Computed : true
    @Common.Label : 'Intrastat Relevance'
    @Common.Heading : 'relevant for Intrastat'
    @Common.QuickInfo : 'Relevant for Intrastat Reporting'
    IsIntrastatReportingRelevant : Boolean not null;
    @Core.Computed : true
    @Common.Label : 'Intrastat Exclusion'
    @Common.Heading : 'exclude from Intrastat'
    @Common.QuickInfo : 'Exclude from Intrastat Reporting'
    IsIntrastatReportingExcluded : Boolean not null;
    @Core.Computed : true
    @Common.Label : 'Draft Indicator'
    @Common.Heading : 'Is Draft'
    @Common.QuickInfo : 'IsDraft Indicator'
    BillingDocumentIsTemporary : Boolean not null;
    @Core.Computed : true
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Net Value'
    @Common.QuickInfo : 'Net Value in Document Currency'
    TotalNetAmount : Decimal(precision: 15) not null;
    @Common.IsCurrency : true
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Document Currency'
    @Common.Heading : 'Crcy'
    @Common.QuickInfo : 'SD Document Currency'
    TransactionCurrency : String(3) not null;
    @Common.IsCurrency : true
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Statistics Currency'
    @Common.Heading : 'Curr.'
    StatisticsCurrency : String(3) not null;
    @Core.Computed : true
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Tax Amount'
    @Common.QuickInfo : 'Tax Amount in Document Currency'
    TotalTaxAmount : Decimal(precision: 13) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Price Group'
    @Common.Heading : 'CPG'
    CustomerPriceGroup : String(2) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Price List Type'
    @Common.Heading : 'PL'
    PriceListType : String(2) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Departure C/R'
    @Common.Heading : 'TDC'
    @Common.QuickInfo : 'Tax Departure Country/Region'
    TaxDepartureCountry : String(3) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'VAT Registration No.'
    @Common.QuickInfo : 'VAT Registration Number'
    VATRegistration : String(20) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Origin Sales Tax No.'
    @Common.Heading : 'OSI'
    @Common.QuickInfo : 'Origin of Sales Tax Number'
    VATRegistrationOrigin : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Ctry/Rgn Sls Tax No.'
    @Common.Heading : 'STC'
    @Common.QuickInfo : 'Country/Region of Sales Tax ID Number'
    VATRegistrationCountry : String(3) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'HierarchyTypePricing'
    @Common.Heading : 'HPr'
    @Common.QuickInfo : 'Hierarchy type for pricing'
    HierarchyTypePricing : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.1 Customer'
    @Common.Heading : 'Tx2Cs'
    @Common.QuickInfo : 'Tax Classification 1 for Customer'
    CustomerTaxClassification1 : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.2 Customer'
    @Common.Heading : 'Tx2Cs'
    @Common.QuickInfo : 'Tax Classification 2 for Customer'
    CustomerTaxClassification2 : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.3 Customer'
    @Common.Heading : 'Tx3Cs'
    @Common.QuickInfo : 'Tax Classification 3 for Customer'
    CustomerTaxClassification3 : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.4 Customer'
    @Common.Heading : 'Tx4Cs'
    @Common.QuickInfo : 'Tax Classification 4 for Customer'
    CustomerTaxClassification4 : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.5 Customer'
    @Common.Heading : 'Tx5Cs'
    @Common.QuickInfo : 'Tax Classification 5 for Customer'
    CustomerTaxClassification5 : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.6 Customer'
    @Common.Heading : 'Tx6Cs'
    @Common.QuickInfo : 'Tax Classification 6 for Customer'
    CustomerTaxClassification6 : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.7 Customer'
    @Common.Heading : 'Tx7Cs'
    @Common.QuickInfo : 'Tax Classification 7 for Customer'
    CustomerTaxClassification7 : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.8 Customer'
    @Common.Heading : 'Tx8Cs'
    @Common.QuickInfo : 'Tax Classification 8 for Customer'
    CustomerTaxClassification8 : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.9 Customer'
    @Common.Heading : 'Tx9Cs'
    @Common.QuickInfo : 'Tax Classification 9 for Customer'
    CustomerTaxClassification9 : String(1) not null;
    @Core.Computed : true
    @Common.Label : 'EU Triangular Deal'
    @Common.QuickInfo : 'Indicator: Triangular Deal Within the EU'
    IsEUTriangularDeal : Boolean not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Pricing Procedure'
    @Common.Heading : 'PriPr.'
    @Common.QuickInfo : 'Pricing Procedure in Pricing'
    SDPricingProcedure : String(6) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Shipping Conditions'
    ShippingCondition : String(2) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Incoterms Version'
    @Common.Heading : 'IncoV'
    IncotermsVersion : String(4) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Incoterms'
    @Common.Heading : 'IncoT'
    @Common.QuickInfo : 'Incoterms (Part 1)'
    IncotermsClassification : String(3) not null;
    @Core.Computed : true
    @Common.Label : 'Incoterms (Part 2)'
    @Common.Heading : 'Inco. 2'
    IncotermsTransferLocation : String(28) not null;
    @Core.Computed : true
    @Common.Label : 'Incoterms Location 1'
    IncotermsLocation1 : String(70) not null;
    @Core.Computed : true
    @Common.Label : 'Incoterms Location 2'
    IncotermsLocation2 : String(70) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Payer'
    PayerParty : String(10) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Contract Account'
    @Common.Heading : 'Cont.Account'
    @Common.QuickInfo : 'Contract Account Number'
    ContractAccount : String(12) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Terms of Payment'
    @Common.QuickInfo : 'Terms of Payment Key'
    CustomerPaymentTerms : String(4) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Payment Method'
    @Common.Heading : 'PM'
    PaymentMethod : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Payment Reference'
    PaymentReference : String(30) not null;
    @Core.Computed : true
    @Common.Label : 'Fixed Value Date'
    @Common.Heading : 'FixValDate'
    FixedValueDate : Date;
    @Core.Computed : true
    @Common.IsDigitSequence : true
    @Common.Label : 'Addit. Value Days'
    @Common.Heading : 'AValD'
    @Common.QuickInfo : 'Additional Value Days'
    AdditionalValueDays : String(2) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Mandate Reference'
    @Common.QuickInfo : 'Unique Reference to Mandate for each Payee'
    SEPAMandate : String(35) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Company Code'
    @Common.Heading : 'CoCd'
    CompanyCode : String(4) not null;
    @Core.Computed : true
    @Common.IsDigitSequence : true
    @Common.Label : 'Fiscal Year'
    @Common.Heading : 'Year'
    FiscalYear : String(4) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Document Number'
    @Common.Heading : 'DocumentNo'
    @Common.QuickInfo : 'Document Number of an Accounting Document'
    AccountingDocument : String(10) not null;
    @Core.Computed : true
    @Common.IsDigitSequence : true
    @Common.Label : 'Posting Period'
    @Common.Heading : 'Period'
    FiscalPeriod : String(3) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Acct Assmt Grp Cust.'
    @Common.Heading : 'AAGC'
    @Common.QuickInfo : 'Account Assignment Group for Customer'
    CustomerAccountAssignmentGroup : String(2) not null;
    @Core.Computed : true
    @Common.Label : 'Set Exchange Rate'
    @Common.Heading : 'SRate'
    @Common.QuickInfo : 'Exchange Rate Setting'
    AccountingExchangeRateIsSet : Boolean not null;
    @Core.Computed : true
    @Common.Label : 'Accounting Exchange Rate'
    @Common.QuickInfo : 'Exchange Rate for FI Postings'
    AccountingExchangeRate : Decimal(9, 5) not null;
    @Core.Computed : true
    @Common.Label : 'Translation Date'
    @Common.Heading : 'TranslDate'
    ExchangeRateDate : Date;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Exchange Rate Type'
    ExchangeRateType : String(4) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Reference'
    @Common.QuickInfo : 'Reference Document Number'
    DocumentReferenceID : String(16) not null;
    @Core.Computed : true
    @Common.Label : 'Assignment'
    @Common.QuickInfo : 'Assignment Number'
    AssignmentReference : String(18) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Reversal Reason'
    @Common.Heading : 'Rev.Reas.'
    @Common.QuickInfo : 'Reason for Reversal or Inverse Posting'
    ReversalReason : String(2) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Dunning Area'
    @Common.Heading : 'Area'
    DunningArea : String(2) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Dunning Block'
    @Common.Heading : 'Block'
    DunningBlockingReason : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Dunning Key'
    @Common.Heading : 'Dunn.Key'
    DunningKey : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Financial Doc. No.'
    @Common.Heading : 'FD No.'
    @Common.QuickInfo : 'Financial doc. processing: Internal financial doc. number'
    InternalFinancialDocument : String(10) not null;
    @Core.Computed : true
    @Common.Label : 'Relevant for Accrual'
    @Common.Heading : 'Is Relevant for Accrual'
    @Common.QuickInfo : 'Is relevant for accrual'
    IsRelevantForAccrual : Boolean not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Sold-to Party'
    @Common.Heading : 'Sold-to'
    SoldToParty : String(10) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Trading Partner No.'
    @Common.Heading : 'Tr.Prt'
    @Common.QuickInfo : 'Company ID of Trading Partner'
    PartnerCompany : String(6) not null;
    @Core.Computed : true
    @Common.Label : 'Customer Reference'
    PurchaseOrderByCustomer : String(35) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Group'
    @Common.Heading : 'CGrp'
    CustomerGroup : String(2) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Dest. Country/Region'
    @Common.Heading : 'Dest. Ctry/Reg'
    @Common.QuickInfo : 'Destination Country/Region'
    Country : String(3) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'City Code'
    @Common.Heading : 'Code'
    CityCode : String(4) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Sales District'
    @Common.Heading : 'SDst'
    SalesDistrict : String(6) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Region'
    @Common.Heading : 'Rg'
    @Common.QuickInfo : 'Region (State, Province, County)'
    Region : String(3) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'County Code'
    @Common.Heading : 'CCd'
    County : String(3) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Credit Control Area'
    @Common.Heading : 'CCAr'
    CreditControlArea : String(4) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Agreement'
    @Common.QuickInfo : 'Agreement (various conditions grouped together)'
    CustomerRebateAgreement : String(10) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Doc. Condition No.'
    @Common.Heading : 'Doc.Cond.'
    @Common.QuickInfo : 'Number of the Document Condition'
    PricingDocument : String(10) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Overall Status'
    @Common.Heading : 'OS'
    @Common.QuickInfo : 'Overall Processing Status (Header/All Items)'
    OverallSDProcessStatus : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Status'
    @Common.QuickInfo : 'SD Billing Status'
    OverallBillingStatus : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Posting Status'
    @Common.Heading : 'PS'
    @Common.QuickInfo : 'Posting Status of Billing Document'
    AccountingPostingStatus : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Posting Status'
    @Common.Heading : 'PsSt'
    @Common.QuickInfo : 'Status for Transfer to Accounting'
    AccountingTransferStatus : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Issue Type'
    @Common.QuickInfo : 'Billing Issue Type'
    BillingIssueType : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Invoice List Status'
    @Common.Heading : 'ILSt'
    @Common.QuickInfo : 'Invoice list status of billing document'
    InvoiceListStatus : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'All Items'
    @Common.Heading : 'AI'
    @Common.QuickInfo : 'Incompletion Status (All Items)'
    OvrlItmGeneralIncompletionSts : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Pricing – All Items'
    @Common.Heading : 'PI'
    @Common.QuickInfo : 'Pricing Incompletion Status (All Items)'
    OverallPricingIncompletionSts : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Clearing Status'
    @Common.QuickInfo : 'Clearing Status of Billing Document'
    InvoiceClearingStatus : String(1) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Invoice List Type'
    @Common.Heading : 'ILTyp'
    InvoiceListType : String(4) not null;
    @Core.Computed : true
    @Common.Label : 'Inv. List Bill. Date'
    @Common.Heading : 'InvList BD'
    @Common.QuickInfo : 'Billing date for the invoice list'
    InvoiceListBillingDate : Date;
    SAP__Messages : many SAP__Message not null;
    @Common.Composition : true
    _Item : Composition of many BillingDocumentItem {  };
  } actions {
    action CreateFromSDDocument(
      _it : many $self not null,
      _Control : D_BillgDocCrteFrmSDDocControlP not null ,
      _Reference : many D_BillgDocCrteFrmSDDocRefP not null
    ) returns many BillingDocument not null;
    action CreateCancellationDocument(
      _it : $self not null,
      @Common.Label : 'Billing Date'
      BillingDocumentDate : Date,
      @Common.Label : 'Reversal Reason'
      @Common.Heading : 'Rev.Reas.'
      @Common.QuickInfo : 'Reason for Reversal or Inverse Posting'
      ReversalReason : String(2) not null
    ) returns BillingDocument not null;
    action PostToAccounting(
      _it : $self not null
    );
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Billing Document Item'
  @Common.SemanticKey : [ 'BillingDocumentItem', 'BillingDocument' ]
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  @Capabilities.FilterRestrictions.FilterExpressionRestrictions : [
    { Property: BillingQuantity, AllowedExpressions: 'MultiValue' },
    { Property: BillingQuantityInBaseUnit, AllowedExpressions: 'MultiValue' },
    {
      Property: MRPRequiredQuantityInBaseUnit,
      AllowedExpressions: 'MultiValue'
    },
    { Property: ItemGrossWeight, AllowedExpressions: 'MultiValue' },
    { Property: ItemNetWeight, AllowedExpressions: 'MultiValue' },
    { Property: ItemVolume, AllowedExpressions: 'MultiValue' },
    { Property: NetAmount, AllowedExpressions: 'MultiValue' },
    { Property: GrossAmount, AllowedExpressions: 'MultiValue' },
    {
      Property: PricingScaleQuantityInBaseUnit,
      AllowedExpressions: 'MultiValue'
    },
    { Property: TaxAmount, AllowedExpressions: 'MultiValue' },
    { Property: CostAmount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal1Amount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal2Amount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal3Amount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal4Amount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal5Amount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal6Amount, AllowedExpressions: 'MultiValue' },
    {
      Property: EligibleAmountForCashDiscount,
      AllowedExpressions: 'MultiValue'
    },
    { Property: RebateBasisAmount, AllowedExpressions: 'MultiValue' },
    { Property: CreditRelatedPrice, AllowedExpressions: 'MultiValue' }
  ]
  entity BillingDocumentItem {
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Billing Document'
    @Common.Heading : 'Bill. Doc.'
    key BillingDocument : String(10) not null;
    @Core.Computed : true
    @Common.IsDigitSequence : true
    @Common.Label : 'Item'
    @Common.QuickInfo : 'Billing Item'
    key BillingDocumentItem : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Doc. Item Cat.'
    @Common.Heading : 'Sales Doc. Item Category'
    @Common.QuickInfo : 'Sales Document Item Category'
    SalesDocumentItemCategory : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Item Type'
    @Common.Heading : 'IT'
    SalesDocumentItemType : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Returns'
    @Common.Heading : 'Ret'
    @Common.QuickInfo : 'Returns item'
    ReturnItemProcessingType : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Created By'
    @Common.QuickInfo : 'Name of Person Responsible for Creating the Object'
    CreatedByUser : String(12) not null;
    @Common.Label : 'Created On'
    @Common.QuickInfo : 'Record Creation Date'
    CreationDate : Date;
    @Common.Label : 'Time'
    @Common.QuickInfo : 'Entry time'
    CreationTime : Time not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Logical system'
    @Common.Heading : 'Log.System'
    ReferenceLogicalSystem : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Division of Order'
    @Common.Heading : 'DivOr'
    @Common.QuickInfo : 'Division in Sales Order Header'
    OrganizationDivision : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Division'
    @Common.Heading : 'Dv'
    Division : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Office'
    @Common.Heading : 'SOff.'
    SalesOffice : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Product'
    @Common.QuickInfo : 'Product Number'
    Product : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Entered'
    OriginallyRequestedMaterial : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'EAN/UPC'
    @Common.QuickInfo : 'International Article Number (EAN/UPC)'
    InternationalArticleNumber : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Pricing Ref. Matl'
    @Common.QuickInfo : 'Pricing Reference Material'
    PricingReferenceMaterial : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Batch'
    @Common.QuickInfo : 'Batch Number'
    Batch : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Product Hierarchy'
    ProductHierarchyNode : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Product Group'
    @Common.Heading : 'Prd Group'
    ProductGroup : String(9) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Group 1'
    @Common.Heading : 'MG 1'
    AdditionalMaterialGroup1 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Group 2'
    @Common.Heading : 'MG 2'
    AdditionalMaterialGroup2 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Group 3'
    @Common.Heading : 'MG 3'
    AdditionalMaterialGroup3 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Group 4'
    @Common.Heading : 'MG 4'
    AdditionalMaterialGroup4 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Group 5'
    @Common.Heading : 'MG 5'
    AdditionalMaterialGroup5 : String(3) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Configuration'
    ProductConfiguration : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Commission Group'
    @Common.Heading : 'Com'
    MaterialCommissionGroup : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    Plant : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Storage Location'
    StorageLocation : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Replacement Part'
    @Common.Heading : 'R'
    @Common.QuickInfo : 'Replacement part'
    ReplacementPartType : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Group 1'
    @Common.Heading : 'MH1'
    @Common.QuickInfo : 'Material Group Hierarchy 1'
    MaterialGroupHierarchy1 : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Group 2'
    @Common.Heading : 'MH2'
    @Common.QuickInfo : 'Material Group Hierarchy 2'
    MaterialGroupHierarchy2 : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Region of Dlv. Plant'
    @Common.Heading : 'Reg'
    @Common.QuickInfo : 'Region in which plant is located'
    PlantRegion : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'County of Dlv.Plant'
    @Common.Heading : 'Cty'
    @Common.QuickInfo : 'County in which plant is located'
    PlantCounty : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'City of Deliv. Plant'
    @Common.Heading : 'Cty'
    @Common.QuickInfo : 'City in which plant is located'
    PlantCity : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'BOM explosion number'
    @Common.Heading : 'BOMexpNo'
    BOMExplosion : String(8) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Mat.Determ.Active'
    @Common.QuickInfo : 'ID for material determination'
    MaterialDeterminationType : String(1) not null;
    @Common.Label : 'Item Description'
    @Common.QuickInfo : 'Short text for sales order item'
    BillingDocumentItemText : String(40) not null;
    @Common.Label : 'Serv. Rendered Date'
    @Common.Heading : 'Serv.R.Dte'
    @Common.QuickInfo : 'Date on which services are rendered'
    ServicesRenderedDate : Date;
    @Measures.Unit : BillingQuantityUnit
    @Common.Label : 'Invoiced Quantity'
    @Common.QuickInfo : 'Actual Invoiced Quantity'
    BillingQuantity : Decimal(13, 3) not null;
    @Common.IsUnit : true
    @Common.Label : 'Sales Unit'
    @Common.Heading : 'SU'
    BillingQuantityUnit : String(3) not null;
    @Measures.Unit : BaseUnit
    @Common.Label : 'Billing Qty in SKU'
    @Common.Heading : 'Bill. Qty in SKU'
    @Common.QuickInfo : 'Billing quantity in stock keeping unit'
    BillingQuantityInBaseUnit : Decimal(13, 3) not null;
    @Common.IsUnit : true
    @Common.Label : 'Base Unit of Measure'
    @Common.Heading : 'BUn'
    BaseUnit : String(3) not null;
    @Measures.Unit : BaseUnit
    @Common.Label : 'Required Quantity'
    @Common.QuickInfo : 'Required quantity for mat.management in stockkeeping units'
    MRPRequiredQuantityInBaseUnit : Decimal(13, 3) not null;
    @Common.Label : 'Denominator'
    @Common.QuickInfo : 'Denominator (divisor) for conversion of sales Qty into SKU'
    BillingToBaseQuantityDnmntr : Decimal(precision: 5) not null;
    @Common.Label : 'Numerator'
    @Common.QuickInfo : 'Numerator (factor) for conversion of sales quantity into SKU'
    BillingToBaseQuantityNmrtr : Decimal(precision: 5) not null;
    @Measures.Unit : ItemWeightUnit
    @Common.Label : 'Gross Weight'
    ItemGrossWeight : Decimal(15, 3) not null;
    @Measures.Unit : ItemWeightUnit
    @Common.Label : 'Net Weight'
    ItemNetWeight : Decimal(15, 3) not null;
    @Common.IsUnit : true
    @Common.Label : 'Unit of Weight'
    @Common.Heading : 'WUn'
    ItemWeightUnit : String(3) not null;
    @Measures.Unit : ItemVolumeUnit
    @Common.Label : 'Volume'
    ItemVolume : Decimal(15, 3) not null;
    @Common.IsUnit : true
    @Common.Label : 'Volume Unit'
    @Common.Heading : 'VUn'
    ItemVolumeUnit : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Dest. Ctry/Reg. Ord.'
    @Common.Heading : 'DCRO'
    @Common.QuickInfo : 'Destination Country/Region of Sales Order'
    BillToPartyCountry : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Region Order'
    @Common.Heading : 'RO'
    @Common.QuickInfo : 'Region of Sales Order'
    BillToPartyRegion : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Billing Rule'
    @Common.Heading : 'BR'
    @Common.QuickInfo : 'Rule in billing plan/invoice plan'
    BillingPlanRule : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Bill. Plan No.'
    @Common.Heading : 'Bill. Plan'
    @Common.QuickInfo : 'Billing Plan Number / Invoicing Plan Number'
    BillingPlan : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Item'
    @Common.QuickInfo : 'Item for billing plan/invoice plan/payment cards'
    BillingPlanItem : String(6) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Net Value'
    @Common.QuickInfo : 'Net Value of Billing item in Document Currency'
    NetAmount : Decimal(precision: 15) not null;
    @Common.IsCurrency : true
    @Common.IsUpperCase : true
    @Common.Label : 'Document Currency'
    @Common.Heading : 'Crcy'
    @Common.QuickInfo : 'SD Document Currency'
    TransactionCurrency : String(3) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Gross Value'
    @Common.QuickInfo : 'Gross Value of the Billing Item in Document Currency'
    GrossAmount : Decimal(precision: 15) not null;
    @Common.Label : 'Pricing Date'
    @Common.Heading : 'Pricing Dt'
    @Common.QuickInfo : 'Date for Pricing and Exchange Rate'
    PricingDate : Date;
    @Common.Label : 'Exchange Rate'
    @Common.Heading : 'Exch.Rate'
    @Common.QuickInfo : 'Exchange Rate for Price Determination'
    PriceDetnExchangeRate : Decimal(9, 5) not null;
    @Measures.Unit : BaseUnit
    @Common.Label : 'Scale Quantity'
    @Common.QuickInfo : 'Scale Quantity in base unit of measure'
    PricingScaleQuantityInBaseUnit : Decimal(13, 3) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Tax Amount'
    @Common.QuickInfo : 'Tax Amount in Document Currency'
    TaxAmount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Cost'
    @Common.QuickInfo : 'Cost in Document Currency'
    CostAmount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Subtotal 1'
    @Common.QuickInfo : 'Subtotal 1 from Pricing Procedure for Price Element'
    Subtotal1Amount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Subtotal 2'
    @Common.QuickInfo : 'Subtotal 2 from Pricing Procedure for Price Element'
    Subtotal2Amount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Subtotal 3'
    @Common.QuickInfo : 'Subtotal 3 from Pricing Procedure for Price Element'
    Subtotal3Amount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Subtotal 4'
    @Common.QuickInfo : 'Subtotal 4 from Pricing Procedure for Price Element'
    Subtotal4Amount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Subtotal 5'
    @Common.QuickInfo : 'Subtotal 5 from Pricing Procedure for Price Element'
    Subtotal5Amount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Subtotal 6'
    @Common.QuickInfo : 'Subtotal 6 from Pricing Procedure for Price Element'
    Subtotal6Amount : Decimal(precision: 13) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Statistical Value'
    @Common.Heading : 'Stat.'
    @Common.QuickInfo : 'Statistical Values'
    StatisticalValueControl : String(1) not null;
    @Common.Label : 'Cash Discount'
    @Common.Heading : 'CDc'
    @Common.QuickInfo : 'Cash Discount Indicator'
    CashDiscountIsDeductible : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Condition group 1'
    @Common.Heading : 'CGr1'
    @Common.QuickInfo : 'Customer condition group 1'
    CustomerConditionGroup1 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Condition group 2'
    @Common.Heading : 'CGr2'
    @Common.QuickInfo : 'Customer condition group 2'
    CustomerConditionGroup2 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Condition group 3'
    @Common.Heading : 'CGr3'
    @Common.QuickInfo : 'Customer condition group 3'
    CustomerConditionGroup3 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Condition group 4'
    @Common.Heading : 'CGr4'
    @Common.QuickInfo : 'Customer condition group 4'
    CustomerConditionGroup4 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Condition group 5'
    @Common.Heading : 'CGr5'
    @Common.QuickInfo : 'Customer condition group 5'
    CustomerConditionGroup5 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Manual Price'
    @Common.Heading : 'MPr'
    @Common.QuickInfo : 'Status manual price change'
    ManualPriceChangeType : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Price Grp'
    @Common.Heading : 'MPG'
    @Common.QuickInfo : 'Material Price Group'
    MaterialPricingGroup : String(2) not null;
    @Common.Label : 'Exchange Rate Stats.'
    @Common.Heading : 'ExRateStat'
    @Common.QuickInfo : 'Exchange rate for statistics (Exch.rate at time of creation)'
    StatisticsExchangeRate : Decimal(9, 5) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Pricing Ref.Material'
    @Common.Heading : 'Pricing Ref.Matl'
    @Common.QuickInfo : 'Pricing reference material of main item'
    MainItemPricingRefMaterial : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'MnItem MatPricingGrp'
    @Common.Heading : 'MnItem MPG'
    @Common.QuickInfo : 'Material pricing group of main item'
    MainItemMaterialPricingGroup : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Overtime Category'
    TimeSheetOvertimeCategory : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Departure Ctry/Reg.'
    @Common.Heading : 'DeCR'
    @Common.QuickInfo : 'Departure Country/Region (from which the goods are sent)'
    DepartureCountry : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Jurisdiction'
    @Common.Heading : 'Tax Jur.'
    TaxJurisdiction : String(15) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class. Material'
    @Common.Heading : 'TxMt1'
    @Common.QuickInfo : 'Tax Classification of Material'
    ProductTaxClassification1 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.2 Material'
    @Common.Heading : 'Tx2Mt'
    @Common.QuickInfo : 'Tax Classification 2 for Material'
    ProductTaxClassification2 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.3 Material'
    @Common.Heading : 'Tx3Mt'
    @Common.QuickInfo : 'Tax Classification 3 for Material'
    ProductTaxClassification3 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.4 Material'
    @Common.Heading : 'Tx4Mt'
    @Common.QuickInfo : 'Tax Classification 4 for Material'
    ProductTaxClassification4 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.5 Material'
    @Common.Heading : 'Tx5Mt'
    @Common.QuickInfo : 'Tax Classification 5 for Material'
    ProductTaxClassification5 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.6 Material'
    @Common.Heading : 'Tx6Mt'
    @Common.QuickInfo : 'Tax Classification 6 for Material'
    ProductTaxClassification6 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.7 Material'
    @Common.Heading : 'Tx7Mt'
    @Common.QuickInfo : 'Tax Classification 7 for Material'
    ProductTaxClassification7 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.8 Material'
    @Common.Heading : 'Tx8Mt'
    @Common.QuickInfo : 'Tax Classification 8 for Material'
    ProductTaxClassification8 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Class.9 Material'
    @Common.Heading : 'Tx9Mt'
    @Common.QuickInfo : 'Tax Classification 9 for Material'
    ProductTaxClassification9 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Reason 0 VAT'
    @Common.Heading : 'RZ'
    @Common.QuickInfo : 'Reason for Zero VAT'
    ZeroVATRsn : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Code'
    @Common.Heading : 'Tx'
    @Common.QuickInfo : 'Tax on sales/purchases code'
    TaxCode : String(2) not null;
    @Common.Label : 'Tax Rate Valid-From'
    @Common.QuickInfo : 'Valid-From Date of the Tax Rate'
    TaxRateValidityStartDate : Date;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Cash Disc. Bas.'
    @Common.Heading : 'CashDiscount Basis'
    @Common.QuickInfo : 'Amount eligible for cash discount in document currency'
    EligibleAmountForCashDiscount : Decimal(precision: 13) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Business Area'
    @Common.Heading : 'BusA'
    BusinessArea : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Profit Center'
    @Common.Heading : 'Profit Ctr'
    ProfitCenter : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Order'
    @Common.QuickInfo : 'Order Number'
    OrderID : String(12) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'WBS Internal ID'
    @Common.Heading : 'WBS Elem'
    @Common.QuickInfo : 'WBS Element'
    WBSElementInternalID : String(8) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Provider Contract'
    @Common.QuickInfo : 'Identification of a Provider Contract'
    ProviderContract : String(20) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Provider Contract Item'
    ProviderContractItem : String(6) not null;
    @Common.Label : 'Per. of Perf. Start'
    @Common.Heading : 'Start Date'
    @Common.QuickInfo : 'Period of Performance Start Date'
    BillingPerformancePeriodStrDte : Date;
    @Common.Label : 'Per. of Perf. End'
    @Common.Heading : 'End Date'
    @Common.QuickInfo : 'Period of Performance End Date'
    BillingPerformancePeriodEndDte : Date;
    @Common.IsUpperCase : true
    @Common.Label : 'Controlling Area'
    @Common.Heading : 'COAr'
    ControllingArea : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Cost Center'
    @Common.Heading : 'Cost Ctr'
    CostCenter : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Originating Document'
    @Common.Heading : 'OriginDoc.'
    OriginSDDocument : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Originating Item'
    @Common.Heading : 'Orig .Item'
    OriginSDDocumentItem : String(6) not null;
    @Common.Label : 'Translation Date'
    @Common.Heading : 'TranslDate'
    PriceDetnExchangeRateDate : Date;
    @Common.IsUpperCase : true
    @Common.Label : 'Acct Assmt Grp Mat.'
    @Common.Heading : 'AAGM'
    @Common.QuickInfo : 'Account Assignment Group for Material'
    MatlAccountAssignmentGroup : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Reference Document'
    @Common.Heading : 'Ref. Doc.'
    @Common.QuickInfo : 'Document Number of Reference Document'
    ReferenceSDDocument : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Reference Item'
    @Common.Heading : 'RefItm'
    @Common.QuickInfo : 'Item number of the reference item'
    ReferenceSDDocumentItem : String(6) not null;
    @Common.Label : 'Ref. Doc. Category'
    @Common.Heading : 'RDCat'
    @Common.QuickInfo : 'Reference Document Category'
    ReferenceSDDocumentCategory : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Document'
    @Common.Heading : 'Sales Doc.'
    SalesDocument : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Sales Document Item'
    @Common.Heading : 'Item'
    SalesDocumentItem : String(6) not null;
    @Common.Label : 'Sales Doc. Category'
    @Common.Heading : 'Doc.Cat.'
    @Common.QuickInfo : 'Sales Document Category'
    SalesSDDocumentCategory : String(4) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Higher-Level Item'
    @Common.Heading : 'HgLvIt'
    @Common.QuickInfo : 'Higher-Level Item in Bill of Material Structures'
    HigherLevelItem : String(6) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Partner Item'
    @Common.Heading : 'ParItm'
    @Common.QuickInfo : 'Item Number in the Partner Segment'
    BillingDocumentItemInPartSgmt : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Ext. Reference Document'
    @Common.QuickInfo : 'External Reference Document'
    ExternalReferenceDocument : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Ext. Reference Doc. Item'
    @Common.QuickInfo : 'External Reference Document Item of Bllg Process Doc. Item'
    BillingDocExtReferenceDocItem : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Prelimin. Bill. Doc.'
    @Common.Heading : 'Preliminary Billing Document'
    @Common.QuickInfo : 'Preliminary Billing Document'
    PrelimBillingDocument : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Prelimin. Doc. Item'
    @Common.Heading : 'Preliminary Billing Document Item'
    @Common.QuickInfo : 'Preliminary Billing Document Item'
    PrelimBillingDocumentItem : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Group'
    @Common.Heading : 'SGrp'
    SalesGroup : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Group 1'
    @Common.Heading : 'Grp1'
    AdditionalCustomerGroup1 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Group 2'
    @Common.Heading : 'Grp2'
    AdditionalCustomerGroup2 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Group 3'
    @Common.Heading : 'Grp3'
    AdditionalCustomerGroup3 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Group 4'
    @Common.Heading : 'Grp4'
    AdditionalCustomerGroup4 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Group 5'
    @Common.Heading : 'Grp5'
    AdditionalCustomerGroup5 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Order Reason'
    @Common.Heading : 'OrdRs'
    @Common.QuickInfo : 'Order Reason (Reason for the Business Transaction)'
    SDDocumentReason : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Retail Promotion'
    @Common.Heading : 'Promotion'
    RetailPromotion : String(10) not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Rebate Basis'
    @Common.Heading : 'Reb. Basis'
    @Common.QuickInfo : 'Rebate Basis 1'
    RebateBasisAmount : Decimal(precision: 13) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Volume Rebate Group'
    @Common.Heading : 'VRG'
    @Common.QuickInfo : 'Volume rebate group'
    VolumeRebateGroup : String(2) not null;
    @Common.Label : 'Credit Funct. Active'
    @Common.Heading : 'Credit Active'
    @Common.QuickInfo : 'ID: Item with active credit function / relevant for credit'
    ItemIsRelevantForCredit : Boolean not null;
    @Measures.ISOCurrency : TransactionCurrency
    @Common.Label : 'Credit Price'
    @Common.QuickInfo : 'Item credit price'
    CreditRelatedPrice : Decimal(precision: 11) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Deal'
    SalesDeal : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Promotion'
    SalesPromotion : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Distr. Order'
    @Common.Heading : 'DisO'
    @Common.QuickInfo : 'Sales district of sales order'
    SalesOrderSalesDistrict : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Grp Order'
    @Common.Heading : 'CGrO'
    @Common.QuickInfo : 'Customer group of sales order'
    SalesOrderCustomerGroup : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Price Group of Order'
    @Common.Heading : 'PO'
    @Common.QuickInfo : 'Price group of sales order'
    SalesOrderCustomerPriceGroup : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Price List Order'
    @Common.Heading : 'PO'
    @Common.QuickInfo : 'Price list type of sales order'
    SalesOrderPriceListType : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Org. of Order'
    @Common.Heading : 'SOOrd'
    @Common.QuickInfo : 'Sales organization of sales order'
    SalesOrderSalesOrganization : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Distr. Channel Order'
    @Common.Heading : 'DCOr'
    @Common.QuickInfo : 'Distribution channel of sales order'
    SalesOrderDistributionChannel : String(2) not null;
    @Common.Label : 'SalesDocumentRefer'
    @Common.Heading : 'Sales document was created from reference'
    @Common.QuickInfo : 'Sales document was created from reference'
    SalesDocIsCreatedFromReference : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Shipping Point'
    @Common.Heading : 'ShPt'
    @Common.QuickInfo : 'Shipping Point / Receiving Point'
    ShippingPoint : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Service Doc. Type'
    @Common.Heading : 'Service Document Type'
    @Common.QuickInfo : 'Service Document Type'
    ServiceDocumentType : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Service Document'
    @Common.QuickInfo : 'Service Document ID'
    ServiceDocument : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Service Doc. Item'
    @Common.Heading : 'Service Document Item'
    @Common.QuickInfo : 'Service Document Item ID'
    ServiceDocumentItem : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Solution Order'
    BusinessSolutionOrder : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Solution Order Item'
    BusinessSolutionOrderItem : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Usage of HL Item'
    @Common.QuickInfo : 'ID for higher-level item usage'
    HigherLevelItemUsage : String(1) not null;
    _BillingDocument : Association to one BillingDocument {  };
  };
};

