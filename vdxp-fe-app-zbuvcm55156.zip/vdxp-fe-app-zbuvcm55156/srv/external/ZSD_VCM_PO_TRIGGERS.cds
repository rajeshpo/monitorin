/* checksum : bf674a3ffa047861b6520244f2d600b5 */
@cds.external : true
@CodeList.CurrencyCodes.Url : '../../../../default/iwbep/common/0001/$metadata'
@CodeList.CurrencyCodes.CollectionPath : 'Currencies'
@CodeList.UnitsOfMeasure.Url : '../../../../default/iwbep/common/0001/$metadata'
@CodeList.UnitsOfMeasure.CollectionPath : 'UnitsOfMeasure'
@Aggregation.ApplySupported.Transformations : [ 'aggregate', 'groupby', 'filter' ]
@Aggregation.ApplySupported.Rollup : #None
@Common.ApplyMultiUnitBehaviorForSortingAndFiltering : true
@Capabilities.FilterFunctions : [
  'eq',
  'ne',
  'gt',
  'ge',
  'lt',
  'le',
  'and',
  'or',
  'contains',
  'startswith',
  'endswith',
  'any',
  'all'
]
@Capabilities.SupportedFormats : [ 'application/json', 'application/pdf' ]
@PDF.Features.DocumentDescriptionReference : '../../../../default/iwbep/common/0001/$metadata'
@PDF.Features.DocumentDescriptionCollection : 'MyDocumentDescriptions'
@PDF.Features.ArchiveFormat : true
@PDF.Features.Border : true
@PDF.Features.CoverPage : true
@PDF.Features.FitToPage : true
@PDF.Features.FontName : true
@PDF.Features.FontSize : true
@PDF.Features.Margin : true
@PDF.Features.Padding : true
@PDF.Features.Signature : true
@PDF.Features.HeaderFooter : true
@PDF.Features.ResultSizeDefault : 20000
@PDF.Features.ResultSizeMaximum : 20000
@Capabilities.KeyAsSegmentSupported : true
@Capabilities.AsynchronousRequestsSupported : true
service ZSD_VCM_PO_TRIGGERS {
  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'CDS for PO Event change data'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity CDPOS {
    @Common.IsUpperCase : true
    @Common.Label : 'Object Value'
    key ChangeDocObject : String(90) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Table Name'
    key DatabaseTable : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Table Key'
    @Common.QuickInfo : 'Changed table record key'
    key ChangeDocTableKey : String(70) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Field Name'
    key ChangeDocDatabaseTableField : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'New Value'
    @Common.QuickInfo : 'New Content of Changed Field'
    ChangeDocNewFieldValue : String(254) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Old Value'
    @Common.QuickInfo : 'Old Content of Changed Field'
    ChangeDocPreviousFieldValue : String(254) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Address 2 Details for VCM PO Triggers'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity FetchADRC {
    @Common.IsUpperCase : true
    @Common.Label : 'Address Number'
    @Common.Heading : 'Addr. No.'
    key AddressID : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Person Number'
    @Common.Heading : 'Person'
    key AddressPersonID : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address Version'
    @Common.Heading : 'Version'
    @Common.QuickInfo : 'Version ID for International Addresses'
    key AddressRepresentationCode : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address Type'
    @Common.Heading : 'Type'
    @Common.QuickInfo : 'Address type (1=Organization, 2=Person, 3=Contact person)'
    AddressObjectType : String(1) not null;
    @Common.Label : 'Language Key'
    @Common.Heading : 'Language'
    CorrespondenceLanguage : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Comm. Method'
    @Common.QuickInfo : 'Communication Method (Key) (Business Address Services)'
    PrfrdCommMediumType : String(3) not null;
    @Common.Label : 'Full Name'
    @Common.QuickInfo : 'Full Name of Person'
    AddresseeFullName : String(80) not null;
    @Common.Label : 'First Name'
    PersonGivenName : String(40) not null;
    @Common.Label : 'Last Name'
    PersonFamilyName : String(40) not null;
    @Common.Label : 'Name'
    @Common.QuickInfo : 'Name 1'
    OrganizationName1 : String(40) not null;
    @Common.Label : 'Name 2'
    OrganizationName2 : String(40) not null;
    @Common.Label : 'Name 3'
    OrganizationName3 : String(40) not null;
    @Common.Label : 'Name 4'
    OrganizationName4 : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Search Term 1'
    AddressSearchTerm1 : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Search Term 2'
    AddressSearchTerm2 : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'City Code'
    @Common.QuickInfo : 'City code for city/street file'
    CityNumber : String(12) not null;
    @Common.Label : 'City'
    CityName : String(40) not null;
    @Common.Label : 'District'
    DistrictName : String(40) not null;
    @Common.Label : 'Different City'
    @Common.Heading : 'City (Diff. from Postal City)'
    @Common.QuickInfo : 'City (different from postal city)'
    VillageName : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Postal Code'
    @Common.Heading : 'Postl Code'
    @Common.QuickInfo : 'City postal code'
    PostalCode : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Company Postal Code'
    @Common.Heading : 'Postl Code'
    @Common.QuickInfo : 'Company Postal Code (for Large Customers)'
    CompanyPostalCode : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Street Code'
    @Common.QuickInfo : 'Street Number for City/Street File'
    Street : String(12) not null;
    @Common.Label : 'Street'
    StreetName : String(60) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Undeliverable'
    @Common.QuickInfo : 'Street Address Undeliverable Flag'
    StreetAddrNonDeliverableReason : String(4) not null;
    @Common.Label : 'Street 2'
    StreetPrefixName1 : String(40) not null;
    @Common.Label : 'Street 3'
    StreetPrefixName2 : String(40) not null;
    @Common.Label : 'Street 4'
    StreetSuffixName1 : String(40) not null;
    @Common.Label : 'Street 5'
    StreetSuffixName2 : String(40) not null;
    @Common.Label : 'House Number'
    @Common.Heading : 'House No.'
    HouseNumber : String(10) not null;
    @Common.Label : 'Supplement'
    @Common.QuickInfo : 'House number supplement'
    HouseNumberSupplementText : String(10) not null;
    @Common.Label : 'Building Code'
    @Common.Heading : 'Building'
    @Common.QuickInfo : 'Building (Number or Code)'
    Building : String(20) not null;
    @Common.Label : 'Floor'
    @Common.QuickInfo : 'Floor in building'
    Floor : String(10) not null;
    @Common.Label : 'Room Number'
    @Common.Heading : 'Room No.'
    @Common.QuickInfo : 'Room or Apartment Number'
    RoomNumber : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Country/Region Key'
    @Common.Heading : 'C/R'
    Country : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Region'
    @Common.Heading : 'Rg'
    @Common.QuickInfo : 'Region (State, Province, County)'
    Region : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Title Key'
    @Common.Heading : 'Key'
    @Common.QuickInfo : 'Form-of-Address Key'
    FormOfAddress : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Jurisdiction'
    TaxJurisdiction : String(15) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Transportation Zone'
    @Common.Heading : 'TranspZone'
    @Common.QuickInfo : 'Transportation zone to or from which the goods are delivered'
    TransportZone : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'PO Box'
    POBox : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Undeliverable'
    @Common.QuickInfo : 'PO Box Address Undeliverable Flag'
    POBoxAddrNonDeliverableReason : String(4) not null;
    @Common.Label : 'PO Box w/o No.'
    @Common.Heading : 'PO'
    @Common.QuickInfo : 'Flag: PO Box Without Number'
    POBoxIsWithoutNumber : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'PO Box Postal Code'
    @Common.Heading : 'Postl Code'
    POBoxPostalCode : String(10) not null;
    @Common.Label : 'PO Box Lobby'
    POBoxLobbyName : String(40) not null;
    @Common.Label : 'PO Box City'
    @Common.QuickInfo : 'PO Box city'
    POBoxDeviatingCityName : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'City Code'
    @Common.QuickInfo : 'City PO box code (City file)'
    POBoxDeviatingCityCode : String(12) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'PO Box Region'
    @Common.Heading : 'PO Region'
    @Common.QuickInfo : 'Region for PO Box (Country/Region, State, Province, ...)'
    POBoxDeviatingRegion : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'PO Box Ctry/Region'
    @Common.Heading : 'PO C/R'
    @Common.QuickInfo : 'PO Box of Country/Region'
    POBoxDeviatingCountry : String(3) not null;
    @Common.Label : 'c/o'
    @Common.Heading : 'c/o name'
    @Common.QuickInfo : 'c/o name'
    CareOfName : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Delvry Serv Type'
    @Common.QuickInfo : 'Type of Delivery Service'
    DeliveryServiceTypeCode : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Delivery Service No.'
    @Common.Heading : 'Delivery Service Number'
    @Common.QuickInfo : 'Number of Delivery Service'
    DeliveryServiceNumber : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Time Zone'
    @Common.Heading : 'Zone'
    @Common.QuickInfo : 'Address Time Zone'
    AddressTimeZone : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'County code'
    @Common.QuickInfo : 'County code for county'
    SecondaryRegion : String(8) not null;
    @Common.Label : 'County'
    SecondaryRegionName : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Township code'
    @Common.QuickInfo : 'Township code for Township'
    TertiaryRegion : String(8) not null;
    @Common.Label : 'Township'
    TertiaryRegionName : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Test stat./City file'
    @Common.Heading : 'Status'
    @Common.QuickInfo : 'City file test status'
    RegionalStructureCheckStatus : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address group'
    @Common.Heading : 'Key'
    @Common.QuickInfo : 'Address Group (Key) (Business Address Services)'
    AddressGroup : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Created By'
    @Common.QuickInfo : 'Created By User'
    AddressCreatedByUser : String(12) not null;
    @odata.Precision : 7
    @odata.Type : 'Edm.DateTimeOffset'
    @Common.Label : 'Created On'
    @Common.QuickInfo : 'Creation Date Time'
    AddressCreatedOnDateTime : Timestamp;
    @Common.IsUpperCase : true
    @Common.Label : 'Changed By'
    @Common.QuickInfo : 'Last Changed By User'
    AddressChangedByUser : String(12) not null;
    @odata.Precision : 7
    @odata.Type : 'Edm.DateTimeOffset'
    @Common.Label : 'Changed On'
    @Common.QuickInfo : 'Last Change Date Time'
    AddressChangedOnDateTime : Timestamp;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Purchase Order Item'
  @Common.SemanticKey : [ 'PurchaseOrderItem', 'PurchaseOrder' ]
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  @Capabilities.FilterRestrictions.FilterExpressionRestrictions : [
    { Property: ProductPurchasePointsQty, AllowedExpressions: 'MultiValue' },
    { Property: NetPriceQuantity, AllowedExpressions: 'MultiValue' },
    { Property: NetAmount, AllowedExpressions: 'MultiValue' },
    { Property: GrossAmount, AllowedExpressions: 'MultiValue' },
    { Property: EffectiveAmount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal1Amount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal2Amount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal3Amount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal4Amount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal5Amount, AllowedExpressions: 'MultiValue' },
    { Property: Subtotal6Amount, AllowedExpressions: 'MultiValue' },
    { Property: OrderQuantity, AllowedExpressions: 'MultiValue' },
    { Property: NetPriceAmount, AllowedExpressions: 'MultiValue' },
    { Property: ItemVolume, AllowedExpressions: 'MultiValue' },
    { Property: ItemGrossWeight, AllowedExpressions: 'MultiValue' },
    { Property: ItemNetWeight, AllowedExpressions: 'MultiValue' },
    {
      Property: NonDeductibleInputTaxAmount,
      AllowedExpressions: 'MultiValue'
    },
    {
      Property: PurgDocReleaseOrderQuantity,
      AllowedExpressions: 'MultiValue'
    },
    { Property: DownPaymentAmount, AllowedExpressions: 'MultiValue' },
    {
      Property: ExpectedOverallLimitAmount,
      AllowedExpressions: 'MultiValue'
    },
    { Property: OverallLimitAmount, AllowedExpressions: 'MultiValue' }
  ]
  entity FetchEKPO {
    @Common.IsUpperCase : true
    @Common.Label : 'Purchase Order'
    @Common.Heading : 'Purchase Order Number'
    @Common.QuickInfo : 'Purchase Order Number'
    key PurchaseOrder : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Purchase Order Item'
    @Common.Heading : 'Item Number of Purchase Order'
    @Common.QuickInfo : 'Item Number of Purchase Order'
    key PurchaseOrderItem : String(5) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Document Item'
    @Common.Heading : 'Item'
    @Common.QuickInfo : 'Concatenation of EBELN and EBELP'
    PurchaseOrderItemUniqueID : String(15) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Purch. Doc. Category'
    @Common.Heading : 'Cat'
    @Common.QuickInfo : 'Purchasing Document Category'
    PurchaseOrderCategory : String(1) not null;
    @Common.IsCurrency : true
    @Common.IsUpperCase : true
    @Common.Label : 'Currency'
    @Common.Heading : 'Crcy'
    @Common.QuickInfo : 'Currency Key'
    DocumentCurrency : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Deletion Indicator'
    @Common.Heading : 'D'
    @Common.QuickInfo : 'Deletion Indicator in Purchasing Document'
    PurchasingDocumentDeletionCode : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Origin'
    @Common.Heading : 'O'
    @Common.QuickInfo : 'Origin of a Purchasing Document Item'
    PurchasingDocumentItemOrigin : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Group'
    @Common.Heading : 'Matl Group'
    MaterialGroup : String(9) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material'
    @Common.QuickInfo : 'Material Number'
    Material : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Type'
    @Common.Heading : 'MTyp'
    MaterialType : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier Mat. No.'
    @Common.Heading : 'Supplier Material Number'
    @Common.QuickInfo : 'Material Number Used by Supplier'
    SupplierMaterialNumber : String(35) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier Subrange'
    @Common.Heading : 'SSR'
    SupplierSubrange : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Mfr Part Number'
    @Common.Heading : 'MPN'
    @Common.QuickInfo : 'Manufacturer Part Number'
    ManufacturerPartNmbr : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Manufacturer'
    @Common.Heading : 'Manufact.'
    @Common.QuickInfo : 'Number of a Manufacturer'
    Manufacturer : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material'
    @Common.QuickInfo : 'Material number'
    ManufacturerMaterial : String(18) not null;
    @Common.Label : 'Short Text'
    PurchaseOrderItemText : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Product Type Group'
    @Common.Heading : 'Product Type Grp'
    ProductType : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Company Code'
    @Common.Heading : 'CoCd'
    CompanyCode : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    Plant : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address'
    @Common.QuickInfo : 'Manual address number in purchasing document item'
    ManualDeliveryAddressID : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address'
    @Common.QuickInfo : 'Number of delivery address'
    ReferenceDeliveryAddressID : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer'
    Customer : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier'
    @Common.QuickInfo : 'Supplier to be Supplied/Who is to Receive Delivery'
    Subcontractor : String(10) not null;
    @Common.Label : 'SC Supplier'
    @Common.Heading : 'S'
    @Common.QuickInfo : 'Subcontracting Supplier'
    SupplierIsSubcontractor : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Cross-plant CM'
    @Common.QuickInfo : 'Cross-Plant Configurable Material'
    CrossPlantConfigurableProduct : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Category'
    @Common.Heading : 'Ct'
    ArticleCategory : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Kanban Indicator'
    PlndOrderReplnmtElmntType : String(1) not null;
    @Common.IsUnit : true
    @Common.Label : 'Points Unit'
    @Common.Heading : 'PUn'
    ProductPurchasePointsQtyUnit : String(3) not null;
    @Measures.Unit : ProductPurchasePointsQtyUnit
    @Common.Label : 'Points'
    @Common.QuickInfo : 'Number of Points'
    ProductPurchasePointsQty : Decimal(13, 3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Storage Location'
    StorageLocation : String(4) not null;
    @Common.IsUnit : true
    @Common.Label : 'Order Unit'
    @Common.Heading : 'OUn'
    @Common.QuickInfo : 'Purchase Order Unit of Measure'
    PurchaseOrderQuantityUnit : String(3) not null;
    @Common.Label : 'Equal To'
    @Common.Heading : 'Eq. To'
    @Common.QuickInfo : 'Numerator for Conversion of Order Unit to Base Unit'
    OrderItemQtyToBaseQtyNmrtr : Decimal(precision: 5) not null;
    @Common.Label : 'Denominator'
    @Common.Heading : 'Denom.'
    @Common.QuickInfo : 'Denominator for Conversion of Order Unit to Base Unit'
    OrderItemQtyToBaseQtyDnmntr : Decimal(precision: 5) not null;
    @Measures.Unit : PurchaseOrderQuantityUnit
    @Common.Label : 'Price Unit'
    @Common.Heading : 'Per'
    NetPriceQuantity : Decimal(precision: 5) not null;
    @Common.Label : 'Delivery Completed'
    @Common.Heading : 'DCI'
    @Common.QuickInfo : '"Delivery Completed" Indicator'
    IsCompletelyDelivered : Boolean not null;
    @Common.Label : 'Final Invoice'
    @Common.Heading : 'FIn'
    @Common.QuickInfo : 'Final Invoice Indicator'
    IsFinallyInvoiced : Boolean not null;
    @Common.Label : 'Goods Receipt'
    @Common.Heading : 'GR'
    @Common.QuickInfo : 'Goods Receipt Indicator'
    GoodsReceiptIsExpected : Boolean not null;
    @Common.Label : 'Invoice Receipt'
    @Common.Heading : 'IR'
    @Common.QuickInfo : 'Invoice Receipt Indicator'
    InvoiceIsExpected : Boolean not null;
    @Common.Label : 'GR-Based Inv. Verif.'
    @Common.Heading : 'GR-IV'
    @Common.QuickInfo : 'Indicator: GR-Based Invoice Verification'
    InvoiceIsGoodsReceiptBased : Boolean not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Agreement Item'
    @Common.Heading : 'Item'
    @Common.QuickInfo : 'Item Number of Principal Purchase Agreement'
    PurchaseContractItem : String(5) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Outline agreement'
    @Common.Heading : 'Agmt.'
    @Common.QuickInfo : 'Number of principal purchase agreement'
    PurchaseContract : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Purchase Requisition'
    @Common.Heading : 'Purch.Req.'
    @Common.QuickInfo : 'Purchase Requisition Number'
    PurchaseRequisition : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Req. Tracking Number'
    @Common.Heading : 'TrackingNo'
    @Common.QuickInfo : 'Requirement Tracking Number'
    RequirementTracking : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Item of requisition'
    @Common.Heading : 'Item'
    @Common.QuickInfo : 'Item number of purchase requisition'
    PurchaseRequisitionItem : String(5) not null;
    @Common.Label : 'Eval. Receipt Sett.'
    @Common.Heading : 'E'
    @Common.QuickInfo : 'Evaluated Receipt Settlement (ERS)'
    EvaldRcptSettlmtIsAllowed : Boolean not null;
    @Common.Label : 'Unltd Overdelivery'
    @Common.Heading : 'Unlimited'
    @Common.QuickInfo : 'Unlimited Overdelivery Allowed'
    UnlimitedOverdeliveryIsAllowed : Boolean not null;
    @Common.Label : 'Overdeliv. Tolerance'
    @Common.Heading : 'Overdel. Tol.'
    @Common.QuickInfo : 'Overdelivery Tolerance'
    OverdelivTolrtdLmtRatioInPct : Decimal(3, 1) not null;
    @Common.Label : 'Underdel. Tolerance'
    @Common.Heading : 'Underdel.Tol.'
    @Common.QuickInfo : 'Underdelivery Tolerance'
    UnderdelivTolrtdLmtRatioInPct : Decimal(3, 1) not null;
    @Common.Label : 'Requisitioner'
    @Common.Heading : 'Requisnr.'
    @Common.QuickInfo : 'Name of requisitioner/requester'
    RequisitionerName : String(12) not null;
    @Common.Label : 'Planned Deliv. Time'
    @Common.Heading : 'PTm'
    @Common.QuickInfo : 'Planned Delivery Time in Days'
    PlannedDeliveryDurationInDays : Decimal(precision: 3) not null;
    @Common.Label : 'GR processing time'
    @Common.Heading : 'GRT'
    @Common.QuickInfo : 'Goods receipt processing time in days'
    GoodsReceiptDurationInDays : Decimal(precision: 3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Partial Deliv./Item'
    @Common.Heading : 'PD'
    @Common.QuickInfo : 'Partial Delivery at Item Level (Stock Transfer)'
    PartialDeliveryIsAllowed : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Consumption'
    @Common.Heading : 'Cns'
    @Common.QuickInfo : 'Consumption posting'
    ConsumptionPosting : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Service Performer'
    @Common.Heading : 'SrvPrfm'
    ServicePerformer : String(10) not null;
    @Common.IsUnit : true
    @Common.Label : 'Base Unit of Measure'
    @Common.Heading : 'BUn'
    BaseUnit : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Item Category'
    @Common.Heading : 'I'
    @Common.QuickInfo : 'Item category in purchasing document'
    PurchaseOrderItemCategory : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Profit Center'
    @Common.Heading : 'Profit Ctr'
    ProfitCenter : String(10) not null;
    @Common.IsUnit : true
    @Common.Label : 'Order Price Unit'
    @Common.Heading : 'OPU'
    @Common.QuickInfo : 'Order Price Unit (Purchasing)'
    OrderPriceUnit : String(3) not null;
    @Common.IsUnit : true
    @Common.Label : 'Volume Unit'
    @Common.Heading : 'VUn'
    ItemVolumeUnit : String(3) not null;
    @Common.IsUnit : true
    @Common.Label : 'Unit of Weight'
    @Common.Heading : 'Un'
    ItemWeightUnit : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Distrib. Indicator'
    @Common.Heading : 'D'
    @Common.QuickInfo : 'Distribution Indicator for Multiple Account Assignment'
    MultipleAcctAssgmtDistribution : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Partial invoice'
    @Common.Heading : 'PIn'
    @Common.QuickInfo : 'Partial invoice indicator'
    PartialInvoiceDistribution : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Pricing Date Control'
    @Common.Heading : 'C'
    @Common.QuickInfo : 'Price Determination (Pricing) Date Control'
    PricingDateControl : String(1) not null;
    @Common.Label : 'Statistical'
    @Common.Heading : 'S'
    @Common.QuickInfo : 'Item is statistical'
    IsStatisticalItem : Boolean not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Higher-Level Item'
    @Common.Heading : 'HLIt'
    @Common.QuickInfo : 'Higher-Level Item in Purchasing Documents'
    PurchasingParentItem : String(5) not null;
    @Common.Label : 'Latest GR Date'
    @Common.Heading : 'GR Date'
    @Common.QuickInfo : 'Latest Possible Goods Receipt'
    GoodsReceiptLatestCreationDate : Date;
    @Common.Label : 'Returns Item'
    @Common.Heading : 'R'
    IsReturnsItem : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Reason for Ordering'
    @Common.Heading : 'OrRea'
    PurchasingOrderReason : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Incoterms'
    @Common.Heading : 'IncoT'
    @Common.QuickInfo : 'Incoterms (Part 1)'
    IncotermsClassification : String(3) not null;
    @Common.Label : 'Incoterms (Part 2)'
    @Common.Heading : 'Inco. 2'
    IncotermsTransferLocation : String(28) not null;
    @Common.Label : 'Incoterms Location 1'
    IncotermsLocation1 : String(70) not null;
    @Common.Label : 'Incoterms Location 2'
    IncotermsLocation2 : String(70) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Prior Supplier'
    @Common.Heading : 'Prior Spp.'
    PriorSupplier : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'EAN/UPC'
    @Common.QuickInfo : 'International Article Number (EAN/UPC)'
    InternationalArticleNumber : String(18) not null;
    @Common.Label : 'Intrastat Srvc. Code'
    @Common.Heading : 'Intrastat Service Code'
    @Common.QuickInfo : 'Intrastat Service Code'
    IntrastatServiceCode : String(30) not null;
    @Common.Label : 'Commodity Code'
    CommodityCode : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Freight Grp'
    @Common.Heading : 'MatFrtGp'
    @Common.QuickInfo : 'Material Freight Group'
    MaterialFreightGroup : String(8) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Qual.f.FreeGoodsDis.'
    @Common.Heading : 'DiK'
    @Common.QuickInfo : 'Material qualifies for discount in kind'
    DiscountInKindEligibility : String(1) not null;
    @Common.Label : 'Shipping block'
    @Common.QuickInfo : 'Item blocked for SD delivery'
    PurgItemIsBlockedForDelivery : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Confirmation Control'
    @Common.Heading : 'Ctr.'
    @Common.QuickInfo : 'Confirmation Control Key'
    SupplierConfirmationControlKey : String(4) not null;
    @Common.Label : 'Print Price'
    @Common.Heading : 'P'
    @Common.QuickInfo : 'Price Printout'
    PriceIsToBePrinted : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Acct Assignment Cat.'
    @Common.Heading : 'A'
    @Common.QuickInfo : 'Account Assignment Category'
    AccountAssignmentCategory : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Purchasing Info Rec.'
    @Common.Heading : 'Info Rec.'
    @Common.QuickInfo : 'Purchasing Info Record Number'
    PurchasingInfoRecord : String(10) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Net Order Value'
    @Common.Heading : 'Net Value'
    @Common.QuickInfo : 'Net Order Value in PO Currency'
    NetAmount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Gross order value'
    @Common.Heading : 'Gross value'
    @Common.QuickInfo : 'Gross order value in PO currency'
    GrossAmount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Effective value'
    @Common.QuickInfo : 'Effective value of item'
    EffectiveAmount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Subtotal 1'
    @Common.QuickInfo : 'Subtotal 1 from Pricing Procedure for Price Element'
    Subtotal1Amount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Subtotal 2'
    @Common.QuickInfo : 'Subtotal 2 from Pricing Procedure for Price Element'
    Subtotal2Amount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Subtotal 3'
    @Common.QuickInfo : 'Subtotal 3 from Pricing Procedure for Price Element'
    Subtotal3Amount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Subtotal 4'
    @Common.QuickInfo : 'Subtotal 4 from Pricing Procedure for Price Element'
    Subtotal4Amount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Subtotal 5'
    @Common.QuickInfo : 'Subtotal 5 from Pricing Procedure for Price Element'
    Subtotal5Amount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Subtotal 6'
    @Common.QuickInfo : 'Subtotal 6 from Pricing Procedure for Price Element'
    Subtotal6Amount : Decimal(precision: 13) not null;
    @Measures.Unit : PurchaseOrderQuantityUnit
    @Common.Label : 'Order Quantity'
    @Common.Heading : 'PO Quantity'
    @Common.QuickInfo : 'Purchase Order Quantity'
    OrderQuantity : Decimal(13, 3) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Net Order Price'
    @Common.Heading : 'Net Price'
    @Common.QuickInfo : 'Net Price in Purchasing Document (in Document Currency)'
    NetPriceAmount : Decimal(precision: 11) not null;
    @Measures.Unit : ItemVolumeUnit
    @Common.Label : 'Volume'
    ItemVolume : Decimal(13, 3) not null;
    @Measures.Unit : ItemWeightUnit
    @Common.Label : 'Gross Weight'
    ItemGrossWeight : Decimal(13, 3) not null;
    @Measures.Unit : ItemWeightUnit
    @Common.Label : 'Net Weight'
    ItemNetWeight : Decimal(13, 3) not null;
    @Common.Label : 'Quantity Conversion'
    @Common.Heading : 'Conv.'
    @Common.QuickInfo : 'Numerator for Conversion of Order Price Unit into Order Unit'
    OrderPriceUnitToOrderUnitNmrtr : Decimal(precision: 5) not null;
    @Common.Label : 'Quantity Conversion'
    @Common.Heading : 'Conv.'
    @Common.QuickInfo : 'Denominator for Conv. of Order Price Unit into Order Unit'
    OrdPriceUnitToOrderUnitDnmntr : Decimal(precision: 5) not null;
    @Common.Label : 'GR Non-Valuated'
    @Common.Heading : 'N'
    @Common.QuickInfo : 'Goods Receipt, Non-Valuated'
    GoodsReceiptIsNonValuated : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Code'
    @Common.Heading : 'Tx'
    @Common.QuickInfo : 'Tax on sales/purchases code'
    TaxCode : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Jurisdiction'
    @Common.Heading : 'Tax Jur.'
    TaxJurisdiction : String(15) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Shipping Instr.'
    @Common.Heading : 'SI'
    @Common.QuickInfo : 'Shipping Instructions'
    ShippingInstruction : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Shipping Type'
    @Common.Heading : 'ST'
    ShippingType : String(2) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Non-deductible'
    @Common.QuickInfo : 'Non-deductible input tax'
    NonDeductibleInputTaxAmount : Decimal(precision: 13) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Stock Type'
    @Common.Heading : 'T'
    StockType : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Valuation Type'
    @Common.Heading : 'Val. Type'
    ValuationType : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Valuation Category'
    @Common.Heading : 'ValCat'
    ValuationCategory : String(1) not null;
    @Common.Label : 'Rejection Indicator'
    @Common.Heading : 'R'
    ItemIsRejectedBySupplier : Boolean not null;
    @Common.Label : 'Price Date'
    @Common.QuickInfo : 'Date of Price Determination'
    PurgDocPriceDate : Date;
    @Measures.Unit : PurchaseOrderQuantityUnit
    @Common.Label : 'Stand.Rel.Order.Qty.'
    @Common.Heading : 'Quantity'
    @Common.QuickInfo : 'Standard release order quantity'
    PurgDocReleaseOrderQuantity : Decimal(13, 3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Earmarked Funds'
    @Common.Heading : 'Earm. Fnds'
    @Common.QuickInfo : 'Document Number for Earmarked Funds'
    EarmarkedFunds : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Earmarked Funds'
    @Common.Heading : 'Earm. Fnds'
    @Common.QuickInfo : 'Document Number for Earmarked Funds'
    EarmarkedFundsDocument : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Document Item'
    @Common.Heading : 'Itm'
    @Common.QuickInfo : 'Earmarked Funds: Document Item'
    EarmarkedFundsItem : String(3) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Document Item'
    @Common.Heading : 'Itm'
    @Common.QuickInfo : 'Earmarked Funds: Document Item'
    EarmarkedFundsDocumentItem : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Bus.area:prtner'
    @Common.Heading : 'BA:P'
    @Common.QuickInfo : 'Business area reported to the partner'
    PartnerReportedBusinessArea : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Special Stock'
    @Common.Heading : 'S'
    @Common.QuickInfo : 'Special Stock Indicator'
    InventorySpecialStockType : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Del. Type f. Returns'
    @Common.Heading : 'Del. Type Returns'
    @Common.QuickInfo : 'Delivery Type for Returns to Supplier'
    DeliveryDocumentType : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Issuing Storage Loc.'
    @Common.Heading : 'IStLoc'
    @Common.QuickInfo : 'Issuing Storage Location for Stock Transport Order'
    IssuingStorageLocation : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Allocation Table'
    @Common.Heading : 'Alloc.Tab.'
    AllocationTable : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Item'
    @Common.Heading : 'Itm'
    @Common.QuickInfo : 'Allocation Table Item'
    AllocationTableItem : String(5) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Retail Promotion'
    @Common.Heading : 'Promotion'
    RetailPromotion : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Down Payment'
    @Common.QuickInfo : 'Down Payment Indicator'
    DownPaymentType : String(4) not null;
    @Common.Label : 'Down Payment %'
    @Common.Heading : 'Down Payt Percentage'
    @Common.QuickInfo : 'Down Payment Percentage'
    DownPaymentPercentageOfTotAmt : Decimal(5, 2) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Down Payment Amount'
    @Common.QuickInfo : 'Down Payment Amount in Document Currency'
    DownPaymentAmount : Decimal(precision: 11) not null;
    @Common.Label : 'Due Date for DP'
    @Common.Heading : 'Due Date for Down Payment'
    @Common.QuickInfo : 'Due Date for Down Payment'
    DownPaymentDueDate : Date;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Expected Value'
    @Common.QuickInfo : 'Expected Value of Overall Limit'
    ExpectedOverallLimitAmount : Decimal(precision: 13) not null;
    @Measures.ISOCurrency : DocumentCurrency
    @Common.Label : 'Overall Limit'
    OverallLimitAmount : Decimal(precision: 13) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Requirement Segment'
    RequirementSegment : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Dangerous Goods Sts'
    @Common.Heading : 'Dngrs Goods Sts'
    @Common.QuickInfo : 'Dangerous Goods Status (Item)'
    PurgProdCmplncDngrsGoodsStatus : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier Check Sts'
    @Common.Heading : 'Supplier Ck Sts'
    @Common.QuickInfo : 'Product Compliance Supplier Check Status (Item)'
    PurgProdCmplncSupplierStatus : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Prod. Marktablty Sts'
    @Common.Heading : 'ProdMarktabltyS'
    @Common.QuickInfo : 'Product Marketability Status (Item)'
    PurgProductMarketabilityStatus : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sfty Data Sheet Sts'
    @Common.Heading : 'SftyDataSheetS'
    @Common.QuickInfo : 'Safety Data Sheet Status (Item)'
    PurgSafetyDataSheetStatus : String(1) not null;
    @Common.Label : 'Real-Time Cons.Post.'
    @Common.QuickInfo : 'Real-Time Consumption Posting of Subcontracting Components'
    SubcontrgCompIsRealTmeCnsmd : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Origin'
    @Common.Heading : 'O'
    @Common.QuickInfo : 'Origin of the material'
    BR_MaterialOrigin : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material Usage'
    @Common.QuickInfo : 'Usage of the material'
    BR_MaterialUsage : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Mat. CFOP category'
    @Common.Heading : 'MC'
    @Common.QuickInfo : 'Material CFOP category'
    BR_CFOPCategory : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'NCM Code'
    @Common.QuickInfo : 'Brazilian NCM Code'
    BR_NCM : String(16) not null;
    @Common.Label : 'Produced in-house'
    @Common.Heading : 'P'
    BR_IsProducedInHouse : Boolean not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Customer'
  @Common.SAPObjectNodeType.Name : 'Customer'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity FetchKNA1 {
    @Common.Text : CustomerName
    @Common.IsUpperCase : true
    @Common.Label : 'Customer'
    @Common.QuickInfo : 'Customer Number'
    key Customer : String(10) not null;
    @Common.Label : 'Name of Customer'
    @Common.Heading : 'Customer'
    CustomerName : String(80) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Name'
    @Common.QuickInfo : 'Customer Full Name'
    CustomerFullName : String(220) not null;
    @Common.Label : 'Name of Customer'
    @Common.Heading : 'Customer'
    @Common.QuickInfo : 'Customer Name'
    BPCustomerName : String(81) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Name'
    @Common.QuickInfo : 'Customer Full Name'
    BPCustomerFullName : String(220) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Created by'
    @Common.QuickInfo : 'Name of Person who Created the Object'
    CreatedByUser : String(12) not null;
    @Common.Label : 'Created On'
    @Common.Heading : 'Date'
    @Common.QuickInfo : 'Record Created On'
    CreationDate : Date;
    @Common.IsUpperCase : true
    @Common.Label : 'Address'
    AddressID : String(10) not null;
    @Common.Text : CustomerClassification_Text
    @Common.IsUpperCase : true
    @Common.Label : 'Customer Classific.'
    @Common.Heading : 'Cl'
    @Common.QuickInfo : 'Customer Classification'
    CustomerClassification : String(2) not null;
    @Core.Computed : true
    @Common.Label : 'Customer Classification Description'
    CustomerClassification_Text : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'VAT Registration No.'
    @Common.QuickInfo : 'VAT Registration Number'
    VATRegistration : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Account group'
    @Common.Heading : 'Group'
    @Common.QuickInfo : 'Customer Account Group'
    CustomerAccountGroup : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Authorization'
    @Common.Heading : 'AuGr'
    @Common.QuickInfo : 'Authorization Group'
    AuthorizationGroup : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Delivery block'
    @Common.Heading : 'DlvBl'
    @Common.QuickInfo : 'Central delivery block for the customer'
    DeliveryIsBlocked : String(2) not null;
    @Common.Label : 'Posting Block'
    @Common.Heading : 'B'
    @Common.QuickInfo : 'Central posting block'
    PostingIsBlocked : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Billing block'
    @Common.Heading : 'BlBlk'
    @Common.QuickInfo : 'Central billing block for customer'
    BillingIsBlockedForCustomer : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Order block'
    @Common.Heading : 'OrBlk'
    @Common.QuickInfo : 'Central order block for customer'
    OrderIsBlockedForCustomer : String(2) not null;
    @Common.QuickInfo : 'International Location Number (Part 1)'
    @Common.IsDigitSequence : true
    @Common.Label : 'Int. location no. 1'
    @Common.Heading : 'ILN 1'
    InternationalLocationNumber1 : String(7) not null;
    @Common.Label : 'One-time account'
    @Common.QuickInfo : 'Indicator: Is the account a one-time account?'
    IsOneTimeAccount : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Jurisdiction'
    @Common.Heading : 'Tax Jur.'
    TaxJurisdiction : String(15) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Industry'
    @Common.Heading : 'Indust.'
    @Common.QuickInfo : 'Industry Key'
    Industry : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax number type'
    @Common.Heading : 'Tax no.ty.'
    @Common.QuickInfo : 'Tax Number Type'
    TaxNumberType : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 1'
    TaxNumber1 : String(16) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 2'
    TaxNumber2 : String(11) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 3'
    TaxNumber3 : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 4'
    TaxNumber4 : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 5'
    TaxNumber5 : String(60) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 6'
    TaxNumber6 : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Group key'
    @Common.Heading : 'Group'
    CustomerCorporateGroup : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier'
    @Common.QuickInfo : 'Account Number of Supplier'
    Supplier : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Nielsen indicator'
    @Common.Heading : 'NS'
    @Common.QuickInfo : 'Nielsen ID'
    NielsenRegion : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Industry code 1'
    @Common.Heading : 'Ind.code 1'
    IndustryCode1 : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Industry code 2'
    @Common.Heading : 'Ind.code 2'
    IndustryCode2 : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Industry code 3'
    @Common.Heading : 'Ind.code 3'
    IndustryCode3 : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Industry code 4'
    @Common.Heading : 'Ind.code 4'
    IndustryCode4 : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Industry code 5'
    @Common.Heading : 'Ind.code 5'
    IndustryCode5 : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Country/Region Key'
    Country : String(3) not null;
    @Common.Label : 'Name'
    @Common.Heading : 'Name 1'
    @Common.QuickInfo : 'Name 1'
    OrganizationBPName1 : String(35) not null;
    @Common.Label : 'Name 2'
    OrganizationBPName2 : String(35) not null;
    @Common.Label : 'City'
    CityName : String(35) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Postal Code'
    @Common.Heading : 'PostalCode'
    PostalCode : String(10) not null;
    @Common.Label : 'Street'
    @Common.QuickInfo : 'Street and House Number'
    StreetName : String(35) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Search term'
    @Common.Heading : 'SearchTerm'
    @Common.QuickInfo : 'Sort field'
    SortField : String(10) not null;
    @Common.Label : 'Fax Number'
    FaxNumber : String(31) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Suframa Code'
    BR_SUFRAMACode : String(9) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Region'
    @Common.Heading : 'Rg'
    @Common.QuickInfo : 'Region (State, Province, County)'
    Region : String(3) not null;
    @Common.Label : 'Telephone 1'
    @Common.QuickInfo : 'First telephone number'
    TelephoneNumber1 : String(16) not null;
    @Common.Label : 'Telephone 2'
    @Common.QuickInfo : 'Second telephone number'
    TelephoneNumber2 : String(16) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Alternative Payer'
    @Common.Heading : 'Alt. Payer'
    @Common.QuickInfo : 'Account Number of an Alternative Payer'
    AlternativePayerAccount : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'DME Recipient Code'
    @Common.Heading : 'R'
    @Common.QuickInfo : 'Recipient Code for Data Medium Exchange'
    DataMediumExchangeIndicator : String(1) not null;
    @Common.Label : 'Liable for VAT'
    VATLiability : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Purpose Completed'
    @Common.Heading : 'Business Purpose Completed Flag'
    @Common.QuickInfo : 'Business Purpose Completed Flag'
    IsBusinessPurposeCompleted : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Type'
    ResponsibleType : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Fiscal address'
    @Common.Heading : 'Fisc.addr.'
    @Common.QuickInfo : 'Account number of the master record with the fiscal address'
    FiscalAddress : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Natural Person'
    NFPartnerIsNaturalPerson : String(1) not null;
    @Common.Label : 'Deletion Flag'
    @Common.Heading : 'DelF'
    @Common.QuickInfo : 'Central Deletion Flag for Master Record'
    DeletionIndicator : Boolean not null;
    @Common.Label : 'Language Key'
    @Common.Heading : 'Language'
    Language : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Trading Partner No.'
    @Common.Heading : 'Tr.Prt'
    @Common.QuickInfo : 'Company ID of Trading Partner'
    TradingPartner : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Deliv Date Rule'
    @Common.Heading : 'DlvDteRule'
    @Common.QuickInfo : 'Delivery Date Rule'
    DeliveryDateTypeRule : String(1) not null;
    @Common.Label : 'Express station'
    @Common.QuickInfo : 'Express train station'
    ExpressTrainStationName : String(25) not null;
    @Common.Label : 'Train station'
    TrainStationName : String(25) not null;
    @Common.QuickInfo : 'International Location Number (Part 2)'
    @Common.IsDigitSequence : true
    @Common.Label : 'Int. location no. 2'
    @Common.Heading : 'ILN 2'
    InternationalLocationNumber2 : String(5) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Check digit'
    @Common.QuickInfo : 'Check digit for the international location number'
    InternationalLocationNumber3 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'City Code'
    @Common.Heading : 'Code'
    CityCode : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'County Code'
    @Common.Heading : 'CCd'
    County : String(3) not null;
    @Common.Label : 'Unloading points'
    @Common.Heading : 'UnlPt'
    @Common.QuickInfo : 'Indicator: Unloading points exist'
    CustomerHasUnloadingPoint : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Working times'
    @Common.Heading : 'Working time calendar'
    @Common.QuickInfo : 'Working Time Calendar'
    CustomerWorkingTimeCalendar : String(2) not null;
    @Common.Label : 'Competitors'
    @Common.Heading : 'C'
    @Common.QuickInfo : 'Indicator: Competitor'
    IsCompetitor : Boolean not null;
    @Common.Label : 'Rep''s Name'
    @Common.Heading : 'Name of Representative'
    @Common.QuickInfo : 'Name of Representative'
    TaxInvoiceRepresentativeName : String(10) not null;
    @Common.Label : 'Type of Business'
    BusinessType : String(30) not null;
    @Common.Label : 'Type of Industry'
    IndustryType : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Consolidated Invoic.'
    @Common.Heading : 'Consolidated Invoicing for Taiwan'
    @Common.QuickInfo : 'Consolidated Invoicing for Taiwan'
    TW_CollvBillingIsSupported : String(1) not null;
    @Common.Label : 'Alt.payer in doc?'
    @Common.QuickInfo : 'Indicator: Is an alternative payer allowed in document?'
    AlternativePayeeIsAllowed : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Attribute 1'
    @Common.Heading : 'A1'
    FreeDefinedAttribute01 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Attribute 2'
    @Common.Heading : 'A2'
    FreeDefinedAttribute02 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Attribute 3'
    @Common.Heading : 'A3'
    FreeDefinedAttribute03 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Attribute 4'
    @Common.Heading : 'A4'
    FreeDefinedAttribute04 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Attribute 5'
    @Common.Heading : 'A5'
    FreeDefinedAttribute05 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Attribute 6'
    @Common.Heading : 'A6'
    FreeDefinedAttribute06 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Attribute 7'
    @Common.Heading : 'A7'
    FreeDefinedAttribute07 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Attribute 8'
    @Common.Heading : 'A8'
    FreeDefinedAttribute08 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Attribute 9'
    @Common.Heading : 'A9'
    FreeDefinedAttribute09 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Attribute 10'
    @Common.Heading : 'A10'
    FreeDefinedAttribute10 : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Payment Reason'
    PaymentReason : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Condition group 1'
    @Common.Heading : 'CGr1'
    @Common.QuickInfo : 'Customer condition group 1'
    CustomerConditionGroup1 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Condition group 2'
    @Common.Heading : 'CGr2'
    @Common.QuickInfo : 'Customer condition group 2'
    CustomerConditionGroup2 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Condition group 3'
    @Common.Heading : 'CGr3'
    @Common.QuickInfo : 'Customer condition group 3'
    CustomerConditionGroup3 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Condition group 4'
    @Common.Heading : 'CGr4'
    @Common.QuickInfo : 'Customer condition group 4'
    CustomerConditionGroup4 : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Condition group 5'
    @Common.Heading : 'CGr5'
    @Common.QuickInfo : 'Customer condition group 5'
    CustomerConditionGroup5 : String(2) not null;
    @Common.Label : 'Prospect'
    @Common.Heading : 'I'
    @Common.QuickInfo : 'Indicator: Sales prospect'
    IsSalesProspect : Boolean not null;
    @Common.Label : 'Payment block'
    @Common.QuickInfo : 'Payment Block'
    PaymentIsBlockedForCustomer : Boolean not null;
    @Common.Label : 'Consumer'
    @Common.QuickInfo : 'Indicator: Consumer'
    IsConsumer : Boolean not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Ctrlr. Set'
    @Common.Heading : 'Data Controller Set Flag'
    @Common.QuickInfo : 'BP: Data Controller Set Flag'
    DataControllerSet : String(1) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController1 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController2 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController3 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController4 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController5 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController6 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController7 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController8 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController9 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController10 : String(30) not null;
    @Common.Label : 'Name'
    @Common.QuickInfo : 'Name 1'
    BusinessPartnerName1 : String(40) not null;
    @Common.Label : 'Name 2'
    BusinessPartnerName2 : String(40) not null;
    @Common.Label : 'Name 3'
    BusinessPartnerName3 : String(40) not null;
    @Common.Label : 'Name 4'
    BusinessPartnerName4 : String(40) not null;
    @Common.Label : 'City'
    BPAddrCityName : String(40) not null;
    @Common.Label : 'Street'
    BPAddrStreetName : String(60) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Search Term 1'
    AddressSearchTerm1 : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Search Term 2'
    AddressSearchTerm2 : String(20) not null;
    @Common.Label : 'District'
    DistrictName : String(40) not null;
    @Common.Label : 'PO Box City'
    @Common.QuickInfo : 'PO Box city'
    POBoxDeviatingCityName : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Title Key'
    @Common.Heading : 'Key'
    @Common.QuickInfo : 'Form-of-Address Key'
    BusinessPartnerFormOfAddress : String(4) not null;
    _CorrespondingSupplier : Association to one FetchLFA1 {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Supplier'
  @Common.SAPObjectNodeType.Name : 'Supplier'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity FetchLFA1 {
    @Common.Text : SupplierName
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier'
    @Common.QuickInfo : 'Account Number of Supplier'
    key Supplier : String(10) not null;
    @Common.Label : 'Account Group'
    @Common.IsUpperCase : true
    @Common.Heading : 'Group'
    @Common.QuickInfo : 'Vendor account group'
    SupplierAccountGroup : String(4) not null;
    @Common.Label : 'Name of Supplier'
    @Common.Heading : 'Supplier'
    SupplierName : String(80) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier Name'
    @Common.QuickInfo : 'Supplier Full Name'
    SupplierFullName : String(220) not null;
    @Common.Label : 'Supplier Name'
    BPSupplierName : String(81) not null;
    @Common.Label : 'Supplier Name'
    @Common.QuickInfo : 'Supplier Full Name'
    BPSupplierFullName : String(163) not null;
    @Common.Label : 'Name'
    @Common.QuickInfo : 'Name 1'
    BusinessPartnerName1 : String(40) not null;
    @Common.Label : 'Name 2'
    BusinessPartnerName2 : String(40) not null;
    @Common.Label : 'Name 3'
    BusinessPartnerName3 : String(40) not null;
    @Common.Label : 'Name 4'
    BusinessPartnerName4 : String(40) not null;
    @Common.Label : 'City'
    BPAddrCityName : String(40) not null;
    @Common.Label : 'Street'
    BPAddrStreetName : String(60) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Search Term 1'
    AddressSearchTerm1 : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Search Term 2'
    AddressSearchTerm2 : String(20) not null;
    @Common.Label : 'District'
    DistrictName : String(40) not null;
    @Common.Label : 'PO Box City'
    @Common.QuickInfo : 'PO Box city'
    POBoxDeviatingCityName : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Title Key'
    @Common.Heading : 'Key'
    @Common.QuickInfo : 'Form-of-Address Key'
    BusinessPartnerFormOfAddress : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Purpose Completed'
    @Common.Heading : 'Business Purpose Completed Flag'
    @Common.QuickInfo : 'Business Purpose Completed Flag'
    IsBusinessPurposeCompleted : String(1) not null;
    @Common.Label : 'Created By'
    @Common.IsUpperCase : true
    @Common.Heading : 'Created by'
    @Common.QuickInfo : 'Name of Person who Created the Object'
    CreatedByUser : String(12) not null;
    @Common.Label : 'Created On'
    @Common.Heading : 'Date'
    @Common.QuickInfo : 'Record Created On'
    CreationDate : Date;
    @Common.Label : 'One-time account'
    @Common.QuickInfo : 'Indicator: Is the account a one-time account?'
    IsOneTimeAccount : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Authorization'
    @Common.Heading : 'AuGr'
    @Common.QuickInfo : 'Authorization Group'
    AuthorizationGroup : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'VAT Registration No.'
    @Common.QuickInfo : 'VAT Registration Number'
    VATRegistration : String(20) not null;
    @Common.Label : 'Posting Block(Deprecated)'
    @Common.Heading : 'B'
    @Common.QuickInfo : 'Central posting block'
    AccountIsBlockedForPosting : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Jurisdiction'
    @Common.Heading : 'Tax Jur.'
    TaxJurisdiction : String(15) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'SCAC'
    @Common.QuickInfo : 'Standard carrier access code'
    SupplierStandardCarrierAccess : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Carrier freight grp'
    @Common.Heading : 'CarFrgtG'
    @Common.QuickInfo : 'Forwarding agent freight group'
    SupplierFwdAgentFreightGroup : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'ServAgntProcGrp'
    @Common.Heading : 'SAGr'
    @Common.QuickInfo : 'Service agent procedure group'
    SupplierAgentProcedureGroup : String(4) not null;
    @Common.Label : 'Social Insurance'
    @Common.Heading : 'Soc. Ins.'
    @Common.QuickInfo : 'Registered for Social Insurance'
    SupplIsSocialInsuranceRegtrd : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Social Ins. Code'
    @Common.Heading : 'SI Code'
    @Common.QuickInfo : 'Activity Code for Social Insurance'
    SocialInsuranceActivityCode : String(3) not null;
    @Common.Label : 'Group Key'
    @Common.IsUpperCase : true
    @Common.Heading : 'Group'
    @Common.QuickInfo : 'Group key'
    SupplierCorporateGroup : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer'
    @Common.QuickInfo : 'Customer Number'
    Customer : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Industry'
    @Common.Heading : 'Indust.'
    @Common.QuickInfo : 'Industry Key'
    Industry : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 1'
    TaxNumber1 : String(16) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 2'
    TaxNumber2 : String(11) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 3'
    TaxNumber3 : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 4'
    TaxNumber4 : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 5'
    TaxNumber5 : String(60) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 6'
    TaxNumber6 : String(20) not null;
    @Common.Label : 'Posting Block'
    @Common.Heading : 'B'
    @Common.QuickInfo : 'Central posting block'
    PostingIsBlocked : Boolean not null;
    @Common.Label : 'Purch. Block'
    @Common.Heading : 'B'
    @Common.QuickInfo : 'Centrally imposed purchasing block'
    PurchasingIsBlocked : Boolean not null;
    @Common.QuickInfo : 'International Location Number (Part 1)'
    @Common.IsDigitSequence : true
    @Common.Label : 'Int. location no. 1'
    @Common.Heading : 'ILN 1'
    InternationalLocationNumber1 : String(7) not null;
    @Common.QuickInfo : 'International Location Number (Part 2)'
    @Common.IsDigitSequence : true
    @Common.Label : 'Int. location no. 2'
    @Common.Heading : 'ILN 2'
    InternationalLocationNumber2 : String(5) not null;
    @Common.Label : 'Check Digit'
    @Common.IsDigitSequence : true
    @Common.QuickInfo : 'Check digit for the international location number'
    InternationalLocationNumber3 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address'
    AddressID : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Region'
    @Common.Heading : 'Rg'
    @Common.QuickInfo : 'Region (State, Province, County)'
    Region : String(3) not null;
    @Common.Label : 'Name'
    @Common.Heading : 'Name 1'
    @Common.QuickInfo : 'Name 1'
    OrganizationBPName1 : String(35) not null;
    @Common.Label : 'Name 2'
    OrganizationBPName2 : String(35) not null;
    @Common.Label : 'City'
    CityName : String(35) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Postal Code'
    @Common.Heading : 'PostalCode'
    PostalCode : String(10) not null;
    @Common.Label : 'Street'
    @Common.QuickInfo : 'Street and House Number'
    StreetName : String(35) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Country/Region Key'
    Country : String(3) not null;
    @Common.Label : 'Int. Location No.'
    @Common.Heading : 'International Location Number'
    @Common.QuickInfo : 'Cocatenated International Location Number'
    ConcatenatedInternationalLocNo : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Block Function'
    @Common.Heading : 'BF'
    @Common.QuickInfo : 'Function That Will Be Blocked'
    SupplierProcurementBlock : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Actual QM System'
    @Common.QuickInfo : 'Supplier''s QM System'
    SuplrQualityManagementSystem : String(4) not null;
    @Common.Label : 'QM System Valid To'
    @Common.Heading : 'Dat'
    @Common.QuickInfo : 'Validity Date of Certification'
    SuplrQltyInProcmtCertfnValidTo : Date;
    @Common.Label : 'Language Key'
    @Common.Heading : 'Language'
    SupplierLanguage : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Alternative Payee'
    @Common.Heading : 'Alt. Payee'
    @Common.QuickInfo : 'Account Number of the Alternative Payee'
    AlternativePayeeAccountNumber : String(10) not null;
    @Common.Label : 'Telephone 1'
    @Common.QuickInfo : 'First telephone number'
    PhoneNumber1 : String(16) not null;
    @Common.Label : 'Fax Number'
    FaxNumber : String(31) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Natural Person'
    IsNaturalPerson : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number'
    @Common.QuickInfo : 'Tax Number at Responsible Tax Authority'
    TaxNumberResponsible : String(18) not null;
    @Common.Label : 'Business Type'
    @Common.Heading : 'Business T'
    @Common.QuickInfo : 'Subcontractor''s Business Type'
    UK_ContractorBusinessType : String(12) not null;
    @Common.Label : 'Prtnr''s Trading Name'
    @Common.Heading : 'Prtnr Name'
    @Common.QuickInfo : 'Partner''s Trading Name'
    UK_PartnerTradingName : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Partner''s UTR'
    @Common.Heading : 'Prtnr UTR'
    @Common.QuickInfo : 'Partner''s Unique Tax Reference (UTR)'
    UK_PartnerTaxReference : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Verification Status'
    @Common.Heading : 'Verif Stat'
    UK_VerificationStatus : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Verification Number'
    @Common.Heading : 'Verif No.'
    UK_VerificationNumber : String(20) not null;
    @Common.Label : 'Comp. House Reg. No.'
    @Common.Heading : 'Companies House Registration Number'
    @Common.QuickInfo : 'Companies House Registration Number'
    UK_CompanyRegistrationNumber : String(8) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Status'
    @Common.QuickInfo : 'Tax Status of the Verified Subcontractor'
    UK_VerifiedTaxStatus : String(1) not null;
    @Common.Label : 'Title'
    FormOfAddress : String(15) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Reference Acct Group'
    @Common.Heading : 'RefGr.'
    @Common.QuickInfo : 'Reference Account Group for One-Time Account (Vendor)'
    ReferenceAccountGroup : String(4) not null;
    @Common.Label : 'Liable for VAT'
    VATLiability : Boolean not null;
    @Common.Label : 'Tax Type'
    @Common.IsUpperCase : true
    @Common.Heading : 'Tax Type'
    @Common.QuickInfo : 'Tax Type'
    ResponsibleType : String(2) not null;
    @Common.Label : 'Tax Number Type'
    @Common.IsUpperCase : true
    @Common.Heading : 'Tax no.ty.'
    @Common.QuickInfo : 'Tax Number Type'
    TaxNumberType : String(2) not null;
    @Common.Label : 'Fiscal Address'
    @Common.IsUpperCase : true
    @Common.Heading : 'Fisc.addr.'
    @Common.QuickInfo : 'Account number of the master record with fiscal address'
    FiscalAddress : String(10) not null;
    @Common.Label : 'Type of Business'
    BusinessType : String(30) not null;
    @Common.Label : 'Date of Birth'
    @Common.Heading : 'Birth Date'
    @Common.QuickInfo : 'Date of Birth of the Person Subject to Withholding Tax'
    BirthDate : Date;
    @Common.Label : 'Payment Block'
    @Common.QuickInfo : 'Payment Block'
    PaymentIsBlockedForSupplier : Boolean not null;
    @Common.Label : 'Search Term'
    @Common.IsUpperCase : true
    @Common.Heading : 'SearchTerm'
    @Common.QuickInfo : 'Sort field'
    SortField : String(10) not null;
    @Common.Label : 'Telephone 2'
    @Common.QuickInfo : 'Second telephone number'
    PhoneNumber2 : String(16) not null;
    @Common.Label : 'Deletion Flag'
    @Common.Heading : 'DelF'
    @Common.QuickInfo : 'Central Deletion Flag for Master Record'
    DeletionIndicator : Boolean not null;
    @Common.Label : 'Rep''s Name'
    @Common.Heading : 'Name of Representative'
    @Common.QuickInfo : 'Name of Representative'
    TaxInvoiceRepresentativeName : String(10) not null;
    @Common.Label : 'Type of Industry'
    IndustryType : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'GST Ven Class.'
    @Common.Heading : 'GST Vendor Classification'
    @Common.QuickInfo : 'Vendor Classification for GST'
    IN_GSTSupplierClassification : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Relevant for POD'
    @Common.Heading : 'POD-Rel.'
    @Common.QuickInfo : 'Supplier indicator relevant for proof of delivery'
    SuplrProofOfDelivRlvtCode : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Trading Partner No.'
    @Common.Heading : 'Tr.Prt'
    @Common.QuickInfo : 'Company ID of Trading Partner'
    TradingPartner : String(6) not null;
    @Common.Label : 'Tax Split'
    @Common.Heading : 'S'
    @Common.QuickInfo : 'Tax Split'
    BR_TaxIsSplit : Boolean not null;
    @Common.Label : 'Enterprise in AU'
    @Common.Heading : 'Not making payment in course of carrying ent. in AU'
    @Common.QuickInfo : 'Is payer making payment in course of carrying on enterprise'
    AU_PayerIsPayingToCarryOnEnt : Boolean not null;
    @Common.Label : 'Individual'
    @Common.Heading : 'Is an individual under 18 and payment does not exceed $'
    @Common.QuickInfo : 'Is an individual under 18 and payment does not exceed $350'
    AU_IndividualIsUnder18 : Boolean not null;
    @Common.Label : 'Payment Does not Exc'
    @Common.Heading : 'The payment does not exceed $75, excl. GST'
    @Common.QuickInfo : 'The payment does not exceed $75, excl. GST'
    AU_PaymentIsExceeding75 : Boolean not null;
    @Common.Label : 'Wholly Input Taxed'
    @Common.Heading : 'The supply that the payment relates to is wholly input'
    @Common.QuickInfo : 'The supply that the payment relates to is wholly input taxed'
    AU_PaymentIsWhollyInputTaxed : Boolean not null;
    @Common.Label : 'Individual w/o Gain'
    @Common.Heading : 'The supply is made by an individual without gain'
    @Common.QuickInfo : 'The supply is made by an individual without gain'
    AU_PartnerIsSupplyWithoutGain : Boolean not null;
    @Common.Label : 'ABN Eligible'
    @Common.Heading : 'The supplier is not entitled to an ABN'
    @Common.QuickInfo : 'The supplier is not entitled to an ABN'
    AU_SupplierIsEntitledToABN : Boolean not null;
    @Common.Label : 'Payment Exempt'
    @Common.Heading : 'The whole of the payment is exempt income for supplier'
    @Common.QuickInfo : 'The whole of the payment is exempt income.'
    AU_PaymentIsIncomeExempted : Boolean not null;
    @Common.Label : 'Hobby'
    @Common.Heading : 'An activity done as a private recreational pursuit'
    @Common.QuickInfo : 'An activity done as a private recreational pursuit'
    AU_SupplyIsMadeAsPrivateHobby : Boolean not null;
    @Common.Label : 'Domestic'
    @Common.Heading : 'wholly of a private or domestic nature'
    @Common.QuickInfo : 'wholly of a private or domestic nature'
    AU_SupplyMadeIsOfDmstcNature : Boolean not null;
    @Common.Label : 'Origin Acceptance'
    @Common.Heading : 'OA'
    @Common.QuickInfo : 'Acceptance At Origin'
    IsToBeAcceptedAtOrigin : Boolean not null;
    @Common.Label : 'Checkbox'
    BPIsEqualizationTaxSubject : Boolean not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Tax Base'
    @Common.QuickInfo : 'Tax Base in Percentage'
    BRSpcfcTaxBasePercentageCode : String(1) not null;
    @Common.Label : 'Profession'
    SupplierProfession : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Ext. manufacturer'
    @Common.Heading : 'Ex. manuf.'
    @Common.QuickInfo : 'External manufacturer code name or number'
    SuplrManufacturerExternalName : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'DME Recipient Code'
    @Common.Heading : 'R'
    @Common.QuickInfo : 'Recipient Code for Data Medium Exchange'
    DataMediumExchangeIndicator : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Instruction Key'
    @Common.Heading : 'IK'
    @Common.QuickInfo : 'Instruction Key for Data Medium Exchange'
    DataExchangeInstructionKey : String(2) not null;
    @Common.Label : 'VSR Relevant'
    @Common.QuickInfo : 'Indicator: vendor sub-range relevant'
    SupplierIsSubRangeRelevant : Boolean not null;
    @Common.Label : 'Train Station'
    @Common.Heading : 'Train station'
    @Common.QuickInfo : 'Train station'
    TrainStationName : String(25) not null;
    @Common.Label : 'Payee in Document'
    @Common.QuickInfo : 'Indicator: Alternative Payee in Document Allowed?'
    AlternativePayeeIsAllowed : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'PBC/ISR Number'
    @Common.Heading : 'ISR Number'
    @Common.QuickInfo : 'ISR Subscriber Number'
    PaytSlipWthRefSubscriber : String(11) not null;
    @Common.Label : 'Stat. Grp, Agent'
    @Common.IsUpperCase : true
    @Common.Heading : 'StGSA'
    @Common.QuickInfo : 'Shipment: statistics group, transportation service agent'
    TranspServiceAgentStstcGrp : String(2) not null;
    @Common.Label : 'Plant Level Relevant'
    @Common.QuickInfo : 'Indicator: plant level relevant'
    SupplierIsPlantRelevant : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Office'
    @Common.QuickInfo : 'Account Number of Master Record of Tax Office Responsible'
    SuplrTaxAuthorityAccountNumber : String(10) not null;
    @Common.Label : 'Carrier confirmation'
    @Common.Heading : 'CC'
    @Common.QuickInfo : 'Carrier confirmation is expected'
    SuplrCarrierConfirmIsExpected : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    @Common.QuickInfo : 'Plant (Own or External)'
    SupplierPlant : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Factory Calendar'
    @Common.Heading : 'Cal'
    @Common.QuickInfo : 'Factory calendar key'
    FactoryCalendar : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Payment Reason'
    PaymentReason : String(4) not null;
    @Common.Label : 'Central Del. Block'
    @Common.Heading : 'DeBl'
    @Common.QuickInfo : 'Central deletion block for master record'
    SupplierCentralDeletionIsBlock : Boolean not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Ctrlr. Set'
    @Common.Heading : 'Data Controller Set Flag'
    @Common.QuickInfo : 'BP: Data Controller Set Flag'
    DataControllerSet : String(1) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController1 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController2 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController3 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController4 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController5 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController6 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController7 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController8 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController9 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController10 : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Transportation Chain'
    SupplierTransportationChain : String(10) not null;
    @Common.Label : 'Staging Time'
    @Common.QuickInfo : 'Staging Time in Days'
    SupplierStagingTimeInDays : Decimal(precision: 3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Scheduling Procedure'
    SupplierSchedulingProcedure : String(1) not null;
    @Common.Label : 'Rel. for Coll. No.'
    @Common.Heading : 'Cross Docking: Collective Numbering Is Supported'
    @Common.QuickInfo : 'Cross Docking: Relevant for Collective Numbering'
    CollectiveNumberingIsRelevant : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'PAN'
    @Common.Heading : 'Permanent account number'
    @Common.QuickInfo : 'Permanent Account Number'
    BusinessPartnerPanNumber : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'PAN Reference Number'
    BPPanReferenceNumber : String(40) not null;
    @Common.Label : 'PAN Valid From Date'
    BPPanValidFromDate : Date;
    _CorrespondingCustomer : Association to one FetchKNA1 {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'CDS View for Plant Details'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity FetchT001W {
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    key Plant : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Valuation Area'
    @Common.Heading : 'ValA'
    ValuationArea : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer No Plant'
    @Common.Heading : 'CustNoPlnt'
    @Common.QuickInfo : 'Customer Number of Plant'
    PlantCustomer : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sls Organization ICB'
    @Common.Heading : 'SO ICB'
    @Common.QuickInfo : 'Sales Organization for Intercompany Billing'
    SalesOrganization : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address'
    AddressID : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Node type: SCN'
    @Common.Heading : 'Nty'
    @Common.QuickInfo : 'Node type: supply chain network'
    Nodetype : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sppl. No. Plnt'
    @Common.Heading : 'Supplier Number Plant'
    @Common.QuickInfo : 'Supplier Number of Plant'
    PlantSupplier : String(10) not null;
    @Common.Label : 'Name'
    @Common.QuickInfo : 'Name 1'
    OrganizationName1 : String(40) not null;
    @Common.Label : 'Name 2'
    OrganizationName2 : String(40) not null;
    @Common.Label : 'City'
    CityName : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Street Code'
    @Common.QuickInfo : 'Street Number for City/Street File'
    Street : String(12) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Language-Dependent Code of Partner Function'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity PFCONV {
    @Common.IsUpperCase : true
    @Common.Label : 'Partner Function'
    @Common.Heading : 'PartF'
    key PartnerFunction : String(2) not null;
    @Common.Label : 'Language Key'
    @Common.Heading : 'Language'
    key Language : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Lang-spec.part.func.'
    @Common.QuickInfo : 'Partner Function (Language-Dependent Code)'
    PartnerFunctionLanguageDepdnt : String(2) not null;
  };
};

