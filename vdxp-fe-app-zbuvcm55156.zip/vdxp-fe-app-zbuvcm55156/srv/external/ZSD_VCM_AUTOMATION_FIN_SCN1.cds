/* checksum : 9bf0fadf59609d3373fc17aeeb16c45e */
@cds.external : true
@CodeList.UnitsOfMeasure.Url : '../../../../default/iwbep/common/0001/$metadata'
@CodeList.UnitsOfMeasure.CollectionPath : 'UnitsOfMeasure'
@Aggregation.ApplySupported.Transformations : [ 'aggregate', 'groupby', 'filter' ]
@Aggregation.ApplySupported.Rollup : #None
@Common.ApplyMultiUnitBehaviorForSortingAndFiltering : true
@Capabilities.FilterFunctions : [
  'eq',
  'ne',
  'gt',
  'ge',
  'lt',
  'le',
  'and',
  'or',
  'contains',
  'startswith',
  'endswith',
  'any',
  'all'
]
@Capabilities.SupportedFormats : [ 'application/json', 'application/pdf' ]
@PDF.Features.DocumentDescriptionReference : '../../../../default/iwbep/common/0001/$metadata'
@PDF.Features.DocumentDescriptionCollection : 'MyDocumentDescriptions'
@PDF.Features.ArchiveFormat : true
@PDF.Features.Border : true
@PDF.Features.CoverPage : true
@PDF.Features.FitToPage : true
@PDF.Features.FontName : true
@PDF.Features.FontSize : true
@PDF.Features.Margin : true
@PDF.Features.Padding : true
@PDF.Features.Signature : true
@PDF.Features.HeaderFooter : true
@PDF.Features.ResultSizeDefault : 20000
@PDF.Features.ResultSizeMaximum : 20000
@Capabilities.KeyAsSegmentSupported : true
@Capabilities.AsynchronousRequestsSupported : true
service ZSD_VCM_AUTOMATION_FIN_SCN1 {
  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Supplier'
  @Common.SAPObjectNodeType.Name : 'Supplier'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity FetchLFA1 {
    @Common.Text : SupplierName
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier'
    @Common.QuickInfo : 'Account Number of Supplier'
    key Supplier : String(10) not null;
    @Common.Label : 'Account Group'
    @Common.IsUpperCase : true
    @Common.Heading : 'Group'
    @Common.QuickInfo : 'Vendor account group'
    SupplierAccountGroup : String(4) not null;
    @Common.Label : 'Name of Supplier'
    @Common.Heading : 'Supplier'
    SupplierName : String(80) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier Name'
    @Common.QuickInfo : 'Supplier Full Name'
    SupplierFullName : String(220) not null;
    @Common.Label : 'Supplier Name'
    BPSupplierName : String(81) not null;
    @Common.Label : 'Supplier Name'
    @Common.QuickInfo : 'Supplier Full Name'
    BPSupplierFullName : String(163) not null;
    @Common.Label : 'Name'
    @Common.QuickInfo : 'Name 1'
    BusinessPartnerName1 : String(40) not null;
    @Common.Label : 'Name 2'
    BusinessPartnerName2 : String(40) not null;
    @Common.Label : 'Name 3'
    BusinessPartnerName3 : String(40) not null;
    @Common.Label : 'Name 4'
    BusinessPartnerName4 : String(40) not null;
    @Common.Label : 'City'
    BPAddrCityName : String(40) not null;
    @Common.Label : 'Street'
    BPAddrStreetName : String(60) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Search Term 1'
    AddressSearchTerm1 : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Search Term 2'
    AddressSearchTerm2 : String(20) not null;
    @Common.Label : 'District'
    DistrictName : String(40) not null;
    @Common.Label : 'PO Box City'
    @Common.QuickInfo : 'PO Box city'
    POBoxDeviatingCityName : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Title Key'
    @Common.Heading : 'Key'
    @Common.QuickInfo : 'Form-of-Address Key'
    BusinessPartnerFormOfAddress : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Purpose Completed'
    @Common.Heading : 'Business Purpose Completed Flag'
    @Common.QuickInfo : 'Business Purpose Completed Flag'
    IsBusinessPurposeCompleted : String(1) not null;
    @Common.Label : 'Created By'
    @Common.IsUpperCase : true
    @Common.Heading : 'Created by'
    @Common.QuickInfo : 'Name of Person who Created the Object'
    CreatedByUser : String(12) not null;
    @Common.Label : 'Created On'
    @Common.Heading : 'Date'
    @Common.QuickInfo : 'Record Created On'
    CreationDate : Date;
    @Common.Label : 'One-time account'
    @Common.QuickInfo : 'Indicator: Is the account a one-time account?'
    IsOneTimeAccount : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Authorization'
    @Common.Heading : 'AuGr'
    @Common.QuickInfo : 'Authorization Group'
    AuthorizationGroup : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'VAT Registration No.'
    @Common.QuickInfo : 'VAT Registration Number'
    VATRegistration : String(20) not null;
    @Common.Label : 'Posting Block(Deprecated)'
    @Common.Heading : 'B'
    @Common.QuickInfo : 'Central posting block'
    AccountIsBlockedForPosting : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Jurisdiction'
    @Common.Heading : 'Tax Jur.'
    TaxJurisdiction : String(15) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'SCAC'
    @Common.QuickInfo : 'Standard carrier access code'
    SupplierStandardCarrierAccess : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Carrier freight grp'
    @Common.Heading : 'CarFrgtG'
    @Common.QuickInfo : 'Forwarding agent freight group'
    SupplierFwdAgentFreightGroup : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'ServAgntProcGrp'
    @Common.Heading : 'SAGr'
    @Common.QuickInfo : 'Service agent procedure group'
    SupplierAgentProcedureGroup : String(4) not null;
    @Common.Label : 'Social Insurance'
    @Common.Heading : 'Soc. Ins.'
    @Common.QuickInfo : 'Registered for Social Insurance'
    SupplIsSocialInsuranceRegtrd : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Social Ins. Code'
    @Common.Heading : 'SI Code'
    @Common.QuickInfo : 'Activity Code for Social Insurance'
    SocialInsuranceActivityCode : String(3) not null;
    @Common.Label : 'Group Key'
    @Common.IsUpperCase : true
    @Common.Heading : 'Group'
    @Common.QuickInfo : 'Group key'
    SupplierCorporateGroup : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer'
    @Common.QuickInfo : 'Customer Number'
    Customer : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Industry'
    @Common.Heading : 'Indust.'
    @Common.QuickInfo : 'Industry Key'
    Industry : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 1'
    TaxNumber1 : String(16) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 2'
    TaxNumber2 : String(11) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 3'
    TaxNumber3 : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 4'
    TaxNumber4 : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 5'
    TaxNumber5 : String(60) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number 6'
    TaxNumber6 : String(20) not null;
    @Common.Label : 'Posting Block'
    @Common.Heading : 'B'
    @Common.QuickInfo : 'Central posting block'
    PostingIsBlocked : Boolean not null;
    @Common.Label : 'Purch. Block'
    @Common.Heading : 'B'
    @Common.QuickInfo : 'Centrally imposed purchasing block'
    PurchasingIsBlocked : Boolean not null;
    @Common.QuickInfo : 'International Location Number (Part 1)'
    @Common.IsDigitSequence : true
    @Common.Label : 'Int. location no. 1'
    @Common.Heading : 'ILN 1'
    InternationalLocationNumber1 : String(7) not null;
    @Common.QuickInfo : 'International Location Number (Part 2)'
    @Common.IsDigitSequence : true
    @Common.Label : 'Int. location no. 2'
    @Common.Heading : 'ILN 2'
    InternationalLocationNumber2 : String(5) not null;
    @Common.Label : 'Check Digit'
    @Common.IsDigitSequence : true
    @Common.QuickInfo : 'Check digit for the international location number'
    InternationalLocationNumber3 : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address'
    AddressID : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Region'
    @Common.Heading : 'Rg'
    @Common.QuickInfo : 'Region (State, Province, County)'
    Region : String(3) not null;
    @Common.Label : 'Name'
    @Common.Heading : 'Name 1'
    @Common.QuickInfo : 'Name 1'
    OrganizationBPName1 : String(35) not null;
    @Common.Label : 'Name 2'
    OrganizationBPName2 : String(35) not null;
    @Common.Label : 'City'
    CityName : String(35) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Postal Code'
    @Common.Heading : 'PostalCode'
    PostalCode : String(10) not null;
    @Common.Label : 'Street'
    @Common.QuickInfo : 'Street and House Number'
    StreetName : String(35) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Country/Region Key'
    Country : String(3) not null;
    @Common.Label : 'Int. Location No.'
    @Common.Heading : 'International Location Number'
    @Common.QuickInfo : 'Cocatenated International Location Number'
    ConcatenatedInternationalLocNo : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Block Function'
    @Common.Heading : 'BF'
    @Common.QuickInfo : 'Function That Will Be Blocked'
    SupplierProcurementBlock : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Actual QM System'
    @Common.QuickInfo : 'Supplier''s QM System'
    SuplrQualityManagementSystem : String(4) not null;
    @Common.Label : 'QM System Valid To'
    @Common.Heading : 'Dat'
    @Common.QuickInfo : 'Validity Date of Certification'
    SuplrQltyInProcmtCertfnValidTo : Date;
    @Common.Label : 'Language Key'
    @Common.Heading : 'Language'
    SupplierLanguage : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Alternative Payee'
    @Common.Heading : 'Alt. Payee'
    @Common.QuickInfo : 'Account Number of the Alternative Payee'
    AlternativePayeeAccountNumber : String(10) not null;
    @Common.Label : 'Telephone 1'
    @Common.QuickInfo : 'First telephone number'
    PhoneNumber1 : String(16) not null;
    @Common.Label : 'Fax Number'
    FaxNumber : String(31) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Natural Person'
    IsNaturalPerson : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Number'
    @Common.QuickInfo : 'Tax Number at Responsible Tax Authority'
    TaxNumberResponsible : String(18) not null;
    @Common.Label : 'Business Type'
    @Common.Heading : 'Business T'
    @Common.QuickInfo : 'Subcontractor''s Business Type'
    UK_ContractorBusinessType : String(12) not null;
    @Common.Label : 'Prtnr''s Trading Name'
    @Common.Heading : 'Prtnr Name'
    @Common.QuickInfo : 'Partner''s Trading Name'
    UK_PartnerTradingName : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Partner''s UTR'
    @Common.Heading : 'Prtnr UTR'
    @Common.QuickInfo : 'Partner''s Unique Tax Reference (UTR)'
    UK_PartnerTaxReference : String(20) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Verification Status'
    @Common.Heading : 'Verif Stat'
    UK_VerificationStatus : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Verification Number'
    @Common.Heading : 'Verif No.'
    UK_VerificationNumber : String(20) not null;
    @Common.Label : 'Comp. House Reg. No.'
    @Common.Heading : 'Companies House Registration Number'
    @Common.QuickInfo : 'Companies House Registration Number'
    UK_CompanyRegistrationNumber : String(8) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Status'
    @Common.QuickInfo : 'Tax Status of the Verified Subcontractor'
    UK_VerifiedTaxStatus : String(1) not null;
    @Common.Label : 'Title'
    FormOfAddress : String(15) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Reference Acct Group'
    @Common.Heading : 'RefGr.'
    @Common.QuickInfo : 'Reference Account Group for One-Time Account (Vendor)'
    ReferenceAccountGroup : String(4) not null;
    @Common.Label : 'Liable for VAT'
    VATLiability : Boolean not null;
    @Common.Label : 'Tax Type'
    @Common.IsUpperCase : true
    @Common.Heading : 'Tax Type'
    @Common.QuickInfo : 'Tax Type'
    ResponsibleType : String(2) not null;
    @Common.Label : 'Tax Number Type'
    @Common.IsUpperCase : true
    @Common.Heading : 'Tax no.ty.'
    @Common.QuickInfo : 'Tax Number Type'
    TaxNumberType : String(2) not null;
    @Common.Label : 'Fiscal Address'
    @Common.IsUpperCase : true
    @Common.Heading : 'Fisc.addr.'
    @Common.QuickInfo : 'Account number of the master record with fiscal address'
    FiscalAddress : String(10) not null;
    @Common.Label : 'Type of Business'
    BusinessType : String(30) not null;
    @Common.Label : 'Date of Birth'
    @Common.Heading : 'Birth Date'
    @Common.QuickInfo : 'Date of Birth of the Person Subject to Withholding Tax'
    BirthDate : Date;
    @Common.Label : 'Payment Block'
    @Common.QuickInfo : 'Payment Block'
    PaymentIsBlockedForSupplier : Boolean not null;
    @Common.Label : 'Search Term'
    @Common.IsUpperCase : true
    @Common.Heading : 'SearchTerm'
    @Common.QuickInfo : 'Sort field'
    SortField : String(10) not null;
    @Common.Label : 'Telephone 2'
    @Common.QuickInfo : 'Second telephone number'
    PhoneNumber2 : String(16) not null;
    @Common.Label : 'Deletion Flag'
    @Common.Heading : 'DelF'
    @Common.QuickInfo : 'Central Deletion Flag for Master Record'
    DeletionIndicator : Boolean not null;
    @Common.Label : 'Rep''s Name'
    @Common.Heading : 'Name of Representative'
    @Common.QuickInfo : 'Name of Representative'
    TaxInvoiceRepresentativeName : String(10) not null;
    @Common.Label : 'Type of Industry'
    IndustryType : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'GST Ven Class.'
    @Common.Heading : 'GST Vendor Classification'
    @Common.QuickInfo : 'Vendor Classification for GST'
    IN_GSTSupplierClassification : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Relevant for POD'
    @Common.Heading : 'POD-Rel.'
    @Common.QuickInfo : 'Supplier indicator relevant for proof of delivery'
    SuplrProofOfDelivRlvtCode : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Trading Partner No.'
    @Common.Heading : 'Tr.Prt'
    @Common.QuickInfo : 'Company ID of Trading Partner'
    TradingPartner : String(6) not null;
    @Common.Label : 'Tax Split'
    @Common.Heading : 'S'
    @Common.QuickInfo : 'Tax Split'
    BR_TaxIsSplit : Boolean not null;
    @Common.Label : 'Enterprise in AU'
    @Common.Heading : 'Not making payment in course of carrying ent. in AU'
    @Common.QuickInfo : 'Is payer making payment in course of carrying on enterprise'
    AU_PayerIsPayingToCarryOnEnt : Boolean not null;
    @Common.Label : 'Individual'
    @Common.Heading : 'Is an individual under 18 and payment does not exceed $'
    @Common.QuickInfo : 'Is an individual under 18 and payment does not exceed $350'
    AU_IndividualIsUnder18 : Boolean not null;
    @Common.Label : 'Payment Does not Exc'
    @Common.Heading : 'The payment does not exceed $75, excl. GST'
    @Common.QuickInfo : 'The payment does not exceed $75, excl. GST'
    AU_PaymentIsExceeding75 : Boolean not null;
    @Common.Label : 'Wholly Input Taxed'
    @Common.Heading : 'The supply that the payment relates to is wholly input'
    @Common.QuickInfo : 'The supply that the payment relates to is wholly input taxed'
    AU_PaymentIsWhollyInputTaxed : Boolean not null;
    @Common.Label : 'Individual w/o Gain'
    @Common.Heading : 'The supply is made by an individual without gain'
    @Common.QuickInfo : 'The supply is made by an individual without gain'
    AU_PartnerIsSupplyWithoutGain : Boolean not null;
    @Common.Label : 'ABN Eligible'
    @Common.Heading : 'The supplier is not entitled to an ABN'
    @Common.QuickInfo : 'The supplier is not entitled to an ABN'
    AU_SupplierIsEntitledToABN : Boolean not null;
    @Common.Label : 'Payment Exempt'
    @Common.Heading : 'The whole of the payment is exempt income for supplier'
    @Common.QuickInfo : 'The whole of the payment is exempt income.'
    AU_PaymentIsIncomeExempted : Boolean not null;
    @Common.Label : 'Hobby'
    @Common.Heading : 'An activity done as a private recreational pursuit'
    @Common.QuickInfo : 'An activity done as a private recreational pursuit'
    AU_SupplyIsMadeAsPrivateHobby : Boolean not null;
    @Common.Label : 'Domestic'
    @Common.Heading : 'wholly of a private or domestic nature'
    @Common.QuickInfo : 'wholly of a private or domestic nature'
    AU_SupplyMadeIsOfDmstcNature : Boolean not null;
    @Common.Label : 'Origin Acceptance'
    @Common.Heading : 'OA'
    @Common.QuickInfo : 'Acceptance At Origin'
    IsToBeAcceptedAtOrigin : Boolean not null;
    @Common.Label : 'Checkbox'
    BPIsEqualizationTaxSubject : Boolean not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Tax Base'
    @Common.QuickInfo : 'Tax Base in Percentage'
    BRSpcfcTaxBasePercentageCode : String(1) not null;
    @Common.Label : 'Profession'
    SupplierProfession : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Ext. manufacturer'
    @Common.Heading : 'Ex. manuf.'
    @Common.QuickInfo : 'External manufacturer code name or number'
    SuplrManufacturerExternalName : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'DME Recipient Code'
    @Common.Heading : 'R'
    @Common.QuickInfo : 'Recipient Code for Data Medium Exchange'
    DataMediumExchangeIndicator : String(1) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Instruction Key'
    @Common.Heading : 'IK'
    @Common.QuickInfo : 'Instruction Key for Data Medium Exchange'
    DataExchangeInstructionKey : String(2) not null;
    @Common.Label : 'VSR Relevant'
    @Common.QuickInfo : 'Indicator: vendor sub-range relevant'
    SupplierIsSubRangeRelevant : Boolean not null;
    @Common.Label : 'Train Station'
    @Common.Heading : 'Train station'
    @Common.QuickInfo : 'Train station'
    TrainStationName : String(25) not null;
    @Common.Label : 'Payee in Document'
    @Common.QuickInfo : 'Indicator: Alternative Payee in Document Allowed?'
    AlternativePayeeIsAllowed : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'PBC/ISR Number'
    @Common.Heading : 'ISR Number'
    @Common.QuickInfo : 'ISR Subscriber Number'
    PaytSlipWthRefSubscriber : String(11) not null;
    @Common.Label : 'Stat. Grp, Agent'
    @Common.IsUpperCase : true
    @Common.Heading : 'StGSA'
    @Common.QuickInfo : 'Shipment: statistics group, transportation service agent'
    TranspServiceAgentStstcGrp : String(2) not null;
    @Common.Label : 'Plant Level Relevant'
    @Common.QuickInfo : 'Indicator: plant level relevant'
    SupplierIsPlantRelevant : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Tax Office'
    @Common.QuickInfo : 'Account Number of Master Record of Tax Office Responsible'
    SuplrTaxAuthorityAccountNumber : String(10) not null;
    @Common.Label : 'Carrier confirmation'
    @Common.Heading : 'CC'
    @Common.QuickInfo : 'Carrier confirmation is expected'
    SuplrCarrierConfirmIsExpected : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    @Common.QuickInfo : 'Plant (Own or External)'
    SupplierPlant : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Factory Calendar'
    @Common.Heading : 'Cal'
    @Common.QuickInfo : 'Factory calendar key'
    FactoryCalendar : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Payment Reason'
    PaymentReason : String(4) not null;
    @Common.Label : 'Central Del. Block'
    @Common.Heading : 'DeBl'
    @Common.QuickInfo : 'Central deletion block for master record'
    SupplierCentralDeletionIsBlock : Boolean not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Ctrlr. Set'
    @Common.Heading : 'Data Controller Set Flag'
    @Common.QuickInfo : 'BP: Data Controller Set Flag'
    DataControllerSet : String(1) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController1 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController2 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController3 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController4 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController5 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController6 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController7 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController8 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController9 : String(30) not null;
    @Common.IsUpperCase : true
    @UI.HiddenFilter : true
    @Common.Label : 'Data Controller'
    @Common.QuickInfo : 'BP: Data Controller (Internal Use Only)'
    DataController10 : String(30) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Transportation Chain'
    SupplierTransportationChain : String(10) not null;
    @Common.Label : 'Staging Time'
    @Common.QuickInfo : 'Staging Time in Days'
    SupplierStagingTimeInDays : Decimal(precision: 3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Scheduling Procedure'
    SupplierSchedulingProcedure : String(1) not null;
    @Common.Label : 'Rel. for Coll. No.'
    @Common.Heading : 'Cross Docking: Collective Numbering Is Supported'
    @Common.QuickInfo : 'Cross Docking: Relevant for Collective Numbering'
    CollectiveNumberingIsRelevant : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'PAN'
    @Common.Heading : 'Permanent account number'
    @Common.QuickInfo : 'Permanent Account Number'
    BusinessPartnerPanNumber : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'PAN Reference Number'
    BPPanReferenceNumber : String(40) not null;
    @Common.Label : 'PAN Valid From Date'
    BPPanValidFromDate : Date;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Valuation Area'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity FetchT001K {
    @Common.IsUpperCase : true
    @Common.Label : 'Valuation Area'
    @Common.Heading : 'ValA'
    key ValuationArea : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Company Code'
    @Common.Heading : 'CoCd'
    CompanyCode : String(4) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'CDS View for Plant Details'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity FetchT001WANDADRC {
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    key Plant : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Valuation Area'
    @Common.Heading : 'ValA'
    ValuationArea : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer No Plant'
    @Common.Heading : 'CustNoPlnt'
    @Common.QuickInfo : 'Customer Number of Plant'
    PlantCustomer : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sls Organization ICB'
    @Common.Heading : 'SO ICB'
    @Common.QuickInfo : 'Sales Organization for Intercompany Billing'
    SalesOrganization : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address'
    AddressID : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Node type: SCN'
    @Common.Heading : 'Nty'
    @Common.QuickInfo : 'Node type: supply chain network'
    Nodetype : String(3) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sppl. No. Plnt'
    @Common.Heading : 'Supplier Number Plant'
    @Common.QuickInfo : 'Supplier Number of Plant'
    PlantSupplier : String(10) not null;
    @Common.Label : 'Name'
    @Common.QuickInfo : 'Name 1'
    OrganizationName1 : String(40) not null;
    @Common.Label : 'Name 2'
    OrganizationName2 : String(40) not null;
    @Common.Label : 'City'
    CityName : String(40) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Street Code'
    @Common.QuickInfo : 'Street Number for City/Street File'
    Street : String(12) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'CDS view to get plant and shipping point'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity FetchTVSWZ {
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    key Plant : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Shipping Point'
    @Common.Heading : 'ShPt'
    @Common.QuickInfo : 'Shipping Point / Receiving Point'
    key Shippingpoint : String(4) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'CDS view for Sales Document item'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  @Capabilities.FilterRestrictions.FilterExpressionRestrictions : [ { Property: Quantity, AllowedExpressions: 'MultiValue' } ]
  entity FetchVBAP {
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Document'
    @Common.Heading : 'Sales Doc.'
    key SalesDocument : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Sales Document Item'
    @Common.Heading : 'Item'
    key SalesDocumentItem : String(6) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material'
    @Common.QuickInfo : 'Material Number'
    Material : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Profit Center'
    @Common.Heading : 'Profit Ctr'
    ProfitCenter : String(10) not null;
    @Measures.Unit : UOM
    @Common.Label : 'Order Quantity'
    @Common.QuickInfo : 'Cumulative order quantity in sales units'
    Quantity : Decimal(15, 3) not null;
    @Common.IsUnit : true
    @Common.Label : 'Sales Unit'
    @Common.Heading : 'SU'
    UOM : String(3) not null;
  };
};

