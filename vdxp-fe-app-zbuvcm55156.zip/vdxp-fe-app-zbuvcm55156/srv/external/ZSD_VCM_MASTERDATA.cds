/* checksum : e1b0b046d4bf893671719222a950418a */
@cds.external : true
@Aggregation.ApplySupported : { Transformations: [ 'aggregate', 'groupby', 'filter' ], Rollup: #None }
@Common.ApplyMultiUnitBehaviorForSortingAndFiltering : true
@Capabilities.FilterFunctions : [
  'eq',
  'ne',
  'gt',
  'ge',
  'lt',
  'le',
  'and',
  'or',
  'contains',
  'startswith',
  'endswith',
  'any',
  'all'
]
@Capabilities.SupportedFormats : [ 'application/json', 'application/pdf' ]
@PDF.Features : {
  DocumentDescriptionReference: '../../../../default/iwbep/common/0001/$metadata',
  DocumentDescriptionCollection: 'MyDocumentDescriptions',
  ArchiveFormat: true,
  Border: true,
  CoverPage: true,
  FitToPage: true,
  FontName: true,
  FontSize: true,
  Margin: true,
  Padding: true,
  Signature: true,
  HeaderFooter: true,
  ResultSizeDefault: 20000,
  ResultSizeMaximum: 20000
}
@Capabilities.KeyAsSegmentSupported : true
@Capabilities.AsynchronousRequestsSupported : true
service ZSD_VCM_MASTERDATA {
  @cds.external : true
  type MasterDataCheckCbAControl {
    @Common.Label : 'Dynamic CbA-Control'
    @Common.Heading : 'Dynamic Create by Association Control'
    @Common.QuickInfo : 'Dynamic Create via Association Control Property'
    _header : Boolean not null;
  };

  @cds.external : true
  type EntityControl {
    @Common.Label : 'Dyn. Method Control'
    @Common.Heading : 'Dynamic Method Control'
    @Common.QuickInfo : 'Dynamic Method Property'
    Deletable : Boolean not null;
    @Common.Label : 'Dyn. Method Control'
    @Common.Heading : 'Dynamic Method Control'
    @Common.QuickInfo : 'Dynamic Method Property'
    Updatable : Boolean not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'custom entity to check master data'
  @Capabilities.NavigationRestrictions.RestrictedProperties : [
    {
      NavigationProperty: _header,
      InsertRestrictions: { Insertable: ![__CreateByAssociationControl/_header] }
    }
  ]
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.FilterRestrictions.NonFilterableProperties : [ '__CreateByAssociationControl', '__EntityControl' ]
  @Capabilities.SortRestrictions.NonSortableProperties : [ '__CreateByAssociationControl', '__EntityControl' ]
  @Capabilities.ReadRestrictions.Readable : false
  @Capabilities.DeleteRestrictions.Deletable : ![__EntityControl/Deletable]
  @Capabilities.UpdateRestrictions.Updatable : ![__EntityControl/Updatable]
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity MasterDataCheck {
    key CompamyCode : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Material'
    @Common.QuickInfo : 'Material Number'
    key Material : String(18) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Profit Center'
    @Common.Heading : 'Profit Ctr'
    key MaterialBrand : String(10) not null;
    key ShipFromBusinessPartner : String(10) not null;
    key ShipFromPlant : String(10) not null;
    key EconomicRegionShipFrom : String(10) not null;
    key ShipToBusinessPartner : String(10) not null;
    key ShipToPlant : String(10) not null;
    key EconomicRegionShipTo : String(10) not null;
    key comments : String(100) not null;
    key VCAShippingRequestID : String(20) not null;
    key ScenarioID : String(20) not null;
    Error : String(1) not null;
    @Core.Computed : true
    @UI.HiddenFilter : true
    @UI.Hidden : true
    @Common.Label : 'Dynamic CbA-Control'
    @Common.Heading : 'Dynamic Create by Association Control'
    @Common.QuickInfo : 'Dynamic Create via Association Control Property'
    __CreateByAssociationControl : MasterDataCheckCbAControl;
    @Core.Computed : true
    @UI.HiddenFilter : true
    @UI.Hidden : true
    @Common.Label : 'Dyn. Method Control'
    @Common.Heading : 'Dynamic Method Control'
    @Common.QuickInfo : 'Dynamic Method Property'
    __EntityControl : EntityControl;
    @Common.Composition : true
    _header : Composition of many MasterDataCheckChild {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Custom entity to check master data'
  @Capabilities.NavigationRestrictions.RestrictedProperties : [
    { NavigationProperty: _root, InsertRestrictions: { Insertable: false } }
  ]
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.FilterRestrictions.NonFilterableProperties : [ '__EntityControl' ]
  @Capabilities.SortRestrictions.NonSortableProperties : [ '__EntityControl' ]
  @Capabilities.ReadRestrictions.Readable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : ![__EntityControl/Deletable]
  @Capabilities.UpdateRestrictions.Updatable : ![__EntityControl/Updatable]
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity MasterDataCheckChild {
    @Core.Computed : true
    key CompamyCode : String(4) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Material'
    @Common.QuickInfo : 'Material Number'
    key Material : String(18) not null;
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Profit Center'
    @Common.Heading : 'Profit Ctr'
    key MaterialBrand : String(10) not null;
    @Core.Computed : true
    key ShipFromBusinessPartner : String(10) not null;
    @Core.Computed : true
    key ShipFromPlant : String(10) not null;
    @Core.Computed : true
    key EconomicRegionShipFrom : String(10) not null;
    @Core.Computed : true
    key ShipToBusinessPartner : String(10) not null;
    @Core.Computed : true
    key ShipToPlant : String(10) not null;
    @Core.Computed : true
    key EconomicRegionShipTo : String(10) not null;
    @Core.Computed : true
    key comments : String(100) not null;
    @Core.Computed : true
    key VCAShippingRequestID : String(20) not null;
    @Core.Computed : true
    key ScenarioID : String(20) not null;
    Error1 : String(1) not null;
    LegalEntity : String(20) not null;
    VirtualEntity : String(10) not null;
    comments1 : String(600) not null;
    @Core.Computed : true
    @UI.HiddenFilter : true
    @UI.Hidden : true
    @Common.Label : 'Dyn. Method Control'
    @Common.Heading : 'Dynamic Method Control'
    @Common.QuickInfo : 'Dynamic Method Property'
    __EntityControl : EntityControl;
    _root : Association to one MasterDataCheck {  };
  };
};

