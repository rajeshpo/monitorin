// --------------------------------------------------------------------------------------------------------------------*
// Application Name : VCM Pre Requisite API
// Object Id       : ZBUVCM55156
// Release         : 1
// Version         : 0.01
// Description     : Application to Perform Automation PreRequisite Checks
// ----------------------------------------------------------------------------*
// Descriptions: Provides service definitions, handlers, and utility functions for the VCM PreRequisite API application .
//This module handles custom actions, and external API integration for managing VCM PreRequisite API.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*

using { ZAPI_BATCH_SRV } from './external/ZAPI_BATCH_SRV';
using { ZAPI_INBOUND_DELIVERY_SRV } from './external/ZAPI_INBOUND_DELIVERY_SRV';
using { ZAPI_MATERIAL_DOCUMENT_SRV } from './external/ZAPI_MATERIAL_DOCUMENT_SRV';
using { ZAPI_SALES_ORDER_SRV } from './external/ZAPI_SALES_ORDER_SRV';
using {ZAPI_SALES_ORDER_WITHOUT_CHARGE_SRV} from './external/ZAPI_SALES_ORDER_WITHOUT_CHARGE_SRV';
using {ZAPI_INSPECTIONLOT_SRV} from './external/ZAPI_INSPECTIONLOT_SRV';
using {ZSD_LOGIST_DEL_109} from './external/ZSD_LOGIST_DEL_109';
using { ZAPI_INFORECORD_PROCESS_SRV } from './external/ZAPI_INFORECORD_PROCESS_SRV';
using{ ZSD_VCM_AUTOMATION_FIN_SCN1 } from './external/ZSD_VCM_AUTOMATION_FIN_SCN1';
using { ZAPI_PURCHASING_SOURCE_SRV } from './external/ZAPI_PURCHASING_SOURCE_SRV';
using { ZAPI_CLFN_CHARACTERISTIC_SRV } from './external/ZAPI_CLFN_CHARACTERISTIC_SRV';
using { BILLINGDOCUMENT } from './external/BILLINGDOCUMENT';
using {ZAPI_OUTBOUND_DELIVERY_SRV} from './external/ZAPI_OUTBOUND_DELIVERY_SRV';
using { PURCHASEORDER } from './external/PURCHASEORDER';
using { ZAPI_PURCHASECONTRACT_PROCESS_SRV } from './external/ZAPI_PURCHASECONTRACT_PROCESS_SRV';
using { ZSD_VCM_PO_TRIGGERS } from './external/ZSD_VCM_PO_TRIGGERS';
using { ZAPI_SUPPLIERINVOICE_PROCESS_SRV } from './external/ZAPI_SUPPLIERINVOICE_PROCESS_SRV';
using { ZAPI_BUSINESS_PARTNER } from './external/ZAPI_BUSINESS_PARTNER';
using { ZSD_VCM_AUTOMATIONFLW } from './external/ZSD_VCM_AUTOMATIONFLW';

@path: '/zbuvcm55156'
service zbuvcm55156Service {





    /**
     * Represents the Virtual enitity data structure for
     * the OutputPayload of PFC Check
     */
    type VEntity {
        Virtual : String(30);
        Legal   : String(40);
    }


    /**
     * Represents the output payload of PFC Check
     */
    type OutPayload {
        PfcCatId        : String(80);
        ProdId          : String(80);
        BpSFrom         : String(80);
        PlantSFrom      : String(80);
        ErSFrom         : String(80);
        BpSTo           : String(80);
        PlantSTo        : String(80);
        ErSTo           : String(80);
        Matnr           : String(80);
        MatBrand        : String(80);
        VirtualEntity   : array of VEntity;
    }

    /**
     * Represents the input payload of PFC Check from SBPA
     */
    type InputPayload {
        BpSFrom         : String(80);
        PlantSFrom      : String(80);
        ErSFrom         : String(80);
        BpSTo           : String(80);
        PlantSTo        : String(80);
        ErSTo           : String(80);
        Matnr           : String(80);
        MatBrand        : String(80);
        InitialDocumentType : String(20);
    }

    type ScenarioInputPayload {
        productFlowCatalogID : String(80);
        shippingReqNo        : String(80);
        initialDocumentNo    : String(80);
    doctype              : String;
    PlantSTo             : String(80);
    cquenceId            : String;
    PlantType: String(10);
    }

    type ScenarioOutputPayload {
        productFlowCatalogID : String(80);
        SID                  : String(20);
        shippingReqNo        : String(80);
        initialDocumentNo    : String(80);
        steps: array of LargeString;
    }

  type MasterDataHeader  : {
    VCAShippingRequestID    : String(50);
    ScenarioID              : String(50);
    ShipFromBusinessPartner : String(20);
    ShipFromPlant           : String(20);
    EconomicRegionShipFrom  : String(10);
    ShipToBusinessPartner   : String(20);
    ShipToPlant             : String(20);
    EconomicRegionShipTo    : String(10);
    Material                : String(40);
    MaterialBrand           : String(40);
    LegalEntity             : String(50);
    VirtualEntity           : String(50);
  }


  type MasterConstants   : {
    VarName                 : String(50);
    SeqNo                   : String;
    High                    : String(50);
    Low                     : String(50);

    VCAShippingRequestID    : String(50);
    ScenarioID              : String(50);
    ShipFromBusinessPartner : String(20);
    ShipFromPlant           : String(20);
    EconomicRegionShipFrom  : String(10);
    ShipToBusinessPartner   : String(20);
    ShipToPlant             : String(20);
    EconomicRegionShipTo    : String(10);
    Material                : String(40);
    MaterialBrand           : String(40);
  }

  type InTimeOrNotInTime : {
    CONST_VAR_NAME          : String(50);
    SEQNO                   : String;
    CATEGORY                : String(20);
    VALUE                   : String(50);

    VCAShippingRequestID    : String(50);
    ScenarioID              : String(50);
    ShipFromBusinessPartner : String(20);
    ShipFromPlant           : String(20);
    EconomicRegionShipFrom  : String(10);
    ShipToBusinessPartner   : String(20);
    ShipToPlant             : String(20);
    EconomicRegionShipTo    : String(10);
    Material                : String(40);
    MaterialBrand           : String(40);
  }


  type MasterDataPayload : {
    ID                      : String(100);
    wfID                    : String(100);
    QueueId                 : String(100);
    VCAShippingRequestID    : String(50);
    ScenarioID              : String(50);
    ShipFromBusinessPartner : String(20);
    ShipFromPlant           : String(20);
    EconomicRegionShipFrom  : String(10);
    ShipToBusinessPartner   : String(20);
    ShipToPlant             : String(20);
    EconomicRegionShipTo    : String(10);
    Material                : String(40);
    MaterialBrand           : String(40);
    _header                 : many MasterDataHeader;
    _InTimeOrNotInTime      : many InTimeOrNotInTime;
    _constants              : many MasterConstants;
  }

/******************************************************************************** */
type OutBoundDelivery {
    ID          : String(100);
    wfID        : String(100);
    APIDetails  : DeliveryAPIDetails;
}

type DeliveryAPIDetails {
    to_DeliveryDocumentItem : DeliveryDocumentItemResults;
    DeliveryDocumentBySupplier: String; //JGHJ-87133
}

type DeliveryDocumentItemResults {
    results : array of DeliveryDocumentItem;
}

type DeliveryDocumentItem {
    ReferenceSDDocument : String(50);
    Batch : String;
    MaterialByCustomer:String;
    DeliveryQuantityUnit:String;
    ActualDeliveryQuantity:String;
    ReferenceSDDocumentItem:String;
}


/****************************************************CREATE SALES ORDER WRAPPER API PAYLOAD STRUCTURE********************************************* */
type SalesOrderItemResultsWrapper {
  results : array of SalesOrderItemResults;
}

type SalesOrderPartnerResultsWrapper {
  results : array of SalesOrderPartnerResults;
}
type SalesOrderCreateData {
  to_Item                    : SalesOrderItemResultsWrapper;
  to_Partner                 : SalesOrderPartnerResultsWrapper;
  SoldToParty                : String(10);
  SalesOrderDate             : String(30);
  SalesOrderType             : String(4);
  SalesOrganization          : String(4);
  DistributionChannel        : String(2);
  OrganizationDivision       : String(2);
  PurchaseOrderByCustomer    : String(35);
  PurchaseOrderByShipToParty : String(35);
  SDDocumentReason           : String(3);
  CustomerPurchaseOrderType  : String(4);
}

type SalesOrderItemResults {
  Batch                  : String(10);
  Material               : String(40);
  SalesOrderItem         : String(6);
  ProductionPlant        : String(4);
  StorageLocation        : String(4);
  RequestedQuantity      : Decimal(13,3);
  SalesOrderItemCategory : String(4);
  RequestedQuantityUnit  : String;
}

type SalesOrderPartnerResults {
  Customer        : String(10);
  PartnerFunction : String(2);
}

type SalesOrderPayload {
  ID      : String(100);
  wfID    : String(100);
  APIDetails : SalesOrderCreateData;
}



/*******************************************CREATE AP INVOICE********************************************** */
 
type SupplierInvoicePayload {
  ID: String(100);
  wfID: String;
  APIDetails: APIDetailsType;
}

type poUncancelPayload {
  ID: String(100);
  wfID: String;
  QueueId: String;
  APIDetails: APIDetails;
}

type APIDetails {
  PurchaseOrder: String;
  PurchaseOrderItem: String;
  PurchaseOrderDeletionCode: String;
}

/**
 * API details for Supplier Invoice
 */
type APIDetailsType {
  CompanyCode: String;
  PostingDate: String;
  DocumentDate: String;
  CreationDate:String;
  PaymentTerms:String;
  DocumentCurrency: String;
  InvoiceGrossAmount: String;
  SupplierInvoiceIDByInvcgParty: String;
  SupplierInvoiceIsCreditMemo:String;
  AccountingDocumentType:String;
  to_SuplrInvcItemPurOrdRef: SuplrInvcItemPurOrdRefAssoc;
}

/**
 * Association for Supplier Invoice Item Purchase Order Reference
 */
type SuplrInvcItemPurOrdRefAssoc {
  results: array of SuplrInvcItemPurOrdRef;
}

/**
 * Structure for each Item in Supplier Invoice Purchase Order Reference
 */
type SuplrInvcItemPurOrdRef {
  TaxCode: String;
  PurchaseOrder: String;
  DocumentCurrency: String;
  PurchaseOrderItem: String;
  ReferenceDocument: String;
  SupplierInvoiceItem: String;
  ReferenceDocumentItem: String;
  PurchaseOrderQuantityUnit: String;
  SupplierInvoiceItemAmount: String;
  QuantityInPurchaseOrderUnit: String;
  ReferenceDocumentFiscalYear: String;
}




/*******************************************CREATE PURCHASE ORDER TYPES  START********************************************** */


type PurchaseOrderPayload {
  ID: String;
  wfID: String;
  APIDetails: PurchaseOrderAPIDetails;
}

/**
 * API Details for Purchase Order
 */
type PurchaseOrderAPIDetails {
  Supplier: String;
  CompanyCode: String;
  PurchaseOrder:String;
  PurchasingGroup: String;
  SupplierPhoneNumber:String;
  DocumentCurrency: String;
  PurchaseContract: String;
  PurchaseOrderDate: String;
  PurchaseOrderType: String;
  SupplyingSupplier: String;
  PurchasingOrganization: String;
  CorrespncExternalReference: String;
  SupplierRespSalesPersonName: String;

  _PurchaseOrderItem: array of  PurchaseOrderItems;
  _PurchaseOrderPartner:array of PurchaseOrderPartners;
}

type PurchaseOrderPartners{
  PartnerFunction:String;
  Supplier:String;
}

/**
 * Purchase Order Item
 */
type PurchaseOrderItems {
  Batch: String;
  Plant: String;
  Material: String;
  OrderQuantity: Decimal(15,3);
  Subcontractor:String;
  NetPriceAmount: Decimal(15,2);
  StorageLocation: String;
  PurchaseContract: String;
  PurchaseOrderItem: String;
  PurchasingInfoRecord:String;
  SupplierIsSubcontractor:Boolean;
  PurchaseContractItem: String;
  AccountAssignmentCategory: String;
  PurchaseOrderQuantityUnit: String;
  PurchaseOrderItemCategory:String;
  ReferenceDeliveryAddressID:String;
  SupplierConfirmationControlKey:String;
  InvoiceIsGoodsReceiptBased: Boolean;
  IsReturnsItem:Boolean;
  DocumentCurrency:String;
  ProfitCenter : String;
  // JGHJ-90834
  Customer: String;
  // JGHJ-90834

  _PurOrdAccountAssignment: array of  PurchaseOrderAccountAssignments;
}

/**
 * Purchase Order Account Assignment
 */
type PurchaseOrderAccountAssignments {
  SalesOrder: String;
  SalesOrderItem: String;
  PurchaseOrderItem: String;
  AccountAssignmentNumber: String;
  GLAccount:String;
  ProfitCenter:String;
}




/*********************************************CREATE GOODS RECIEPT / MATERIAL TRANSFER START********************************************** */

type GRPayload {
  ID: String;
  wfID: String;
  APIDetails: GRAPIDetails;
}

/**
 * API Details for Goods Receipt
 */
@cds.persistence.skip
type GRAPIDetails {
  PostingDate: String;
  GoodsMovementCode: String;
  ReferenceDocument: String;
  MaterialDocumentYear: String;
  DocumentDate:String;

  /**
   * Nested array of Material Document Items
   * CAP expects a direct array for Composition of many
   */
  to_MaterialDocumentItem: GRMaterialDocumentItemAssoc;
}

type GRMaterialDocumentItemAssoc {
  results: array of GRMaterialDocumentItem;
}

/**
 * Structure for each Material Document Item
 */
@cds.persistence.skip
type GRMaterialDocumentItem {
  Batch: String;
  Plant: String;
  Material: String;
  CostCenter:String;
  EntryUnit: String;
  SalesOrder:String; //JGHJ-87950
  SalesOrderItem:String; //JGHJ-87950
  MaterialBaseUnit:String;
  IssgOrRcvgMaterial:String;
  QuantityInBaseUnit:String;
  PurchaseOrder: String;
  StorageLocation: String;
  GoodsMovementType: String;
  PurchaseOrderItem: String;
  QuantityInEntryUnit: String;
  MaterialDocumentItem: String;
  MaterialDocumentYear:String;
  IssuingOrReceivingPlant:String;
  IssuingOrReceivingStorageLoc:String;
  GoodsMovementRefDocType: String;
  IssgOrRcvgSpclStockInd:String; //Defect JGHJ-76763
  InventorySpecialStockType:String; //Defect JGHJ-76814
  Supplier:String;//Defect JGHJ-76814
  Delivery:String;//SC3 TAT JGHJ-55536
  DeliveryItem:String;//SC3 TAT JGHJ-55536
  SpecialStockIdfgSalesOrder:String; //JGHJ-87950
  SpecialStockIdfgSalesOrderItem:String; //JGHJ-87950

}

/**************************************CREATE GOODS RECIEPT ********************************* */

type GIPayload{
  ID: String;
  wfID: String;
  APIDetails: GIAPIDetails;
}

type GIAPIDetails{
  DeliveryDocument : String;

}



/**************************************AR INVOICE START********************************* */
type ARIPayload {
    ID          : String;
    wfID        : String;
    APIDetails  : ARIDetailsType;
}

type ARIDetailsType {
    _Reference  : array of ReferenceType;
}

type ReferenceType {
    SDDocument         : String;
    SalesOrganization  : String;
    SDDocumentCategory : String;
    BillingDocumentDate: String;
    BillingDocumentType: String;
}


/**************************************CREATE BATCH ********************************* */
type BatchPayload {
    ID          : String;
    wfID        : String;
    APIDetails  : BDetailsType;
}

type BDetailsType{
     Batch: String;
     Plant: String;
     Material: String;
     ExpiryDate: String;
     ManufacturingDate:String;
     VendrBatch:String
}

/**************************************UPDATE BATCH CHARACTERISTICS********************************* */
type updateBPayload{
    ID          : String;
    wfID        : String;
    APIDetails  : UBDetailsType;
}

type UBDetailsType{
  Batch: String;
  CharcValue: String;
  Material: String;
  CharcInternalID: String;
  BatchIdentifyingPlant: String;
  ManufactureDate:String;
  ShelfLifeExpirationDate:String;
  CharcValueDependency: String;
  CharcFromNumericValue: Double;
}


/*******************************UPDATE OBD WITH BATCH*********************************** */

type updateOBDBatch{
   ID          : String;
   wfID        : String;
   DeliveryDocument: String;
   DeliveryDocumentItem: String;
   APIDetails  : OBDBatchDetailsType;
}
type updateOBDHeader{
   ID          : String;
   wfID        : String;
   DeliveryDocument: String;
   APIDetails  : OBDHeaderDetailsType;
}

type OBDHeaderDetailsType{
  DeliveryDocumentBySupplier: String; //JGHJ-87137
}

type OBDBatchDetailsType{
  Batch: String;
  StorageLocation: String;
  MaterialByCustomer:String;
  DeliveryDocumentBySupplier: String; //JGHJ-87137
}

/************************************GR AFTER IBD ************************************ */

type IBDGRPayload{
    ID          : String;
    wfID        : String;
    APIDetails  : IBDGRDetailsType;
}

type IBDGRDetailsType{
  DeliveryDocument: String;
  ActualGoodsMovementDate: String;
}


/*********************************CANCEL INSPECTION LOT******************** */

type ILPayload{
  ID          : String;
  wfID        : String;
  APIDetails  : ILDetailsType;
}

type ILDetailsType{
  Message: String;
  InspectionLot: String;
}

/***************************************UPDATE PURCHASE ORDER ITEM OR PURCAHSE ORDER ACCOUNT ASSIGNMENT*********** */

type POIPayload{
  ID          : String;
  wfID        : String;
  APIDetails  : POIDetailsType;
}

type POIDetailsType{
  PurchaseOrder: String;
  PurchaseOrderItem: String;
  AccountAssignmentNumber: String;
  IsCompletelyDelivered: Boolean;
  SalesOrder:String;
  SalesOrderItem:String;
}

/***************************************UPDATE SALES ORDER ITEM ********************************************* */

type SOIPayload {
    ID         : String;
    wfID       : String;
    APIDetails : SOIDetailsType;
  }

type SOIDetailsType {
    SalesOrder              : String;
    SalesOrderItem          : String;
    SalesDocumentRjcnReason : String;
  }

/*************************************Set Picking BASE Quantity ********************************************* */

type SPQPayload{
  ID          : String;
  wfID        : String;
  APIDetails  : SPQDetailsType;
}

type SPQDetailsType{
  BaseUnit:String; 
  DeliveryDocument:String; 
  DeliveryDocumentItem: String; 
  ActualDeliveredQtyInBaseUnit: String;
}

/*************************************Posting Inbound Delivery ************************************************* */

type IBDPayload{
  ID          : String;
  wfID        : String;
  APIDetails  : DeliveryAPIDetail;
}

type DeliveryAPIDetail {
    Supplier              : String;
    DeliveryDate          : String;
    to_DeliveryDocumentItem : DeliveryDocumentItemResult;
    DeliveryDocumentBySupplier: String; //JGHJ-87133
}

type DeliveryDocumentItemResult {
    results : array of DeliveryDocumentItems;
}

type DeliveryDocumentItems {
    Batch                   : String;
    Plant                   : String;
    Material                : String;
    ReferenceSDDocument     : String;
    DeliveryQuantityUnit    : String;
    ActualDeliveryQuantity  : String;
    ReferenceSDDocumentItem : String;
}

// ---- CR - JGHJ-89833 -- START

  type PickOneItemWithSalesQuantityPayload {
    ID         : String;
    wfID       : String;
    APIDetails : PickOneItemWithSalesQuantity;
  }

  type PickOneItemWithSalesQuantity {
    DeliveryDocument       : String(10);
    DeliveryDocumentItem   : String(6);
    DeliveryQuantityUnit   : String(3);
    ActualDeliveryQuantity : String;
  }

  // JGHJ-102853
  type UpdateBatchCharValueType {
    Batch                    : String(10);
    CharcValue               : String(70);
    Material                 : String(18);
    CharcInternalID          : String(10);
    BatchIdentifyingPlant    : String(4);
    CharcValueDependency     : String(1);
    CharcFromNumericValue    : Double;
    CharcFromDecimalValue    : Decimal(31,14);
    CharcValuePositionNumber : String(3);
  }

  type UpdateBatchCharValuePayload {
    ID         : String;
    wfID       : String;
    APIDetails : UpdateBatchCharValueType;
  }

  // JGHJ-102853

  // ---- CR - JGHJ-89833 -- END

  type PfcCheckForLineItemPayload{
    ID         : String;
    wfID       : String;
    QueueId    : String;
    APIDetails : PfcCheckForLineItemType;
  }

  type PfcCheckForLineItemType {
    material      : String;
    materialBrand : String;
    catalogId     : String;
    item          : String;
  }

  type create_PurchaseOrderLineItemPayload{
    ID         : String;
    wfID       : String;
    QueueId    : String;
    APIDetails : create_PurchaseOrderLineItemType;
  }
  type create_SalesOrderLineItemPayload{
    ID         : String;
    wfID       : String;
    QueueId    : String;
    APIDetails : create_SalesOrderLineItemType;
  }

  type create_PurchaseOrderLineItemType {
      PurchaseOrder:String;
      PurchaseOrderItem: String;
      Material: String;
      AccountAssignmentCategory:String;
      Plant:String;
      StorageLocation:String;
      PurchaseContract: String;
      InvoiceIsGoodsReceiptBased: Boolean;
      OrderQuantity: Int16;
      PurchaseOrderQuantityUnit:String;
      PurchaseContractItem:String;
}
  type create_SalesOrderLineItemType {
      SalesOrder:String;
      SalesOrderItem: String;
      Material: String;
      ProductionPlant:String;
      StorageLocation:String;
      RequestedQuantity: Int16;
    }

// JGHJ-87133
  type create_BatchSplitItemOutbDeliveryPayload{
    ID         : String;
    wfID       : String;
    APIDetails : create_BatchSplitItemOutbDeliveryType;
  }
// JGHJ-87133
  type create_BatchSplitItemOutbDeliveryType {
    Batch                  : String;
    DeliveryDocument       : String;
    DeliveryDocumentItem   : String;
    DeliveryQuantityUnit   : String;
    ActualDeliveryQuantity : String;
    BatchBySupplier        : String; //JGHJ-87137
  }
   // JGHJ-87133
    action create_BatchSplitItemOutbDelivery(payload:create_BatchSplitItemOutbDeliveryPayload) returns LargeString;
    action poUncancel(Payload:poUncancelPayload) returns LargeString;
  // JGHJ-87133
  // JGHJ-87133
    action create_BatchSplitItemInbDelivery(payload:create_BatchSplitItemOutbDeliveryPayload) returns LargeString;
  // JGHJ-87133
    action create_PurchaseOrderLineItem(payload:create_PurchaseOrderLineItemPayload) returns  LargeString;
    action create_SalesOrderLineItem(payload:create_SalesOrderLineItemPayload) returns LargeString;
    action PfcCheckForLineItem(payload:PfcCheckForLineItemPayload) returns String;
    action masterdataCheck(payload : MasterDataPayload) returns String;
    action ScenarioCheck(Payload: array of ScenarioInputPayload,ID:String,wfID:String) returns array of ScenarioOutputPayload;
    action pfcCheck(InputPayload: array of InputPayload,ID:String,wfID:String)         returns array of OutPayload;
    action pfcCheckPO(InputPayload: array of InputPayload,ID:String,wfID:String)         returns array of OutPayload;
    action post_OutbDeliveryHeader(Payload: OutBoundDelivery) returns LargeString;
    action create_SaleOrder(Payload:SalesOrderPayload) returns LargeString;
    action create_SupplierInvoice(Payload:SupplierInvoicePayload) returns LargeString;
    action create_PurchaseOrder(Payload:PurchaseOrderPayload) returns LargeString;
    action create_GR(Payload:GRPayload) returns LargeString;
    action post_GoodsIssue(Payload:GIPayload) returns LargeString;
    action post_ARInvoice(Payload:ARIPayload) returns LargeString;
    action create_MaterialDocTransfer(Payload:GRPayload) returns LargeString;
    action create_Batch(Payload:BatchPayload) returns LargeString;
    action update_BatchChar(Payload:updateBPayload) returns LargeString;
    action update_BatchManuDate(Payload:updateBPayload) returns LargeString;
    action update_OBDBatch(Payload:updateOBDBatch) returns LargeString;
    action update_OBDHeaders(Payload:updateOBDHeader) returns LargeString;
    action post_IBD_GR(Payload:IBDGRPayload) returns LargeString;
    action cancel_InspectionLot(Payload:ILPayload) returns LargeString;
    action update_PurchaseOrderItem(Payload:POIPayload) returns LargeString;
    action setPickQuantity(Payload:SPQPayload) returns LargeString;
    action addTimeout(seconds:String) returns String;
    action post_LegacySalesOrder(so_Num:String,reference_Po:String, wfID:String) returns String;
    action post_PurchaseOrderAccountAssignment (Payload:POIPayload) returns LargeString;
    action post_IBD(Payload:IBDPayload) returns LargeString;
    action update_SalesOrderItem(Payload:SOIPayload) returns LargeString;
    // ---- CR - JGHJ-89833 -- START
    action post_PickOneItemWithSalesQuantity(Payload: PickOneItemWithSalesQuantityPayload)        returns LargeString;
    // ---- CR - JGHJ-89833 -- END
    // ---- JGHJ-102853 --- START
    action update_BatchCharValue(Payload: UpdateBatchCharValuePayload) returns LargeString;
    // ---- JGHJ-102853 --- END


    
  entity Batch               as projection on ZAPI_BATCH_SRV.Batch;
  entity A_InbDeliveryHeader as projection on ZAPI_INBOUND_DELIVERY_SRV.A_InbDeliveryHeader;
  // JGHJ-87133
  entity A_OutbDeliveryHeader as projection on ZAPI_OUTBOUND_DELIVERY_SRV.A_OutbDeliveryHeader;
  // JGHJ-87133

  entity A_MaterialDocumentHeader as projection on ZAPI_MATERIAL_DOCUMENT_SRV.A_MaterialDocumentHeader;
  entity A_MaterialDocumentItem as projection on ZAPI_MATERIAL_DOCUMENT_SRV.A_MaterialDocumentItem;

  entity A_InbDeliveryItem as projection on ZAPI_INBOUND_DELIVERY_SRV.A_InbDeliveryItem;

  entity CquenceDetails  as projection on ZSD_LOGIST_DEL_109.CquenceDetails;

  entity A_SalesOrder  as projection on ZAPI_SALES_ORDER_SRV.A_SalesOrder;
  entity A_SalesOrderItem as projection on ZAPI_SALES_ORDER_SRV.A_SalesOrderItem;
  entity A_SalesOrderHeaderPartner  as projection on ZAPI_SALES_ORDER_SRV.A_SalesOrderHeaderPartner;

  entity A_SalesOrderWithoutCharge as projection on ZAPI_SALES_ORDER_WITHOUT_CHARGE_SRV.A_SalesOrderWithoutCharge;
  entity A_SlsOrdWthoutChrgPartner as projection on ZAPI_SALES_ORDER_WITHOUT_CHARGE_SRV.A_SlsOrdWthoutChrgPartner;

  entity A_InspectionLot as projection on ZAPI_INSPECTIONLOT_SRV.A_InspectionLot;
  entity A_InspLotUsageDecision as projection on ZAPI_INSPECTIONLOT_SRV.A_InspLotUsageDecision;

  entity A_PurchasingInfoRecord as projection on ZAPI_INFORECORD_PROCESS_SRV.A_PurchasingInfoRecord;
  entity A_PurgInfoRecdOrgPlantData as projection on ZAPI_INFORECORD_PROCESS_SRV.A_PurgInfoRecdOrgPlantData;

  entity FetchT001WANDADRC as projection on ZSD_VCM_AUTOMATION_FIN_SCN1.FetchT001WANDADRC;
  entity FetchLFA1 as projection on ZSD_VCM_AUTOMATION_FIN_SCN1.FetchLFA1;
  entity FetchT001K as projection on ZSD_VCM_AUTOMATION_FIN_SCN1.FetchT001K;

  entity FetchT001W as projection on ZSD_VCM_PO_TRIGGERS.FetchT001W;
  entity FetchKNA1 as projection on ZSD_VCM_PO_TRIGGERS.FetchKNA1;
  entity FetchADRC as projection on ZSD_VCM_PO_TRIGGERS.FetchADRC;

  entity A_PurchasingSource as projection on ZAPI_PURCHASING_SOURCE_SRV.A_PurchasingSource;
  entity A_ClfnCharacteristicForKeyDate as projection on ZAPI_CLFN_CHARACTERISTIC_SRV.A_ClfnCharacteristicForKeyDate;


  entity BillingDocument as projection on BILLINGDOCUMENT.BillingDocument;
  entity BillingDocumentItem as projection on BILLINGDOCUMENT.BillingDocumentItem;

  entity A_OutbDeliveryItem as projection on ZAPI_OUTBOUND_DELIVERY_SRV.A_OutbDeliveryItem;

  entity A_PurchaseContractItem as projection on ZAPI_PURCHASECONTRACT_PROCESS_SRV.A_PurchaseContractItem;

  entity PurchaseOrder as projection on PURCHASEORDER.PurchaseOrder;
  entity PurchaseOrderItem as projection on PURCHASEORDER.PurchaseOrderItem;

  entity A_SuplrInvcItemPurOrdRef as projection on ZAPI_SUPPLIERINVOICE_PROCESS_SRV.A_SuplrInvcItemPurOrdRef;
  entity A_PurCtrPartners               as projection on ZAPI_PURCHASECONTRACT_PROCESS_SRV.A_PurCtrPartners;

  entity knvp as projection on ZSD_VCM_AUTOMATIONFLW.knvp;
  entity CustomertoBP as projection on ZSD_VCM_AUTOMATIONFLW.CustomertoBP;

  entity A_BusinessPartner as projection on ZAPI_BUSINESS_PARTNER.A_BusinessPartner;

  // CR JIRA  JGHJ-87133 -- START ---
  entity A_PurchaseContract             as projection on ZAPI_PURCHASECONTRACT_PROCESS_SRV.A_PurchaseContract;
  entity A_SalesOrderScheduleLine       as projection on ZAPI_SALES_ORDER_SRV.A_SalesOrderScheduleLine;
  entity A_CustomerSalesArea            as projection on ZAPI_BUSINESS_PARTNER.A_CustomerSalesArea;
  entity PurchaseOrderScheduleLine      as projection on PURCHASEORDER.PurchaseOrderScheduleLine;
  // CR JIRA  JGHJ-87133 -- END ---

  entity A_SupplierInvoice as projection on ZAPI_SUPPLIERINVOICE_PROCESS_SRV.A_SupplierInvoice;
  entity A_SalesOrderItemPrElement as projection on ZAPI_SALES_ORDER_SRV.A_SalesOrderItemPrElement;
  // JGHJ-102853 -- START
  entity BatchCharcValue as projection on ZAPI_BATCH_SRV.BatchCharcValue;
  // JGHJ-102853 -- END

}
