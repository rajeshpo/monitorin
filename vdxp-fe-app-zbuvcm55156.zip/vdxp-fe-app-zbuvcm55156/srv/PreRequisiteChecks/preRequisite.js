// --------------------------------------------------------------------------------------------------------------------*
// Application Name : VCM Pre Requisite API 
// Object Id       : ZBUVCM55156
// Release         : 1
// Version         : 0.01
// Description     : Application to Perform Automation PreRequisite Checks
// ----------------------------------------------------------------------------*
// Descriptions:This has logic functions used in Pfc Check and Scenario Check
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*

const textBundle = require('../_i18n/textBundle');
let bundle = '';

/**
 * Process PFCCheck for inputpayload 
 * Enriches InputPayload with CatId and Ventities from pfcData based on Matnr and MatBrand matching
 * 
 * @param {Array} pfcData - Array of PFC data objects containing Items and Ventities
 * @param {Array} InputPayload - Array of input payload objects to be enriched
 * @returns {Array} OutputPayload - Enriched payload with CatId and Ventities added
 */
async function pfcCheck(req, pfcData, InputPayload, odata, pfcDest, legEntityData) {
  try {
    // Input validation
    if (!Array.isArray(pfcData) || !Array.isArray(InputPayload)) {
      throw new Error('Both pfcData and InputPayload must be arrays');
    }

    if (!InputPayload?.length) {
     throw new Error("InputPayload is empty");
    }

    // Create lookup maps based on business partner/plant info first, then Matnr/MatBrand
    const businessContextLookup = new Map();

    pfcData.forEach(pfcItem => {
      // Ensure pfcItem has required structure
      if (!pfcItem || typeof pfcItem !== 'object') return;

      const items = pfcItem.Items || [];
      const ventities = pfcItem.Ventities || [];

      // Create header ShipFrom ShipTo  key from pfcItem (parent level)
      const businessContextKey = `${pfcItem.BpSFrom || ""}-${pfcItem.ErSFrom || ""}-${pfcItem.BpSTo || ""}-${pfcItem.ErSTo || ""}`;

      // Initialize the ShipFrom ShipTo  entry if it doesn't exist
      if (!businessContextLookup.has(businessContextKey)) {
        businessContextLookup.set(businessContextKey, {
          matnrLookup: new Map(),
          matBrandTypeLookup:new Map(),
          matTypeOnlyLookup: new Map(),
          ventities: ventities
        });
      }

      const contextData = businessContextLookup.get(businessContextKey);

      // Process Items array within this business context
      items.forEach(item => {
        if (!item) return;
        
        let dateCheck =  isCurrentDateWithinRange(item); // Defect JGHJ-75773
        const lookupData = {
          CatId: item.CatId || "",
          ProdId: pfcItem.ProdId || "",
          Ventities: ventities,  // Defect JGHJ-75773
          Status: item.Status,   // Defect JGHJ-75773
          dateCheck: dateCheck,  // Defect JGHJ-75773
          ApprStatus: item.ApprStatus  // Defect JGHJ-75773
        };

        // Primary lookup: If item has Matnr, add to matnrLookup within this context
        if (item.Matnr && item.MatBrand && item.MatType) { // Defect JGHJ-75773
          contextData.matnrLookup.set(item.Matnr, lookupData);
        }
        //First Fallback lookup: If item has MatBrand and MatType but NO Matnr , add to matBrandTypeLookup within this context
        if (!item.Matnr && item.MatBrand && item.MatType) { // Defect JGHJ-75773
          contextData.matBrandTypeLookup.set(`${item.MatBrand}_${item.MatType}`, lookupData);
        }
        // Fallback lookup: If item has MatType but NO Matnr and NO MatBrand, add to matTypeOnlyLookup within this context
        else if (!item.MatBrand && !item.Matnr && item.MatType) { // Defect JGHJ-95554
          contextData.matTypeOnlyLookup.set(item.MatType, lookupData);
        }
      });
    });

    /**************************************************************ECOREGION FETCHING LOGIC********************************************************************************** */
    const EcoRegionData = await pfcDest.tx(req).get(`/zbuvcm47419/EcoRegion`);
const ecoRegions = EcoRegionData?.value || [];

const CountrySFrom = await odata.run(
  SELECT.columns('Country').from('Massbpplantcntrykey').where({ BusinessPartner: InputPayload[0].BpSFrom })
);

const countryFrom = CountrySFrom?.[0]?.Country;
const erFrom = ecoRegions.find(e => e.CountryCode === countryFrom);
InputPayload[0].ErSFrom = erFrom?.EcoRegCode || null;


const CountrySTo = await odata.run(
  SELECT.columns('Country').from('Massbpplantcntrykey').where({ BusinessPartner: InputPayload[0].BpSTo })
);

const countryTo = CountrySTo?.[0]?.Country;
const erTo = ecoRegions.find(e => e.CountryCode === countryTo);
InputPayload[0].ErSTo = erTo?.EcoRegCode || null;

    /********************************************************************************************************************************************************************************* */

    for (const record of InputPayload) {
      const matType = await odata.run(
        SELECT.one
          .columns('ProductType')
          .from('Material')
          .where({
            Product: record.Matnr,
            ProfitCenter: record.MatBrand
          })
      );
      record.ErSFrom = erFrom?.EcoRegCode || null; // header level value same for all item level.
      record.ErSTo = erTo?.EcoRegCode || null;// header level value same for all item level.
      record.MatType = matType?.ProductType ?? null;
    }

    // Process InputPayload to create OutputPayload
    const OutputPayload = InputPayload.map(inputItem => {
      let matchedData = null;
      if (!inputItem || typeof inputItem !== 'object') {
        return {
          PfcCatId: matchedData?.CatId || "",
          ProdId: matchedData?.ProdId || "",
          BpSFrom: inputItem.BpSFrom || "",
          PlantSFrom: inputItem.PlantSFrom || "",
          ErSFrom: inputItem.ErSFrom || "",
          BpSTo: inputItem.BpSTo || "",
          PlantSTo: inputItem.PlantSTo || "",
          ErSTo: inputItem.ErSTo || "",
          Matnr: inputItem.Matnr || "",
          MatBrand: inputItem.MatBrand || "",
          MatType: inputItem.MatType || "",
          VirtualEntity: [],
          Status:"InActive"
        };
      }

      

      if(!inputItem?.BpSFrom || !inputItem?.BpSTo){
            throw new Error("ShipFrom Or ShipTo Business Partner not available in the payload")
      }



      // Step 1: Create business context key from InputPayload
      let inputBusinessContextKey = `${inputItem.BpSFrom || ""}-${""}-${inputItem.BpSTo || ""}-${""}`; // key with just Business Partner Info


      // Step 2: Find the matching business context in pfcData
      let businessContext = businessContextLookup.get(inputBusinessContextKey);

      if (!businessContext) {
        // if BpShipTo is not present then check fro BpShipFrom and ErShipTo
        inputBusinessContextKey = `${inputItem.BpSFrom || ""}-${""}-${""}-${inputItem.ErSTo || ""}`; // Checking the catalog with the key ShipFrom BP and ShipToEcoRegion
        businessContext = businessContextLookup.get(inputBusinessContextKey);
      }

      if (!businessContext) {
        // if BpShipFrom is not present then check fro ErShipFrom and BpShipTo
        inputBusinessContextKey = `${""}-${inputItem.ErSFrom || ""}-${inputItem.BpSTo || ""}-${""}`; // Checking the catalog with the key Ship From EcoRegion  and ShipToBp
        businessContext = businessContextLookup.get(inputBusinessContextKey);
      }

      if (!businessContext) {
        // if BpShipFrom  & BpShipTo both are  not present then check fro ErShipFrom and ErShipTo
        inputBusinessContextKey = `${""}-${inputItem.ErSFrom || ""}-${""}-${inputItem.ErSTo || ""}`; // Checking the catalog with the key Ship From EcoRegion  and ShipToBp
        businessContext = businessContextLookup.get(inputBusinessContextKey);
      }

      if (businessContext) {
        // Step 3: Within the matched business context, look for Matnr/MatBrand matches

        // Primary check: If InputPayload has Matnr, check within this business context
        if (inputItem.Matnr) {
          matchedData = businessContext.matnrLookup.get(inputItem.Matnr);
        }

        // Fallback check: If no Matnr match found and InputPayload has MatBrand,
        if(!matchedData){ 
             matchedData = businessContext.matBrandTypeLookup.get(`${inputItem.MatBrand}_${inputItem.MatType}`);
        }


        // Fallback check: If no Matnr match found and InputPayload has MatBrand,
        // check for items that have MatBrand but no Matnr within this business context
        if (!matchedData && inputItem.MatType) {
          matchedData = businessContext.matTypeOnlyLookup.get(inputItem.MatType);
        }

        if (!matchedData) {
          if(!inputItem.ErSTo){
            throw new Error("Eco Region level check not possible for Business Partner missing Country configuration")
          }
          inputBusinessContextKey = `${inputItem.BpSFrom || ""}-${""}-${""}-${inputItem.ErSTo || ""}`; // Checking the catalog with the key ShipFrom BP and ShipToEcoRegion
          businessContext = businessContextLookup.get(inputBusinessContextKey);
          if (businessContext) {
            // Primary check: If InputPayload has Matnr, check within this business context
            if (inputItem.Matnr) {
              matchedData = businessContext.matnrLookup.get(inputItem.Matnr);
            }
            
            // Fallback check: If no Matnr match found and InputPayload has MatBrand,
            if(!matchedData){ 
              matchedData = businessContext.matBrandTypeLookup.get(`${inputItem.MatBrand}_${inputItem.MatType}`);
            }

            // Fallback check: If no Matnr match found and InputPayload has MatBrand,
            // check for items that have MatBrand but no Matnr within this business context
            if (!matchedData && inputItem.MatType) {
              matchedData = businessContext.matTypeOnlyLookup.get(inputItem.MatType);
            }
          }
        }
      }
/*********** Defect JGHJ-75773 ****************/
      let pfcCheckPassed = null;
       //final concluded info if PFC is passing all check and can be used
      pfcCheckPassed = matchedData
      let status = "InActive" 
      if (matchedData && matchedData.Status === "Active" && matchedData.dateCheck && matchedData.ApprStatus === "Approved") {
        status = "Active";
      } else if (matchedData && matchedData.ApprStatus !== "Approved") {
        // status = "InActive Due to Approval Status Failed";
        status = `Product Flow Catalog ID: ${matchedData.CatId} is with Product Flow Status '${matchedData.ApprStatus}'`;
      } else if (matchedData && matchedData.Status !== 'Active') {
        // status = "InActive Due to Status Not Active";
        status = `Product Flow Catalog ID: ${matchedData.CatId} is with Status '${matchedData.Status}'`;
      } else if (matchedData && !matchedData.dateCheck) {
        // status = "InActive Due to Date Range Failed";
        status = `Product Flow Catalog ID: ${matchedData.CatId} is not within the validity period`;
      } else {
        status = "InActive";
      }

      // Transform Ventities to include only required fields
      let transformedVentities = pfcCheckPassed ?
        pfcCheckPassed.Ventities.map(ventity => ({
          VirtualEntity: ventity?.Plant ? ventity.Plant : ventity?.BPartner,
          legalEntity: ventity?.Plant ? getLegalEntityFromPlant(ventity.Plant, legEntityData) : "",
          SeqNo: ventity?.SeqNum || ""
        })) : [];

/*********** Defect JGHJ-75773 ****************/
      


      // Create output item with all original properties plus CatId and Ventities
      return {
        PfcCatId: pfcCheckPassed?.CatId || "",
        ProdId: pfcCheckPassed?.ProdId || "",
        BpSFrom: inputItem.BpSFrom || "",
        PlantSFrom: inputItem.PlantSFrom || "",
        ErSFrom: inputItem.ErSFrom || "",
        BpSTo: inputItem.BpSTo || "",
        PlantSTo: inputItem.PlantSTo || "",
        ErSTo: inputItem.ErSTo || "",
        Matnr: inputItem.Matnr || "",
        MatBrand: inputItem.MatBrand || "",
        VirtualEntity: transformedVentities,
        Status:status
      };
    });

    return OutputPayload;

  } catch (error) {
    // Log error for debugging in CAP application
    console.error('Error in processPayload function:', error.message);
    return error;
  }
};



/**
 * Format Scenario data for return  
 * @param {Array} sidInfo - Array of Scenarioid
 * @param {Array} InputPayload - Array of input payload objects to be enriched
 * @returns {Array} OutputPayload - Enriched payload with CatId and Ventities added
 */
async function formatSidOutputPayload(sidInfo, payload) {
  const sidMap = new Map(sidInfo.map(item => [item.CatId, item.SId]));

  // Merge sid with payload based on productFlowCatalogID === CatId
  const output = payload.map(entry => ({
    productFlowCatalogID: entry.productFlowCatalogID,
    SID: sidMap.get(entry.productFlowCatalogID) || "",  // fallback null if no match
    shippingReqNo: entry.shippingReqNo,
    initialDocumentNo: entry.initialDocumentNo
  }));

  return output;
}

function getLegalEntityFromPlant(plant, legEntityData) {
  const record = legEntityData.find(item => item.ValuationArea === plant);
  return record ? record.CompanyCode : "";
}

 function isCurrentDateWithinRange(item) {
  if (!item?.VFrom || !item?.VTo) return false;

  const today = new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"

  return today >= item.VFrom && today <= item.VTo;
}

async function pfcCall(req,ZSD_VCM_PREREQAPI,ZSD_VCM_PRODUCTFLOW){
  const locale = req.user.locale;
  bundle = textBundle.getTextBundle(locale);
  const pfcDest = await cds.connect.to("pfcservice");

  const pfcData = await pfcDest.tx(req).get('/zbuvcm47419/getPfcData');
  const legEntityData = await ZSD_VCM_PREREQAPI.tx(req).get(`/FetchT001K`);

  const result = await pfcCheck(req, pfcData.value, req.data.InputPayload, ZSD_VCM_PRODUCTFLOW, pfcDest, legEntityData);

  let invalidItems = []

  if (Array.isArray(result) && result.length > 0) {
    invalidItems = result?.filter(item => item?.Status !== "Active");
  } else {
    throw new Error(`${bundle.getText("pfcMessage")}`)
  }


  if (invalidItems.length > 0) {
    const catID = invalidItems[0]?.PfcCatId;
    if (catID) {
      let error=invalidItems[0]?.Status
      throw new Error(error);
    } else {
      throw new Error(`${bundle.getText("pfcMessage")}`)
    }
  }

  for (const record of result) {
    record.Status = "S";
  }

  return result;

}

module.exports = { pfcCheck, formatSidOutputPayload, pfcCall }