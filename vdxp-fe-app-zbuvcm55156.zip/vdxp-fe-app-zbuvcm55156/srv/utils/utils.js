function retrieveErrorMessage(error) {
  const body = error?.reason?.response?.body;

  // --- ODATA V4 ---
  // API: error.details[]
  const v4Details = body?.error?.details;

  // --- ODATA V2 ---
  // API: error.innererror.errordetails[]
  const v2Details = body?.error?.innererror?.errordetails;

  // Merge V4 + V2 details
  const allDetails = [...(v4Details || []), ...(v2Details || [])];

  // Extract readable text messages
  const messages = allDetails
    .map(d => d.message || d?.message?.value)
    .filter(Boolean);

  if (messages.length > 0) {
    return messages;              // Return array of messages
  }

  // --- fallback: top-level SAP message ---
  const sapMessage =
    body?.error?.message?.value ||     // V2 message
    body?.error?.message ||            // V4 message
    error?.reason?.message ||          // Axios/CAP wrapper
    error?.message;                    // Generic fallback

  return sapMessage || "Unknown Error Occurred";
}

module.exports = {
  retrieveErrorMessage
};