// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Prerequisite API
// Object Id       : ZBUVCM55156
// Release         : 1
// Version         : 0.01
// Description     :  Application to Perform Automation PreRequisite Checks
// ----------------------------------------------------------------------------*
// Descriptions:  This is handling the mail send when error is encountered in document Posting.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*  
 
'use strict';
const cds = require('@sap/cds');
const constants = require('../config/constants');
const logger = cds.log('zbuvcm55156-preRequisiteAPI');
//Begin of change R2.1 Hypercare Bugfix JGHJ-104620
const { retrieveErrorMessage } = require('../utils/utils');
//End of change R2.1 Hypercare Bugfix JGHJ-104620


 
 
/**
 * Generic function to post payload to CPI
 * @param {*} EmailPayload      - Full JSON payload for CPI
 * @returns response from CPI
 */
async function callCPI(EmailPayload,req) {
  try {
    const destApi = await cds.connect.to(constants.CPI_EMAIL_DESTINATION);
 
    const cpiResponse = await destApi.send({
      method: "POST",
      path: constants.CPI_DESTPATH,
      data: EmailPayload,
      responseType: 'text', // <- handle HTML/text response
      headers: {
        "Content-Type": "application/json",
        "Accept":"*/*"
      }
    });
    logger.info(constants.cpi_Response, cpiResponse);
 
    return {
      status: 200,
      message: constants.e_success
    };
  } catch (error) {
    logger.error(constants.cpi_Error, error.message);
    req.error(constants.cpi_Error + ': ' + error.message);
  }
}





/**
 * Generic function to get DL List for VCM and AT 
 * @param {*} req  - request object
 * @param {*} odata     - DL api endpoint connection
 * @param {*} call      - AT or VCM
 * @returns response from fetchDLlist as DL list String
 */
async function fetchDLlist(req,odata,call,errorType){
  let at_DL,vcm_DL;
  const cds = require('@sap/cds');
  const tx = cds.tx(req)
  if(call === 'AT'){
    at_DL = await odata.tx(req).get(constants.at_DL_URL);
    at_DL = at_DL?.value.filter((item)=> item.Type === errorType);
    return cleanDLlist(at_DL);
  }else{
   await tx.begin();
   vcm_DL = await tx.run(SELECT.from("JNJ_COM_ZBUVCM55155_SYN_EMAILNOTIFY").where({Type:errorType}));
   await tx.commit();
   return cleanDLlist(vcm_DL);
  }



}


/**
 * Generic function to get Email Body  for VCM and AT 
 * @param {*} req  - request object
 * @param {*} data     - info required in mail
 * @param {*} error      - error encountered in posting call
 * @returns response - its the email  struncture in html
 */
async function getEmailBody(call,data,error,activity, errorMsg){
let htmlParts = [];

htmlParts.push('<!DOCTYPE html>');
htmlParts.push('<html>');
htmlParts.push('<head>');
htmlParts.push('<title>Material List</title>');
htmlParts.push('<style>');
htmlParts.push('  body { font-family: Arial, sans-serif; margin: 20px; }');
htmlParts.push('  h1 { color: #333; }');
htmlParts.push('  table { width: 100%; border-collapse: collapse; margin-top: 20px; }');
htmlParts.push('  th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }');
htmlParts.push('  th { background-color: #f2f2f2; }');
htmlParts.push('  tr:nth-child(even) { background-color: #f9f9f9; }');
htmlParts.push('</style>');
htmlParts.push('</head>');
htmlParts.push('<body>');

htmlParts.push('<p>Dear User,</p>');

htmlParts.push('<p>The main process orchestration with shipping request number ' + data.shippingReqNumber + ' and initial document number ' + data.initialDocNumber + ' has went into error. Error messages are as follows:</p>');
htmlParts.push('<table>');
htmlParts.push('<thead>');
htmlParts.push('<tr><th>Activity</th><th>Error Code</th><th>Error Message</th></tr>');
htmlParts.push('</thead>');
htmlParts.push('<tbody>');
//for (var i = 0; i < $.context.action_get_getV1WorkflowInstancesWorkflowInstanceIdErrorMessages_1.result.responseArray.length; i++) {
     htmlParts.push('<tr>');
     htmlParts.push('<td>' + activity + '</td>');
     htmlParts.push('<td>' + error.statusCode + '</td>');
     //Begin of change R2.1 Hypercare Bugfix JGHJ-104620
    //  htmlParts.push('<td>' + error.message + '</td>');   
     htmlParts.push('<td>' + errorMsg + '</td>');
     //End of change R2.1 Hypercare Bugfix JGHJ-104620
     htmlParts.push('</tr>');
//}
htmlParts.push('</tbody>');
htmlParts.push('</table>');

htmlParts.push('</body>');
htmlParts.push('</html>');

let finalHtml = htmlParts.join('\n');
    finalHtml = finalHtml.replace(/"/g, '///"');

return Buffer.from(finalHtml, 'utf-8').toString('base64');

}

function convertSAPDateToISO(sapDate) {
  if(sapDate){
  const timestamp = parseInt(sapDate.match(/\d+/)[0], 10);
  const date = new Date(timestamp);
  const offsetMs = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - offsetMs).toISOString().split('.')[0];
  }
}



function cleanDLlist(emailArray = []) {
  if (!Array.isArray(emailArray)) return "";

  // Collect all emails from Email and AlternateEmail fields
  const allEmails = emailArray.flatMap(entry => {
    const emails = [];

        // Handle both camelCase and UPPERCASE keys
    const emailKey = entry.Email ?? entry.EMAIL;
    const altEmailKey = entry.AlternateEmail ?? entry.ALTERNATEEMAIL;

    if (emailKey) {
      emails.push(...emailKey.split(/\s*,\s*/));
    }
   
    if (altEmailKey) {
      emails.push(...altEmailKey.split(/\s*,\s*/));
    }

    return emails;
  });

  // Remove duplicates and empty strings
  const uniqueEmails = [...new Set(allEmails.filter(Boolean))];

  // Return as comma-separated string
  return uniqueEmails.join(", ");
}


async function sendMail(req, error, data, orchrestration, activity) {
  try {
    const errorType = error.statusCode === 500 ? constants.at_TE : constants.at_OE;
    // const emailData = await getEmailBody('', data, error, activity);
    const AT_Dl_List = await fetchDLlist(req, orchrestration, constants.AT, errorType);

    // Begin of change R2.1 Hypercare Bugfix JGHJ-104620 
    const errorMessage = retrieveErrorMessage(error);

    function getMsg(msg) {
      let errMsg = '';

      if (typeof msg === "object") {
        errMsg = JSON.stringify(msg?.value ?? msg);
      } else {
        errMsg = JSON.stringify(msg);
      }

      return errMsg || '';
    }

    let emailInfos = [];
    if (Array.isArray(errorMessage) && errorMessage.length > 0) {
      for (const msg of errorMessage) {
        const errorMsg = getMsg(msg);
        const emailData = await getEmailBody('', data, error, activity, errorMsg);
        emailInfos.push({
          Email_Body: emailData,
          Email_Subject: constants.errorIntimationEmailSubject + data.shippingReqNumber
        });
      }
    } else {
      const emailData = await getEmailBody('', data, error, activity, getMsg(errorMessage));
      emailInfos.push({
        Email_Body: emailData,
        Email_Subject: constants.errorIntimationEmailSubject + data.shippingReqNumber
      });
    }

    // const emailInfo = {
    //   "Email_Body": emailData,
    //   "Email_Subject": constants.errorIntimationEmailSubject + data.shippingReqNumber,
    //   "Email_Recipients": AT_Dl_List
    // }
    // // /*********************************AT MAIL CALL ***********************/

    // // AT mail
    // const tx = cds.tx(req)
    // await tx.begin();
    // const SOPOResponse = await tx.run(
    //   SELECT.one
    //     .from("JNJ_COM_ZBUVCM55156_SYN_SHIPPINGREQUESTENTITYDOCS")
    //     .columns("PARENT_ID")
    //     .where({ ID: data.ID })
    // );

    // if (SOPOResponse) {
    //   const SOPOType = await cds.run(
    //     SELECT.one
    //       .from("JNJ_COM_ZBUVCM55156_SYN_SHIPPINGREQUEST")
    //       .columns("INITIALDOCUMENTTYPE")
    //       .where({ ID: SOPOResponse.PARENT_ID })
    //   );

    //   // if (SOPOType && SOPOType.INITIALDOCUMENTTYPE === 'Sales Order') {
    //   //   await callCPI(emailInfo,req)
    //   // }

    //   if (SOPOType && SOPOType.INITIALDOCUMENTTYPE === 'Sales Order') {
    //     for (const emailInfo of emailInfos) {
    //       emailInfo.Email_Recipients = AT_Dl_List;
    //       await callCPI(emailInfo, req);
    //     }
    //   }

    // }

    // await tx.commit();

    // AT mail
    const tx = cds.tx(req);
    try {
      await tx.begin();
      const SOPOResponse = await tx.run(
        SELECT.one.from("JNJ_COM_ZBUVCM55156_SYN_SHIPPINGREQUESTENTITYDOCS")
          .columns("PARENT_ID").where({ ID: data.ID }));

      if (SOPOResponse) {
        const SOPOType = await tx.run(
          SELECT.one.from("JNJ_COM_ZBUVCM55156_SYN_SHIPPINGREQUEST").columns("INITIALDOCUMENTTYPE")
            .where({ ID: SOPOResponse.PARENT_ID })
        );

        if (SOPOType?.INITIALDOCUMENTTYPE === 'Sales Order') {
          for (const emailInfo of emailInfos) {
            emailInfo.Email_Recipients = AT_Dl_List;
            await callCPI(emailInfo, req);
          }
        }
      }

      await tx.commit();

    } catch (error) {
      await tx.rollback(error);
      throw error;
    }


    /*******************************VCM MAIL CALL************************/
    const VCM_Dl_List = await fetchDLlist(req, '', constants.VCM, constants.VCM);
    // emailInfo.Email_Recipients = VCM_Dl_List;
    // await callCPI(emailInfo,req)

    for (const emailInfo of emailInfos) {
      emailInfo.Email_Recipients = VCM_Dl_List;
      await callCPI(emailInfo, req);
    }

  } catch (error) {
    console.error('Error in sending email:', error);
  }
}


module.exports = { callCPI ,fetchDLlist, getEmailBody,sendMail,convertSAPDateToISO}