// Change Log:
//    Date     |     Author             |   Change Id   |  Change Description
  //  4/3/2026    rchitike@its.jnj.com      JGHJ-89782      added common function to get error msg for array and updated error table with proper error message.
// ----------------------------------------------------------------------------*


const { default: cds } = require('@sap/cds');
const constants = require('../config/constants');
const { sendMail } = require('./errorMail');
const { executeWithRetry } = require('./executeWithRetry');
const { retrieveErrorMessage } = require('../utils/utils');
const logger = cds.log('zbuvcm55156-preRequisiteAPI');

const { syn_ShippingRequestEntityDocs, syn_ShippingRequestErrors, syn_ShippingRequest } = cds.entities('jnj.com.zbuvcm55156');

/**
* Update error table and entity docs for a given ShippingRequestEntityDoc record.
* 
* - Updates `ShippingRequest.docFlowStateCheckStatus`
* - Updates `ShippingRequestEntityDocs.errorStatus` & error details
* - Inserts a record into `ShippingRequestErrors` if status != success
* 
* @param {Object} data - Payload with ID, errorStatus, errorDescription, wfInstanceId
* @returns {Object} Result with updated entity ID
*/

async function updateErrorTable(req, data, error) {
  try {
    const cds = require('@sap/cds');
    const tx = cds.tx(req)
    await tx.begin();
    if (!data?.ID) {
      throw new Error('ID Is Missing');
    }

    // Fetch entity doc record
    const getEntity = await tx.run(SELECT.one.from(syn_ShippingRequestEntityDocs).where({ ID: data.ID }));
    if (!getEntity) {
      throw new Error('No Data Found');
    }
    data['shippingReqNumber'] = getEntity?.parent_shippingReqNo;
    data['initialDocNumber'] = getEntity?.parent_initialDocumentNo;
    // Update ShippingRequest header state
    const result1 = await tx.run(UPDATE(syn_ShippingRequest).set({
      docFlowStateCheckStatus: constants.E || "",
      status: constants.E
    }).where({ ID: getEntity.parent_ID }));

    const errorMessage = retrieveErrorMessage(error);
    let messageError = ''

    if (Array.isArray(errorMessage) && errorMessage?.length && errorMessage?.length > 0) {
      messageError = errorMessage[0]
    } else {
      messageError = errorMessage
    }

    if (Array.isArray(messageError)) {
      messageError = messageError
        .map(msg => getMsg(msg))
        .join(", ");
    }
    else if (messageError && typeof messageError === "object") {
      messageError = JSON.stringify(messageError.value ?? messageError);
    } else {
      messageError = JSON.stringify(messageError);
    }
    
    // Check if this is the same error as the last recorded one to preserve errorCreationDate
    const errorHistory = await tx.run(
      SELECT.from(syn_ShippingRequestErrors)
        .where({ parent_ID: data.ID })
        .orderBy('vcaErrorTimeStamp desc')
    );
    const isSameError = errorHistory?.some(e => e.vcaErrorType?.toLowerCase() !== 'success' && e.vcaErrorStatus === messageError);
    const firstErrorTimeStamp = errorHistory?.filter(e => e.vcaErrorType?.toLowerCase() !== 'success' && e.vcaErrorStatus === messageError)?.at(-1)?.vcaErrorTimeStamp;
    logger.info('Line 78 - First Error Timestamp:', firstErrorTimeStamp);

    // Update ShippingRequestEntityDocs with error details
    const result = await tx.run(UPDATE(syn_ShippingRequestEntityDocs).set({
      errorStatus: constants.E,
      errorDescription: messageError,
      wfInstanceId: data.wfInstanceId,
      errorCreationDate: (data.errorStatus !== 201 && !isSameError) ? new Date() : firstErrorTimeStamp,
      errorResolutionDate: data.errorStatus === 201 ? new Date() : "",
    }).where({ ID: data.ID }));

       await tx.run(UPDATE(syn_ShippingRequest).set({
        docFlowStateCheckStatus: constants.E || "",
        status: constants.E
       }).where({ ID: data.ID }));

    function getMsg(msg) {
      let errMsg = ''
      if (typeof msg === "object") {
        errMsg = JSON.stringify(msg?.value ?? msg)
      }
      else {
        errMsg = JSON.stringify(msg)
      }
      return errMsg || ''
    }

    // Insert into error table if failure
    if (data.errorStatus !== 201) {
      if (Array.isArray(errorMessage) && errorMessage.length > 0) {
        let insertPromises = errorMessage.map((msg) =>

          tx.run(
            INSERT.into(syn_ShippingRequestErrors).entries({
              ID: cds.utils.uuid(),
              parent_ID: getEntity.ID,
              vcaErrorStatus: getMsg(msg),
              vcaErrorType: constants.E,
              wfInstanceId: data.wfInstanceId,
              vcaErrorTimeStamp: new Date()
            }))
        );
        const insertRecord = await Promise.all([...insertPromises]);

        console.log(insertRecord);
      } else {
        const insertRecord = await tx.run(INSERT.into(syn_ShippingRequestErrors).entries({
          ID: cds.utils.uuid(),
          parent_ID: getEntity.ID,
          vcaErrorStatus: messageError,
          vcaErrorType: constants.E,
          wfInstanceId: data.wfInstanceId,
          vcaErrorTimeStamp: new Date()
        }));
        console.log(insertRecord);
      }

    }

    if (result === 0 || result1 === 0) {
      throw new Error('No Shipping Request Error Found');
    }

    await tx.commit();

    return { ID: getEntity.ID };
  } catch (error) {
    console.error('Update on ErrorTable Failed', error);
    return req.error(500, error?.message);
  }
}

async function updateQueueErrorTable(req, data, error, queueID,errorType) {
  try {
    const cds = require('@sap/cds');
    const tx = cds.tx(req)
    await tx.begin();
    
    if (!queueID) {
      throw new Error('Queue ID is Missing');
    }

    // Fetch entity doc record
    const getEvent = await tx.run(SELECT.one.from('JNJ_COM_ZBUVCM55156_SYN_SHIPPINGREQUESTQUEUE').where({ ID: queueID }));
    if (!getEvent) {
      throw new Error('No Event Found');
    }
    
    const getDocumentName= await tx.run(SELECT.one.from(syn_ShippingRequestEntityDocs).columns('documentType').where({ ID: data.ID }));
    if(!getDocumentName) {
      logger.error('No Document Found for the given ID:', data.ID);
    }
    let errorMessages

    if(getDocumentName){
      errorMessages = "Error in " + getDocumentName?.documentType
    } else if(errorType === constants.PFC){
      errorMessages = data.errorDescription || "Error in PFC Check"
    } else {
      errorMessages = data.errorDescription || "Error in Master Data Check"
    }
    const result = await tx.run(UPDATE('JNJ_COM_ZBUVCM55156_SYN_SHIPPINGREQUESTQUEUE').set({
      status: constants.E || "",
      errorMessage: errorMessages,
      wfInstanceId: data.wfInstanceId,
    }).where({ ID: getEvent.ID }));

    const errorMessage = retrieveErrorMessage(error);
    let messageError = ''

    if (Array.isArray(errorMessage) && errorMessage?.length && errorMessage?.length > 0) {
      messageError = errorMessage[0]
    } else {
      messageError = errorMessage
    }

    if (Array.isArray(messageError)) {
      messageError = messageError
        .map(msg => getMsg(msg))
        .join(", ");
    }
    else if (messageError && typeof messageError === "object") {
      messageError = JSON.stringify(messageError.value ?? messageError);
    } else {
      messageError = JSON.stringify(messageError);
    }

      function getMsg(msg) {
      let errMsg = ''
      if (typeof msg === "object") {
        errMsg = JSON.stringify(msg?.value ?? msg)
      }
      else {
        errMsg = JSON.stringify(msg)
      }
      return errMsg || ''
    }

    // Insert into error table if failure
    if (data.errorStatus !== 201) {
      if (Array.isArray(errorMessage) && errorMessage.length > 0) {
        let insertPromises = errorMessage.map((msg) =>
          
          tx.run(
            INSERT.into('JNJ_COM_ZBUVCM55156_SYN_QUEUEREQUESTERRORS').entries({
              ID: cds.utils.uuid(),
              parent_ID: getEvent.ID,
              errorMessage: getMsg(msg),
              errorType: constants.E,
              wfInstanceId: data.wfInstanceId,
              timeStamp: new Date()
            }))
        );
        const insertRecord = await Promise.all([...insertPromises]);
        
        console.log(insertRecord);
      } else {
        const insertRecord = await tx.run(INSERT.into('JNJ_COM_ZBUVCM55156_SYN_QUEUEREQUESTERRORS').entries({
          ID: cds.utils.uuid(),
          parent_ID: getEvent.ID,
          errorMessage: messageError,
          errorType: constants.E,
          wfInstanceId: data.wfInstanceId,
          timeStamp: new Date()
        }));
        console.log(insertRecord);
      }

    }

    if (result === 0) {
      throw new Error('No Queue Event Found');
    }

    await tx.commit();

    const OmService = await cds.connect.to("VCM_ORDERMONITORING_CAP")
    let op = await OmService.post('/zbuvcm55155/QueueInError', { queueId: queueID })
    logger.info(`Response from VCM_ORDERMONITORING_CAP: ${JSON.stringify(op)}`)

    return { ID: getEvent.ID };

  }
    catch (error) { 
      console.error('Update on QueueErrorTable Failed', error);
      return req.error(500, error?.message);
    }
}

/**
* Update header error table .
* @param {Object} data - Payload with ID, errorStatus, errorDescription, type
* @returns {Object} Result with updated entity ID
*/
async function updateHeaderErrorTable(req, data, type,individualErrors=[]) {

  try {

    const cds = require('@sap/cds');
    const tx = cds.tx(req)
    let updateJson;


    if (type === constants.MASTERDATA) {
      // Update ShippingRequest header state error update
      updateJson = {
        masterDataErrorDesciption: data.errorDescription ? data.errorDescription : undefined,
        masterDataStatus: data.errorStatus,
        masterDataErrorCreationDate:new Date(),
        wfInstanceId: data.wfInstanceId,
        status:data.errorStatus
      }
    } else if (type === constants.PFC) {
      updateJson = {
        pfcCheckErrorDescription: data.errorDescription ? data.errorDescription : undefined,
        pfcCheckStatus: data.errorStatus,
        pfcCheckErrorCreationDate:new Date(),
        wfInstanceId: data.wfInstanceId,
        status:data.errorStatus
      }
    } else {
      updateJson = {
        scenarioCheckStatusErrorDescription: data.errorDescription ? data.errorDescription : undefined,
        scenarioDeterminationCheckStatus: data.errorStatus,
        scenarioCheckErrorCreationDate: new Date(),
        wfInstanceId: data.wfInstanceId,
        status:data.errorStatus
      }
    }

    if (updateJson) {

      const categoryLabel = type === constants.MASTERDATA ? "MasterData"
        : type === constants.PFC ? "PFC"
        : "ScenarioDetermination";

      const errors = [];
      if (
      type === constants.MASTERDATA &&
      Array.isArray(individualErrors) &&
      individualErrors.length > 0
    ) {
      for (const err of individualErrors) {
        errors.push({
          ID: cds.utils.uuid(),
          parent_ID: data.ID,
          vcaErrorStatus: `${categoryLabel}: ${err}`,
          vcaErrorType: data.errorStatus,
          wfInstanceId: data.wfInstanceId,
          vcaErrorTimeStamp: new Date()
        });
      }
    } else {
      // Default: insert one combined error
      errors.push({
        ID: cds.utils.uuid(),
        parent_ID: data.ID,
        vcaErrorStatus: `${categoryLabel}: ${data.errorDescription || "Unknown error"}`,
        vcaErrorType: data.errorStatus,
        wfInstanceId: data.wfInstanceId,
        vcaErrorTimeStamp: new Date()
      });
    }

      await tx.begin();
      await tx.run(UPDATE(syn_ShippingRequest).set(updateJson).where({ ID: data.ID }));
      await tx.run(INSERT.into(syn_ShippingRequestErrors).entries(errors));
      await tx.commit();
    }else{
      throw new Error(`updateJson for ${type} is not defined for the given type`);
    }


  } catch (error) {
    return error;
  }
}

async function updateLegacySo(req, data, tx, PURCHASEORDER, getEntity) {

  const { so_Num, reference_Po } = data;

  if (!reference_Po || !so_Num) {
    throw new Error("Reference PO or legacy SO missing!")
  }

  if (!getEntity) {
    throw new Error(`Reference Purchase Order: ${reference_Po} not found in VCM!`)
  }

  if (!getEntity.parent_initialDocumentNo) {
    throw new Error(`Initial document number not found for: ${reference_Po}`)
  }

  await executeWithRetry(() =>
    PURCHASEORDER.send({
      method: "PATCH",
      path: `PurchaseOrder(PurchaseOrder='${getEntity?.parent_initialDocumentNo}')`,
      data: {
        CorrespncExternalReference: so_Num
      },
      headers: { "If-Match": "*" }
    })
  );

  let POStepIdtoLegacySO = 'L_' + getEntity?.stepID?.replace(/PO$/, 'SO')
  // Update ShippingRequestEntityDocs with error details
  const result = await tx.run(UPDATE(syn_ShippingRequestEntityDocs).set({
    documentNumber: so_Num,
    errorStatus: "Success",
    errorDescription: `Legacy Intercompany Sales Order Created Successfully! - ${so_Num}`,
    wfInstanceId: "",
    creationDate: new Date()
  }).where({ parent_ID: getEntity.parent_ID, stepID: POStepIdtoLegacySO }));

  const getEntitySO = await tx.run(SELECT.one.from(syn_ShippingRequestEntityDocs).where({ parent_ID: getEntity.parent_ID, stepID: POStepIdtoLegacySO }));

  const insert = await tx.run(
    INSERT.into(syn_ShippingRequestErrors).entries({
      ID: cds.utils.uuid(),
      parent_ID: getEntitySO?.ID,
      vcaErrorStatus: "",
      vcaErrorType: "Success",
      wfInstanceId: "",
      vcaErrorTimeStamp: new Date()
    })
  );

  await tx.commit()

  return { shippingReqNum: getEntity?.parent_shippingReqNo };

}


function wrapperResponseObj(res, type) {
  return {
    customResponse: {
      responseStatus: type
    },
    stdResponse: type === "F" ? {} : res
  }
}

  async function readProxyWithErrorHandling({
    req,
    srv,
    activity,
    id,
    wfID,
    queueID=null,
    orchrestration
  }) {
    try {
      logger.info(`${activity} READ for ID: ${id}`, JSON.stringify(req?.query))

      // Handle empty $filter
      if (req.query?.SELECT?.where?.length === 0) {
        delete req.query.SELECT.where;
      }

      const response = await srv.tx(req).run(req.query);
      return wrapperResponseObj(response, constants.wrapperSuccess);

    } catch (error) {
      logger.error(
        `${activity} READ failed for ID: ${id}`,
        JSON.stringify(error)
      );

      const data = {
        ID: id,
        wfInstanceId: wfID,
        errorDescription: error.message,
        errorStatus: error.statusCode
      };

      // same behavior as POST failure

      if (queueID) {
        await updateQueueErrorTable(req, data, error, queueID)
      } else {
        await updateErrorTable(req, data, error);
      }
      await sendMail(req, error, data, orchrestration, activity);

      return wrapperResponseObj(error, constants.wrapperError);
    }
  }


module.exports = {updateQueueErrorTable, updateLegacySo,updateErrorTable, updateHeaderErrorTable,wrapperResponseObj,readProxyWithErrorHandling }

