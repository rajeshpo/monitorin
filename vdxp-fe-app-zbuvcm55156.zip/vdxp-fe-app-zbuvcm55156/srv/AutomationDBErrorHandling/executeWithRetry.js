const LOCK_TEXT = "locked";
const LOCK_TEXT1 = "already processing";
const cds = require('@sap/cds');
const logger = cds.log('zbuvcm55156-preRequisiteAPI');
const { retrieveErrorMessage } = require('../utils/utils');
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
const {syn_ShippingRequestEntityDocs} = cds.entities('jnj.com.zbuvcm55156');


async function executeWithRetry(operation, ID) {

    const MAX_RETRIES = parseInt(process.env.RETRY) || 5;
    const DELAY = 3000;

    logger.info(`S4 API Retry Configuration: Max Retries = ${MAX_RETRIES}, Delay = ${DELAY}s`)

    let attempt = 1;
 
    let SO = '';

    if (ID) {
        SO = await SELECT.one.from(syn_ShippingRequestEntityDocs).columns('parent_initialDocumentNo').where({ ID: ID });
    }

    while (true) {
        try {

            logger.info(`Executing S4 APIS for SO ${SO.parent_initialDocumentNo} in Entity ${ID}. Attempt ${attempt}/${MAX_RETRIES}`);

            return await operation();

        } catch (error) {

            const errorMessage = retrieveErrorMessage(error);
            let messageError = ''

            if (Array.isArray(errorMessage) && errorMessage?.length && errorMessage?.length > 0) {
                messageError = errorMessage[0]
            } else {
                messageError = errorMessage
            }

            if (Array.isArray(messageError)) {
                messageError = messageError
                    .map(msg => getMsg(msg))
                    .join(", ");
            }
            else if (messageError && typeof messageError === "object") {
                messageError = JSON.stringify(messageError.value ?? messageError);
            } else {
                messageError = JSON.stringify(messageError);
            }

            const isLockIssue = error?.message?.includes(LOCK_TEXT) || error?.message?.includes(LOCK_TEXT1) || messageError?.includes(LOCK_TEXT) || messageError?.includes(LOCK_TEXT1);

            logger.info(`Error occurred during S4 API execution for SO ${SO.parent_initialDocumentNo} in Entity ${ID}: ${messageError || error.message} . Is Lock Issue: ${isLockIssue}`);

            if (!isLockIssue || attempt >= MAX_RETRIES) {
                throw error;
            }

            logger.warn(
                `S4 Lock detected for SO ${SO.parent_initialDocumentNo} in Entity ${ID}. Waiting ${DELAY / 1000}s before retry ${attempt + 1}/${MAX_RETRIES}`
            );

            await sleep(DELAY);

            attempt++;
        }
    }
}

module.exports = {
    executeWithRetry
}