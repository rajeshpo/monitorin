// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Product Flow Catalog
// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Application to create new Product Flows
// ----------------------------------------------------------------------------*
// Descriptions: Table and Views
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*
namespace jnj.com.zbuvcm47419;

using {
  cuid,
  managed
} from '@sap/cds/common';


// @assert.unique: {uniqueKeys: [CatId]}
entity PfcHeaders : managed, cuid {
  key BatchID    : UUID;
      CatId      : String(40);
      ProdId     : String(8);
      BpSFrom    : String(10);
      Matnr      : String(40);
      MatDesc    : String(40);
      MatBrand   : String(10);
      MatType    : String(4);
     
      BpSTo      : String(10);
      PlantSFrom : String(10);
      PlantSTo   : String(10);
      ErSFrom    : String(10);
      ErSTo      : String(10);
      SId        : String(30);
      viewOnly   : Boolean default false;
      PfDesc     : String(60);
      ParentID   : String;
      Parent     : Association to one PfcHeaders
                     on Parent.BatchID = ParentID;

      Items      : Composition of many PfcItems
                     on Items.parent = $self;
      // WfHist     : Composition of many PfcWorkfMatComments
      //                on WfHist.BatchID = $self.BatchID;

      Ventities  : Composition of many PfcEntities
                     on Ventities.parent = $self
// ChangeLogs : Composition of many PfcChangeLogs
//                on ChangeLogs.BatchID = $self.BatchID;
}

// @assert.unique: {uniqueKeys: [
//   CatId,
//   MatBrand,
//   Matnr,
//   VFrom,
//   VTo
// ]}
entity PfcItems : cuid, managed {
  // key BatchID     : UUID;
  parent      : Association to PfcHeaders;
  ParentID    : String;
  CatId       : String(12);
  MatBrand    : String(10);
  ItemNum     : String(10);
  Matnr       : String(40);
  MatDesc     : String(40);
  VFrom       : DateTime;
  VTo         : DateTime;
  MatType     : String(4);
  ApprStatus  : String(40);
  ApprDate    : DateTime;
  FApprover   : String(30);
  Comment     : String(120);
  Exclude     : Boolean;
  WorkfInstId : String(12);
// Association to Comments table
// Comments : Composition of many PfcItemComments
//     on Comments.PfcItem_BatchID = $self.BatchID;

}


entity PfcEntities : cuid, managed {
  parent   : Association to PfcHeaders;
  ParentID : String;
  CatId    : String(12);
  SeqNum   : String(6);
  ArchType : String(4);
  Plant    : String(10);
  BPartner : String(10);
}

entity PfcEcoRegions {
  key CountryCode : String(2);
      EcoRegCode  : String(6);
      EcoRegName  : String(14);
}


@assert.unique: {uniqueKeys: [
  CatId,
  Timestamp,
  Matnr,
  CreatedBy
]}
entity PfcChangeLogs {
  key BatchID   : UUID;
      CatId     : String(12);
      Timestamp : DateTime;
      CreatedBy : String(10);
      Comment   : String(120);
      Matnr     : String(40);
      MatBrand  : String(10);
      PrevVTo   : DateTime;
      CurrVTo   : DateTime;
}


entity PfcItemComments : cuid, managed {
  key CommentID       : UUID;
      PfcItem_BatchID : UUID; // Foreign Key to PfcItems
      Timestamp       : DateTime;
      Uname           : String(20);
      Comment         : String(60);
}

@cds.persistence.skip
entity Status {
  key StatusID : Integer;
      Desc     : String(20);
}


// view PFC_ListView as
//   select from PfcItems as l
//   inner join PfcHeaders as h
//     on l.BatchID = h.BatchID
//   {

//     key h.CatId as Cat_ID,
//     key l.MatBrand,
//     key l.Matnr,
//         l.MatDesc,
//         h.ProdId,
//         h.BpSFrom,
//         h.BpSTo,
//         h.PlantSFrom,
//         h.PlantSTo,
//         h.Items,
//         h.Ventities
//   }


view PfcItemsView as
  select
    CatId,
    MatBrand,
    Matnr,
    MatDesc,
    ApprStatus
  from PfcItems;

view ProdFIDValHelp as select distinct key ProdId from PfcHeaders;
view SFBPValueHelp as select distinct key BpSFrom from PfcHeaders;
view STBPValueHelp as select distinct key BpSTo from PfcHeaders;
view MatnrValHelp as select distinct key Matnr from PfcItemsView;
view MatBrandValHelp as select distinct key MatBrand from PfcItemsView;
