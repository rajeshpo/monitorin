// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Product Flow Catalog
// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Validation module for Product Flow Catalog Application
// ----------------------------------------------------------------------------*
// Descriptions: it will have all thevalidations at the time of create Screen
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*
const constants = require('../config/constants'); 

function checkPartnerPlantNull(plant,partner){
    if (!plant && !partner) {
        return true;
    }else{
        return false;
    }
}

function checkMaterialNull(matnr,matbrnd){
    if (!matnr && !matbrnd) {
        return true;
    }else{
        return false;
    }
}
