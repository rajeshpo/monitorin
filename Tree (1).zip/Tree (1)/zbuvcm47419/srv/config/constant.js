// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Product Flow Catalog Application
// ----------------------------------------------------------------------------*
// Descriptions:   To maintain constants for the Application 
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*

module.exports = Object.freeze({
    "MatStatus":[
        { StatusID: 1, SText: 'New' },
        { StatusID: 2, SText: 'Approved' },
        { StatusID: 3, SText: 'Pending For Approval'},
        { StatusID: 4, SText: 'Rework' },
        { StatusID: 5, SText: 'Reject' }
    ],
    "BpPlantError":"Please select atleast BusinessPartner or Plant Value!"
})