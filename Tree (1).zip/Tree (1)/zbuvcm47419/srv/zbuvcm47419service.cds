// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Product Flow Catalog App
// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Provides service definitions, data model projections, and custom actions for managing the Product Flow Catalog.
// ----------------------------------------------------------------------------*
// Descriptions: Provides service definitions, handlers, and utility functions for the Product Flow Catalog application.
//This module handles custom actions, and external API integration for managing Product Flow Catalog.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*

using {jnj.com.zbuvcm47419 as db} from '../db/zbuvcm47419schema';

@path: '/zbuvcm47419'
service zbuvcm47419Service {

  //Header Entity
  @odata.draft.enabled
  entity PFC_List          as projection on db.PfcHeaders;
  // Item Entity
  // entity PfcItemsList        as projection on db.PfcItems;

  // // Comments Entity
  // entity PfcComments as projection on db.PfcWorkfMatComments;

  // // ChangeLog Entity
  // entity PfcChangeLogs       as projection on db.PfcChangeLogs;
  // // Virtual Entity
  // entity PfcEntities         as projection on db.PfcEntities;
  // // EcoRegion
  // entity PfcEcoRegions       as projection on db.PfcEcoRegions;

  //CatalogID valueHelp
  // entity I_CatID_VH          as
  //   projection on db.PfcHeaders {
  //     key CatId
  //   };

  // entity I_ProdId_VH         as projection on db.ProdFIDValHelp;
  // entity I_SFBP_VH           as projection on db.SFBPValueHelp;
  // entity I_STBP_VH           as projection on db.STBPValueHelp;

  //entity I_Matnr_VH as projection on db.MatnrValHelp;


  //entity I_MatBrnd_VH as projection on db.MatBrandValHelp;

  entity I_MatStatus_VH as projection on db.Status;

  
  type MatDetail {
    MatBrand : String(10);
    Matnr    : String(40);
    VFrom    : DateTime;
    VTo      : DateTime;
  }

  type VDetail {
    SeqNo    : Integer;
    ArchType : String(10);
    Ve_Plant : String(60);
    Ve_BP    : String(60);
  }

  type MaterialUpdateList {
     WorkfInstId : String(12);
     Matnr       : String(40);
     MatBrand    : String(10);
     ApprStatus  : String(40);
     ApprDate    : DateTime;
     FApprover   : String(30);
     Comment     : String(120);
  }

  type Comments {

  }

  type ApproverInfo {
    Dl_BtpId   : String(20);
    DL_EmailId : String(60);
  }

  type MassUploadData {

  }

  type MassUploadResponse {

  }

  //WorkFlowHistory

  type ScenarioData {
    Matnr : String(20);
    MatBrnd : String(40);
    ShipFrom_BP: String(30);
    ShipFrom_P:String(60);
    ShipTo_P :String(30);
    ShipTo_BP: String(30);
    typeOfOrder: String(3);
  }

  type ScenDetResponse{

  }

  function ApproverDetermination(ShipEcoRegion : String)                                      returns String;
  function MaterialDetails(Cat_ID : String, Wf_ID : String)                                   returns array of MatDetail;
  function VEntityDetails(Cat_ID : String)                                                    returns array of VDetail;
  action   WorkflowUpdate(MatData : array of MaterialUpdateList) returns LargeString;
  action   MassUpload(PostingData : array of MassUploadData)                                 returns array of MassUploadResponse;
  function ScenarioDeterminationAPI(Data: array of ScenarioData) returns array of ScenDetResponse;
}



annotate zbuvcm47419Service.PFC_List with @cds.search: {
  Matnr, CatId
};

annotate zbuvcm47419Service.PFC_List with @Aggregation.RecursiveHierarchy #CatalogHierarchy: {
  ParentNavigationProperty: Parent, // navigates to a node's parent
  NodeProperty            : BatchID // identifies a node, usually the key
};

extend zbuvcm47419Service.PFC_List with @(
  // The columns expected by Fiori to be present in hierarchy entities
  Hierarchy.RecursiveHierarchy #CatalogHierarchy          : {
    LimitedDescendantCount: LimitedDescendantCount,
    DistanceFromRoot      : DistanceFromRoot,
    DrillState            : DrillState,
    LimitedRank           : LimitedRank
  },
  // Disallow filtering on these properties from Fiori UIs
  Capabilities.FilterRestrictions.NonFilterableProperties: [
    'LimitedDescendantCount',
    'DistanceFromRoot',
    'DrillState',
    'LimitedRank'
  ],
  // Disallow sorting on these properties from Fiori UIs
  Capabilities.SortRestrictions.NonSortableProperties    : [
    'LimitedDescendantCount',
    'DistanceFromRoot',
    'DrillState',
    'LimitedRank'
  ],
) columns { // Ensure we can query these fields from database
  null as LimitedDescendantCount : Int16,
  null as DistanceFromRoot       : Int16,
  null as DrillState             : String,
  null as LimitedRank            : Int16,
};
