// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Product Flow Catalog
// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : Application to create new Product Flows
// ----------------------------------------------------------------------------*
// Descriptions: Provides service definitions, handlers, and utility functions for the Product Flow Catalog App application.
//This module handles custom actions, and external API integration for managing Product Flow Catalog App.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*
const cds = require('@sap/cds');
const constants = require('./config/constant');

module.exports = srv => {


  const { PfcHeaders } = cds.entities








  srv.after(['CREATE'], ['PFC_List'], async (data, req) => {

    const insertPayloads = data.Items.map(mat => ({
      CatId: data.CatId,
      Matnr: mat.Matnr,

      MatBrand: mat.MatBrand,
      MatType: mat.MatType,
      BpSFrom: data.BpSFrom,
      BpSTo: data.BpSTo,
      PlantSFrom: data.PlantSFrom,
      PlantSTo: data.PlantSTo,
      ProdId: data.ProdId,
      ParentID: data.BatchID,
      viewOnly: true,
      Items: data.Items.map(child => ({
        ParentID: data.CatId,
        Matnr: child.Matnr,
        MatBrand: mat.MatBrand,
        MatType: mat.MatType,
        matDesc: mat.MatDesc,
        ApprStatus: mat.ApprStatus,
        ApprDate: mat.ApprDate,
      })),
      Ventities: data.Ventities.map(child => ({
        // ID:data.ID,
        ParentID: data.BatchID,
        CatId: data.CatId,
        SeqNum: child.SeqNum,
        ArchType: child.ArchType,
        Plant: child.Plant,
        BPartner: child.BPartner,
      }))
    }));

    await INSERT.into(PfcHeaders).entries(insertPayloads);


  });



  srv.after('UPDATE', 'PFC_List', async (data) => {
    console.log(data)
    await DELETE(PfcHeaders).where({
      CatId: data.CatId,
      ParentID: { '!=': null }
    })
    const insertPayloads = data.Items.map(mat => ({

      CatId: data.CatId,
      Matnr: mat.Matnr,
      MatBrand: mat.MatBrand,
      MatType: mat.MatType,
      BpSFrom: data.BpSFrom,
      BpSTo: data.BpSTo,
      PlantSFrom: data.PlantSFrom,
      PlantSTo: data.PlantSTo,
      ProdId: data.ProdId,
      viewOnly: true,
      ParentID: data.BatchID,
      Items: data.Items.map(child => ({
        // ID:data.ID,
        ParentID: data.BatchID,
        Matnr: child.Matnr,
        MatBrand: child.MatBrand,
        matDesc: child.MatDesc,
        ApprStatus: child.ApprStatus,
        ApprDate: child.ApprDate,
        MatType: child.MatType
      })),
      Ventities: data.Ventities.map(child => ({
        // ID:data.ID,
        ParentID: data.BatchID,
        CatId: data.CatId,
        SeqNum: child.SeqNum,
        ArchType: child.ArchType,
        Plant: child.Plant,
        BPartner: child.BPartner,
      }))

    }));

    console.log(insertPayloads)

    await INSERT.into(PfcHeaders).entries(insertPayloads);
  })






  // srv.before('SAVE', 'PFC_List', async (req) => {
  //   const REQUIRED_FIELDS = ["Matnr", "MatDesc", "MatStatus", "Criticality"];
  //   const headerData = req.data;

  //   // ✅ Check if Mitems are part of the incoming payload
  //   if (!headerData.Mitems || headerData.Mitems.length === 0) {
  //     req.error(400, 'At least one Material Item (Mitems) must be added.');
  //   }

  //   // ✅ Validate each line item
  //   for (const item of headerData.Mitems || []) {
  //     if (!item.Matnr) {
  //       req.error(400, `Matnr is required for item.`);
  //     }
  //     if (item.MatStatus!=="Ma") {
  //       req.error(400, `MatStatus is required for material ${item.Matnr}.`);
  //     }
  //     if (item.Mbrand==='!NEW') {
  //       req.error(400, `MBRAND is required for material ${item.Matnr}.`);
  //     }
  //   }
  // });






  // srv.on('DELETE', 'PFC_List.drafts', async (req) => {

  //   console.log("Hii")
  //   // optionally log or trace the delete
  //   // cleanup if any orphaned child drafts remain
  // });

  // MaterialDetails for SBPA WorkFlow  
  srv.on('MaterialDetails', async (req) => {
    // Extract the parameters passed in the function call
    const { CatId, Wf_ID } = req.data;

    // Query the "PfcItems" table to fetch the required fields
    const results = await cds.run(
      SELECT.from('PfcItems')
        .columns(['MatBrand', 'Matnr', 'VFrom', 'VTo', 'Createdby', 'CreatedDate'])
        .where({
          CatId: CatId,
          WorkfInstId: Wf_ID
        }).orderBy('ItemNum')
    );

    // Return the results back to the caller
    return results;
  });

  // "VEntityDetails" call from SBPA Workflow 
  srv.on('VEntityDetails', async (req) => {
    // Extracting the parameter passed in the function call
    const { CatId } = req.data;

    // Querying the "PfcEntities" table to fetch the required fields and order by SeqNum
    const results = await cds.run(
      SELECT.from('PfcEntities')
        .columns(['SeqNum', 'ArchType', 'Plant', 'BPartner'])
        .where({ CatId: CatId })
        .orderBy('SeqNum') // Sort by SeqNum in ascending order
    );

    // Return the results back to the caller
    return results;
  });

  srv.on('WorkflowUpdate', async (req) => {
    // Extract MaterialUpdateList input from the request
    const materialUpdates = req.data.MatData;

    // Check if any updates were provided
    if (!materialUpdates || materialUpdates.length === 0) {
      return 'No updates provided.';
    }

    // Prepare a batch of queries for bulk update
    const queries = materialUpdates.map((update) => {
      const {
        WorkfInstId,
        Matnr,
        MatBrand,
        ApprStatus,
        ApprDate,
        FApprover,
        Comment
      } = update;

      // Return an async query promise for each record
      return cds.run(
        UPDATE('PfcItems')
          .set({
            MatBrand: MatBrand,
            ApprStatus: ApprStatus,
            ApprDate: ApprDate,
            FApprover: FApprover,
            Comment: Comment
          })
          .where({
            WorkfInstId: WorkfInstId,
            Matnr: Matnr
          })
      );
    });

    // Execute all queries in parallel to improve performance
    await Promise.all(queries);

    // Return a success message
    return `Workflow updates processed successfully for ${materialUpdates.length} record(s).`;
  });


  srv.on('READ', 'I_MatStatus_VH', async (req) => {
    // Return constant value help data
    //For testing directly using constant value , will mainatain this in constant.js
    return constants.MatStatus;
  });


};
