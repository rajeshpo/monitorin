const cds = require('@sap/cds');
const hdbext = require("@sap/hdbext");
const dbclass = require("sap-hdbext-promisfied");


// This reusable function is used to make procedure call
let _callHdbProcedure = async function (sProcedureName, oInputParams) {

    //call procedure
    const db = await cds.connect.to('db');
    const dbConn = new dbclass(await dbclass.createConnection(db.options.credentials));
    const sp = await dbConn.loadProcedurePromisified(hdbext, null, sProcedureName);
    var oDbProcedureRet = dbConn.callProcedurePromisified(sp, oInputParams);
    return oDbProcedureRet;
}

module.exports = { _callHdbProcedure }