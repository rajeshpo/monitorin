## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Wed Jun 11 2025 06:03:27 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.18.0|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>Custom Page V4|
|**Service Type**<br>Local Cap|
|**Service URL**<br>http://localhost:4004/zbuvcm47419/|
|**Module Name**<br>zbuvcm47419|
|**Application Title**<br>Product Flow Catalog|
|**Namespace**<br>|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.136.1|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|
|**Main Entity**<br>PFC_List|

## zbuvcm47419

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply start your CAP project and navigate to the following location in your browser:

http://localhost:4004/zbuvcm47419/webapp/index.html

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


