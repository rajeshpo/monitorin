using zbuvcm47419Service as service from '../../srv/zbuvcm47419service';
using from '../../db/zbuvcm47419schema';

annotate service.PFC_List with @(
    Capabilities.DeleteRestrictions: {Deletable: false},
    UI.LineItem : [
        {
            $Type : 'UI.DataField',
            Value : CatId,
            Label : 'CatId',
        },
        {
            $Type : 'UI.DataField',
            Value : BpSFrom,
            Label : 'BpSFrom',
        },
        {
            $Type : 'UI.DataField',
            Value : BpSTo,
            Label : 'BpSTo',
        },
        {
            $Type : 'UI.DataField',
            Value : PlantSFrom,
            Label : 'PlantSFrom',
        },
        {
            $Type : 'UI.DataField',
            Value : PlantSTo,
            Label : 'PlantSTo',
        },
        {
            $Type : 'UI.DataField',
            Value : ProdId,
            Label : 'ProdId',
        },
        {
            $Type : 'UI.DataField',
            Value : viewOnly,
            Label : 'viewOnly',
        },
        {
            $Type : 'UI.DataField',
            Value : Matnr,
            Label : 'Matnr',
        },
        {
            $Type : 'UI.DataField',
            Value : MatBrand,
            Label : 'MatBrand',
        },
        {
            $Type : 'UI.DataField',
            Value : MatType,
            Label : 'MatType',
        },
        {
            $Type : 'UI.DataField',
            Value : MatDesc,
            Label : 'MatDesc',
        },
    ],
  

    UI.HeaderFacets : [
        {
            $Type : 'UI.ReferenceFacet',
            Label : 'Product Flow Header Details',
            ID : 'ProductFlowHeaderDetails',
            Target : '@UI.FieldGroup#ProductFlowHeaderDetails',
        },
    ],
    UI.FieldGroup #ProductFlowHeaderDetails : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Value : CatId,
                Label : 'CatId',
            },
            {
                $Type : 'UI.DataField',
                Value : BpSFrom,
                Label : 'BpSFrom',
            },
            {
                $Type : 'UI.DataField',
                Value : BpSTo,
                Label : 'BpSTo',
            },
            {
                $Type : 'UI.DataField',
                Value : PlantSFrom,
                Label : 'PlantSFrom',
            },
            {
                $Type : 'UI.DataField',
                Value : PlantSTo,
                Label : 'PlantSTo',
            },
            {
                $Type : 'UI.DataField',
                Value : ProdId,
                Label : 'ProdId',
            },
        ],

        
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            Label : 'Material Details',
            ID : 'MaterialDetails',
            Target : 'Items/@UI.LineItem#MaterialDetails',
        },
        {
            $Type : 'UI.ReferenceFacet',
            Label : 'Virtual Entities',
            ID : 'VirtualEntities',
            Target : 'Ventities/@UI.LineItem#VirtualEntities',
        },
    ],
    UI.FieldGroup #MaterialDetails : {
        $Type : 'UI.FieldGroupType',
        Data : [
        ],
    },

          UI.UpdateHidden                : viewOnly,
    UI.SelectionFields : [
        CatId,
        Matnr,
        MatBrand,
        MatType,
    ],
);

annotate service.PfcItems with @(
    Capabilities.DeleteRestrictions: {Deletable: false},
    UI.LineItem #MaterialDetails : [
        {
            $Type : 'UI.DataField',
            Value : Matnr,
            Label : 'Matnr',
        },
        {
            $Type : 'UI.DataField',
            Value : MatBrand,
            Label : 'MatBrand',
        },
        {
            $Type : 'UI.DataField',
            Value : MatDesc,
            Label : 'MatDesc',
        },
        {
            $Type : 'UI.DataField',
            Value : ApprStatus,
            Label : 'ApprStatus',
        },
        {
            $Type : 'UI.DataField',
            Value : ApprDate,
            Label : 'ApprDate',
        },
        {
            $Type : 'UI.DataField',
            Value : MatType,
            Label : 'MatType',
        },
        {
            $Type : 'UI.DataField',
            Value : Exclude,
            Label : 'Exclude',
        },
    ]
);

annotate service.PfcEntities with @(
    UI.LineItem #VirtualEntities : [
        {
            $Type : 'UI.DataField',
            Value : BPartner,
            Label : 'BPartner',
        },
        {
            $Type : 'UI.DataField',
            Value : ArchType,
            Label : 'ArchType',
        },
        {
            $Type : 'UI.DataField',
            Value : Plant,
            Label : 'Plant',
        },
        {
            $Type : 'UI.DataField',
            Value : SeqNum,
            Label : 'SeqNum',
        },
    ]
);

annotate service.PFC_List with {
    CatId @Common.Label : 'CatId'
};

annotate service.PFC_List with {
    Matnr @Common.Label : 'Matnr'
};

annotate service.PFC_List with {
    MatBrand @Common.Label : 'MatBrand'
};

annotate service.PFC_List with {
    MatType @Common.Label : 'MatType'
};

