sap.ui.define(['sap/ui/core/mvc/ControllerExtension,sap/ui/core/mvc/JSONModel'], function (ControllerExtension,JSONModel) {
	'use strict';

	return ControllerExtension.extend('zbuvcm47419.ext.controller.CustomObjectPageController', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
            onInit: function () {
				let da3 = {
                    "nodes": [
                        {
                            "id": "1",
                            "lane": "0",
                            "title": "Gurabo",
                            "titleAbbreviation": "Gurabo",
                            "type": "Single",
							
                            "children": [
                                {
                                    "nodeId": 14,
                                    "connectionLabel": {
                                        "id": "myButtonId1To14",
                                        "text": "IC_SALE",
                                        "enabled": true,
										"state": "Positive",

										"tooltip": "This is the tooltip text for IC_SALE" // Tooltip text
                                      
                                    }
                                }
                            ],
                            "state": "Positive",
                            "stateText": null,
                            "focused": false,
                            "texts": [""],
                            "highlighted": false
                        },
                        {
                            "id": "14",
                            "lane": "1",
                            "title": "JB1",
                            "titleAbbreviation": "JB1",
                            "type": "Single",
                            "children": [
                                {
                                    "nodeId": 20,
                                    "connectionLabel": {
                                        "id": "myButtonId14To30",
                                        "text": "FLASH_SALE",
                                        "enabled": true,
                                        "state": "Positive"
                                    }
                                }
                            ],
                            "stateText": "Plant_101",
                            "focused": false,
                            "texts": ["text 1", "text 2"],
                            "highlighted": false
                        },
                        {
                            "id": "20",
                            "lane": "2",
                            "title": "JB2",
                            "titleAbbreviation": "JB2",
                            "type": "Single",
                            "children": [
                                {
                                    "nodeId": 30,
                                    "connectionLabel": {
                                        "id": "myButtonId14To20",
                                        "text": "FLASH_SALE",
										"enabled": true,
										"priority": 7,
                                        "state": "Positive",
										"tooltip":"Hiiiiiiiiiiiiii"
                                    }
                                }
                            ],
                            "stateText": "Plant_102",
                            "focused": true,
                            "texts": null,
                            "highlighted": false
                        },
                        {
                            "id": "30",
                            "lane": "3",
                            "title": "KDC",
                            "titleAbbreviation": "KDC",
                            "type": "Single",
                            "children": null,
                            "state": "Positive",
                            "stateText": null,
                            "focused": true,
                            "texts": null,
                            "highlighted": false
                        }
                    ],
                    "lanes": [
                        {
                            "id": "0",
                            "icon": "sap-icon://factory",
                            "label": "Ship From BP",
                            "position": 0,
                            "state": [
                                {
                                    "state": "Positive",
                                    "value": 10
                                }
                            ]
                        },
                        {
                            "id": "1",
                            "icon": "sap-icon://building",
                            "label": "Virtual Entity 1",
                            "position": 1,
                            "state": [
                                {
                                    "state": "Negative",
                                    "value": 25
                                }
                            ]
                        },
                        {
                            "id": "2",
                            "icon": "sap-icon://building",
                            "label": "Virtual Entity 2",
                            "position": 2,
                            "state": [
                                {
                                    "state": "Negative",
                                    "value": 25
                                }
                            ]
                        },
                        {
                            "id": "3",
                            "icon": "sap-icon://factory",
                            "label": "Ship To BP",
                            "position": 3,
                            "state": [
                                {
                                    "state": "Positive",
                                    "value": 10
                                }
                            ]
                        }
                    ]
                };

                // Set up the model
                let oModel3 = new JSONModel(da3);
                this.getView().setModel(oModel3, "data3");
            },

            onAfterRendering: function () {
                
            },

         
        }
	});
});
