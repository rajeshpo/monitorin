sap.ui.define(['sap/ui/core/mvc/ControllerExtension'], function (ControllerExtension) {
	'use strict';

	return ControllerExtension.extend('zbuvcm47419.ext.controller.CustomListReportController', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             * @memberOf zbuvcm47419.ext.controller.CustomListReportController
             */
			onInit: function () {
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				var oModel = this.base.getExtensionAPI().getModel();
			},
			routing: {
				onBeforeNavigation: function (mNavigationParameters) {
					
					const oBindingContext = mNavigationParameters.bindingContext,
						objectInformation = oBindingContext.getObject()
					const oComponent = this.base.getModel('globalModel');
					

					if (oComponent) {
						oComponent.setProperty("/sharedData", objectInformation);
					} else {
						console.error("Global model not found in Main controller.");
					}
					console.log(oBindingContext, "oBind")
				},
				handleRouting: function() {
					console.log("handleRouting");
				},
				
				
			},
		}
	});
});
