sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'zbuvcm47419/test/integration/FirstJourney',
		'zbuvcm47419/test/integration/pages/PFC_ListMain'
    ],
    function(JourneyRunner, opaJourney, PFC_ListMain) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('zbuvcm47419') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onThePFC_ListMain: PFC_ListMain
                }
            },
            opaJourney.run
        );
    }
);