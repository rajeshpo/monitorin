sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("zbuvcm47419.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);