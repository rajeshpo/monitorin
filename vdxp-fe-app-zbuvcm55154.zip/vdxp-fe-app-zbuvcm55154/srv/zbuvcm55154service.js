// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Scenario 1 Constant Tables
// Object Id       : ZBUVCM55154
// Release         : 1
// Version         : 0.01
// Description     : Application to create new Product Flows
// ----------------------------------------------------------------------------*
// Descriptions: Table and Views
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*


const { getUUIDFromPathVal } = require('@cap-js/change-tracking/lib/entity-helper');
const constants = require('./config/constants');
const Check = require('./utils/excelCheck');
const { default: cds } = require('@sap/cds');
const { error } = require('@sap/cds');
const { message } = require('@sap/cds/lib/log/cds-error');
const logger = cds.log('vcm55154-program');
const { syn_SIdPairSequence, syn_PfcArchTypeMapping, BackupProgram, syn_SeqStepsID } = cds.entities('jnj.com.zbuvcm55154');
let sheetData = [];
module.exports = async (srv) => {



  /**
 * Service handler for ScenarioType_VH
 * Returns Type constants directly without calling external service
 * URL: /zbuvcm55154/ScenarioType_VH
 */
  srv.on('READ', 'ScenarioType_VH', async (req) => {
    console.log(constants.ScenarioType)
    return constants.ScenarioType;
  });

  srv.on('READ', 'DocumentType_VH', async (req) => {
    console.log(constants.DocumentType)
    return constants.DocumentType;
  });

  srv.on('READ', 'InitialDocumentType_VH', async (req) => {
    console.log(constants.InitialDocumentType)
    return constants.InitialDocumentType;
  });

  /** 
   * Service handler for Upload Excel
   * Data from uploaded excel and fetched and retuned to UI
   * Method:PUT
 */
  srv.on(constants.PUT, constants.uploadExcel, async (req) => {
    try {

      sheetData = await Check.getExcel(req);
      // logger.info(constants.BTPLogging + "Excel SuccessFully Fetched" + JSON.stringify(sheetData.Item));
      return sheetData;
    } catch (oError) {
      return oError.message;
    }
  });

  /** 
   * Function handler to return the extracted excel data to UI
 */
  srv.on(constants.uploadCompletedExcel, async (req) => {
    if (sheetData.hasOwnProperty(constants.Item)) {
      const items = sheetData.Item;
      if (items.length > 0) {
        // logger.info(constants.BTPLogging + "Excel Upload Successful");
        return [{
          value: items
        }];
      } else {
        return [];
        // logger.info(constants.BTPLogging + constants.UploadExcelNoItem);
      }
    } else {
      return [];
      // logger.info(constants.BTPLogging + constants.UploadExcelIncorrect);
    }
  });


  /** 
  * Action handler to return the store the mass upload of scenario steps
*/
  srv.on('createScenarioData', async (req) => {


    const data = req.data.ScenarioSteps;

    try {
      const result = await cds.run(INSERT.into(syn_SIdPairSequence).entries(data));
      console.log('Scenario Steps record inserted:', result);
      return { success: true, message: 'Scenario Steps inserted successfully' };
    } catch (error) {
      console.error('Error inserting Scenario Steps :', error);
      return { success: false, error: error.message };
    }

  })


  /** 
* Action handler to return the store the mass upload of scenario steps
*/
  srv.on('createBackupProgramData', async (req) => {


    const data = req.data.BackupProgramData;

    try {
      const result = await cds.run(INSERT.into(BackupProgram).entries(data));
      console.log('Backup Program Data record inserted:', result);
      return { success: true, message: 'Backup Program Data inserted successfully' };
    } catch (error) {
      console.error('Error inserting Scenario Steps :', error);
      return { success: false, error: error.message };
    }

  })


  srv.on('getDuplicateData', async (req) => {

    let type = req.data.type
    let data = await cds.run(
      SELECT.from(type)
    );

    return data

  });

  srv.on('mandatoryDataforUploadCheck', async (req) => {
    try {
      //const scenarioSteps = await cds.run(SELECT.distinct.from(syn_SIdPairSequence).columns('Steps'));
      //const  scenarioSteps =  constants.ScenarioSteps;
      const scenarioStepsRaw = await cds.run(
        SELECT.distinct.from(syn_SeqStepsID)
      );

      // Map Step → Steps
      const scenarioSteps = scenarioStepsRaw.map(row => ({
        ...row,
        Steps: row.Step
      }));
      const archtypeSteps = await cds.run(SELECT.distinct.from(syn_PfcArchTypeMapping).columns('ArchType'));
      return [
        {
          scenarioConstValue: scenarioSteps,
          archtypeConstValue: archtypeSteps.map(a => a.ArchType)
        }
      ];
    } catch (error) {
      console.error('Error fetching mandatory data:', error);
      return { success: false, error: error.message };
    }
  })


  srv.before('CREATE', 'SIdPairSequenceForUI', async req => {

    const { SId, Entity } = req.data;

    // --- Entity validation ---
    if (SId && Entity) {
      const vpCount = (SId.match(/VP/g) || []).length;

      if (vpCount > 0) {
        const allowedVE = Array.from(
          { length: vpCount },
          (_, i) => `VE${i + 1}`
        );

        const allowedEntities = ['SF', 'ST', ...allowedVE];

        if (!allowedEntities.includes(Entity.trim())) {
          req.error({
            code: 'INVALID_ENTITY',
            message: `Allowed values: ${allowedEntities.join(', ')}`,
            target: 'Entity'   // 👈 highlights this field in UI
          });
        }
      }
    }

  });



  /**
   * Service handler for READ I_MatStatus_VH
   * Returns material status constants directly without calling external service
   * URL: /zbuvcm47419/I_MatStatus_VH
   */
  srv.on('READ', 'action_VH', async (req) => {
    return constants.Action;
  });



  /**
  * Service handler for READ I_MatStatus_VH
  * Returns material status constants directly without calling external service
  * URL: /zbuvcm47419/I_MatStatus_VH
  */
  srv.on('READ', 'variation_VH', async (req) => {
    return constants.Variation;
  });

  /**
  * Service handler for READ I_MatStatus_VH
  * Returns material status constants directly without calling external service
  * URL: /zbuvcm47419/I_MatStatus_VH
  */
  srv.on('READ', 'scenario_VH', async (req) => {
    return constants.Scenario;
  });


  //  /**
  //  * Service handler for READ I_MatType_VH
  //  * Forwards the query to the external service ZSD_VCM_PRODUCTFLOW
  //  * URL: /zbuvcm47419/I_MatType_VH
  //  */
  // this.on('READ', "archType_VH", (req) => ZSD_VCM_PRODUCTFLOW.run(req.query));


  //  /**
  //  * Service handler for READ I_MatType_VH
  //  * Forwards the query to the external service ZSD_VCM_PRODUCTFLOW
  //  * URL: /zbuvcm47419/I_MatType_VH
  //  */
  // this.on('READ', "steps_VH", (req) => ZSD_VCM_PRODUCTFLOW.run(req.query));

  srv.on('Process', 'BackupProgram', async (req) => {
    try {
      const { BackupProgram } = cds.entities
      const { ID } = req.params[0]

      // Fetch Backup Program record
      const documentData = await SELECT.one
        .from(BackupProgram)
        .where({ ID })

      if (!documentData) {
        return req.error(404, 'Backup Program not found')
      }

      if (documentData.status === 'Processed') {
        return req.reject(400, 'Document Already Processed')
      }

      // Initial document type decides the processing logic
      const documentType = documentData.initialDocumentType

      // Connect to Event Mesh once
      const eventmesh = await cds.connect.to("eventmeshservice")

      /**
       * Helper function to publish event to Event Mesh
       */
      const publishEvent = async (endpoint, payload) => {
        return eventmesh.send("POST", endpoint, payload)
      }

      switch (documentType) {

        /**
         * =========================
         * PURCHASE ORDER PROCESSING
         * =========================
         */
        case "Purchase Order": {
          const poService = await cds.connect.to("PURCHASEORDER")
          const { PurchaseOrder } = poService.entities

          // Validate PO existence in S/4
          const poExists = await poService.run(
            SELECT.one.from(PurchaseOrder).where({
              PurchaseOrder: documentData.initialDocumentNo
            })
          )

          if (!poExists) break

          // Build PO event payload
          const payload = {
            type: "sap.s4.beh.inbounddelivery.v1.InboundDelivery.Created.v1",
            data: {
              PurchaseOrder: documentData.initialDocumentNo
            }
          }

          await publishEvent("/zbuEventMesh/eventHandlerPO", payload)
          await UPDATE(BackupProgram).with({ status: 'Processed' }).where({ ID })
          req.notify(`Request Processes successfully for PO: ${payload?.data?.PurchaseOrder}`)
          break
        }

        /**
         * ======================
         * SALES ORDER PROCESSING
         * ======================
         */
        case "Sales Order": {
          const soService = await cds.connect.to("ZAPI_SALES_ORDER_SRV")
          const { A_SalesOrder } = soService.entities

          // Validate SO existence in S/4
          const soExists = await soService.run(
            SELECT.one.from(A_SalesOrder).where({
              SalesOrder: documentData.initialDocumentNo
            })
          )

          if (!soExists) break

          let payload = null

          // ZCL – Sales Order Without Charge
          if (documentData.docType === "ZCL") {
            payload = {
              type: "sap.s4.beh.salesorder.v1.SalesOrder.Create.v1",
              data: {
                SalesOrder: "",
                SalesOrderType: "",
                SalesOrderWithoutCharge: documentData.initialDocumentNo,
                SalesOrderWithoutChargeType: "ZCL"
              }
            }
          }

          // ZPM – Normal Sales Order
          const validDocTypes = ["ZPM", "ZDR", "ZCR"];

          if (validDocTypes.includes(documentData.docType)) {
            payload = {
              type: "sap.s4.beh.salesorder.v1.SalesOrder.Create.v1",
              data: {
                SalesOrder: documentData.initialDocumentNo,
                SalesOrderType: documentData.docType,
                SalesOrderWithoutCharge: "",
                SalesOrderWithoutChargeType: ""
              }
            };
          }

          if (payload) {

            await publishEvent("/zbuEventMesh/eventHandler", payload)

            await UPDATE(BackupProgram).with({ status: 'Processed' }).where({ ID })
            req.notify(`Request Processes successfully for Sales Order: ${payload?.data?.SalesOrder}`)
          } else {
            req.error(`Request Processes unsuccessfully for Sales Order: ${payload?.data?.SalesOrder}`)
          }

          break
        }

        /**
         * ======================
         * DEFAULT / UNSUPPORTED
         * ======================
         */
        default:
          req.notify(`Unsupported document type: ${documentType}`)
      }
    } catch (error) {
      req.reject(400, error.message)
    }
  });

  srv.on('READ', 'deleteChangeView', async (req) => {
    const data = await cds.run(
      SELECT.from('sap.changelog.ChangeView')
        .where({ modification: 'delete' })
        .orderBy({ createdAt: 'desc' })
    );
    if (req.query.SELECT.count) {
      data.$count = data.length;
    }
    return data;
  });

  srv.on('FetchDoctype', async (req) => {  // Fetching DOCTYPE
    try {

      const { Tvarc } = cds.entities;

      const tvarcData = await cds.run(
        SELECT.one.from(Tvarc)
          .columns('Low').where ({ VarName: 'AP_JOB_DOCTYPE' })
      );
      logger.info("Tvrdata",tvarcData);

      return tvarcData;

    } catch (error) {
      
      return {
        success: false,
        error: error.message
      };
    }
  });

  // Defect JGHJ-103176
  srv.on("userInfo", async (req) => {
    return {
      id: req.user.id,
      roles: JSON.stringify(req.user.roles)
    };
  });
 
srv.on('error', (err, req) => {
  if (err.code === 301) {
    err.message =  `Duplicate entry violates a unique constraint (${req.query.INSERT.into.ref[0].split(".")[1] || 'unknown entity'}).`;
    return req.error(
      {
        status : 301,
        message: err.message
      }    
    )
  }
});

}
