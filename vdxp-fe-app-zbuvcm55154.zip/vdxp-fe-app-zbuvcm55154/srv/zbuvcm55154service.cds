// --------------------------------------------------------------------------------------------------------------------*
// Application Name :  Scenario 1 Constant Tables
// Object Id       : ZBUVCM47419
// Release         : 1
// Version         : 0.01
// Description     : This application is maintained to handle constant tables for the Scenarion 1
// ----------------------------------------------------------------------------*
// Descriptions: Provides service definitions, handlers, and utility functions for the Scenario 1.
//This module handles custom actions, and external API integration for managing Product Flow Catalog.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*
using {jnj.com.zbuvcm55154 as db} from '../db/zbuvcm55154schema';
using {sap.changelog as changetracking} from '@cap-js/change-tracking';


@path: '/zbuvcm55154'
service zbuvcm55154Service {
   @Capabilities: {SearchRestrictions: {
      $Type     : 'Capabilities.SearchRestrictionsType',
      Searchable: false
   }}
   entity TAVARC                   as projection on db.Tvarc;

   // @(restrict: [{to: [
   //    'XS3-VCM-CONSTB-SUP',
   //    'XS2-VCM-CONSTB-IT'
   // ]}])

   @odata.draft.enabled
   entity TAVARCFORUI 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                              
   as projection on db.Tvarc;

   @Capabilities: {SearchRestrictions: {
      $Type     : 'Capabilities.SearchRestrictionsType',
      Searchable: false
   }}
   entity FilterConstant           as projection on db.VCMFilterConstant;

   // @(restrict: [{to: [
   //    'XS3-VCM-CONSTB-SUP',
   //    'XS2-VCM-CONSTB-IT'
   // ]}])
   
   @odata.draft.enabled
   entity FilterConstantForUI 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                              
   as projection on db.VCMFilterConstant;


   entity NonVCMStepSeq            as projection on db.Non_VcmStepSeq_TABLE;

   // @(restrict: [{to: [
   //    'XS3-VCM-CONSTB-SUP',
   //    'XS2-VCM-CONSTB-IT'
   // ]}])
   @Capabilities: {SearchRestrictions: {
      $Type     : 'Capabilities.SearchRestrictionsType',
      Searchable: false
   }}
   @odata.draft.enabled
   entity NonVCMStepSeqForUI
    @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                             
   as projection on db.Non_VcmStepSeq_TABLE;

   entity DocumentType_VH {
        key type : String
    }

   entity ScenarioType_VH {
        key Desc : String
    }
   entity InitialDocumentType_VH {
        key type : String
    }

   @odata.draft.enabled
   entity EmailNotifyForUI 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                          
   as projection on db.syn_EmailNotify;

   @odata.draft.enabled
   entity PfcWorkFlowApproverForUI 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                          
   as projection on db.syn_PfcWorkFlowApprover;

   @Capabilities: {SearchRestrictions: {
      $Type     : 'Capabilities.SearchRestrictionsType',
      Searchable: false
   }}
   @odata.draft.enabled
   entity SIdPairSequenceForUI 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                          
   as projection on db.syn_SIdPairSequence;

   @odata.draft.enabled
   entity PfcEcoRegionsForUI 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                          
   as projection on db.syn_PfcEcoRegions;

   @odata.draft.enabled
   entity GLAccountMappingUI 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                          
   as projection on db.syn_GLAccountMapping;

   @odata.draft.enabled
   entity SCASenarioStepsUI 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                          
   as projection on db.syn_NonVCAScenarioConfig;
   @odata.draft.enabled
   entity UASIDDeterminationUI 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                        
   as projection on db.syn_UASIDDetermination;

   entity JomChargeBackGL          as projection on db.JomChargeBackGL;

   @Capabilities: {SearchRestrictions: {
      $Type     : 'Capabilities.SearchRestrictionsType',
      Searchable: false
   }}
   @odata.draft.enabled
   entity JomChargeBackGLUI 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                        
   as projection on db.JomChargeBackGL;

   @cds.persistence.skip
   @odata.singleton
    entity uploadExcel {
        @Core.MediaType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        excel : LargeBinary;
    };

   type SequenceStepsData {
      Id          : UUID;
      SId         : String(255);
      Pair        : String(255);
      Description : String(255);
      System      : String(255);
      ArchType    : String(255);
      Variation   : String(255);
      Sequence    : String(255);
      Steps       : String(255);
      Entity      : String(255);
      Action      : String(255);
      stepID : String(255);
   }

   type BackupData{
      initialDocumentNo:String(10);
      initialDocumentType:String(50);
      docType:String;
      plant:String(10);
      status:String;
   }


      type SequenceSteps {
      SId         : String(255);
      Pair        : String(255);
      Description : String(255);
      System      : String(255);
      ArchType    : String(255);
      Variation   : String(255);
      Sequence    : String(255);
      Steps       : String(255);
      Entity      : String(255);
      Action      : String(255);
}

   @odata.draft.enabled
   entity PfcArchTypeMapping 
    @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                     
   as projection on db.syn_PfcArchTypeMapping;


   @odata.draft.enabled
   entity StepDetail 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                      
   as projection on db.syn_SeqStepsID;

   /*********************************Create Screen Value Help*********************************************************/

   entity archType_VH as projection on db.archTypeValueHelp;
   
   entity steps_VH as projection on db.stepsValueHelp;

   entity scenarioSteps_VH as projection on db.syn_SeqStepsID{
      key ID,
      Step as Steps
   };

   entity action_VH as projection on db.Action;
    
   entity variation_VH as projection on db.Variation;

   entity scenario_VH as projection on db.Scenario;

   entity ChangeView as projection on changetracking.ChangeView;

   @cds.persistence.skip
   entity deleteChangeView {
      key ID                : String;
          attribute         : String;
          changeLog_ID      : String;
          createdAt         : Timestamp;
          createdBy         : String;
          entity            : String;
          entityKey         : String;
          keys              : String;
          modification      : String;
          objectID          : String;
          parentKey         : String;
          parentObjectID    : String;
          serviceEntity     : String;
          serviceEntityPath : String;
          valueChangedFrom  : String;
          valueChangedTo    : String;
          valueDataType     : String;
   }
  
   // action   logReport(SequenceRecords : SequenceStepsHANA)                  returns String;
    // Define a function to insert records
    action   createScenarioData(ScenarioSteps : array of SequenceStepsData)                             returns String;

   action   createBackupProgramData(BackupProgramData : array of BackupData)                             returns String;

   function uploadCompletedExcel()  returns String;
   function mandatoryDataforUploadCheck() returns String;

   function FetchDoctype() returns array of String;  // Fetch distinct document type from Constant table

   // Backup program
   @odata.draft.enabled
   entity BackupProgram 
   @(restrict: [
      {
         grant: [
            'READ',
            'CREATE',
            'UPDATE',
            'DELETE'
         ],
         to   : 'XS2-VCM-CONSTB-MNT'
      },
      {
         grant: ['READ'],
         to   : 'XS3-VCM-CONSTB-DSP'
      }
   ])                        
   as projection on db.BackupProgram
      actions {
         @(
            cds.odata.bindingparameter.name: '_it',
            Common.SideEffects             : {TargetEntities: ['_it']}
         )
         action Process();
      };

   action   getDuplicateData(type: String)                                  returns array of String;

   // Defect JGHJ-103176
    type UserInfo {
        id    : String;
        roles : LargeString;
    }

    function userInfo()            returns UserInfo;
}
//  rowPress="rowpress"
