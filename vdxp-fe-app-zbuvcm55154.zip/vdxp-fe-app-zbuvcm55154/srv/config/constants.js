// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Scenario 1 Constant Tables
// Object Id       : ZBUVCM55154
// Release         : 1
// Version         : 0.01
// Description     : Application to create new Product Flows
// ----------------------------------------------------------------------------*
// Descriptions: Table and Views
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*

module.exports = Object.freeze({
    "ScenarioType": [
        { Desc: 'Normal' },
        { Desc: 'Remanufacturing' },
    ],
    "DocumentType": [
        { type: 'ZPM' },
        { type: 'ZCL' },
        { type: 'ZDR' },
        { type: 'ZCR' },
        { type: 'ZAFL' },
        { type: 'ZAFS' }
    ],
    "InitialDocumentType":[
        {type:"Purchase Order"},
        {type:"Sales Order"}
    ],
    "ScenarioSteps": [
        { Steps: 'TRADE SO', ID: 'TSO' },
        { Steps: 'SUBCON PO', ID: 'SPO' },
        { Steps: 'INTERCOMPANY SO', ID: 'ICSO' },
        { Steps: 'GOODS RECEIPT', ID: 'GR' },
        { Steps: 'INTERCOMPANY PO', ID: 'ICPO' },
        { Steps: 'AP INVOICE', ID: 'API' },
        { Steps: 'OUTBOUND DELIVERY', ID: 'OBD' },
        { Steps: 'GOODS ISSUE', ID: 'GI' },
        { Steps: 'AR INVOICE', ID: 'ARI' },
        { Steps: 'LEGACY INTERCOMPANY SO', ID: 'L_ICSO' },
        { Steps: 'LEGACY OUTBOUND DELIVERY', ID: 'L_OBD' },
        { Steps: 'LEGACY GOODS ISSUE', ID: 'L_PGI' },
        { Steps: 'LEGACY AR INVOICE', ID: 'L_ARI' },
        { Steps: 'BATCH CREATION', ID: 'BC' },
        { Steps: 'INBOUND DELIVERY', ID: 'IBD' },
        { Steps: 'STOCK IN TRANSIT', ID: 'SIT' }
    ],
    "Action": [
        { Action: 'I' },
        { Action: 'A' },
        { Action: 'M' },
        { Action: 'L' },
        { Action: 'T' }
    ],
    "Variation": [
        { variation: '1',desc:"SO" },
        { variation: '2',desc:"PO" },
    ],
    "Scenario": [
        { scenario: 'Push' },
        { scenario: 'Pull' },
        { scenario: 'AT' },
    ],
    PUT: 'PUT',
    uploadCompletedExcel: 'uploadCompletedExcel',
    uploadExcel: 'uploadExcel',
    Item: 'Item',
    DATA: 'data',
    END: 'end',
    BUFFER: 'buffer'
});