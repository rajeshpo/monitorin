## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Fri Sep 26 2025 13:59:59 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.18.7|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>Custom Page V4|
|**Service Type**<br>Local CAP|
|**Service URL**<br>http://localhost:4004/zbuvcm55154/|
|**Module Name**<br>zbuvcm55154constantui|
|**Application Title**<br>Constant Tables|
|**Namespace**<br>com.jnj|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.140.0|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|
|**Main Entity**<br>NonVCMStepSeq|

## zbuvcm55154constantui

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated app, start your CAP project:  and navigate to the following location in your browser:

http://localhost:4004/com.jnj.zbuvcm55154constantui/index.html

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


