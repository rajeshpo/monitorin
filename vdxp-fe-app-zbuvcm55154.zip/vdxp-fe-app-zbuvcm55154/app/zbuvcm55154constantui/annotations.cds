using zbuvcm55154Service as service from '../../srv/zbuvcm55154service';

annotate service.deleteChangeView with @(

    UI.LineItem #tableMacro: [
        {
            $Type: 'UI.DataField',
            Value: attribute,
            Label: '{i18n>Attribute}',
        },
        {
            $Type: 'UI.DataField',
            Value: valueChangedFrom,
            Label: '{i18n>ValueChangedFrom}',
        },
        {
            $Type: 'UI.DataField',
            Value: valueChangedTo,
            Label: '{i18n>ValueChangedTo}',
        },
        {
            $Type: 'UI.DataField',
            Value: entity,
            Label: '{i18n>ChangeLog.entity}',
        },
        {
            $Type: 'UI.DataField',
            Value: serviceEntity,
            Label: '{i18n>ChangeLog.serviceEntity}',
        },
        {
            $Type: 'UI.DataField',
            Value: modification,
            Label: '{i18n>Modification}',
        },
        {
            $Type: 'UI.DataField',
            Value: createdAt,
            Label: '{i18n>CreatedAt1}',
        },
        {
            $Type: 'UI.DataField',
            Value: createdBy,
            Label: '{i18n>CreatedBy}',
        },
        {
            $Type : 'UI.DataField',
            Value : changeLog_ID,
            Label : 'changeLog_ID',
            @UI.Hidden,
        },
        {
            $Type : 'UI.DataField',
            Value : ID,
            Label : 'ID',
            @UI.Hidden,
        },
        {
            $Type : 'UI.DataField',
            Value : keys,
            Label : 'keys',
            @UI.Hidden,
        },
        {
            $Type : 'UI.DataField',
            Value : entityKey,
            Label : 'entityKey',
            @UI.Hidden,
        },
        {
            $Type : 'UI.DataField',
            Value : objectID,
            Label : 'objectID',
            @UI.Hidden,
        },
        {
            $Type : 'UI.DataField',
            Value : parentKey,
            Label : 'parentKey',
            @UI.Hidden,
        },
        {
            $Type : 'UI.DataField',
            Value : parentObjectID,
            Label : 'parentObjectID',
            @UI.Hidden,
        },
        {
            $Type : 'UI.DataField',
            Value : serviceEntityPath,
            Label : 'serviceEntityPath',
            @UI.Hidden,
        },
        {
            $Type : 'UI.DataField',
            Value : valueDataType,
            Label : 'valueDataType',
            @UI.Hidden,
        },
    ],
    UI.HeaderInfo          : {Title: {
        $Type: 'UI.DataField',
        Value: ID,
        },
    },
);

annotate service.TAVARCFORUI with @(
    UI.LineItem #tableMacro   : [
        {
            $Type: 'UI.DataField',
            Value: VarName,
            Label: '{i18n>VariableName}',
        },
        {
            $Type: 'UI.DataField',
            Value: SeqNo,
            Label: '{i18n>SequenceNumber1}',
        },
        {
            $Type: 'UI.DataField',
            Value: Low,
            Label: '{i18n>Value}',
        },
        {
            $Type: 'UI.DataField',
            Value: High,
            Label: '{i18n>Category1}',
        },
    ],


    UI.Facets                 : [{
        $Type : 'UI.ReferenceFacet',
        Label : '{i18n>TavarcUi}',
        ID    : 'TAVARCFORUI',
        Target: '@UI.FieldGroup#TAVARCFORUI',
    }, ],
    UI.FieldGroup #TAVARCFORUI: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Value: VarName,
                Label: '{i18n>VariableName}',
            },
            {
                $Type: 'UI.DataField',
                Value: SeqNo,
                Label: '{i18n>SequenceNumber1}',
            },
            {
                $Type: 'UI.DataField',
                Value: Low,
                Label: '{i18n>Value}',
            },
            {
                $Type: 'UI.DataField',
                Value: High,
                Label: '{i18n>Category}',
            },
        ]
    },
    UI.HeaderInfo             : {
        Title         : {
            $Type: 'UI.DataField',
            Value: VarName,
        },
        TypeName      : '',
        TypeNamePlural: '',
    },
);

annotate service.FilterConstantForUI with @(
    UI.LineItem #tableMacro           : [
        {
            $Type: 'UI.DataField',
            Value: Type,
            Label: '{i18n>Type}',
        },
        {
            $Type: 'UI.DataField',
            Value: ConstantVar,
            Label: '{i18n>ConstantVariable1}',
        },
        {
            $Type: 'UI.DataField',
            Value: SeqNum,
            Label: '{i18n>SequenceNumber1}',
        },
        {
            $Type: 'UI.DataField',
            Value: Category,
            Label: '{i18n>Category1}',
        },
        {
            $Type: 'UI.DataField',
            Value: Value,
            Label: '{i18n>Value}',
        },
    ],

    UI.Facets                         : [{
        $Type : 'UI.ReferenceFacet',
        Label : 'FilterConstant UI',
        ID    : 'FilterConstantForUI',
        Target: '@UI.FieldGroup#FilterConstantForUI',
    }, ],
    UI.FieldGroup #FilterConstantForUI: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Value: Type,
                Label: 'Type',
            },
            {
                $Type: 'UI.DataField',
                Value: ConstantVar,
            },
            {
                $Type: 'UI.DataField',
                Value: SeqNum,
            },
            {
                $Type: 'UI.DataField',
                Value: Category,
                Label: 'Category',
            },
            {
                $Type: 'UI.DataField',
                Value: Value,
                Label: 'Value',
            },
        ]
    },
    UI.HeaderInfo                     : {
        Title         : {
            $Type: 'UI.DataField',
            Value: Category,
        },
        TypeName      : '',
        TypeNamePlural: '',
    },


);


annotate service.NonVCMStepSeqForUI with {
  TriggerDoc @Common: {
        FieldControl: #Mandatory,
    }
};
annotate service.NonVCMStepSeqForUI with {
  FP_Matnr @Common: {
        FieldControl: #Mandatory,
    }
};
annotate service.NonVCMStepSeqForUI with {
  SourcePlant @Common: {
        FieldControl: #Mandatory,
    }
};
annotate service.NonVCMStepSeqForUI with {
  DocType @Common: {
        FieldControl: #Mandatory,
    }
};
annotate service.NonVCMStepSeqForUI with {
  Variable @Common: {
        FieldControl: #Mandatory,
    }
};
annotate service.NonVCMStepSeqForUI with {
  Vendor @Common: {
        FieldControl: #Mandatory,
    }
};
annotate service.NonVCMStepSeqForUI with {
  StepSeq @Common: {
        FieldControl: #Mandatory,
    }
};
annotate service.NonVCMStepSeqForUI with {
  ScenarioType @(
    Common: {
            FieldControl: #Mandatory,
        },
    Common.ValueList : {
        $Type : 'Common.ValueListType',
        CollectionPath : 'ScenarioType_VH',
        Parameters : [
            {
                $Type : 'Common.ValueListParameterInOut',
                LocalDataProperty : ScenarioType,
                ValueListProperty : 'Desc',
            },
        ],
        Label : '{i18n>ScenarioType}',
    },
    Common.ValueListWithFixedValues : true,
)
};
annotate service.NonVCMStepSeqForUI with @(
    UI.LineItem #tableMacro            : [
        {
            $Type: 'UI.DataField',
            Value: TriggerDoc,
        },
        {
            $Type: 'UI.DataField',
            Value: SourcePlant,
        },
        {
            $Type: 'UI.DataField',
            Value: DocType,
        },
        {
            $Type: 'UI.DataField',
            Value: Variable,
        },
        {
            $Type: 'UI.DataField',
            Value: Vendor,
        },
        {
            $Type: 'UI.DataField',
            Value: StepSeq,
        },
        {
            $Type: 'UI.DataField',
            Value: Transaction,
            Label: 'Transaction',
        },
        {
            $Type: 'UI.DataField',
            Value: TransactionDesc,
            Label: 'TransactionDesc',
        },
        {
            $Type: 'UI.DataField',
            Value: Plant,
            Label: 'Plant',
        },
        {
            $Type: 'UI.DataField',
            Value: FP_Matnr,
            Label: 'FP_Matnr',
        },
        {
            $Type: 'UI.DataField',
            Value: Aph_Matnr,
            Label: 'Aph_Matnr',
        },
        {
            $Type: 'UI.DataField',
            Value: Retain_Matnr,
            Label: 'Retain_Matnr',
        },
        {
            $Type: 'UI.DataField',
            Value: Aph_Frozen,
            Label: 'Aph_Frozen',
        },
        {
            $Type: 'UI.DataField',
            Value: MovType,
            Label: 'MovType',
        },
        {
            $Type: 'UI.DataField',
            Value: GM_Code,
            Label: 'GM_Code',
        },
        {
            $Type: 'UI.DataField',
            Value: PO_DocType,
            Label: 'PO_DocType',
        },
        {
            $Type: 'UI.DataField',
            Value: POrg,
            Label: 'POrg',
        },
        {
            $Type: 'UI.DataField',
            Value: PGrp,
            Label: 'PGrp',
        },
        {
            $Type: 'UI.DataField',
            Value: CompCode,
            Label: 'CompCode',
        },
        {
            $Type: 'UI.DataField',
            Value: Supplier,
            Label: 'Supplier',
        },
        {
            $Type: 'UI.DataField',
            Value: GoodsSupplier,
            Label: 'GoodsSupplier',
        },
        {
            $Type: 'UI.DataField',
            Value: AccountCat,
            Label: 'AccountCat',
        },
        {
            $Type: 'UI.DataField',
            Value: ItemCat,
            Label: 'ItemCat',
        },
        {
            $Type: 'UI.DataField',
            Value: TCode,
            Label: 'TCode',
        },
        {
            $Type: 'UI.DataField',
            Value: Status,
            Label: 'Status',
        },
        {
            $Type: 'UI.DataField',
            Value: VFrom,
            Label: 'VFrom',
        },
        {
            $Type: 'UI.DataField',
            Value: VTo,
            Label: 'VTo',
        },
    ],
    UI.Facets                          : [{
        $Type : 'UI.ReferenceFacet',
        Label : 'Non Vcm Step Sequence UI',
        ID    : 'NonVcmStepSequenceUI',
        Target: '@UI.FieldGroup#NonVcmStepSequenceUI',
    }, ],
    UI.FieldGroup #NonVcmStepSequenceUI: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Value: TriggerDoc,
            },
            {
                $Type: 'UI.DataField',
                Value: SourcePlant,
            },
            {
                $Type: 'UI.DataField',
                Value: DocType,
            },
            {
                $Type: 'UI.DataField',
                Value: Variable,
            },
            {
                $Type: 'UI.DataField',
                Value: Vendor,
            },
            {
                $Type: 'UI.DataField',
                Value: StepSeq,
            },
            {
                $Type: 'UI.DataField',
                Value: Transaction,
                Label: 'Transaction',
            },
            {
                $Type: 'UI.DataField',
                Value: TransactionDesc,
                Label: 'TransactionDesc',
            },
            {
                $Type: 'UI.DataField',
                Value: Plant,
                Label: 'Plant',
            },
            {
                $Type: 'UI.DataField',
                Value: FP_Matnr,
                Label: 'FP_Matnr',
            },
            {
                $Type: 'UI.DataField',
                Value: Aph_Matnr,
                Label: 'Aph_Matnr',
            },
            {
                $Type: 'UI.DataField',
                Value: Retain_Matnr,
                Label: 'Retain_Matnr',
            },
            {
                $Type: 'UI.DataField',
                Value: Aph_Frozen,
                Label: 'Aph_Frozen',
            },
            {
                $Type: 'UI.DataField',
                Value: MovType,
                Label: 'MovType',
            },
            {
                $Type: 'UI.DataField',
                Value: GM_Code,
                Label: 'GM_Code',
            },
            {
                $Type: 'UI.DataField',
                Value: PO_DocType,
                Label: 'PO_DocType',
            },
            {
                $Type: 'UI.DataField',
                Value: POrg,
                Label: 'POrg',
            },
            {
                $Type: 'UI.DataField',
                Value: PGrp,
                Label: 'PGrp',
            },
            {
                $Type: 'UI.DataField',
                Value: CompCode,
                Label: 'CompCode',
            },
            {
                $Type: 'UI.DataField',
                Value: Supplier,
                Label: 'Supplier',
            },
            {
                $Type: 'UI.DataField',
                Value: GoodsSupplier,
                Label: 'GoodsSupplier',
            },
            {
                $Type: 'UI.DataField',
                Value: AccountCat,
                Label: 'AccountCat',
            },
            {
                $Type: 'UI.DataField',
                Value: ItemCat,
                Label: 'ItemCat',
            },
            {
                $Type: 'UI.DataField',
                Value: TCode,
                Label: 'TCode',
            },
            {
                $Type: 'UI.DataField',
                Value: Status,
                Label: 'Status',
            },
            {
                $Type: 'UI.DataField',
                Value: VFrom,
                Label: 'VFrom',
            },
            {
                $Type: 'UI.DataField',
                Value: VTo,
                Label: 'VTo',
            },
            {
                $Type : 'UI.DataField',
                Value : ScenarioType,
            },
            {
                $Type : 'UI.DataField',
                Value : FPEX_MATNR,
            },
            {
                $Type : 'UI.DataField',
                Value : RBEX_MATNR,
            },
            {
                $Type : 'UI.DataField',
                Value : SpecialStockIndicator,
            },
        ],
    },
);

annotate service.EmailNotifyForUI with @(
    UI.LineItem #tableMacro      : [
        {
            $Type: 'UI.DataField',
            Value: Email,
            Label: '{i18n>Email}',
        },
        {
            $Type: 'UI.DataField',
            Value: type,
            Label: '{i18n>Type}',
        },
    ],
    UI.Facets                    : [{
        $Type : 'UI.ReferenceFacet',
        Label : 'General Details',
        ID    : 'GeneralDetails',
        Target: '@UI.FieldGroup#GeneralDetails',
    }, ],
    UI.FieldGroup #GeneralDetails: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Value: Email,
            },
            {
                $Type: 'UI.DataField',
                Value: type,
            },
        ],
    },
);

annotate service.PfcWorkFlowApproverForUI with @(
    UI.LineItem #tableMacro          : [
        {
            $Type: 'UI.DataField',
            Value: EcoRCode,
            Label: '{i18n>EcoregionCode}',
        },
        {
            $Type: 'UI.DataField',
            Value: Dl_list,
            Label: '{i18n>DlList}',
        },
        {
            $Type: 'UI.DataField',
            Value: Btp_list,
            Label: '{i18n>BtpList}',
        },
    ],
    UI.Facets                        : [{
        $Type : 'UI.ReferenceFacet',
        Label : '{i18n>GeneralDetails}',
        ID    : 'i18nGeneralDetails',
        Target: '@UI.FieldGroup#i18nGeneralDetails',
    }, ],
    UI.FieldGroup #i18nGeneralDetails: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Value: EcoRCode,
            },
            {
                $Type: 'UI.DataField',
                Value: Dl_list,
            },
            {
                $Type: 'UI.DataField',
                Value: Btp_list,
            },
        ],
    },
);

annotate service.SIdPairSequenceForUI with @(
    UI.LineItem #tableMacro          : [
        {
            $Type: 'UI.DataField',
            Value: SId,
            Label: 'SId',
        },
        {
            $Type: 'UI.DataField',
            Value: Sequence,
            Label: 'Sequence',
        },
        {
            $Type: 'UI.DataField',
            Value: Pair,
            Label: 'Pair',
        },
        {
            $Type: 'UI.DataField',
            Value: Entity,
            Label: 'Entity',
        },
        {
            $Type: 'UI.DataField',
            Value: Description,
            Label: 'Description',
        },
        {
            $Type: 'UI.DataField',
            Value: Action,
            Label: 'Action',
        },
        {
            $Type: 'UI.DataField',
            Value: ArchType,
            Label: 'ArchType',
        },
        {
            $Type: 'UI.DataField',
            Value: Steps,
            Label: 'Steps',
        },
        {
            $Type: 'UI.DataField',
            Value: System,
            Label: '{i18n>System}',
        },
        {
            $Type: 'UI.DataField',
            Value: Variation,
            Label: 'Variation',
        },
    ],
    UI.Facets                        : [{
        $Type : 'UI.ReferenceFacet',
        Label : 'General Information',
        ID    : 'GeneralInformation',
        Target: '@UI.FieldGroup#GeneralInformation',
    }, ],
    UI.FieldGroup #GeneralInformation: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Value: SId,
            },
            {
                $Type: 'UI.DataField',
                Value: Steps,
            },
            {
                $Type: 'UI.DataField',
                Value: System,
            },
            {
                $Type: 'UI.DataField',
                Value: Variation,
            },
            {
                $Type: 'UI.DataField',
                Value: Sequence,
            },
            {
                $Type: 'UI.DataField',
                Value: Pair,
            },
            {
                $Type: 'UI.DataField',
                Value: Entity,
            },
            {
                $Type: 'UI.DataField',
                Value: Description,
            },
            {
                $Type: 'UI.DataField',
                Value: ArchType,
            },
            {
                $Type: 'UI.DataField',
                Value: Action,
            },
        ],
    },
);

annotate service.PfcEcoRegionsForUI with @(
    UI.LineItem #tableMacro          : [
        {
            $Type: 'UI.DataField',
            Value: EcoRegCode,
            Label: '{i18n>Ecoregcode}',
        },
        {
            $Type: 'UI.DataField',
            Value: EcoRegName,
            Label: '{i18n>EcoregionName}',
        },
        {
            $Type: 'UI.DataField',
            Value: CountryCode,
            Label: '{i18n>Countrycode}',
        },
    ],
    UI.Facets                        : [{
        $Type : 'UI.ReferenceFacet',
        Label : 'General Information',
        ID    : 'GeneralInformation',
        Target: '@UI.FieldGroup#GeneralInformation',
    }, ],
    UI.FieldGroup #GeneralInformation: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Value: CountryCode,
            },
            {
                $Type: 'UI.DataField',
                Value: EcoRegCode,
            },
            {
                $Type: 'UI.DataField',
                Value: EcoRegName,
            },
        ],
    },
);
annotate service.GLAccountMappingUI with @(
    UI.LineItem #tableMacro : [
        {
            $Type : 'UI.DataField',
            Value : GLAccountType,
            Label : '{i18n>GlaccountType}',
        },
        {
            $Type : 'UI.DataField',
            Value : GLAccountFrom,
            Label : '{i18n>GlaccountFrom}',
        },
        {
            $Type : 'UI.DataField',
            Value : GLAccountTo,
            Label : '{i18n>GlaccountTo}',
        },
    ],
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            Label : '{i18n>GeneralInformation}',
            ID : 'i18nGeneralInformation',
            Target : '@UI.FieldGroup#i18nGeneralInformation',
        },
    ],
    UI.FieldGroup #i18nGeneralInformation : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Value : ID,
                Label : '{i18n>Id}',
            },
            {
                $Type : 'UI.DataField',
                Value : GLAccountType,
                Label : '{i18n>GlaccountType}',
            },
            {
                $Type : 'UI.DataField',
                Value : GLAccountFrom,
                Label : '{i18n>GlaccountFrom}',
            },
            {
                $Type : 'UI.DataField',
                Value : GLAccountTo,
                Label : '{i18n>GlaccountTo}',
            },
        ],
    },
);

annotate service.GLAccountMappingUI with {
    GLAccountType @Common.FieldControl : #Mandatory
};

annotate service.GLAccountMappingUI with {
    GLAccountFrom @Common.FieldControl : #Mandatory
};

annotate service.BackupProgram with {
    initialDocumentNo  @Common.FieldControl : #Mandatory;
    initialDocumentType @Common.FieldControl : #Mandatory;
    docType  @Common.FieldControl : #Mandatory;
    // JGHJ-92333
    plant @Common.FieldControl : #Mandatory;
    // JGHJ-92333

}

annotate service.UASIDDeterminationUI with {
    flowId @Common.FieldControl : #Mandatory;
    UasId @Common.FieldControl : #Mandatory;
    sequenceId @Common.FieldControl : #Mandatory;
} ;



annotate service.SIdPairSequenceForUI with {
    Action @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'action_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : Action,
                    ValueListProperty : 'Action',
                },
            ],
            Label : 'Action',
        },
        Common.ValueListWithFixedValues : true,
)};

annotate service.SIdPairSequenceForUI with {
    ArchType @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'archType_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : ArchType,
                    ValueListProperty : 'ArchType',
                },
            ],
            Label : 'ArchType',
        },
        Common.ValueListWithFixedValues : true,
)};

annotate service.SIdPairSequenceForUI with {
    Steps @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'scenarioSteps_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : Steps,
                    ValueListProperty : 'Steps',
                },
                {
                    $Type : 'Common.ValueListParameterOut',
                    ValueListProperty : 'ID',
                    LocalDataProperty : stepID,
                },
            ],
            Label : 'Steps',
        },
        Common.ValueListWithFixedValues : true,
)};

annotate service.SIdPairSequenceForUI with {
    System @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'scenario_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : System,
                    ValueListProperty : 'scenario',
                },
            ],
            Label : 'Scenario',
        },
        Common.ValueListWithFixedValues : true,
)};

annotate service.SIdPairSequenceForUI with {
    Variation @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'variation_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : Variation,
                    ValueListProperty : 'variation',
                },
            ],
            Label : 'Variation',
        },
        Common.ValueListWithFixedValues : true,
)};


annotate service.BackupProgram with @(
    UI.LineItem #tableMacro : [
        {
            $Type : 'UI.DataField',
            Value : initialDocumentNo,
        },
        {
            $Type : 'UI.DataField',
            Value : initialDocumentType,
        },
        {
            $Type : 'UI.DataField',
            Value : docType,
        },
        {
            $Type : 'UI.DataField',
            Value : plant,
        },
        {
            $Type : 'UI.DataField',
            Value : status,
        },
        {
            $Type : 'UI.DataFieldForAction',
            Action : 'zbuvcm55154Service.Process',
            Label : 'Process',
        },
    ]
);

annotate service.PfcArchTypeMapping with @(
    UI.LineItem #tableMacro      : [
        {
            $Type: 'UI.DataField',
            Value: ArchType,
            Label: 'ArchType Mapping',
        },
        {
            $Type: 'UI.DataField',
            Value: Sf_In_S4,
            Label: 'Ship From in S4',
        },
        {
            $Type: 'UI.DataField',
            Value: Sf_In_NonS4,
            Label: 'Ship From in NON S4',
        },
        {
            $Type: 'UI.DataField',
            Value: St_In_S4,
            Label: 'Ship To in S4',
        },
        {
            $Type: 'UI.DataField',
            Value: St_In_NonS4,
            Label: 'Ship To in Non S4',
        },
        {
            $Type: 'UI.DataField',
            Value: Vir_In_S4,
            Label: 'Virtual Entity in S4',
        },
        {
            $Type: 'UI.DataField',
            Value: Vir_In_NonS4,
            Label: 'Virtual Entity in Non S4',
        },
        {
            $Type: 'UI.DataField',
            Value: Vir1_In_S4,
            Label: 'Virtual Entity 1 in S4',
        },
        {
            $Type: 'UI.DataField',
            Value: Vir1_In_NonS4,
            Label: 'Virtual Entity 1 in Non S4',
        }
    ],
    UI.Facets                    : [{
        $Type : 'UI.ReferenceFacet',
        Label : 'General Details',
        ID    : 'GeneralDetails',
        Target: '@UI.FieldGroup#GeneralDetails',
    }, ],
    UI.FieldGroup #GeneralDetails: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Value: ArchType,
            },
            {
                $Type: 'UI.DataField',
                Value: Sf_In_S4,
            },
            {
                $Type: 'UI.DataField',
                Value: Sf_In_NonS4,
            },
            {
                $Type: 'UI.DataField',
                Value: St_In_S4,
            },
            {
                $Type: 'UI.DataField',
                Value: St_In_NonS4,
            },
            {
                $Type: 'UI.DataField',
                Value: Vir_In_S4,
            },
            {
                $Type: 'UI.DataField',
                Value: Vir_In_NonS4,
            },
            {
                $Type: 'UI.DataField',
                Value: Vir1_In_S4,
            },
            {
                $Type: 'UI.DataField',
                Value: Vir1_In_NonS4,
            }
        ],
    },
);


annotate service.StepDetail with @(
    UI.LineItem #tableMacro : [
        {
            $Type : 'UI.DataField',
            Value : ID,
        },
        {
            $Type : 'UI.DataField',
            Value : Step,
        },
    ]
);


annotate service.JomChargeBackGLUI with @(
    UI.LineItem #tableMacro : [
        {
            $Type : 'UI.DataField',
            Value : ServiceMaterial,
        },
        {
            $Type : 'UI.DataField',
            Value : Gl,
        },
    ],
     UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            Label : '{i18n>GeneralInformation}',
            ID : 'i18nGeneralInformation',
            Target : '@UI.FieldGroup#i18nGeneralInformation',
        },
    ],
    UI.FieldGroup #i18nGeneralInformation : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Value : ServiceMaterial,
                Label : '{i18n>ServiceMaterial}',
            },
            {
                $Type : 'UI.DataField',
                Value : Gl,
                Label : '{i18n>GL}',
            },
        ],
    },
);
annotate service.SCASenarioStepsUI with @(
    UI.LineItem #tableMacro : [
        {
                $Type : 'UI.DataField',
                Value : scenarioID,
                Label : '{i18n>ScenarioId}',
            },
            {
                $Type : 'UI.DataField',
                Value : process,
                Label : '{i18n>Process}',
            },
            {
                $Type : 'UI.DataField',
                Value : sequence,
                Label : '{i18n>Sequence}',
            },
            {
                $Type : 'UI.DataField',
                Value : variation,
                Label : '{i18n>Variation}',
            },
            {
                $Type : 'UI.DataField',
                Value : step,
                Label : '{i18n>Step}',
            },
            {
                $Type : 'UI.DataField',
                Value : stepID,
                Label : '{i18n>StepId}',
            },
            {
                $Type : 'UI.DataField',
                Value : action,
                Label : '{i18n>Action}',
            },
    ],
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            Label : '{i18n>GeneralInformation}',
            ID : 'i18nGeneralInformation',
            Target : '@UI.FieldGroup#i18nGeneralInformation',
        },
    ],
    UI.FieldGroup #i18nGeneralInformation : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Value : scenarioID,
                Label : '{i18n>ScenarioId}',
            },
            {
                $Type : 'UI.DataField',
                Value : process,
                Label : '{i18n>Process}',
            },
            {
                $Type : 'UI.DataField',
                Value : sequence,
                Label : '{i18n>Sequence}',
            },
            {
                $Type : 'UI.DataField',
                Value : variation,
                Label : '{i18n>Variation}',
            },
            {
                $Type : 'UI.DataField',
                Value : step,
                Label : '{i18n>Step}',
            },
            {
                $Type : 'UI.DataField',
                Value : stepID,
                Label : '{i18n>StepId}',
            },
            {
                $Type : 'UI.DataField',
                Value : action,
                Label : '{i18n>Action}',
            },
        ],
    },
);

annotate service.SCASenarioStepsUI with {
    scenarioID @Common.FieldControl : #Mandatory
};

annotate service.SCASenarioStepsUI with {
    process @Common.FieldControl : #Mandatory
};

annotate service.SCASenarioStepsUI with {
    sequence @Common.FieldControl : #Mandatory
};

annotate service.SCASenarioStepsUI with {
    variation @Common.FieldControl : #Mandatory
};

annotate service.SCASenarioStepsUI with {
    step @Common.FieldControl : #Mandatory
};

annotate service.SCASenarioStepsUI with {
    stepID @Common.FieldControl : #Mandatory
};

annotate service.SCASenarioStepsUI with {
    action @Common.FieldControl : #Mandatory
};

annotate service.BackupProgram with {
    initialDocumentType @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'InitialDocumentType_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : initialDocumentType,
                    ValueListProperty : 'type',
                },
            ],
            Label : 'Initial Document Type',
        },
        Common.ValueListWithFixedValues : true,
)};

annotate service.BackupProgram with {
    docType @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'DocumentType_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : docType,
                    ValueListProperty : 'type',
                },
            ],
            Label : '{i18n>docType}',
        },
        Common.ValueListWithFixedValues : true,
)};

annotate service.UASIDDeterminationUI with @(
    UI.LineItem #tableMacro : [
        {
            $Type : 'UI.DataField',
            Value : UasId,
            Label : 'UasId',
        },
        {
            $Type : 'UI.DataField',
            Value : flowId,
            Label : 'flowId',
        },
        {
            $Type : 'UI.DataField',
            Value : description,
            Label : 'description',
        },
        {
            $Type : 'UI.DataField',
            Value : sequenceId,
            Label : 'sequenceId',
        },
        {
            $Type : 'UI.DataField',
            Value : createdAt,
        },
        {
            $Type : 'UI.DataField',
            Value : createdBy,
        },
        {
            $Type : 'UI.DataField',
            Value : modifiedAt,
        },
        {
            $Type : 'UI.DataField',
            Value : modifiedBy,
        },
    ],
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            Label : '{i18n>GeneralInformation}',
            ID : 'i18nGeneralInformation',
            Target : '@UI.FieldGroup#i18nGeneralInformation',
        },
    ],
    UI.FieldGroup #i18nGeneralInformation : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Value : flowId,
            },
            {
                $Type : 'UI.DataField',
                Value : UasId,
            },
            {
                $Type : 'UI.DataField',
                Value : sequenceId,
            },
            {
                $Type : 'UI.DataField',
                Value : description,
            },
            {
                $Type : 'UI.DataField',
                Value : createdAt,
            },
            {
                $Type : 'UI.DataField',
                Value : createdBy,
            },
            {
                $Type : 'UI.DataField',
                Value : modifiedAt,
            },
            {
                $Type : 'UI.DataField',
                Value : modifiedBy,
            },
        ],
    },
);

