sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.jnj.zbuvcm55154constantui.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);