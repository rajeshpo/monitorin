sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"com/jnj/zbuvcm55154constantui/test/integration/pages/NonVCMStepSeqMain"
], function (JourneyRunner, NonVCMStepSeqMain) {
    'use strict';

    var runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('com/jnj/zbuvcm55154constantui') + '/test/flp.html#app-preview',
        pages: {
			onTheNonVCMStepSeqMain: NonVCMStepSeqMain
        },
        async: true
    });

    return runner;
});

