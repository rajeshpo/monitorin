sap.ui.define(['sap/ui/core/mvc/ControllerExtension', "../util/UIConstants",], function (ControllerExtension, UIConstants) {
	'use strict';

	return ControllerExtension.extend('com.jnj.zbuvcm55154constantui.ext.controller.ObjectPageUserRole', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf com.jnj.zbuvcm55154constantui.ext.controller.ObjectPageUserRole
			 */
			onInit: function () {
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				var oModel = this.base.getExtensionAPI().getModel();
			},

			// Defect JGHJ-103176
			onAfterRendering: function () {
				// Fetch user roles
				this._getUserRoles();
			},
		},

		// Defect JGHJ-103176
		_getUserRoles: async function () {
			try {
				const odataModel = this.getView().getModel();
				const oBinding = odataModel.bindContext("/userInfo(...)");
				await oBinding.invoke();
				const response = oBinding.getBoundContext().getObject();
				const aRoles = Object.keys(JSON.parse(response.roles || "{}"));
				this._handleUserRoles(aRoles);
			} catch (error) {
				console.error("Error fetching user roles:", error);
			}
		},

		// Defect JGHJ-103176
		_handleUserRoles: function (roles) {
			const bReadOnly =
				roles.includes("XS3-VCM-CONSTB-DSP") &&
				!roles.includes("XS2-VCM-CONSTB-MNT");
			if (!bReadOnly) {
				return;
			}
			this._applyRoleRestrictions(0);
		},

		// Defect JGHJ-103176
		_applyRoleRestrictions: function (iRetry) {
			const aRestrictedControlIds = [
				UIConstants.tvarcEdit,
				UIConstants.tvarcDelete,
				UIConstants.filterConstantEdit,
				UIConstants.filterConstantDelete,
				UIConstants.nonVcmStepEdit,
				UIConstants.nonVcmStepDelete,
				UIConstants.emailNotifyEdit,
				UIConstants.emailNotifyDelete,
				UIConstants.pfcWorkflowApprEdit,
				UIConstants.pfcWorkflowApprDelete,
				UIConstants.sidPairSeqEdit,
				UIConstants.sidPairSeqDelete,
				UIConstants.ecoRegionEdit,
				UIConstants.ecoRegionDelete,
				UIConstants.glAMapEdit,
				UIConstants.glAMapDelete,
				UIConstants.jomCbackEdit,
				UIConstants.jomCbackDelete,
				UIConstants.scaScenarioEdit,
				UIConstants.scaScenarioDelete,
				UIConstants.uasIdDeterminationEdit,
				UIConstants.uasIdDeterminationDelete
			];

			const aButtons = sap.ui.core.Element.registry.filter(function (oControl) {
				return oControl.isA("sap.m.Button");
			});

			let bFound = false;

			aButtons.forEach(function (oButton) {
				const sId = oButton.getId();
				if (sId.includes("StandardAction::Edit")) {
					// Disable Edit button
					oButton.setEnabled(false);

				} else if (sId.includes("StandardAction::Delete")) {
					// Hide Delete button
					oButton.setVisible(false);

				} else {
					// Hide all custom Create/Upload/Download buttons
					oButton.setVisible(false);
				}
			});
			// Retry while FE is still rendering controls
			if (!bFound && iRetry < 10) {
				setTimeout(() => {
					this._applyRoleRestrictions(iRetry + 1);
				}, 200);
			}
		},
	});
});
