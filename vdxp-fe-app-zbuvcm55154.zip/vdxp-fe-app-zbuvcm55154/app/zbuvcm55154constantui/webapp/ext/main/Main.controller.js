sap.ui.define(
    [
        'sap/fe/core/PageController',
        "sap/m/MessageToast",
        "sap/m/MessageBox",
        'sap/ui/core/Fragment',
        "sap/ui/export/Spreadsheet",
        "../util/UIConstants",
    ],
    function (PageController, MessageToast, MessageBox, Fragment, Spreadsheet, UIConstants) {
        'use strict';

        return PageController.extend('com.jnj.zbuvcm55154constantui.ext.main.Main', {
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             * @memberOf com.jnj.zbuvcm55154constantui.ext.main.Main
             */
            onInit: function () {
                PageController.prototype.onInit.apply(this, arguments); // needs to be called to properly initialize the page controller
                const that = this;
                const oRouter = this.getAppComponent().getRouter();
                oRouter.getRoute("NonVCMStepSeqMain").attachPatternMatched(async function (oEvent) {
                    if (that.getModel("ui").getProperty("/isEditable")) {
                        that.getModel("ui").setProperty("/isEditable", false);
                    }
                });
                // Defect JGHJ-103176
                oRouter.getRoute("NonVCMStepSeqMain").attachPatternMatched(this._onMainRouteMatched, this);
            },

            // Defect JGHJ-103176
            _onMainRouteMatched: async function () {
                await this._getUserRoles();
            },

            // Defect JGHJ-103176
            _getUserRoles: async function () {
                try {
                    const odataModel = this.getView().getModel();
                    const oBinding = odataModel.bindContext("/userInfo(...)");
                    await oBinding.invoke();
                    const response = oBinding.getBoundContext().getObject();
                    const aRoles = Object.keys(JSON.parse(response.roles || "{}"));
                    this._handleUserRoles(aRoles);
                } catch (error) {
                    console.error("Error fetching user roles:", error);
                }
            },

            // Defect JGHJ-103176
            _handleUserRoles: function (roles) {
                const bReadOnly =
                    roles.includes("XS3-VCM-CONSTB-DSP") &&
                    !roles.includes("XS2-VCM-CONSTB-MNT");
                if (!bReadOnly) {
                    return;
                }
                this._applyRoleRestrictions(0);
            },

            // Defect JGHJ-103176
            _applyRoleRestrictions: function (iRetry) {
                const aRestrictedControlIds = [
                    UIConstants.nonVcmCreate,
                    UIConstants.tvarcCreate,
                    UIConstants.glAMapCreate,
                    UIConstants.filterConstCreate,
                    UIConstants.emailNotifyCreate,
                    UIConstants.pfcWorkflowApprCreate,
                    UIConstants.sidPairCreate,
                    UIConstants.sidPairUpload,
                    UIConstants.sidPairDownload,
                    UIConstants.ecoRegionCreate,
                    UIConstants.backupTableCreate,
                    UIConstants.archTypeMapCreate,
                    UIConstants.stepRecordCreate,
                    UIConstants.jomCbackCreate,
                    UIConstants.scaScenarioCreate,
                    UIConstants.uasIdDeterminationCreate,
                    UIConstants.backupProgramProcess,
                    UIConstants.backupProgramDownload,
                    UIConstants.backupProgramUpload,
                    UIConstants.tvarcEdit
                ];

                const aButtons = sap.ui.core.Element.registry.filter(function (oControl) {
                    return oControl.isA("sap.m.Button");
                });

                let bFound = false;

                aButtons.forEach(function (oButton) {
                    const sId = oButton.getId();
                    if (aRestrictedControlIds.includes(sId)) {
                        bFound = true;
                        // Hide button
                        oButton.setVisible(false);
                    }
                });
                // Retry while FE is still rendering controls
                if (!bFound && iRetry < 10) {
                    setTimeout(() => {
                        this._applyRoleRestrictions(iRetry + 1);
                    }, 200);
                }
            },

            create: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/NonVCMStepSeqForUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: [
                        "ScenarioType",
                        "TriggerDoc",
                        "SourcePlant",
                        "DocType",
                        "Variable",
                        "Vendor",
                        "StepSeq",
                        "FP_Matnr",
                        // ***** DEFECT - JGHJ-75713 ***** START *****
                        "FPEX_MATNR",
                        // ***** DEFECT - JGHJ-75713 ***** END *****,
                        // ***** DEFECT - JGHJ-76814 ***** START *****,
                        "RBEX_MATNR",
                        "SpecialStockIndicator",
                        // ***** DEFECT - JGHJ-76814 ***** END *****,
                        "Transaction",
                        "TransactionDesc",
                        "Plant",
                        "Aph_Matnr",
                        "Retain_Matnr",
                        "Aph_Frozen",
                        "MovType",
                        "GM_Code",
                        "PO_DocType",
                        "POrg",
                        "PGrp",
                        "CompCode",
                        "Supplier",
                        "GoodsSupplier",
                        "AccountCat",
                        "ItemCat",
                        "TCode",
                        "Status",
                        "VFrom",
                        "VTo"
                    ]

                });
            },
            createButtonTVARVC: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/TAVARCFORUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["VarName", "SeqNo", "High", "Low"]
                });
            },
            createButtonFilterConstant: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/FilterConstantForUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["ConstantVar", "SeqNum", "Type", "Category", "Value"]

                });
            },
            createButtonVCMEmailNotify: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/EmailNotifyForUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["type", "Email"]

                });
            },
            createButtonVCMPfcWorkFlowApprover: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/PfcWorkFlowApproverForUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["Dl_list", "Btp_list"]

                });
            },
            createButtonVCMPFCSIdPairSequence: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/SIdPairSequenceForUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["SId", "Pair", "ArchType", "Variation",
                        "Sequence", "Description", "System", 'Steps', 'Entity', 'Action', 'ArchType', 'stepID']
                });
            },
            createButtonVCMPfcEcoRegions: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/PfcEcoRegionsForUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["EcoRegCode", 'EcoRegName']
                });
            },
            refreshButtonVCMBackupPrg: function() {
                this.getAppComponent().getModel().refresh();
            },
            createButtonGLAMAP: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/GLAccountMappingUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["GLAccountType", "GLAccountFrom", "GLAccountTo"]
                });
            },
            pressbackuptablecreate: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/BackupProgram");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["initialDocumentNo", "initialDocumentType", "docType", "plant"]
                });
            },
            archtypemappingtablecreate: function (){
                const listBinding = this.getAppComponent().getModel().bindList("/PfcArchTypeMapping");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["ArchType", "Sf_In_S4", "Sf_In_NonS4", "St_In_S4", "St_In_NonS4","Vir_In_S4","Vir_In_NonS4","Vir1_In_S4","Vir1_In_NonS4"]
                });
            },
            steprecordcreate: function (){
                const listBinding = this.getAppComponent().getModel().bindList("/StepDetail");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["ID", "Step"]
                });
            },
            jomchargebacktablecreate: function(){
                 const listBinding = this.getAppComponent().getModel().bindList("/JomChargeBackGLUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["ServiceMaterial", "Gl"]
                });
            },
            SCASenarioStepstablecreate: function () {
                const listBinding = this.getAppComponent().getModel().bindList("/SCASenarioStepsUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["scenarioID", "process", "sequence", "variation", "step", "stepID", "action"]
                });
            },
            UASIDDeterminationtablecreate:function(){
                const listBinding = this.getAppComponent().getModel().bindList("/UASIDDeterminationUI");

                console.log(listBinding)
                this.editFlow.createDocument(listBinding, {
                    creationMode: "CreationDialog",
                    creationDialogFields: ["flowId", "UasId", "sequenceId", "description"]
                });
            },
            uploadButtonVCMPFCSIdPairSequence: function () {
                let oView = this.getView();
                let oDataModel = oView.getModel();
                let i18nModel = oView.getModel('i18n').getResourceBundle();
                if (!this._pPopover) {
                    this._pPopover = Fragment.load({
                        id: oView.getId(),
                        name: "com.jnj.zbuvcm55154constantui.ext.main.uploader",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }
                this._pPopover.then(function (oPopover) {
                    oPopover.open();
                });
            },
            uploadButtonVCMBackupPrg: function () {
                let oView = this.getView();
                this._uploadType = "BACKUP";
                if (!this._pPopover) {
                    this._pPopover = Fragment.load({
                        id: oView.getId(),
                        name: "com.jnj.zbuvcm55154constantui.ext.main.uploader",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }
                this._pPopover.then(function (oPopover) {
                    oPopover.open();
                });
            },
            downloadButtonVCMPFCSIdPairSequence: function (call="",data=[]) {
                let i18nModel = this.getView().getModel('i18n').getResourceBundle();
                // Define column structure manually
                let aCols,templateData;
                if(call==="error"){
                 aCols = [
                    { label: i18nModel.getText("SId"), property: "SId", type: String },
                    { label: i18nModel.getText("Pair"), property: "Pair", type: String },
                    { label: i18nModel.getText("Description"), property: "Description", type: String },
                    { label: i18nModel.getText("System"), property: "System", type: String },
                    { label: i18nModel.getText("ArchType"), property: 'ArchType', type: String },
                    { label: i18nModel.getText("Variation"), property: 'Variation', type: String },
                    { label: i18nModel.getText("Sequence"), property: 'Sequence', type: String },
                    { label: i18nModel.getText("Steps"), property: 'Steps', type: String },
                    { label: i18nModel.getText("Entity"), property: 'Entity', type: String },
                    { label: i18nModel.getText("Action"), property: 'Action', type: String },
                    { label: i18nModel.getText("Error"), property: 'Error', type: String }
                ];
                templateData=data;
            }else{
                aCols = [
                    { label: i18nModel.getText("SId"), property: "SId", type: String },
                    { label: i18nModel.getText("Pair"), property: "Pair", type: String },
                    { label: i18nModel.getText("Description"), property: "Description", type: String },
                    { label: i18nModel.getText("System"), property: "System", type: String },
                    { label: i18nModel.getText("ArchType"), property: 'ArchType', type: String },
                    { label: i18nModel.getText("Variation"), property: 'Variation', type: String },
                    { label: i18nModel.getText("Sequence"), property: 'Sequence', type: String },
                    { label: i18nModel.getText("Steps"), property: 'Steps', type: String },
                    { label: i18nModel.getText("Entity"), property: 'Entity', type: String },
                    { label: i18nModel.getText("Action"), property: 'Action', type: String }
                ];

                templateData = [{
                    SId: "",
                    Pair: "",
                    Description: "",
                    System: "",
                    ArchType: "",
                    Variation: "",
                    Sequence: "",
                    Steps: "",
                    Entity: "",
                    Action: ""
                }]

            }

                 

                const oSpreadsheet = new Spreadsheet({
                    workbook: {
                        columns: aCols
                    },
                    dataSource: templateData,
                    fileName: `${call==='error'?'Scenario Steps Sequence Error Table':'Scenario Steps Sequence Template'}`
                });
                oSpreadsheet.build().then(() => {
                    MessageToast.show("Template is Downloading");
                })
                    .catch((err) => {
                        MessageBox.error("Error while generating Excel template");
                    });
            },
           downloadButtonVCMBackupPrg: function (call="",data=[]) {
                let i18nModel = this.getView().getModel('i18n').getResourceBundle();
                // Define column structure manually
                let aCols,templateData;
                if(call==="error"){
                 aCols = [
                    { label: i18nModel.getText("initialDocumentNo"), property: "initialDocumentNo", type: String },
                    { label: i18nModel.getText("initialDocumentType"), property: "initialDocumentType", type: String },
                    { label: i18nModel.getText("docType"), property: "docType", type: String },
                    { label: i18nModel.getText("plant"), property: "plant", type: String },
                    { label: i18nModel.getText("Error"), property: 'Error', type: String }
                ];
                templateData=data;
            }else{
                aCols = [
                    { label: i18nModel.getText("initialDocumentNo"), property: "initialDocumentNo", type: String },
                    { label: i18nModel.getText("initialDocumentType"), property: "initialDocumentType", type: String },
                    { label: i18nModel.getText("docType"), property: "docType", type: String },
                    { label: i18nModel.getText("plant"), property: "plant", type: String },
                ];

                templateData = [{
                    initialDocumentNo: "",
                    initialDocumentType: "",
                    docType: "",
                    plant: ""
                }]

            }

                 

                const oSpreadsheet = new Spreadsheet({
                    workbook: {
                        columns: aCols
                    },
                    dataSource: templateData,
                    fileName: `${call==='error'?'Backup Program Error Table':'Backup Program Template'}`
                });
                oSpreadsheet.build().then(() => {
                    MessageToast.show("Template is Downloading");
                })
                    .catch((err) => {
                        MessageBox.error("Error while generating Excel template");
                    });
            },
            onCloseDialog: function () {
                let oFileUploader = this._getFileUploader();
                oFileUploader.clear();
                this._pPopover.then(function (oPopover) {
                    oPopover.close();
                });
            },
            /**
            *Returns the reference to the file uploader control.
            *@returns {sap.u.FileUploader} The FileUploader control.
            *@public
            */
            _getFileUploader: function () {
                return this.getView().byId("idFileUploader");
            },
                    /**
          * Execution upload button down.
          * @this ClassThis
          * @public
          */
        onPressExecuteUpload: function () {
            this.uploadFieldCheck();
        },
        /**
         * Upload File Check Validation Processing
         * @this ClassThis
         * @private
         * @return {promise} check result
         */
        uploadFieldCheck: function () {
            const that = this;
            let i18nModel = this.getView().getModel('i18n').getResourceBundle();
            this._getFileUploader().setValueStateText(i18nModel.getText('mandatoryField'));
            if (this._getFileUploader().getValue() === "" && this._getFileUploader().getValueState() === "Error") {
                MessageBox.error(i18nModel.getText('errorExist'));
            }
            if (this._getFileUploader().getValue() === "") {
                this._getFileUploader().setValueState("Error");
            } else {
                this._getFileUploader().setValueState("None");
                MessageBox.information(i18nModel.getText("confirmUpload"), {

                    actions: [i18nModel.getText('Yes'), i18nModel.getText('No')],
                    emphasizedAction: i18nModel.getText('Yes'),
                    onClose: function (sAction) {
                        if (sAction === i18nModel.getText('Yes')) {
                            that._chkFile();
                        }
                    }
                });
            }
        },
         /**
         * File Check Processing
         * @this ClassThis
         * @private
         * @return {promise} check result
         */
        _chkFile: function () {
            const that = this;
            let i18nModel = this.getView().getModel('i18n').getResourceBundle();
            return new Promise(function (resolve, reject) {
                let oFile = that._getFileUploader().oFileUpload.files[0];
                if (typeof oFile === "undefined") {
                    const sErrorMsg = i18nModel.getText("fileNotExist");
                    MessageBox.error(sErrorMsg);
                    return reject();
                }
                let nSize = oFile.size;
                if (nSize > 10485760) {
                    MessageBox.error(i18nModel.getText("fileSizeLimit"));
                } else {
                    that.onUpload();
                }
            })
        },

        _checkDBDuplicates: async function (aRecordsErrors, oDataModel,type) {

                    let oModelBindingContext = oDataModel.bindContext("/getDuplicateData(...)");
                    oModelBindingContext.setParameter("type", type);
                    await oModelBindingContext.invoke()

                    const dbRecords = oModelBindingContext.getBoundContext().getObject().value;

                    /* ---- FAST LOOKUP (O(1)) ---- */
                    const existingDocs = new Set(
                        dbRecords.map(r => r.initialDocumentNo)
                    );

                    const appendError = (record, msg) => {
                        record.Error += (record.Error ? ' | ' : '') + msg;
                    };

                    aRecordsErrors.forEach(record => {
                        if (existingDocs.has(record.initialDocumentNo)) {
                            appendError(
                                record,
                                `${record.initialDocumentNo} already exists`
                            );
                        }
                    });
                },

        /**
         * File upload
         * @this ClassThis
         * @private
         * @return {promise} A processing result object
         */
            onUpload: function () {
                let oFileUploader = this._getFileUploader();
                let i18nModel = this.getView().getModel('i18n').getResourceBundle();
                let oDataModelServiceUrl = this.getView().getModel().getServiceUrl().replace(/\/$/, '') + '/uploadExcel/excel';
                const oModel = this.getView().getModel();
                const sToken = oModel.mHeaders["X-CSRF-Token"];
                oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
                    name: 'X-CSRF-Token',
                    value: sToken
                }));
                oFileUploader.setProperty('uploadUrl', oDataModelServiceUrl);
                oFileUploader
                    .checkFileReadable()
                    .then(function () {
                        oFileUploader.upload();
                        sap.ui.core.BusyIndicator.show();
                    }, function (error) {
                        MessageToast.show(i18nModel.getText("fileNotExist"));
                    }).then(function () {
                        oFileUploader.clear();
                        sap.ui.core.BusyIndicator.hide();
                    });
            },
            handleUploadComplete: async function () {
                try{
                    let oModel = this.getView().getModel();
                    const that = this;
                    let oContextBinding = oModel.bindContext("/uploadCompletedExcel(...)");
                    let i18nModel = this.getView().getModel('i18n').getResourceBundle();
                    that.onCloseDialog();

                    await oContextBinding.invoke();
                    let excelData = oContextBinding.getBoundContext().getObject().value;

                    if (this._uploadType === "BACKUP") {
                    let updatedArray = [];
                    excelData.forEach((element) => {
                        if (element.initialDocumentNo !== '' && element.initialDocumentType !== '' && element.docType !== '' && element.plant !== '' ) {
                            updatedArray.push(element);
                        }
                    });
                    if ((updatedArray?.length || excelData?.length) && (excelData?.length !== updatedArray?.length)) {
                        MessageBox.error(i18nModel.getText("mandatoryFieldEmpty"));
                        return;
                    }

                    const aSequenceRecords = await that._formatExcelDataBackupPrg(excelData);
                    that.insertRecords(aSequenceRecords,"BACKUP");

                    }else{
                    
                    let updatedArray = [];
                    excelData.forEach((element) => {
                        if (element.SId !== '' && element.Sequence !== '' && element.System !== '' && element.Variation !== '' && element.Steps !== '' && element.Entity !== '') {
                            updatedArray.push(element);
                        }
                    });
                    if ((updatedArray?.length || excelData?.length) && (excelData?.length !== updatedArray?.length)) {
                        MessageBox.error(i18nModel.getText("mandatoryFieldEmpty"));
                        return;
                    }
                    // const validValues = await that._fetchValidValues();
                    const aSequenceRecords = await that._formatExcelData(excelData);
                    that.insertRecords(aSequenceRecords);
                }
                }catch(error){
                    MessageBox.error("Error occured while uploading excel!");
                    return
                }
            },

            _onFileError: function (ex) {
                console.error("Error reading file:", ex);
                MessageToast.show("Error reading file.");
            },

            _formatExcelData: async function (excelData) {
                let validRecords = [];

                const scenarioMap = {
                    PUSH: 'Push',
                    PULL: 'Pull',
                    AT: 'AT'
                };


                excelData.forEach(record => {
                    const rawScenario = record.Scenario?.trim().toUpperCase();
                    const systemValue = scenarioMap[rawScenario]
                    || rawScenario?.charAt(0) + rawScenario?.slice(1).toLowerCase();

                    validRecords.push({
                        SId: record.Scenario_ID?.trim() || null,
                        Pair: record.Pair?.trim() || " ",
                        Description: record.Description?.trim() || null,
                        System: systemValue || null,
                        ArchType: record.Arch_Type?.trim() || " ",
                        Variation: record.Variation?.trim() || null,
                        Sequence: record.Sequence,
                        Steps: record.Steps?.trim() || null,
                        Entity: record.Entity?.trim() || null,
                        Action: record.Action?.trim() || null
                    });
                });

                return { ScenarioSteps: validRecords };
        },
        _formatExcelDataBackupPrg: async function (excelData) {
                let validRecords = [];
                let i18nModel = this.getView().getModel('i18n').getResourceBundle();
                

            
                excelData.forEach(record => {
                    validRecords.push({
                        initialDocumentNo: record[i18nModel.getText("initialDocumentNo")] ? record[i18nModel.getText("initialDocumentNo")].trim() : null,
                        initialDocumentType: record[i18nModel.getText("initialDocumentType")] ? record[i18nModel.getText("initialDocumentType")].trim() : null,
                        docType: record[i18nModel.getText("docType")] ? record[i18nModel.getText("docType")].trim() : null,
                        plant: record[i18nModel.getText("plant")] ? record[i18nModel.getText("plant")].trim() : null,
                        status: "New",
                    });
                });

                return { BackupProgramData: validRecords };
        },
        insertRecords: async function (Payload,type="") {
            const oDataModel = this.getView().getModel();
            let data = null
            if(type==="BACKUP"){
            data = await this._validateRecordsBackUpProgram(Payload.BackupProgramData,oDataModel);
            }else{
            data = await this._validateRecords(Payload.ScenarioSteps);
            }
            let invalidRecords = data[0]?.aRecordsErrors;
            let validRecords = data[0]?.aRecords;
            let message = '';

            if (validRecords?.length === 0) {
                message += `No valid records to insert.`;
            }

            const hasErrors = invalidRecords.some(record =>
                record.Error && record.Error.trim() !== ""
            );

            if (hasErrors) {
                MessageBox.error("Errors recorded in the records uploaded , please check the downloaded file.");
                
                if(type==="BACKUP"){
                    this.downloadButtonVCMBackupPrg("error",invalidRecords);
                }else{
                this.downloadButtonVCMPFCSIdPairSequence("error",invalidRecords);
                }

                return Promise.reject("Check the error messages.");
            }
            this._InvalidRecords = undefined;
            this._validationErrorRecord = undefined;
            if(type==="BACKUP"){
            await this._createRecordsBackupPrg(oDataModel, validRecords);
            }else{
            await this._createRecords(oDataModel, validRecords);
            }

        },
        _validateRecords: async function (aRecords) {
                let aRecordsErrors = aRecords.map(r => ({ ...r, Error: "" }));
                const oModel = this.getView().getModel();
                const oContextBinding = oModel.bindContext("/mandatoryDataforUploadCheck(...)");
                await oContextBinding.invoke();

                const mandatoryData = oContextBinding.getBoundContext().getObject();

                const validSteps = mandatoryData.scenarioConstValue || [];
                const validStepsDisplay = validSteps.map(s =>
                    typeof s === 'string' ? s : s.Steps
                );
                const validStepsMap = validSteps.reduce((map, step) => {
                // scenarioConstValue is string[] → no ID
                    // If later replaced by object list, this still works
                    if (typeof step === "string") {
                        map[step.toLowerCase().trim()] = step; // fallback ID = value itself
                    } else {
                        map[step.Steps.toLowerCase().trim()] = step.ID;
                    }
                    return map;
                }, {});
                let validArchTypes = (mandatoryData.archtypeConstValue || []).map(type => type.toUpperCase().trim());
                const validAction = ["L", "A", "M", "I", "T"]
                const validSystem = ["PUSH","PULL","AT"]

                // 🔹 Group records by SId
                const recordsBySId = {};
                aRecordsErrors.forEach(r => {
                    r.Error = ""; // initialize per record
                    recordsBySId[r.SId.trim()] = recordsBySId[r.SId.trim()] || [];
                    recordsBySId[r.SId.trim()].push(r);
                });

                /* =========================================================
                   1️⃣ PER-RECORD VALIDATION (MANDATORY + VALUE CHECKS)
                ========================================================= */
                aRecordsErrors.forEach(record => {

                    const appendError = (msg) => {
                        record.Error += (record.Error ? ' | ' : '') + msg;
                    };

                    // Mandatory fields
                    const mandatoryFields = [
                        'SId',
                        'System',
                        'Variation',
                        'Sequence',
                        'Steps',
                        'Entity',
                        'Action'
                    ];

                    mandatoryFields.forEach(field => {
                        if (!record[field]) {
                            appendError(`${field === "System"?"Scenario":field} is mandatory.`);
                        }
                    });

                    const step = record.Steps.trim().toLowerCase();
                    const stepId = validStepsMap[step];

                    if (!stepId) {
                        appendError(
                            `Invalid column "Steps" "${record.Steps}". Allowed values: ${validStepsDisplay.join(', ')}`
                        );
                    }

                        // ArchType validation
                    if (record.ArchType && !validArchTypes.includes(record.ArchType.toUpperCase())) {
                        appendError(
                            `Invalid column "ArchType": "${record.ArchType}". Allowed values: ${validArchTypes.join(', ')}`
                        );
                    }

                     // Action validation
                    if (record.Action && !validAction.includes(String(record.Action).toUpperCase())) {
                        appendError(
                            `Invalid column "Action" : "${record.Action}". Allowed values: ${validAction.join(', ')}`
                        );
                    }

                    // System validation
                    if(record.System && !validSystem.includes(record.System.toUpperCase())){
                         appendError(
                            `Invalid column "Scenario" : "${record.System}". Allowed values: ${validSystem.join(', ')}`
                        );
                    }

                    // Variation validation
                    if(record.Variation && !(record.Variation === '1' || record.Variation === "2")){
                         appendError(
                            `Invalid column "Variation" "${record.Variation}". Allowed values:1,2}`
                        );
                    }

                    // Entity range validation (VE / SF / ST)
                    if (record.SId && record.Entity) {
                        const vpCount = (record.SId.match(/VP/g) || []).length;

                        if (vpCount > 0) {
                            const allowedVE = Array.from(
                                { length: vpCount },
                                (_, i) => `VE${i + 1}`
                            );
                            const allowedEntities = ['SF', 'ST', ...allowedVE];

                            if (!allowedEntities.includes(record.Entity.trim())) {
                                appendError(
                                    `Invalid Entity "${record.Entity}". Allowed values: ${allowedEntities.join(', ')}`
                                );
                            }
                        }
                    }
                });


               aRecords.forEach(record=>{
                    const step = record.Steps.trim().toLowerCase();
                    record.Steps = record.Steps.trim()
                    const stepId = validStepsMap[step];
                    record.stepID = stepId ? stepId.trim() : null;
               }) 

                return [{"aRecords":aRecords,"aRecordsErrors":aRecordsErrors}];
            },
            _validateRecordsBackUpProgram: async function (aRecords, oDataModel) {
                let aRecordsErrors = aRecords.map(r => ({ ...r, Error: "" }));

                /* =========================================================
                    PER-RECORD VALIDATION (MANDATORY + VALUE CHECKS)
                ========================================================= */
                aRecordsErrors.forEach(record => {

                    const appendError = (msg) => {
                        record.Error += (record.Error ? ' | ' : '') + msg;
                    };

                    // Mandatory fields
                    const mandatoryFields = [
                        'initialDocumentNo',
                        'initialDocumentType',
                        'docType',
                        'plant'
                    ];

                    const VALID_VALUES = {
                        initialDocumentType: ["Purchase Order", "Sales Order"],
                        docType: ["ZPM", "ZCL", "ZDR", "ZCR", "ZAFS", "ZAFL"]
                    };

                    mandatoryFields.forEach(field => {
                        if (!record[field]) {
                            appendError(`${field} is mandatory.`);
                        }
                    });

                    // initialDocumentType check
                    if (
                        record.initialDocumentType &&
                        !VALID_VALUES.initialDocumentType.includes(
                            record.initialDocumentType.trim()
                        )
                    ) {
                        appendError(
                            `initialDocumentType must be Purchase Order or Sales Order.`
                        );
                    }

                    // docType check
                    if (
                        record.docType &&
                        !VALID_VALUES.docType.includes(
                            record.docType.trim()
                        )
                    ) {
                        appendError(
                            `docType must be ZPM or ZCL.`
                        );
                    }



                });

                // async function _handleDBDuplicates(data, oDataModel) {

                //     let oModelBindingContext = oDataModel.bindContext("/getBackUpProgramData(...)");
                //     oModelBindingContext.setParameter("type", "Backup");
                //     await oModelBindingContext.invoke()

                //     const response = oModelBindingContext.getBoundContext().getObject();


                //     aRecordsErrors.forEach(record => {

                //         const appendError = (msg) => {
                //             record.Error += (record.Error ? ' | ' : '') + msg;
                //         };

                //         response.forEach(dbrecord => {
                //             if (dbrecord.initialDocumentNo === record.initialDocumentNo) {
                //                 appendError(
                //                     `${dbrecord.initialDocumentNo} already exists`
                //                 );
                //             }
                //         })

                //     });

                // }


                await this._checkDBDuplicates(aRecordsErrors, oDataModel,"BackupProgram")
                return [{ "aRecords": aRecords, "aRecordsErrors": aRecordsErrors }];
            },

            _checkForDuplicates: function (records, isUpdate = false) {
                const oDataModel = this.getView().getModel();

                return new Promise(async (resolve) => {
                    await oDataModel.bindList("/xref").requestContexts().then(function (aContexts) {
                        let existingRecords = aContexts.map(function (oContext) {
                            return oContext.getObject();
                        });
                        const duplicates = records.filter(newRecord =>
                            existingRecords.some(existingRecord =>
                                existingRecord.DataCategory === newRecord.DataCategory &&
                                existingRecord.HarmonizedKeyValue === newRecord.HarmonizedKeyValue &&
                                existingRecord.LegacySourceOfTruth === newRecord.LegacySourceOfTruth &&
                                existingRecord.LegacyKeyValue === newRecord.LegacyKeyValue &&
                                existingRecord.DeletionFlag === false && // Only consider non-deleted
                                (!isUpdate || existingRecord.ID !== newRecord.ID) // Avoid self-duplicate check
                            )
                        );
                        resolve(duplicates);
                    }).catch((oError) => {
                        MessageToast.show("Error checking for duplicates.");
                        reject(oError);
                    });
                });
            },

            _handleDuplicates: function (xrefRecords, duplicates) {
                if (duplicates.length > 0) {
                    const duplicateMessage = duplicates.map(record =>
                        `Category: ${record.DataCategory}, Harmonized Key: ${record.HarmonizedKeyValue}, Legacy SOT: ${record.LegacySourceOfTruth}, LegacyKeyValue: ${record.LegacyKeyValue}\n`
                    );
                    this._duplicateRecordMessage += `Records : \n\n${duplicateMessage}\n\n These records will not be inserted.\n\n`;
                }

                return xrefRecords.filter(record => !duplicates.some(duplicate =>
                    duplicate.DataCategory === record.DataCategory &&
                    duplicate.HarmonizedKeyValue === record.HarmonizedKeyValue &&
                    duplicate.LegacySourceOfTruth === record.LegacySourceOfTruth &&
                    duplicate.LegacyKeyValue === record.LegacyKeyValue
                    // &&
                    // duplicate.DeletionFlag === true
                ));
            },

            _createRecords: async function (oDataModel, recordsToInsert) {
                const that = this;
                if (recordsToInsert.length === 0) {
                    let message = "";
                    if (this._duplicateRecordMessage) {
                        message += `Existing Records :- \n\n${this._duplicateRecordMessage}\n\n`;
                    }
                    if (message !== "") {
                        MessageBox.information(message.trim());
                        // return Promise.reject("Check the error messages.");
                    }
                    this.getView().byId("com.jnj.zbuvcm55154constantui::NonVCMStepSeqMain--TableVCMPFCSIdPairSequence-content").getModel().refresh();
                    return Promise.reject("No valid records to insert.");
                }

                // Get the duplicate record if present in the excel
                const map = new Map();
                const duplicates = [];

                // Remove duplicates by converting the objects into JSON strings and using a Set
                const uniqueResultsToInsert = Array.from(new Set(recordsToInsert.map(a => JSON.stringify(a))))
                    .map(e => JSON.parse(e));

                // Loop through the data and count occurrences of each object
                recordsToInsert.forEach(obj => {
                    const key = JSON.stringify(obj); // Convert the object to a string for comparison
                    if (map.has(key)) {
                        map.set(key, map.get(key) + 1); // Increment the count if the object is already in the map
                    } else {
                        map.set(key, 1); // Otherwise, set the count to 1
                    }
                });

                // Find duplicates by filtering out objects that appear more than once
                recordsToInsert.forEach(obj => {
                    const key = JSON.stringify(obj);
                    if (map.get(key) > 1 && !duplicates.some(item => JSON.stringify(item) === key)) {
                        duplicates.push(obj);
                    }
                });


                let message = "";
                if (message !== "") {
                    MessageBox.information(message.trim());
                    // return Promise.reject("Check the error messages.");
                }

                return new Promise(async (resolve, reject) => {
                    let oModelBindingContext = oDataModel.bindContext("/createScenarioData(...)");
                    oModelBindingContext.setParameter("ScenarioSteps", uniqueResultsToInsert);
                    await oModelBindingContext.invoke().then(function () {
                        let response = oModelBindingContext.getBoundContext().getObject();
                        if (response.success) {
                            that._handleCreateSuccess(that, resolve)
                        } else {
                            that._handleCreateError(response, reject)
                        }
                    });
                });
            },
            
            _createRecordsBackupPrg: async function (oDataModel, recordsToInsert) {
                const that = this;
                if (recordsToInsert.length === 0) {
                    let message = "";
                    if (this._duplicateRecordMessage) {
                        message += `Existing Records :- \n\n${this._duplicateRecordMessage}\n\n`;
                    }
                    if (message !== "") {
                        MessageBox.information(message.trim());
                        // return Promise.reject("Check the error messages.");
                    }
                    this.getView().byId("com.jnj.zbuvcm55154constantui::NonVCMStepSeqMain--Table-content").getModel().refresh();
                    return Promise.reject("No valid records to insert.");
                }

                // Get the duplicate record if present in the excel
                const map = new Map();
                const duplicates = [];

                // Remove duplicates by converting the objects into JSON strings and using a Set
                const uniqueResultsToInsert = Array.from(new Set(recordsToInsert.map(a => JSON.stringify(a))))
                    .map(e => JSON.parse(e));

                // Loop through the data and count occurrences of each object
                recordsToInsert.forEach(obj => {
                    const key = JSON.stringify(obj); // Convert the object to a string for comparison
                    if (map.has(key)) {
                        map.set(key, map.get(key) + 1); // Increment the count if the object is already in the map
                    } else {
                        map.set(key, 1); // Otherwise, set the count to 1
                    }
                });

                // Find duplicates by filtering out objects that appear more than once
                recordsToInsert.forEach(obj => {
                    const key = JSON.stringify(obj);
                    if (map.get(key) > 1 && !duplicates.some(item => JSON.stringify(item) === key)) {
                        duplicates.push(obj);
                    }
                });


                let message = "";
                if (message !== "") {
                    MessageBox.information(message.trim());
                    // return Promise.reject("Check the error messages.");
                }

                return new Promise(async (resolve, reject) => {
                    let oModelBindingContext = oDataModel.bindContext("/createBackupProgramData(...)");
                    oModelBindingContext.setParameter("BackupProgramData", uniqueResultsToInsert);
                    await oModelBindingContext.invoke().then(function () {
                        let response = oModelBindingContext.getBoundContext().getObject();
                        if (response.success) {
                            that._handleCreateSuccess(that, resolve,"BACKUP")
                        } else {
                            that._handleCreateError(response, reject)
                        }
                    });
                });
            },

            _handleCreateSuccess: function (controller, resolve,type="") {
                let i18nModel = controller.getView().getModel('i18n').getResourceBundle();
                MessageToast.show(i18nModel.getText("recordsUploadSuccess"));
                if(type === "BACKUP"){
                     controller.getView().byId("com.jnj.zbuvcm55154constantui::NonVCMStepSeqMain--TableVCMPFCSIdPairSequence-content").getModel().refresh();
                }else{
                controller.getView().byId("com.jnj.zbuvcm55154constantui::NonVCMStepSeqMain--TableVCMPFCSIdPairSequence-content").getModel().refresh();
                }
                resolve();
            },

            _handleCreateError: function (oError, reject) {
                MessageBox.error(oError.error);
                reject(oError.error);
            }

            /**
             * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
             * (NOT before the first rendering! onInit() is used for that one!).
             * @memberOf com.jnj.zbuvcm55154constantui.ext.main.Main
             */
            //  onBeforeRendering: function() {
            //
            //  },

            /**
             * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
             * This hook is the same one that SAPUI5 controls get after being rendered.
             * @memberOf com.jnj.zbuvcm55154constantui.ext.main.Main
             */
            //  onAfterRendering: function() {
            //
            //  },

            /**
             * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
             * @memberOf com.jnj.zbuvcm55154constantui.ext.main.Main
             */
            //  onExit: function() {
            //
            //  }


        });
    }
);
