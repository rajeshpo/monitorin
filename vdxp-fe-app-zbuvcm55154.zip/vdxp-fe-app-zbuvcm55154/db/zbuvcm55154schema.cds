// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Scenario 1 Constant Tables
// Object Id       : ZBUVCM55154
// Release         : 1
// Version         : 0.01
// Description     : Application to create new Product Flows
// ----------------------------------------------------------------------------*
// Descriptions: Table and Views
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
//  28-04-2026      PJadav2       JGHJ-92487    Updated change log implementation
// ----------------------------------------------------------------------------*
namespace jnj.com.zbuvcm55154;

using {
  cuid,
  managed
} from '@sap/cds/common';

//--- DEFECT JGHJ-92622 -- START ----------
@assert.unique: {Tvarc_UQ_Keys: [
  VarName,
  SeqNo,
  High,
  Low
]}
entity Tvarc : cuid, managed {
  VarName : String(50)  @changelog @mandatory @Core.Immutable @title: '{i18n>VariableName}';
  SeqNo   : String(12)  @changelog @mandatory @Core.Immutable  @title: '{i18n>SequenceNumber}';
  High    : String(20)  @changelog  @title: '{i18n>Category}';
  Low     : String(30)  @changelog  @title: '{i18n>Value}';
}


@assert.unique: {VCMFilterConstantKeys: [
  ConstantVar,
  SeqNum
]}
entity VCMFilterConstant : cuid, managed {
  ConstantVar : String(60)  @changelog  @mandatory  @Core.Immutable  @title: '{i18n>ConstantVariable}';
  SeqNum      : String(20)  @changelog  @mandatory  @Core.Immutable  @title: '{i18n>SequenceNumber}';
  Category    : String(30)  @changelog  @title: '{i18n>Category}';
  Value       : String(15)  @changelog  @title: '{i18n>Value}';
  Type        : String(15)  @changelog  @title: '{i18n>Type}';
}


//--- DEFECT JGHJ-92622 -- END ----------

// entity AdditionalConst : cuid, managed {
//   key SO_Type     : String(50);
//   key Partner     : String(50);
//   key Matnr       : String(60);
//   key Plant       : String(50);
//       PO_Doc_Type : String(50);
//       Porg        : String(60);
//       Pgrp        : String(70);
//       ComCode     : String(20);
//       Vendor      : String(50);
// }

@assert.unique: {FP_Matnr_unique: [
  TriggerDoc,
  SourcePlant,
  DocType,
  Variable,
  Vendor,
  StepSeq,
  FP_Matnr,
  ScenarioType
]}
entity Non_VcmStepSeq_TABLE : cuid, managed {
  TriggerDoc      : String(10) @changelog   @title: 'Trigger Document';
  SourcePlant     : String(20) @changelog  @title: 'Source Plant';
  DocType         : String(10) @changelog  @title: 'Document Type';
  Variable        : String(8)  @changelog  @title: 'Variable';
  Vendor          : String(50) @changelog  @title: 'Vendor';
  StepSeq         : String(12) @changelog  @title: 'Step Sequence';
  Transaction     : String(15) @changelog  @title: 'Transaction';
  TransactionDesc : String(100) @changelog  @title: 'Transaction Description';
  Plant           : String(90) @changelog  @title: 'Plant';
  FP_Matnr        : String(80) @changelog  @title: 'FP Material';
  Aph_Matnr       : String(80) @changelog  @title: ' Aphrerisis Material';
  Retain_Matnr    : String(80) @changelog  @title: 'Retain Bag Material';
  Aph_Frozen      : String(20) @changelog  @title: 'Apherisis Frozen Material';
  MovType         : String(10) @changelog  @title: 'Movement Type';
  GM_Code         : String(20) @changelog  @title: 'Goods Movement Code';
  PO_DocType      : String(20) @changelog  @title: 'PO Document Type';
  POrg            : String(10) @changelog  @title: 'Purchase Organisation';
  PGrp            : String(12) @changelog  @title: 'Purchase Grp';
  CompCode        : String(20) @changelog  @title: 'Company Code';
  Supplier        : String(80) @changelog  @title: ' Supplier';
  GoodsSupplier   : String(50) @changelog  @title: 'Goods Supplier';
  AccountCat      : String(15) @changelog  @title: 'Account Category';
  ItemCat         : String(10) @changelog  @title: 'Item Category';
  TCode           : String(50) @changelog  @title: 'T Code';
  Status          : String(10) @changelog  @title: 'Status';
  VFrom           : Date       @changelog  @title: 'Valid From';
  VTo             : Date       @changelog  @title: ' Valid To';
  ScenarioType    : String     @changelog  @title: 'ScenarioType';

  // ***** DEFECT - JGHJ-75713 ***** START *****
  FPEX_MATNR      : String    @changelog   @title: 'FG Excep Release material';
  // ***** DEFECT - JGHJ-75713 ***** END *****


  // ***** DEFECT - JGHJ-76814 ***** START *****,
  RBEX_MATNR      : String    @changelog   @title: 'RB Excep Release material';
  SpecialStockIndicator  : String   @changelog    @title: 'Special Stock Indicator';
  // ***** DEFECT - JGHJ-76814 ***** END *****


}

@cds.persistence.exists
@assert.unique: {VCMFilterConstantKeys: [
  type
]}
entity syn_EmailNotify : cuid, managed {
      Email : String @changelog @title: '{i18n>Email}';
      type  : String @changelog @Core.Immutable @title: '{i18n>Type}';
}


/**
 * Maps eco-region codes to designated workflow approvers via distribution (DL)
 * and BTP user lists. Used to determine approval routing based on region.
 */
@cds.persistence.exists
entity syn_PfcWorkFlowApprover {
  key EcoRCode : String(8)    @changelog  @title: '{i18n>EcoregionCode}';
      Dl_list  : String(200)  @changelog  @title: '{i18n>DlList}';
      Btp_list : String(200)  @changelog  @title: '{i18n>BtpList}';
}

/**
 * Defines ordered steps for scenario ID pairs in product flow automation.
 * Captures pair ID, architecture type, system, variation (SO/PO), sequence,
 * steps, entities, and actions for driving process logic.
 */
@cds.persistence.exists
@assert.unique: {SidPair_unique: [
  SId,
  System,
  ArchType,
  Variation,
  Sequence,
  stepID
]}
entity syn_SIdPairSequence : cuid, managed {
  SId         : String(50)  @changelog  @Core.Immutable               @title      : '{i18n>SId}'        @description: 'scenario ID  is maintained in this entity';
  Pair        : String(20)  @changelog  @Core.Immutable               @title      : '{i18n>Pair}'       @description: 'scenario ID pair is maintained in this entity';
  Description : String(50)  @changelog  @title: '{i18n>Description}'  @description: 'scenario ID pair dscription is maintained in this entity';
  System      : String(50)  @changelog  @title: '{i18n>System}'       @description: 'scenario ID pair system info is maintained in this entity';
  ArchType    : String(30)  @changelog  @Core.Immutable               @title      : '{i18n>ArchType}'   @description: 'scenario ID pair archtype is maintained in this entity';
  Variation   : String(10)  @changelog  @Core.Immutable               @title      : '{i18n>Variation}'  @description: 'scenario ID pair for which Variation is maintained in this entity (1-SO and 2-PO)';
  Sequence    : Integer     @changelog  @Core.Immutable               @title      : '{i18n>Sequence}'   @description: 'scenario ID pair sequence  is maintained in this entity';
  Steps       : String(80)  @changelog  @title: '{i18n>Steps}'        @description: 'scenario ID pair step is maintained in this entity';
  Entity      : String(10)  @changelog  @title: '{i18n>Entity}'       @description: 'scenario ID pair part  is maintained in this entity';
  Action      : String(35)  @changelog  @title: '{i18n>Action}'       @description: 'scenario ID pair automation info is maintained in this entity';
  stepID      : String(10)  @readonly   @title: 'step ID'             @description: 'scenario ID pair step id is maintained in this entity';
}

/**
 * Defines UASID in product flow.
 */
@cds.persistence.exists
entity syn_UASIDDetermination : managed {
      sequenceId  : String(8)    @changelog  @title: 'Sequence ID';
      UasId       : String(60)   @changelog  @title: 'UAS ID';
  key flowId      : String(30)   @changelog  @title: 'Flow ID';
      description : String(100)  @changelog  @title: 'Description';
}


/**
 * Represents item-level details of a Shipping Request.
 * Captures material-specific information such as type, brand, quantity,
 * and batch. Acts as a child entity of ShippingRequest, holding
 * transactional line items for each request.
 */
@cds.persistence.exists
entity syn_ShippingRequestItem : cuid, managed {
  parent_shippingReqNo : String(18);
  parent_initialDocumentNo : String(10);        
  followOnDocumentNo  : String(20)         @description: 'Reference GR or follow-on document number'  @title: 'Reference Document Number';
  itemNo              : String(20)         @description: 'Item number';
  materialNumber      : String             @description: 'Material Number';
  materialType        : String             @description: 'Type/category of the material';
  materialBrand       : String             @description: 'Brand associated with the material';
  materialDescription : String             @description: 'Detailed description of the material';
  quantity            : String             @description: 'Quantity of material requested/shipped';
  uom                 : String             @description: 'Unit of Measure (e.g., EA, KG, L)';
  batchNumber         : String             @description: 'Batch number for traceability of the material';
  status              : String default 'A' @description: 'Status representing Active or Inactive';

  AF_FZ_Mat           : String(20);
  RETAINBAG_Mat       : String(20);
  AF_FRSH_Mat         : String(20);

}

/**
 * Logs approval history for materials in a Product Flow, including workflow 
 * instance ID, status, timestamp, approver, and comments. Used for tracking
 * decision-making steps in material-level workflows.
 */
@cds.persistence.exists
entity syn_PfcArchTypeMapping : managed {
  key ArchType      : String(16)  @changelog  @title: '{i18n>ArchType}'       @description: 'Product Flow Arch Type';
      Sf_In_S4      : String(10)  @changelog  @title: '{i18n>Sf_In_S4}'       @description: 'Ship From in S\4';
      Sf_In_NonS4   : String(10)  @changelog  @title: '{i18n>Sf_In_NonS4}'    @description: 'Ship From in NON S\4';
      St_In_S4      : String(10)  @changelog  @title: '{i18n>St_In_S4}'       @description: 'Ship To in S\4';
      St_In_NonS4   : String(10)  @changelog  @title: '{i18n>St_In_NonS4}'    @description: 'Ship To in NON S\4';
      Vir_In_S4     : String(10)  @changelog  @title: '{i18n>Vir_In_S4}'      @description: 'Virtual in S\4';
      Vir_In_NonS4  : String(10)  @changelog  @title: '{i18n>Vir_In_NonS4}'   @description: 'Virtual in NON S\4';
      Vir1_In_S4    : String(10)  @changelog  @title: '{i18n>Vir1_In_S4}'     @description: 'First Virtual in S\4';
      Vir1_In_NonS4 : String(10)  @changelog  @title: '{i18n>Vir1_In_NonS4}'  @description: 'Virtual in NON S\4';
}

/**
 * Defines eco-regions by country, including a unique region code and name.
 * Serves as reference data for assigning economic regions in product flows.
 */
@cds.persistence.exists
entity syn_PfcEcoRegions {

  key CountryCode : String(10)   @title: '{i18n>Countrycode}'    @description: 'Country code for which the eco-region is defined.';
      EcoRegCode  : String(50)   @changelog @title: '{i18n>Ecoregcode}'     @description: 'Unique code identifying the eco-region.';
      EcoRegName  : String(100)  @changelog @title: '{i18n>EcoregionName}'  @description: 'Name or description of the eco-region.';

}

@cds.persistence.exists
entity syn_GLAccountMapping : cuid {
  GLAccountType : String(20)  @changelog @title: '{i18n>GLAccountType}'  @description: 'Type/category of the GL account';
  GLAccountFrom : String(20)  @changelog @title: '{i18n>GLAccountFrom}'  @description: 'Starting GL account number of the range';
  GLAccountTo   : String(20)  @changelog @title: '{i18n>GLAccountTo}'    @description: 'Ending GL account number of the range';
}

/**
 * Logs approval history for materials in a Product Flow, including workflow 
 * instance ID, status, timestamp, approver, and comments. Used for tracking
 * decision-making steps in material-level workflows.
 */
 @cds.persistence.exists
entity syn_SeqStepsID : managed {
  key ID: String(10)  @title: '{i18n>ID}'    @description: 'step ID which will be used in Automation Db for backend logics.';
  Step:String  @changelog @title: '{i18n>Step}'    @description: 'Steps available of automation.';
}


entity InTimeOrNotInTime {
      CONST_VAR_NAME : String(20) @changelog;
      SEQNO          : String(5) @changelog;
  key CATEGORY       : String(5);
      VALUE          : String(20) @changelog;
}

/**
 * Keeps Mapping of Service Material with GL Account in VCM
 */
entity JomChargeBackGL : managed, cuid {
  ServiceMaterial : String(30) @changelog @title : '{i18n>ServiceMaterial}' @description : 'Details of the Service material';
  Gl              : String(60) @changelog @title : '{i18n>GL}' @description : 'Details of GL for the given material';
}


@cds.persistence.exists
@assert.unique: {NonVCA_unique: [
  scenarioID,
  process,
  sequence
]}
entity syn_NonVCAScenarioConfig: cuid, managed {
  scenarioID : String(10)  @changelog  @Core.Immutable             @title      : '{i18n>ScenarioID}'  @description: 'Unique identifier of the business scenario (e.g., S1, S2)';
  process    : String(20)  @changelog  @Core.Immutable             @title      : '{i18n>Process}'     @description: 'Process type associated with the scenario (e.g., CBACK, ASN).';
  sequence   : Integer     @changelog  @Core.Immutable             @title      : '{i18n>Sequence}'    @description: 'Execution order of the step within the scenario process flow.';
  variation  : Integer     @changelog  @title: '{i18n>Variation}'  @description: 'Defines alternative flow variations within the same scenario.';
  step       : String(40)  @changelog  @title: '{i18n>Step}'       @description: 'Business step description within the scenario workflow.';
  stepID     : String      @changelog  @title: '{i18n>StepID}'     @description: 'Technical identifier representing the workflow step.';
  action     : String(1)   @changelog  @title: '{i18n>Action}'     @description: 'Indicates the action type for the step.';
}


/**
 * Provides localized Action  for use in UIs (e.g.,  Action).
 * Used as a value help or display reference; not stored in the database.
 */
@cds.persistence.skip
entity Action {
  key Action : String(5);
}

/**
 * Provides localized Variation  for use in UIs (e.g.,  Variation).
 * Used as a value help or display reference; not stored in the database.
 */
@cds.persistence.skip
entity Variation {
  key variation : String(5);
     desc : String(10);
}

/**
 * Provides localized Variation  for use in UIs (e.g.,  Variation).
 * Used as a value help or display reference; not stored in the database.
 */
@cds.persistence.skip
entity Scenario {
  key scenario : String(5);
}


@cds.persistence.skip
entity ScenarioSteps {
  key Steps : String(100);
      ID : String(10);
}

view archTypeValueHelp as
  select distinct key ArchType from syn_PfcArchTypeMapping
  where
    ArchType is not null;

view stepsValueHelp as
  select distinct key Steps from syn_SIdPairSequence
  where
    Steps is not null;


entity BackupProgram : cuid, managed {
  key initialDocumentNo   : String(10)   @title: '{i18n>initialDocumentNo}'    @description: 'Document number of the initial triggering document';
      initialDocumentType : String(50)  @changelog @title: '{i18n>initialDocumentType}'  @description: 'Type of the initial document (e.g., Sales Order, Purchase Order)';
      docType             : String      @changelog  @title: '{i18n>docType}';
      plant               : String(10)  @changelog @title: '{i18n>plant}';
      status              : String      @changelog @title: '{i18n>status}' default 'New' @readonly;

}