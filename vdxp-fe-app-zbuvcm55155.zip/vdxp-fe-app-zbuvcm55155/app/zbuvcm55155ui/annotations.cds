using zbuvcm55155Service as service from '../../srv/zbuvcm55155service';
using from '../../db/zbuvcm55155schema';

annotate service.ShippingRequestView with @(
    Capabilities.SearchRestrictions                 : {Searchable: false},
    UI.FieldGroup #GeneratedGroup                   : {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Label: '{i18n>Shippingreqno}',
                Value: shippingReqNo,
            },
            {
                $Type: 'UI.DataField',
                Label: '{i18n>Referencedocumentno}',
                Value: referenceDocumentNo,
            },
            {
                $Type: 'UI.DataField',
                Label: '{i18n>initialDocumentNo}',
                Value: initialDocumentNo,
            },
            {
                $Type: 'UI.DataField',
                Label: '{i18n>Requesteddeliverydate}',
                Value: requestedDeliveryDate,
            },
            {
                $Type: 'UI.DataField',
                Label: '{i18n>Scenarioid}',
                Value: scenarioID,
            },
            {
                $Type: 'UI.DataField',
                Label: '{i18n>productFlowCatalogID}',
                Value: productFlowCatalogID,
            },

            {
                $Type: 'UI.DataField',
                Label: '{i18n>productFlowID}',
                Value: productFlowID,
            },
        ],
    },
    UI.FieldGroup #GeneratedGroupForDocumentOverview: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Label: '{i18n>Shippingreqno}',
                Value: shippingReqNo,
            },
            {
                $Type: 'UI.DataField',
                Label: '{i18n>initialDocumentNo}',
                Value: initialDocumentNo,
            }
        ],
    },
    UI.Facets                                       : [
        {
            $Type : 'UI.ReferenceFacet',
            Label : '{i18n>Documents}',
            ID    : 'i18nFlowDetails',
            Target: 'entity/@UI.LineItem#i18nFlowDetails1',
            @UI.Hidden,
        },

        {
            $Type : 'UI.ReferenceFacet',
            Label : 'PreRequisite Status',
            ID    : 'PreRequisiteStatus',
            Target: 'to_prereqStatus/@UI.LineItem#PreRequisiteStatus',
        },
        {
            $Type : 'UI.ReferenceFacet',
            Label : '{i18n>ProductDetails}',
            ID    : 'ProductDetails',
            Target: 'items/@UI.LineItem#ProductDetails',
        },

        {
            $Type : 'UI.ReferenceFacet',
            Label : '{i18n>Comments}',
            ID    : 'Comments',
            Target: 'comments/@UI.LineItem#Comments',
        },
        {
            $Type : 'UI.ReferenceFacet',
            Label : 'Change Events',
            ID : 'ChangeEvents',
            Target : 'changeEvents/@UI.LineItem#ChangeEvents',
        },
    ],
    UI.LineItem                                     : [
        {
            $Type: 'UI.DataField',
            Label: '{i18n>shippingReqNo}',
            Value: shippingReqNo,
        },
        {
            $Type: 'UI.DataField',
            Label: '{i18n>Referencedocumentno}',
            Value: referenceDocumentNo,
        },
        {
            $Type: 'UI.DataField',
            Label: '{i18n>initialDocumentNo}',
            Value: initialDocumentNo,
        },
        {
            $Type: 'UI.DataField',
            Value: initialDocumentType,
            Label: '{i18n>InitialDocumentType}',
        },
        {
            $Type      : 'UI.DataField',
            Label      : '{i18n>Status}',
            Value      : status,
            Criticality: statusCriticality,
        },
        {
            $Type: 'UI.DataField',
            Value: shipFromPlant,
        },
        {
            $Type: 'UI.DataField',
            Value: shipFromBusinessPartner,
        },
        {
            $Type: 'UI.DataField',
            Value: shipToPlant,
        },
        {
            $Type: 'UI.DataField',
            Value: shipToBusinessPartner,
        },
        {
            $Type      : 'UI.DataField',
            Label      : '{i18n>Priority}',
            Value      : priority,
            Criticality: Criticality,
        },
        {
            $Type: 'UI.DataField',
            Value: createdAt,
            Label: '{i18n>CreatedAt}',
        },
        {
            $Type: 'UI.DataField',
            Value: requestedDeliveryDate,

        },
        {
            $Type        : 'UI.DataFieldForAction',
            Action       : 'zbuvcm55155Service.Reprocess',
            Label        : 'Reprocess',
            ![@UI.Hidden]: {$edmJson: {$Path: '/FeatureControl/operationHidden'}}
        },
        {
            $Type: 'UI.DataField',
            Value: userName,
            Label: '{i18n>UserID}',
        },
    ],


    UI.SelectionFields                              : [
        shippingReqNo,
        status,
        shipFromPlant,
        shipFromBusinessPartner,
        shipToPlant,
        initialDocumentNo,
        referenceDocumentNo,
        shipToBusinessPartner,
    ],
    UI.Identification                               : [
        {
            $Type        : 'UI.DataFieldForAction',
            Action       : 'zbuvcm55155Service.Reprocess',
            Label        : '{i18n>Reprocess}',
            ![@UI.Hidden]: {$edmJson: {$Path: '/FeatureControl/operationHidden'}}
        },
        {
            $Type : 'UI.DataFieldForAction',
            Action: 'zbuvcm55155Service.addComment',
            Label : '{i18n>Addcomment}',
        },
    ],
    UI.HeaderInfo                                   : {
        TypeName      : '{i18n>ShippingDetail}',
        TypeNamePlural: '{i18n>ShippingDetails}',
        Title         : {
            $Type: 'UI.DataField',
            Value: initialDocumentNo,
        },
        Description   : {
            $Type: 'UI.DataField',
            Value: initialDocumentType,
        },
    },
    UI.DeleteHidden : true,
);


// annotate service.ShippingRequestView with {
//     referenceDocumentNo   @(
//         Common.Label                   : '{i18n>Shippingreqno}'

//         Common.ValueList               : {
//             SearchSupported: false,
//             $Type          : 'Common.ValueListType',
//             CollectionPath : 'ShippingRequest_VH',
//             Parameters     : [{
//                 $Type            : 'Common.ValueListParameterInOut',
//                 LocalDataProperty:  shippingReqNo,
//                 ValueListProperty: 'shippingReqNo',
//             }, ],
//             Label          : '{i18n>Shippingreqno}',
//         },
//         Common.ValueListWithFixedValues: false,
//     );
//     followOnDocumentNo    @Common.Label: '{i18n>followOnDocumentNo}';
//     masterDataStatus      @Common.Label: '{i18n>masterDataStatus}';
//     scenarioID            @Common.Label: '{i18n>scenarioID}';
//     requestedDeliveryDate @Common.Label: '{i18n>requestedDeliveryDate}';
// };

annotate service.ShippingRequestView with {

    status @(
        Common.Label                   : '{i18n>Status}',
        Common.ValueList               : {

            $Type         : 'Common.ValueListType',
            CollectionPath: 'I_ProcessingStage_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: status,
                ValueListProperty: 'Desc',
            }, ],
            Label         : '{i18n>ProcessingStage}',
        },
        Common.ValueListWithFixedValues: true,
    )
};

annotate service.ShippingRequestView with {
    shipFromPlant @(
        Common.Label                   : '{i18n>Shipfromplant}',
        Common.ValueList               : {
            SearchSupported: false,
            $Type          : 'Common.ValueListType',
            CollectionPath : 'I_P_VH',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: shipFromPlant,
                    ValueListProperty: 'Plant',
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'PlantName',
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'BusinessPartner',
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'CountryCode',
                },
            ],
            Label          : 'Ship From',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.I_BP_VH with {
    BusinessPartnerName @Common.Label: '{i18n>BusinessPartnerName}';
};

annotate service.I_BPST_VH with {
    BPCustomerName @Common.Label: '{i18n>BusinessCustomerName}';
};

annotate service.ShippingRequest_VH with {
    shippingReqNo @Common.Label: '{i18n>Shippingreqno}'
};

annotate service.ShippingRequest_VH1 with {
    initialDocumentNo @Common.Label: '{i18n>initialDocumentNo}'
};


annotate service.ShippingRequestView with {
    shipFromBusinessPartner @(
        Common.Label                   : '{i18n>Shipfrombusinesspartner}',
        Common.ValueList               : {
            SearchSupported: false,
            $Type          : 'Common.ValueListType',
            CollectionPath : 'I_BP_VH',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: shipFromBusinessPartner,
                    ValueListProperty: 'BusinessPartner',
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'BusinessPartnerName',
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'Plant',
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'CountryCode',
                },
            ],
            Label          : 'Bp(Ship From)',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.ShippingRequestView with {
    shipToPlant @(
        Common.Label                   : '{i18n>Shiptoplant}',
        Common.ValueList               : {
            SearchSupported: false,
            $Type          : 'Common.ValueListType',
            CollectionPath : 'I_P_VH',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: shipToPlant,
                    ValueListProperty: 'Plant',
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'PlantName',
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'BusinessPartner',
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'CountryCode',
                },
            ],
            Label          : 'Ship To',
        },
        Common.ValueListWithFixedValues: false,
    )
};



annotate service.ShippingRequestView with {
    initialDocumentNo @(
        Common.ValueList               : {
            SearchSupported: false,
            $Type          : 'Common.ValueListType',
            CollectionPath : 'ShippingRequest_VH1',
            Parameters     : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: initialDocumentNo,
                ValueListProperty: 'initialDocumentNo',
            }, ],
            Label          : '{i18n>initialDocumentNo}',
        },
        Common.ValueListWithFixedValues: false,
        Common.Label                   : '{i18n>initialDocumentNo}',
    )
};

annotate service.ShippingRequestView with {
    referenceDocumentNo @(
        // Common.Label                   : '{i18n>ReferenceDocumentNo}',
        Common.ValueList               : {
            SearchSupported: false,
            $Type         : 'Common.ValueListType',
            CollectionPath: 'ShippingRequest_VH2',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: referenceDocumentNo,
                ValueListProperty: 'referenceDocumentNo',
               
            }, ],
            Label:'Reference Number'
        },
        Common.ValueListWithFixedValues: false,
        Common.Label                   : '{i18n>Referencedocumentno}',
    )
};

annotate service.ShippingRequestItem with @(
    Capabilities.SearchRestrictions: {Searchable: false},
    UI.LineItem #ProductDetails    : [
        {
            $Type: 'UI.DataField',
            Value: materialNumber,
            Label: '{i18n>Materialnumber}',
        },
        {
            $Type: 'UI.DataField',
            Value: materialBrand,
            Label: '{i18n>ProfitCenter}',
        },
        {
            $Type: 'UI.DataField',
            Value: materialDescription,
            Label: '{i18n>Materialdescription}',
        },
        {
            $Type: 'UI.DataField',
            Value: materialType,
            Label: '{i18n>Materialtype}',
        },
        {
            $Type: 'UI.DataField',
            Value: quantity,
            Label: '{i18n>Quantity}',
        },
        {
            $Type: 'UI.DataField',
            Value: uom,
            Label: '{i18n>Uom}',
        },
        {
            $Type: 'UI.DataField',
            Value: followOnDocumentNo,
            Label: '{i18n>Followondocumentno}',
        },
        {
            $Type: 'UI.DataField',
            Value: batchNumber,
            Label: '{i18n>Batchnumber}',
        },
        {
            $Type : 'UI.DataField',
            Value : AF_FRSH_Mat,
            Label : 'AF_FRSH_Mat',
        },
        {
            $Type : 'UI.DataField',
            Value : AF_FZ_Mat,
            Label : 'AF_FZ_Mat',
        },
        {
            $Type : 'UI.DataField',
            Value : RETAINBAG_Mat,
            Label : 'RETAINBAG_Mat',
        },
    ]
);

annotate service.Comments with @(
    Capabilities.SearchRestrictions: {Searchable: false},
    UI.LineItem #Comments          : [
        {
            $Type: 'UI.DataField',
            Value: comments,
            Label: '{i18n>Comments1}',
        },
        {
            $Type: 'UI.DataField',
            Value: createdBy,
            Label: '{i18n>UserID}',
        },
        {
            $Type: 'UI.DataField',
            Value: createdAt,
            Label: '{i18n>CreatedAt}',
        }
    ]
);


annotate service.ShippingRequestEntityDocs with @(
    UI.LineItem #tableMacro     : [
        {
            $Type: 'UI.DataField',
            Value: documentType,
            Label: 'Document Type',
        },
        {
            $Type: 'UI.DataField',
            Value: documentNumber,
            Label: 'Document Number',
        },
        {
            $Type: 'UI.DataField',
            Value: errorStatus,
            Label: 'Error Status',
        },
        {
            $Type: 'UI.DataField',
            Value: errorResolutionDate,
            Label: 'Error Resolution Date',
        },
        {
            $Type: 'UI.DataField',
            Value: errorDescription,
            Label: 'Error Description',
        },
        {
            $Type: 'UI.DataField',
            Value: errorCreationDate,
            Label: 'Error Creation Date',
        },
        {
            $Type: 'UI.DataField',
            Value: entityType,
            Label: 'Entity Type',
        },
    ],
    UI.LineItem #Docs           : [
        {
            $Type: 'UI.DataField',
            Value: documentNumber,
            Label: 'Document Number',
        },
        {
            $Type: 'UI.DataField',
            Value: documentType,
            Label: 'Document Type',
        },
        {
            $Type: 'UI.DataField',
            Value: entityType,
            Label: 'Entity Type',
        },
        {
            $Type: 'UI.DataField',
            Value: errorDescription,
            Label: 'Error Description',
        },
        {
            $Type: 'UI.DataField',
            Value: errorStatus,
            Label: 'Error Status',
        },
        {
            $Type: 'UI.DataField',
            Value: errorResolutionDate,
            Label: 'Error Resolution Date',
        },
        {
            $Type: 'UI.DataField',
            Value: errorCreationDate,
            Label: 'Error Creation Date',
        },
    ],
    UI.LineItem #FlowDetails    : [],
    UI.LineItem #tableMacro1    : [
        {
            $Type: 'UI.DataField',
            Value: documentNumber,
            Label: 'Document Number',
        },
        {
            $Type: 'UI.DataField',
            Value: documentSequence,
            Label: 'Document Sequence',
        },
        {
            $Type: 'UI.DataField',
            Value: documentType,
            Label: 'Document Type',
        },
        {
            $Type: 'UI.DataField',
            Value: entityRank,
            Label: 'Entity Rank',
        },
        {
            $Type: 'UI.DataField',
            Value: entityType,
            Label: 'Entity Type',
        },
        {
            $Type: 'UI.DataField',
            Value: errorDescription,
            Label: 'Error Description',
        },
        {
            $Type: 'UI.DataField',
            Value: errorStatus,
            Label: 'Error Status',
        },
    ],
    UI.LineItem #tableMacro2    : [
        {
            $Type: 'UI.DataField',
            Value: documentNumber,
            Label: 'documentNumber',
        },
        {
            $Type: 'UI.DataField',
            Value: documentType,
            Label: 'documentType',
        },
        {
            $Type: 'UI.DataField',
            Value: entityType,
            Label: 'entityType',
        },
        {
            $Type: 'UI.DataField',
            Value: errorStatus,
            Label: 'errorStatus',
        },
    ],
    UI.Facets                   : [{
        $Type : 'UI.ReferenceFacet',
        Label : '{i18n>Errors}',
        ID    : 'Errors',
        Target: 'errors/@UI.LineItem#Errors',
    }, ],
    UI.LineItem #DOcs           : [
        {
            $Type: 'UI.DataField',
            Value: documentNumber,
            Label: '{i18n>Documentnumber}',
        },
        {
            $Type: 'UI.DataField',
            Value: documentType,
            Label: '{i18n>Documenttype}',
        },
        {
            $Type: 'UI.DataField',
            Value: errorStatus,
            Label: '{i18n>Errorstatus}',
        },
        {
            $Type: 'UI.DataField',
            Value: errorDescription,
            Label: '{i18n>Errordescription}',
        },
        {
            $Type: 'UI.DataField',
            Value: entityType,
            Label: '{i18n>Entitytype}',
        },
    ],
    UI.HeaderInfo               : {
        Title         : {
            $Type: 'UI.DataField',
            Value: documentNumber,
        },
        TypeName      : '',
        TypeNamePlural: '',
        Description   : {
            $Type: 'UI.DataField',
            Value: documentType,
        },
    },
    UI.LineItem #i18nFlowDetails: [
        {
            $Type: 'UI.DataField',
            Value: documentNumber,
            Label: 'documentNumber',
        },
        {
            $Type: 'UI.DataField',
            Value: documentType,
            Label: 'documentType',
        },
        {
            $Type: 'UI.DataField',
            Value: errorStatus,
            Label: 'errorStatus',
        },
        {
            $Type: 'UI.DataField',
            Value: legalEntity,
            Label: 'legalEntity',
        },
        {
            $Type: 'UI.DataField',
            Value: errorCreationDate,
            Label: 'errorCreationDate',
        },
        {
            $Type: 'UI.DataField',
            Value: errorResolutionDate,
            Label: 'errorResolutionDate',
        },
    ],
);

annotate service.items with @(UI.LineItem #ProductDetails: [
    {
        $Type: 'UI.DataField',
        Value: materialNumber,
        Label: '{i18n>Materialnumber}',
    },
    {
        $Type: 'UI.DataField',
        Value: materialBrand,
        Label: '{i18n>Materialbrand}',
    },
    {
        $Type: 'UI.DataField',
        Value: materialDescription,
        Label: '{i18n>Materialdescription}',
    },
    {
        $Type: 'UI.DataField',
        Value: materialType,
        Label: '{i18n>Materialtype}',
    },
    {
        $Type: 'UI.DataField',
        Value: quantity,
        Label: '{i18n>Quantity}',
    },
    {
        $Type: 'UI.DataField',
        Value: uom,
        Label: '{i18n>Uom}',
    },
]);

annotate service.ShippingRequestErrors with @(
    Capabilities.SearchRestrictions: {Searchable: false},
    UI.LineItem #Errors            : [
        {
            $Type: 'UI.DataField',
            Value: vcaErrorType,
            Label: '{i18n>Vcaerrortype}',
        },
        {
            $Type: 'UI.DataField',
            Value: vcaErrorStatus,
            Label: '{i18n>Vcaerrorstatus}',
        },
        {
            $Type: 'UI.DataField',
            Value: vcaErrorTimeStamp,
            Label: '{i18n>Vcaerrortimestamp}',
        },
    ],
    UI.LineItem #i18nErrors        : [
        {
            $Type      : 'UI.DataField',
            Value      : vcaErrorStatus,
            Label      : '{i18n>Vcaerrorstatus}',
            Criticality: Criticality,
        },
        {
            $Type: 'UI.DataField',
            Value: vcaErrorType,
            Label: '{i18n>Vcaerrortype}',
        },
        {
            $Type: 'UI.DataField',
            Value: vcaErrorTimeStamp,
            Label: '{i18n>Vcaerrortimestamp}',
        },
    ],
    UI.LineItem #Error             : [
        {
            $Type: 'UI.DataField',
            Value: vcaErrorStatus,
            Label: '{i18n>Vcaerrortype}',
        },
        {
            $Type      : 'UI.DataField',
            Value      : vcaErrorType,
            Label      : '{i18n>Vcaerrorstatus}',
            Criticality: Criticality,
        },
        {
            $Type: 'UI.DataField',
            Value: createdAt,
            Label: '{i18n>errorCreationDate}',
        }
    ],
);

annotate service.EntityDocs with @(
    Capabilities.SearchRestrictions: {Searchable: false},
    UI.LineItem #i18nFlowDetails1  : [
        {
            $Type: 'UI.DataField',
            Value: documentType,
            Label: '{i18n>documentType}',
        },

        // {
        //     $Type : 'UI.DataField',
        //     Value : documentNumber,
        //     Label : '{i18n>documentNumber}',
        // },
        {
            $Type      : 'UI.DataField',
            Value      : errorStatus,
            Label      : '{i18n>errorStatus}',
            Criticality: errorStatusCriticality,
        },
        {
            $Type: 'UI.DataField',
            Value: legalEntity,
            Label: '{i18n>legalEntity}',
        },
        {
            $Type: 'UI.DataField',
            Value: creationDate,
            Label: '{i18n>CreationDate}',
        },
        {
            $Type: 'UI.DataField',
            Value: errorCreationDate,
            Label: '{i18n>errorCreationDate}',
        },
        {
            $Type: 'UI.DataField',
            Value: errorDescription,
            Label: '{i18n>Errordescription}',
        },
        {
            $Type : 'UI.DataField',
            Value : vcaAction,
            Label : '{i18n>DocumentAction}',
        },
        {
            $Type : 'UI.DataField',
            Value : vcaDocSystem,
            Label : '{i18n>DocumentSystem}',
        },
        {
            $Type : 'UI.DataField',
            Value : action,
            Label : '{i18n>Action}'
        },
        {
            $Type : 'UI.DataField',
            Value : stepID,
            Label : '{i18n>StepId}',
        },
    ],
    UI.Facets                      : [{
        $Type : 'UI.ReferenceFacet',
        Label : '{i18n>Messages}',
        ID    : 'Error',
        Target: 'errors/@UI.LineItem#Error',
    }, ],
    UI.LineItem #tableMacro        : [
        {
            $Type: 'UI.DataField',
            Value: businessPartnerId,
            Label: 'Business Partner',
        },
        {
            $Type: 'UI.DataField',
            Value: ecoRegion,
            Label: 'Eco Region',
        },
        {
            $Type: 'UI.DataField',
            Value: entityType,
            Label: 'Entity Type',
        },
        {
            $Type: 'UI.DataField',
            Value: plant,
            Label: 'Plant',
        },
        {
            $Type: 'UI.DataField',
            Value: legalEntity,
            Label: 'Legal Entity',
        },
    ],
    UI.HeaderInfo                  : {
        Title         : {
            $Type: 'UI.DataField',
            Value: documentNumber,
        },
        TypeName      : '',
        TypeNamePlural: '',
        Description   : {
            $Type: 'UI.DataField',
            Value: documentType,
        },
    },
    UI.LineItem #i18nErrorLogs     : [
        {

            $Type: 'UI.DataField',
            Value: errors.vcaErrorStatus,
            Label: 'vcaErrorStatus',
        },
        {
            $Type: 'UI.DataField',
            Value: errors.vcaErrorTimeStamp,
            Label: 'vcaErrorTimeStamp',
        },
        {
            $Type: 'UI.DataField',
            Value: errors.vcaErrorType,
            Label: 'vcaErrorType',
        },
        {
            $Type: 'UI.DataField',
            Value: errorCreationDate,
            Label: 'errorCreationDate',
        },
        {
            $Type: 'UI.DataField',
            Value: errorResolutionDate,
            Label: 'errorResolutionDate',
        },
    ],
    UI.LineItem #tableMacro1       : [
        {
            $Type: 'UI.DataField',
            Value: documentType,
            Label: 'documentType',
        },
        {
            $Type: 'UI.DataField',
            Value: documentNumber,
            Label: 'documentNumber',
        },
    ],
    UI.LineItem #tableMacro2       : [
        {
            $Type: 'UI.DataField',
            Value: documentNumber,
            Label: 'documentNumber',
        },
        {
            $Type: 'UI.DataField',
            Value: creationDate,
            Label: 'creationDate',
        },
        {
            $Type: 'UI.DataField',
            Value: documentType,
            Label: 'documentType',
        },
        {
            $Type: 'UI.DataField',
            Value: errorCreationDate,
            Label: 'errorCreationDate',
        },
        {
            $Type: 'UI.DataField',
            Value: errorStatus,
            Label: 'errorStatus',
        },
    ],
);

annotate service.ShippingRequestEntityLocationSummary with @(
    UI.PresentationVariant : {

        SortOrder     : [{
            Property  : entityRank,
            Descending: false
        }],
        Visualizations: ['@UI.LineItem#tableMacro']
    },
    UI.LineItem #tableMacro: [
        {
            $Type: 'UI.DataField',
            Value: entityType,
            Label: '{i18n>entityType}',
        },
        {
            $Type: 'UI.DataField',
            Value: legalEntity,
            Label: '{i18n>legalEntity}',
        },
        {
            $Type: 'UI.DataField',
            Value: businessPartnerId,
            Label: '{i18n>businessPartnerId}',
        },
        {
            $Type: 'UI.DataField',
            Value: plant,
            Label: '{i18n>plant}',
        },
        {
            $Type: 'UI.DataField',
            Value: entityRank,
            Label: '{i18n>entityRank}',
            @UI.Hidden,
        },
    ]
);

annotate service.ShippingRequestWithErrors with @(
    Capabilities.SearchRestrictions: {Searchable: false},
    UI.LineItem #i18nErrorLogs     : [
        {
            $Type: 'UI.DataField',
            Value: documentType,
            Label: '{i18n>Documenttype}',
        },
        {
            $Type: 'UI.DataField',
            Value: documentNumber,
            Label: '{i18n>Documentnumber}',
        },
        {
            $Type: 'UI.DataField',
            Value: followOnDocumentNo,
            Label: '{i18n>FollowonDocumentNumber}',
        },
        {
            $Type      : 'UI.DataField',
            Value      : vcaErrorType,
            Label      : 'Type',
            Criticality: Criticality,
        },
        {
            $Type: 'UI.DataField',
            Value: vcaErrorStatus,
            Label: 'Status',
        },
        {
            $Type: 'UI.DataField',
            Value: errorResolutionDate,
            Label: '{i18n>ErrorResolutionDate}',
        },
        {
            $Type : 'UI.DataField',
            Value : createdAt,
            Label : '{i18n>ErrorCreationDate}',
        },
    ]
){
    errorCreationDate @UI.Hidden;
    createdAt @title: 'Error Creation Date';
};



annotate service.ShippingRequestPrereqStatus with @(UI.LineItem #PreRequisiteChecks: [
    {
        $Type: 'UI.DataField',
        Value: shippingReqNo,
        Label: '{i18n>ShippingReqNumber}',
    },
    {
        $Type: 'UI.DataField',
        Value: checkType,
        Label: '{i18n>CheckType}',
    },
    {
        $Type: 'UI.DataField',
        Value: checkLabel,
        Label: '{i18n>CheckLabel}',
    },
    {
        $Type: 'UI.DataField',
        Value: status,
        Label: '{i18n>Errorstatus}',
    },
    {
        $Type: 'UI.DataField',
        Value: sortOrder,
        Label: '{i18n>Order}',
    },
]);

annotate service.ShippingRequestView with {
    shippingReqNo @(
        Common.Label                   : '{i18n>shippingReqNo}',
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'ShippingRequest_VH',
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: shippingReqNo,
                ValueListProperty: 'shippingReqNo',
            }, ],
            Label         : 'Shipping Request Number',
        },
        Common.ValueListWithFixedValues: false,
    )
};

annotate service.ShippingRequestPrereqStatus with @(
    Capabilities.SearchRestrictions: {Searchable: false},
    UI.LineItem #PreRequisiteStatus: [
        {
            $Type: 'UI.DataField',
            Value: checkLabel,
            Label: '{i18n>Checklabel}',
        },
        {
            $Type      : 'UI.DataField',
            Value      : status,
            Label      : '{i18n>Status1}',
            Criticality: mainCriticality,
        },
        {
            $Type: 'UI.DataField',
            Value: errorDescription,
            Label: '{i18n>Errordescription}',
        },
        {
            $Type : 'UI.DataField',
            Value : errorCreationDate,
            Label : '{i18n>errorCreationDate}',
        },
        {
            $Type : 'UI.DataField',
            Value : errorResolutionDate,
            Label : '{i18n>ErrorResolutionDate}',
        },
    ],
    UI.LineItem #tableMacro        : [
        {
            $Type: 'UI.DataField',
            Value: checkLabel,
            Label: 'checkLabel',
        },
        {
            $Type: 'UI.DataField',
            Value: status,
            Label: 'status',
        },
    ],
);


annotate service.ShippingRequestView with {
    shipToBusinessPartner @(
        Common.Label : '{i18n>BusinessPartnershipTo}',
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'I_BPST_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : shipToBusinessPartner,
                    ValueListProperty : 'Customer',
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'BPCustomerName',
                    Label:'Bp Customer name'
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty : 'Country',
                },
            ],
            Label : '{i18n>BusinessPartnershipTo}',
        },
        Common.ValueListWithFixedValues : false,
    )
};

annotate service.ShippingRequestEntityFollowOnDocs with @(
    UI.LineItem #tableMacro : [
        {
            $Type : 'UI.DataField',
            Value : initialDocumentNo,
            Label : '{i18n>initialDocumentNo}',
        },
        {
            $Type : 'UI.DataField',
            Value : shippingReqNo,
            Label : '{i18n>shippingReqNo}',
        },
        {
            $Type : 'UI.DataField',
            Value : followOnDocumentNo,
            Label : '{i18n>Followondocumentno}',
        },
        {
            $Type : 'UI.DataField',
            Value : itemNo,
            Label : '{i18n>ItemNumber}',
        },
        {
            $Type : 'UI.DataField',
            Value : quantity,
            Label : '{i18n>Quantity}',
        },
        {
            $Type : 'UI.DataField',
            Value : uom,
            Label : '{i18n>Uom}',
        },
        {
            $Type : 'UI.DataField',
            Value : materialNumber,
            Label : '{i18n>Materialnumber}',
        },
        {
            $Type : 'UI.DataField',
            Value : batchNumber,
            Label : '{i18n>Batchnumber}',
        },
    ]
);

//Open Items JGHJ-87133 R2.2 change start
annotate service.asnOrphanDocs with @(
    Capabilities.SearchRestrictions: {Searchable: false},
    UI.LineItem #AsnOrphanLogs     : [
        {
            $Type: 'UI.DataField',
            Value: initialDocumentNo,
            Label: 'Initial Document No.',
        },
        {
            $Type: 'UI.DataField',
            Value: legacyDocNum,
            Label: 'Outbound Delivery (Legacy)',
        },
        {
            $Type: 'UI.DataField',
            Value: legacyRefDocNum,
            Label: 'Reference SO/PO (Legacy)',
        },
        {
            $Type     : 'UI.DataField',
            Value     : createdAt,
            Label     : '{i18n>asnCreationDate}',
            Importance: #High,
        },
        {
            $Type     : 'UI.DataField',
            Value     : modifiedAt,
            Label     : '{i18n>asnModificationDate}',
            Importance: #High,
        },
        {
            $Type: 'UI.DataField',
            Value: error,
            Label: 'Error Details',
        }
    ]
);
//Open Items JGHJ-87133 R2.2 change end

annotate service.ShippingRequestQueue with @(
    UI.LineItem #ChangeEvents : [
        {
            $Type : 'UI.DataField',
            Value : parentPO,
            Label : '{i18n>PurchaseOrder}',
        },
        {
            $Type : 'UI.DataField',
            Value : itemNo,
            Label : '{i18n>Item}',
        },
        {
            $Type      : 'UI.DataField',
            Value      : status,
            Label      : '{i18n>Errorstatus}',
            Criticality: statusCriticality,
        },
        {
            $Type : 'UI.DataField',
            Value : errorMessage,
            Label : '{i18n>MessageDescription}',
        },
        {
            $Type : 'UI.DataField',
            Value : queueNo,
            Label : '{i18n>Queue}',
        },
        {
            $Type : 'UI.DataField',
            Value : actionType,
            Label : '{i18n>ActionType}',
        },
        {
            $Type : 'UI.DataField',
            Value : deliveryDate,
            Label : '{i18n>DeliveryDate}',
        },
        {
            $Type : 'UI.DataField',
            Value : quantity,
            Label : '{i18n>Quantity}',
        },
        {
            $Type : 'UI.DataField',
            Value : createdAt,
        },
        {
            $Type : 'UI.DataField',
            Value : modifiedAt,
        },
        {
            $Type : 'UI.DataField',
            Value : modifiedBy,
        },
        {
            $Type : 'UI.DataField',
            Value : ID,
            Label : 'ID',
        },
        {
            $Type : 'UI.DataField',
            Value : createdBy,
        }
    ],
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            Label : 'Errors',
            ID : 'Errors',
            Target : 'errors/@UI.LineItem#Errors',
        },
    ],
);

annotate service.QueueRequestErrors with @(
    UI.LineItem #Errors : [
        {
            $Type : 'UI.DataField',
            Value : parent.parentPO,
            Label : '{i18n>PurchaseOrder}',
        },
        {
            $Type : 'UI.DataField',
            Value : parent.itemNo,
            Label : '{i18n>Item}',
        },
        {
            $Type : 'UI.DataField',
            Value : parent.actionType,
            Label : '{i18n>ActionType}',
        },
        {
            $Type : 'UI.DataField',
            Value : parent.status,
            Label : '{i18n>Errorstatus}',
        },
        {
            $Type : 'UI.DataField',
            Value : errorMessage,
            Label : '{i18n>MessageDescription}',
        },
        {
            $Type : 'UI.DataField',
            Value : errorType,
            Label : '{i18n>ErrorType}',
        },
        {
            $Type : 'UI.DataField',
            Value : timeStamp,
            Label : '{i18n>Time}',
        },
        {
            $Type : 'UI.DataField',
            Value : ID,
            Label : 'ID',
        },
    ]
);

