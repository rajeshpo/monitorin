## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Mon Jul 28 2025 15:23:27 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.18.3|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>List Report Page V4|
|**Service Type**<br>Local CAP|
|**Service URL**<br>http://localhost:4004/zbuvcm55155/|
|**Module Name**<br>zbuvcm55155ui|
|**Application Title**<br>Monitoring Application|
|**Namespace**<br>jnj.com|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.138.1|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|
|**Main Entity**<br>ShippingRequestView|

## zbuvcm55155ui

An SAP Fiori application for VCM Monitoring 

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated app, start your CAP project:  and navigate to the following location in your browser:

http://localhost:4004/zbuvcm55155ui/webapp/index.html

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


