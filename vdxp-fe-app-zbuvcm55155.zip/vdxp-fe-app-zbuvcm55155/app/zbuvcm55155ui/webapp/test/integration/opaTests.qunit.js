sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'jnj/com/zbuvcm55155ui/test/integration/FirstJourney',
		'jnj/com/zbuvcm55155ui/test/integration/pages/ShippingRequestViewList',
		'jnj/com/zbuvcm55155ui/test/integration/pages/ShippingRequestViewObjectPage'
    ],
    function(JourneyRunner, opaJourney, ShippingRequestViewList, ShippingRequestViewObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('jnj/com/zbuvcm55155ui') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheShippingRequestViewList: ShippingRequestViewList,
					onTheShippingRequestViewObjectPage: ShippingRequestViewObjectPage
                }
            },
            opaJourney.run
        );
    }
);