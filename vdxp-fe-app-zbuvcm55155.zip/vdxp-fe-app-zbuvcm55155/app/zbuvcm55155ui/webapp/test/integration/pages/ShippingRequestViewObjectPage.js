sap.ui.define(['sap/fe/test/ObjectPage'], function(ObjectPage) {
    'use strict';

    var CustomPageDefinitions = {
        actions: {},
        assertions: {}
    };

    return new ObjectPage(
        {
            appId: 'jnj.com.zbuvcm55155ui',
            componentId: 'ShippingRequestViewObjectPage',
            contextPath: '/ShippingRequestView'
        },
        CustomPageDefinitions
    );
});