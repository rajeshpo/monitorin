sap.ui.define(['sap/fe/test/ListReport'], function(ListReport) {
    'use strict';

    var CustomPageDefinitions = {
        actions: {},
        assertions: {}
    };

    return new ListReport(
        {
            appId: 'jnj.com.zbuvcm55155ui',
            componentId: 'ShippingRequestViewList',
            contextPath: '/ShippingRequestView'
        },
        CustomPageDefinitions
    );
});