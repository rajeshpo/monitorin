sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("jnj.com.zbuvcm55155ui.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);