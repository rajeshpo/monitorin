sap.ui.define(['sap/ui/core/mvc/ControllerExtension', 'sap/ui/model/json/JSONModel', "sap/ushell/Container","sap/m/MessageToast","sap/m/MessageBox"], function (ControllerExtension, JSONModel, Container, MessageToast, MessageBox	) {
	'use strict';

	return ControllerExtension.extend('jnj.com.zbuvcm55155ui.ext.controller.ObjectPageController', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf jnj.com.zbuvcm55155ui.ext.controller.ShippingRequestList
			 */
			onInit: function () {
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				var oModel = this.base.getExtensionAPI().getModel();
				const oRouter = this.base.getAppComponent().getRouter();
				oRouter.getRoute('ShippingRequestViewObjectPage').attachPatternMatched(this._onObjectMatched, this);


			},
		},

		onAfterRendering: function () {
    const oTable = this.byId("EntityTable").getTable();
    const aColumns = oTable.getColumns();
    const oCustomCol = aColumns[aColumns.length - 1]; // your custom column (last)
    oTable.removeColumn(oCustomCol);
    oTable.insertColumn(oCustomCol, 1); // 👈 put it in 2nd place
},

		_onObjectMatched: async function (oEvent) {
			const odataModel = this.getView().getModel();
			let oModelBindingContext = odataModel.bindContext(
				"/getLocationSummary(...)"
			);
			const params = oEvent.getParameter("arguments");

			let shipId = params.key.split(",")[1].split("=")[1];


			oModelBindingContext.setParameter("shippingReqNo", shipId);
			await oModelBindingContext.invoke();

			const response = oModelBindingContext
				.getBoundContext()
				.getObject().value;
			console.log(response, "response")
			let followOnDocFound=response[0].followOnDocFound||false
			let sFrom = response[0].result1[0]?.shipFromBusinessPartnerName || response[0].result1[0]?.shipFromBusinessPartner || response[0].result1[0]?.shipFromPlantName || response[0].result1[0]?.shipFromPlant
			let sTo = response[0].result1[0]?.shipToBusinessPartnerName || response[0].result1[0]?.shipToBusinessPartner || response[0].result1[0]?.shipToPlantName || response[0].result1[0]?.shipToPlant
			// Final processFlowFinalData
			const processFlowFinalData = {
				"nodes": [
				],
				"lanes": [
					{
						"id": "0",
						"icon": "sap-icon://factory",
						"label": `Ship From ${sFrom
							}`,
						"position": 0,
						"state": [
							{
								"state": "Positive",
								"value": 10
							}
						]
					}, {
						"id": "1",
						"icon": "sap-icon://factory",

						"label": `Ship To ${sTo}`,

						"position": 1,
						"state": [
							{
								"state": "Positive",
								"value": 100
							}
						]
					},
				]
			}

			// Set the model
			this.getView().setModel(new JSONModel(processFlowFinalData), "pf2");
			this.getView().setModel(
				new JSONModel({
					followOnDocFound: followOnDocFound
				}),
				"followOnDocModel"
			);
			const oView = this.base.getView();
			const sViewId = oView.getId();

			const oTable = sap.ui.getCore().byId(
				sViewId + "--fe::CustomSubSection::DocumentOverview--EntityTable-content"
			);

			if (oTable) {
				oTable.rebind();
				sap.ui.getCore().byId("jnj.com.zbuvcm55155ui::ShippingRequestViewObjectPage--fe::CustomSubSection::DocumentOverview--BackToMaster")?.setVisible(false)
			}


			const lanes = [];

			// Ensure response has required fields
			// if (!response || !response.ShipFromBP || !response.ShipToBP || !Array.isArray(response.Ventities)) {
			//   console.error("Invalid input structure for process flow lanes.");
			//   return lanes;
			// }

			// Step 1: Add ShipFrom BP lane
			lanes.push({
				id: "0",
				icon: "sap-icon://factory",
				label: sFrom,
				position: 0,
				"state": [
					{
						"state": "Positive",
						"value": 100
					}
				]
			});

			// // Step 2: Sort Virtual Entities by their rank or sequence
			// const sortedVEs = [...response.Ventities].sort((a, b) => {
			//   const rankA = a.EntityRank || 0;
			//   const rankB = b.EntityRank || 0;
			//   return rankA - rankB;
			// });

			// Step 3: Add lanes for each VE in sorted order
			response[0].uniqueResult.forEach((ve, idx) => {
				let veName = ve?.plantName||ve?.plant
				lanes.push({
					id: (idx + 1).toString(),
					icon: "sap-icon://building",
					label: veName || `VE ${idx + 1}`,
					position: idx + 1,
					"state": [
						{
							"state": "Positive",
							"value": 100
						}
					]
				});
			});

			// Step 4: Add ShipTo BP lane
			lanes.push({
				id: (lanes.length).toString(),
				icon: "sap-icon://factory",
				label: sTo,
				position: lanes.length,
				"state": [
					{
						"state": "Positive",
						"value": 100
					}
				]
			});

			let financialData = {
				"lanes": lanes,
				"nodes": []
			}

			let shipData = {
				shipFrom: response[0].result1[0]?.shipFromBusinessPartner || response[0].result1[0]?.shipFromBusinessPartnerName || response[0].result1[0]?.shipFromPlantName || response[0].result1[0]?.shipFromPlant,
				sTo: response[0].result1[0]?.shipToBusinessPartner || response[0].result1[0]?.shipToBusinessPartnerName || response[0].result1[0]?.shipToPlantName || response[0].result1[0]?.shipToPlant
			}
			this.getView().setModel(new JSONModel(shipData), "shipData");
			this.getView().setModel(new JSONModel(financialData), "pf4");
			// Set the model


		},

		onPressDocumentNumber: function (oEvent) {
			MessageToast.show("You pressed the custom action in the table");
		},
		onPressRefresh: function() {
			console.log("onPressRefresh");
			this.base.getExtensionAPI().refresh()
		},
		onAutoRefresh: function() {
			var that = this
			let button = this.getView().byId("jnj.com.zbuvcm55155ui::ShippingRequestViewObjectPage--fe::CustomSubSection::DocumentOverview--EntityTable-content::CustomAction::autoRefresh")
			button.setEnabled(false)
			MessageToast.show("The content on this table will Auto Refresh after every 10 seconds.")
			setInterval(function(){
				that.base.getExtensionAPI().refresh()
			},10000)
		},
		reprocessQueue: async function (oEvent) {
			MessageToast.show("Custom handler invoked.");

			const odataModel = this.getView().getModel();
			let oModelBindingContext = odataModel.bindContext(
				"/reprocessQueueItem(...)"
			);
			const path = oEvent.getPath();

			const match = path.match(/initialDocumentNo='([^']+)'/);

			const initialDocumentNo = match?.[1];

			console.log(initialDocumentNo);


			oModelBindingContext.setParameter("PO", initialDocumentNo);
			try {
				await oModelBindingContext.invoke();

			const response = oModelBindingContext
				.getBoundContext()
				.getObject().value;
				var that = this
				that.base.getExtensionAPI().refresh()
			console.log(response, "response")
			} catch (error) {
				MessageBox.error(`Error reprocessing queue: ${error.message}`);
				console.error("Error details:", error);
				var that = this
				that.base.getExtensionAPI().refresh()
			}
		},



	});
});
