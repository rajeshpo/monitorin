sap.ui.define(['sap/ui/core/mvc/ControllerExtension', 'sap/ui/model/json/JSONModel'], function (ControllerExtension, JSONModel) {
	'use strict';

	return ControllerExtension.extend('jnj.com.zbuvcm55155ui.ext.controller.ShippingRequestList', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf jnj.com.zbuvcm55155ui.ext.controller.ShippingRequestList
			 */
			onInit: function () {
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				var oModel = this.base.getExtensionAPI().getModel();



			},
		},
		
		onPressDocumentNumber: function (oEvent) {
			MessageToast.show("You pressed the custom action in the table");
		},


	});
});
