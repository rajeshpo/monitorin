sap.ui.define([
    "sap/m/MessageToast", "sap/ui/core/library"
], function (MessageToast, coreLibrary) {
    'use strict';

    function _getColorByState(oItem) {
        switch (oItem.getState()) {
            case "Error": return coreLibrary.IconColor.Negative;
            case "Warning": return coreLibrary.IconColor.Critical;
            case "Success": return coreLibrary.IconColor.Positive;
        }
    }
    return {
        
        onPress: function(oEvent) {
            var oItem = oEvent.getSource(),
                aCustomData = oItem.getCustomData(),
                sTitle = aCustomData[0].getValue(),
                sIcon = aCustomData[1].getValue(),
                sSubTitle = aCustomData[2].getValue();
                // sDescription = aCustomData[3].getValue();
            var that = this
            var oPopover = new sap.m.Popover({
                contentWidth: "300px",
                title: "Shipping Status",
                content: [
                    new sap.m.HBox({
                        items: [
                            new sap.ui.core.Icon({
                                src: sIcon,
                                color: _getColorByState(oItem)
                            }).addStyleClass("sapUiSmallMarginBegin sapUiSmallMarginEnd"),
                            new sap.m.FlexBox({
                                width: "100%",
                                renderType: "Bare",
                                direction: "Column",
                                items: [new sap.m.Title({
                                    level: coreLibrary.TitleLevel.H1,
                                    text: sTitle
                                }), new sap.m.Text({
                                    text: sSubTitle
                                }).addStyleClass("sapUiSmallMarginBottom sapUiSmallMarginTop"),
                                // new sap.m.Text({
                                //     text: sDescription
                                // })
                                ]
                            })
                        ]
                    }).addStyleClass("sapUiTinyMargin")
                ],
                footer: [
                    new sap.m.Toolbar({
                        content: [
                            new sap.m.ToolbarSpacer(),
                            new sap.m.Button({
                                text: "Close",
                                press: function () {
                                    oPopover.close();
                                }
                            })]
                    })
                ]
            });

            oPopover.openBy(oEvent.getParameter("item"));
        }
    };
});
