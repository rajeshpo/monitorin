sap.ui.define([
    "sap/m/MessageToast",
    "sap/m/library"
], function (MessageToast, mobileLibrary) {
    "use strict";

    async function navigateToCrossApp(semanticObject, action, params = {}) {
        try {
            if (!sap.ushell || !sap.ushell.Container) {
                MessageToast.show("Not running inside Fiori Launchpad");
                return;
            }

            const oCrossAppNavigator = await sap.ushell.Container.getServiceAsync("Navigation");
            await oCrossAppNavigator.navigate({
                target: {
                    semanticObject: semanticObject,
                    action: action
                },
                params: params
            });

        } catch (e) {
            MessageToast.show("Cross-App navigation failed");
            console.error("Cross-app nav error:", e);
        }
    }

    return {

        onComboRowSelect: function (oEvent) {
            const oTable = oEvent.getSource();
            const aContexts = oEvent.getParameter("bindingContext")
            const oSelectedObject = aContexts.getObject();

            // Example keys – adjust to your model
            const shippingReqNo = oSelectedObject.shippingReqNo;
            const followOnDocumentNo = oSelectedObject.followOnDocumentNo;


            const aFilters = [];

            if (shippingReqNo) {
                aFilters.push(
                    new sap.ui.model.Filter(
                        "parent_shippingReqNo",
                        sap.ui.model.FilterOperator.EQ,
                        shippingReqNo
                    )
                );
            }

            if (followOnDocumentNo) {
                aFilters.push(
                    new sap.ui.model.Filter({
                        filters: [
                            new sap.ui.model.Filter(
                                "followOnDocumentNo",
                                sap.ui.model.FilterOperator.EQ,
                                followOnDocumentNo
                            ),
                            new sap.ui.model.Filter(
                                "followOnDocumentNo",
                                sap.ui.model.FilterOperator.EQ,
                                null
                            ),
                            new sap.ui.model.Filter(
                                "followOnDocumentNo",
                                sap.ui.model.FilterOperator.EQ,
                                ""
                            )
                        ],
                        and: false // OR condition
                    })
                );
            }

            this.byId("EntityTable").getRowBinding().filter(aFilters)
            this.byId("MasterSection").setVisible(false);
            this.byId("BackToMaster").setVisible(true)
            this.byId("DetailSection").setVisible(true);
        },
        onBackToMaster: function () {
            // Clear detail table filters
            this.byId("EntityTable").getRowBinding().filter([]);

            // Toggle visibility
            this.byId("DetailSection").setVisible(false);
            this.byId("MasterSection").setVisible(true);
            this.byId("BackToMaster").setVisible(false);

        },


        onDocLinkPress: async function (oEvent) {
            const oContext = oEvent.getSource().getBindingContext();
            // const docType = oContext.getProperty("documentType");
            const rawDocType = (oContext.getProperty("stepID") || "").trim();
            const documentYear = (oContext.getProperty("documentYear") || "").trim();

            const hash = sap.ui.core.routing.HashChanger.getInstance().getHash();
            console.log("FLP Hash:", hash);

            // Extract query params from the hash
            const paramsString = hash.match(/\((.*)\)/)?.[1];
            console.log("Params string:", paramsString);

            const params = {};
            if (paramsString) {
                paramsString.split(",").forEach(pair => {
                    const [key, rawValue] = pair.split("=");
                    // Remove quotes (')
                    const value = rawValue.replace(/^'(.*)'$/, "$1");
                    params[key] = value;
                });
            }


            const docNum = oContext.getProperty("documentNumber");
            // const docTypeMap = {
            //     "BT_FP": "BATCH",
            //     "BT_APH": "BATCH",
            //     "BT_RT": "BATCH",
            //     "BT_FRZ":"BATCH",
            //     "PO_SUB": "PO",
            //     "PO_APH": "PO",
            //     "ICSO": "PO",
            //     "IM_TR": "IM_TR",  // no mapping given → keep as-is
            //     "ICSO": "SO",
            //     "TSO": "SO",
            //     "OBD": "OD",
            //     "GI": "GI",
            //     "ARI": "ARINV",
            //     "ICPO": "PO",
            //     "GR": "GR",
            //     "IBD_PGR": "GR",
            //     "API": "APINV"
            // };

             function _getDocTypeFromStep (stepID) {

                const step = (stepID || "").toUpperCase();

                // ---- Purchase Order ----
                if (step.includes("PO"))
                    return "PO";

                // ---- Sales Order ----
                if (step.includes("SO") || step.includes("TSO"))
                    return "SO";

                // ---- Goods Receipt ----
                if (step.includes("GR") || step.includes("PGR"))
                    return "GR";

                // ---- Goods Issue ----
                if (step.includes("GI"))
                    return "GI";

                // ---- Outbound Delivery ----
                if (step.includes("OBD"))
                    return "OD";

                // ---- Inbound Delivery ----
                if (step.includes("IBD"))
                    return "IBD";

                // ---- Batch ----
                if (step.startsWith("BT_"))
                    return "BATCH";

                // ---- AP Invoice ----
                if (step.includes("API"))
                    return "APINV";

                // ---- AR Invoice ----
                if (step.includes("ARI"))
                    return "ARINV";

                if (step === "IM_TR")
                    return "IM_TR";   // inventory transfer


                return null; // unknown but safe
            }

            // const docType = docTypeMap[rawDocType] || rawDocType; // default: pass through
            const docType = _getDocTypeFromStep(rawDocType);

            if (!docType) {
                MessageToast.show("Unsupported step: " + rawDocType);
                return;
            }

            let sSemanticObject, sAction, oParams;

            switch (docType) {
                //BATCH MSC3N
                case "BATCH":
                    sSemanticObject = "Batch";
                    sAction = "display";
                    let sMaterial = "";
                    const odataModel = this._view.getModel();
                    let oModelBindingContext = odataModel.bindContext("/getMaterialData(...)");
                    oModelBindingContext.setParameter("initialDocumentNo", params.initialDocumentNo);
                    oModelBindingContext.setParameter("shippingReqNo", params.shippingReqNo);
                    await oModelBindingContext.invoke();

                    const response = oModelBindingContext.getBoundContext().getObject()
                    if (rawDocType === "BT_FP") {
                        sMaterial = response.materialNumber;
                    } else if (rawDocType === "BT_APH") {
                        sMaterial = response.AF_FRSH_Mat;
                    } else if (rawDocType === "BT_RT") {
                        sMaterial = response.RETAINBAG_Mat;
                    }else if(rawDocType==="BT_FRZ"){
                        sMaterial=response.AF_FZ_Mat
                    }
                    oParams = { Batch: [docNum], Material: sMaterial };
                    break;
                case "SO": // Sales Order: F1814
                    sSemanticObject = "SalesOrder";
                    sAction = "displayFactSheet";
                    oParams = { SalesOrder: [docNum] };
                    break;

                case "GI": // Goods Issue (Material Document) F1077
                    sSemanticObject = "MaterialDocument";
                    sAction = "displayFactSheet";
                    // oParams = { MaterialDocument: [docNum], MaterialDocumentYear: documentYear };
                    oParams = { MaterialDocument: [docNum] };
                    break;

                case "OD": // Outbound Delivery: F0233A
                    sSemanticObject = "OutboundDelivery";
                    sAction = "displayFactSheet";
                    oParams = { OutboundDelivery: [docNum] };
                    break;

                case "APINV": // Accounts Payable Invoice: MIR4
                    sSemanticObject = "SupplierInvoice";
                    sAction = "displayAdvanced";
                    oParams = { SupplierInvoice: [docNum], FiscalYear: documentYear };
                    break;

                case "PO": // Purchase Order: F0348A
                    sSemanticObject = "PurchaseOrder";
                    sAction = "displayFactSheet";
                    oParams = { PurchaseOrder: [docNum] };
                    break;

                case "IBD": // Inbound Delivery: F0232A
                    sSemanticObject = "InboundDelivery";
                    sAction = "displayFactSheet";
                    oParams = { InboundDelivery: [docNum] };
                    break;

                case "ARINV": // Accounts Receivable Invoice: F0797
                    sSemanticObject = "BillingDocument";
                    sAction = "displayBillingDocument";
                    oParams = { BillingDocument: [docNum] };
                    break;

                case "GR": // Accounts Receivable Invoice: F1077
                    sSemanticObject = "MaterialDocument";
                    sAction = "displayFactSheet";
                    // oParams = { MaterialDocument: [docNum], MaterialDocumentYear: documentYear };
                    oParams = { MaterialDocument: [docNum] };

                    break;

                default:
                    MessageToast.show("No navigation mapping for document type: " + docType);
                    return;
            }

            navigateToCrossApp(sSemanticObject, sAction, oParams);
        }
    };
});