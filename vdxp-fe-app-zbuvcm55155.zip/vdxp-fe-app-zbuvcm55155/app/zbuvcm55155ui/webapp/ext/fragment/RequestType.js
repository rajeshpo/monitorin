sap.ui.define(["sap/ui/model/Filter", "sap/ui/model/FilterOperator"], function(Filter, FilterOperator) {
    "use strict";
    return {
        filterItems: function(sValue) {
            switch (sValue) {
                case "0":
                        return new Filter({
                        filters: [
                            new Filter({ path: "shippingReqNo", operator: FilterOperator.StartsWith, value1: 'SH' }),
                            new Filter({ path: "shippingReqNo", operator: FilterOperator.StartsWith, value1: 'S' }),
                            new Filter({ path: "shippingReqNo", operator: FilterOperator.StartsWith, value1: 'V' })
                        ],
                        and: false
                    });
                case "1":
                    return new Filter({ path: "shippingReqNo", operator: FilterOperator.StartsWith, value1: 'SH' });
                case "2":
                    // return new Filter({ path: "shippingReqNo", operator: FilterOperator.StartsWith, value1: 'S' });
                    
                    return new Filter({
                        filters: [
                            new Filter({ path: "shippingReqNo", operator: FilterOperator.StartsWith, value1: 'S' }),
                            new Filter({ path: "shippingReqNo", operator: FilterOperator.NotStartsWith, value1: 'SH' })
                        ],
                        and: true
                    });
                case "3":
                    return new Filter({ path: "shippingReqNo", operator: FilterOperator.StartsWith, value1: 'V' });
            }
        }
    };
});
