using zbuvcm55155Service as service from '../../srv/zbuvcm55155service';
annotate service.emailNotifyEntity with @(
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Value : type,
                Label : '{i18n>Vcaerrorstatus}',
            },
            {
                $Type : 'UI.DataField',
                Label : 'Email',
                Value : Email,
            },
        ],
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : 'General Information',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
    ],
    UI.LineItem : [
        {
            $Type : 'UI.DataField',
            Value : type,
            Label : '{i18n>Vcaerrorstatus}',
        },
        {
            $Type : 'UI.DataField',
            Label : 'Email',
            Value : Email,
        },
    ],
    UI.HeaderInfo : {
        Title : {
            $Type : 'UI.DataField',
            Value : type,
        },
        TypeName : '',
        TypeNamePlural : '',
    },
);

annotate service.emailNotifyEntity with {
    type @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'I_Type_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : type,
                    ValueListProperty : 'Type',
                },
            ],
            Label : '{i18n>Vcaerrorstatus}',
        },
        Common.ValueListWithFixedValues : true,
)};

annotate service.emailNotifyEntity with {
    Email @UI.MultiLineText : true
};

