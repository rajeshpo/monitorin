## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Thu Sep 04 2025 14:33:54 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.18.6|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>List Report Page V4|
|**Service Type**<br>Local CAP|
|**Service URL**<br>http://localhost:4004/zbuvcm55155/|
|**Module Name**<br>zbuvcm55155dlemailui|
|**Application Title**<br>Email Notifications|
|**Namespace**<br>jnj.com.zbuvcm55155dlemailui|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.140.0|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|
|**Main Entity**<br>emailNotifyEntity|

## zbuvcm55155dlemailui

DL email list Application

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated app, start your CAP project:  and navigate to the following location in your browser:

http://localhost:4004/zbuvcm55155dlemailui/webapp/index.html

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


