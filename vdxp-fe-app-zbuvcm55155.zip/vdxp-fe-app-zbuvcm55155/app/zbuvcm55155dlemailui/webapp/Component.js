sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("jnj.com.zbuvcm55155dlemailui.zbuvcm55155dlemailui.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);