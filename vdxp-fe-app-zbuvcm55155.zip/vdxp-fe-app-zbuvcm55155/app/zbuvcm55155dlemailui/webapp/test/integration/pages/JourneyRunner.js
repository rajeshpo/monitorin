sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"jnj/com/zbuvcm55155dlemailui/zbuvcm55155dlemailui/test/integration/pages/emailNotifyEntityList",
	"jnj/com/zbuvcm55155dlemailui/zbuvcm55155dlemailui/test/integration/pages/emailNotifyEntityObjectPage"
], function (JourneyRunner, emailNotifyEntityList, emailNotifyEntityObjectPage) {
    'use strict';

    var runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('jnj/com/zbuvcm55155dlemailui/zbuvcm55155dlemailui') + '/index.html',
        pages: {
			onTheemailNotifyEntityList: emailNotifyEntityList,
			onTheemailNotifyEntityObjectPage: emailNotifyEntityObjectPage
        },
        async: true
    });

    return runner;
});

