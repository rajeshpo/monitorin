sap.ui.define(['sap/fe/test/ObjectPage'], function(ObjectPage) {
    'use strict';

    var CustomPageDefinitions = {
        actions: {},
        assertions: {}
    };

    return new ObjectPage(
        {
            appId: 'jnj.com.zbuvcm55155dlemailui.zbuvcm55155dlemailui',
            componentId: 'emailNotifyEntityObjectPage',
            contextPath: '/emailNotifyEntity'
        },
        CustomPageDefinitions
    );
});