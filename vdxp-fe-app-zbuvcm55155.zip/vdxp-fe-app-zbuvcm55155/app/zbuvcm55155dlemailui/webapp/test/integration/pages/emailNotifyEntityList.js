sap.ui.define(['sap/fe/test/ListReport'], function(ListReport) {
    'use strict';

    var CustomPageDefinitions = {
        actions: {},
        assertions: {}
    };

    return new ListReport(
        {
            appId: 'jnj.com.zbuvcm55155dlemailui.zbuvcm55155dlemailui',
            componentId: 'emailNotifyEntityList',
            contextPath: '/emailNotifyEntity'
        },
        CustomPageDefinitions
    );
});