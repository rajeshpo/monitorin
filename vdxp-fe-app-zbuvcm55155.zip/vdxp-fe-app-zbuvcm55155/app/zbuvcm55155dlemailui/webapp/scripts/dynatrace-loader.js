sap.ui.define([], () => {
    "use strict";

    const DYNATRACE_URL_DEV_PQ = "https://js-cdn.dynatrace.com/jstag/19223e8e12b/bf29850eyy/211e049811a1f3a0_complete.js";
    const DYNATRACE_URL_QA_PROD = "https://js-cdn.dynatrace.com/jstag/176fb25782e/bf38106xcc/2e5cb49ce79be179_complete.js";

    const getDynatraceUrlByEnvironment = () => {
        const currentOrigin = window.location.origin.toLowerCase();

        if (currentOrigin.includes("qa") || currentOrigin.includes("prd")) {
            return DYNATRACE_URL_QA_PROD;
        }

        if (currentOrigin.includes("dev") || currentOrigin.includes("pq")) {
            return DYNATRACE_URL_DEV_PQ;
        }

        return DYNATRACE_URL_DEV_PQ;
    };

    const loadDynatraceScript = () => {
        const script = document.createElement("script");
        script.src = getDynatraceUrlByEnvironment();
        script.async = true;
        script.crossOrigin = "anonymous";

        document.head.appendChild(script);
    };

    loadDynatraceScript();

    return {};
});