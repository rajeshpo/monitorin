// Application Name : Value Chain Monitoring Application
// Object Id       : ZBUVCM55155
// Release         : 1
// Version         : 0.01
// Description     : Value Chain Monitoring Application
// ----------------------------------------------------------------------------*
// Descriptions: Table and Views
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*
namespace jnj.com.zbuvcm55155;

using {
  cuid,
  managed
} from '@sap/cds/common';

/**
 * Represents header-level data for a Shipping Request.
 * Captures unique shipping request scenarios involving initial, reference,
 * and follow-on documents. Acts as the master entity for related line items,
 * attached documents, user comments, and location summaries.
 */
@assert.unique: {
  automation: [
    shippingReqNo,
    initialDocumentNo,
    referenceDocumentNo,
    followOnDocumentNo
  ],
  uniqueref     : [initialDocumentNo],
  shippingReqNo : [shippingReqNo]
}
entity ShippingRequest : cuid, managed {
  key shippingReqNo                       : String(18)  @Core.Computed  @description: 'Unique identifier for the Shipping Request (system generated)';
  key initialDocumentNo                   : String(10)  @description: 'Document number of the initial triggering document';
      initialDocumentType                 : String(50)  @description: 'Type of the initial document (e.g., Sales Order, Purchase Order)';
      referenceDocumentNo                 : String(35)  @description: 'Reference document number linked to the shipping request';
      followOnDocumentNo                  : String(20)  @description: 'Follow-on document number created during processing';
      status                              : String(11)  @description: 'Overall processing status of the Shipping Request';

      shipFromBusinessPartner             : String(10)  @description: 'Business Partner ID of the Ship-From location';
      shipFromPlant                       : String(10)  @description: 'Plant code of the Ship-From location';
      shipToBusinessPartner               : String(10)  @description: 'Business Partner ID of the Ship-To location';
      shipToPlant                         : String(10)  @description: 'Plant code of the Ship-To location';
      shipFromBusinessPartnerName         : String      @description: 'Name of the Ship-From Business Partner';
      shipFromPlantName                   : String      @description: 'Name of the Ship-From Plant';
      shipToBusinessPartnerName           : String      @description: 'Name of the Ship-To Business Partner';
      shipToPlantName                     : String      @description: 'Name of the Ship-To Plant';
      shipFromEr                          : String;
      shipFromeEoRegionName               : String;
      shipToEr                            : String;
      shipToeEoRegionName                 : String;

      requestedDeliveryDate               : Date        @description: 'Requested delivery date for the shipment';
      scenarioID                          : String(20)  @description: 'Scenario identifier used for determination logic';

      masterDataStatus                    : String(20)  @description: 'Validation status of master data';
      masterDataErrorDesciption           : String      @description: 'Detailed error message for master data validation';
      masterDataErrorCreationDate         : Timestamp   @description: 'Represents when error occured for master data check';
      masterDataErrorResolutionDate       : Timestamp   @description: 'Represents when error error resolved for master data';

      pfcCheckStatus                      : String(20)  @description: 'Product Flow Catalog check status';
      pfcCheckErrorDescription            : String(400) @description: 'Error message related to Product Flow Catalog validation';
      pfcCheckErrorCreationDate           : Timestamp   @description: 'Represents when pfc check error occured';
      pfcCheckErrorResolutionDate         : Timestamp   @description: 'Represents when error got resolved or created';

      scenarioDeterminationCheckStatus    : String(20)  @description: 'Status of scenario determination check';
      scenarioCheckStatusErrorDescription : String(400) @description: 'Error message related to scenario determination';
      scenarioCheckErrorCreationDate      : Timestamp   @description: 'Represents when scenario check error occured';
      scenarioCheckErrorResolutionDate    : Timestamp   @description: 'Respresents when scenario check error got resolved or created';


      docFlowStateCheckStatus             : String(20)  @description: 'Status of document flow state validation';
      wfInstanceId                        : String(80)  @description: 'Workflow instance ID triggered for this shipping request';
      productFlowCatalogID                : String(14)  @description: 'Identifier of the Product Flow Catalog linked to this request';
      productFlowID                       : String      @description: 'Unique Product Flow ID associated with the scenario';

      creationDate                        : Timestamp   @description: 'Date when the shipping request was created';
      userName                            : String(20)  @description: 'User ID of the person who created the request';
      // --- Compositions ---
      items                               : Composition of many ShippingRequestItem
                                              on items.parent = $self
                                                        @description: 'List of Material details for this Shipping Request';

      entity                              : Composition of many ShippingRequestEntityDocs
                                              on entity.parent = $self
                                                        @description: 'List of documents generated for this request';

      comments                            : Composition of many Comments
                                              on comments.parent = $self
                                                        @description: 'User comments and logs linked to this request';

      to_Locations                        : Composition of many ShippingRequestEntityLocationSummary
                                              on to_Locations.shippingReqNo = shippingReqNo
                                                        @description: 'Location summary details for this shipping request';

      to_prereqStatus                     : Composition of many ShippingRequestPrereqStatus
                                              on to_prereqStatus.shippingReqNo = $self.shippingReqNo
                                                        @description: 'Prerequisite checks and statuses for this request';

      allErrorLogs                        : Composition of many ShippingRequestWithErrors
                                              on allErrorLogs.shippingReqNo = shippingReqNo
                                                        @description: 'Consolidated error logs for this Shipping Request';
      followToDocuments                   : Association to many ShippingRequestEntityFollowOnDocs
                                              on  followToDocuments.initialDocumentNo = initialDocumentNo
                                              and followToDocuments.shippingReqNo     = shippingReqNo;
      //Open Items JGHJ-87133 R2.2 change start
      asnOrphans                          : Association to many asnOrphanDocs
                                              on asnOrphans.initialDocumentNo = initialDocumentNo;
      //Open Items JGHJ-87133 R2.2 change end
      changeEvents                        : Association to many ShippingRequestQueue
                                              on changeEvents.parentPO = initialDocumentNo;                             
}


/**
 * Represents document-level data linked to a Shipping Request.
 * Captures follow-on documents, business entities, statuses, and errors
 * that form part of the overall shipping request process.
 * Acts as a child entity of ShippingRequest and stores transactional
 * and validation details such as error logs, document sequences,
 * and associated business partners, plants, and eco-regions.
 */
entity ShippingRequestEntityDocs : cuid, managed {
          parent                 : Association to ShippingRequest @UI.Hidden;

          followOnDocumentNo     : String(20)                     @(title     : '{i18n>FollowonDocumentNumber}')                  @description        : 'Reference GR or follow-on document number';
          documentType           : String(60)                     @description: 'Document Type (e.g., Sales Order, Purchase Order)';
          documentNumber         : String(20) @UI : { Hidden }                     @description: 'Document Number';
          errorStatus            : String(20) default 'Pending'   @description: 'Error Status Code';
          errorDescription       : String                         @description: 'Document error description or remarks';
          wfInstanceId           : String(80)                     @UI.Hidden                                                      @description        : 'Workflow Instance ID for tracking and retriggering the flow';
          errorCreationDate      : Timestamp                           @description: 'Date when the error was created';
          creationDate           : Timestamp                           @description: 'General creation date of the record';
          // createdAT      : Date                           @description: 'General creation date of the record';
          errorResolutionDate    : Timestamp                           @description: 'Date when the document error was resolved'       @title              : 'Error Resolution Date';
          entityType             : String(20)                     @(title     : '{i18n>entityType}')                              @description        : 'Type of business entity (e.g., SF, ST)';
          entityRank             : Integer                        @UI.Hidden                                                      @description        : 'Rank or order of the entity within the flow';
          documentSequence       : Integer                        @(title     : '{i18n>documentSequence}')                        @description        : 'Sequence of the document in the process flow';
          ecoRegion              : String(10)                     @description: 'Eco region or regional code'                     @title              : 'Eco Region';
          businessPartnerId      : String(10)                     @description: 'Business Partner ID (customer/vendor)'           @title              : 'Business Partner';
          plant                  : String(10)                     @description: 'Plant identifier';
          bpName                 : String                         @description: 'Business Partner name'                           @title              : 'Business Partner Name';
          plantName              : String                         @description: 'Plant name'                                      @title              : 'Plant Name';
          ecoRegionName          : String                         @description: 'Eco region descriptive name'                     @title              : 'Eco Region Name';
          legalEntity            : String(20)                     @description: 'Legal entity';
          documentYear           : String                         @description: 'Document year (used in reporting/partitioning)'  @title              : 'Document Year';
          isAT                   : Boolean default false          @UI.Hidden                                                      @description        : 'Flag for AT documents (if applicable)';
          isExceptionalDocument  : Boolean default false          @UI.Hidden                                                      @Common.FieldControl: #Hidden  @description: 'Flag for exceptional documents (hidden in UI)';

  virtual errorStatusCriticality : Integer default 2              @UI.Hidden                                                      @description        : 'Derived criticality level of the error status';
          transactionDesc        : String;

          @(title: '{i18n>transactionDesc}')
          action                 : String;

          errors                 : Composition of many ShippingRequestErrors
                                     on errors.parent = $self
          //R2.2 Start
                                                                  @description: 'Errors occured in the process for this document';
          vcaAction              : String(1)
                                                                  @(title     : '{i18n>DocumentAction}')
                                                                  @description: 'Document action from Scenario Determination (A/M/I)';
          vcaDocSystem           : String(12)
                                                                  @(title     : '{i18n>DocumentSystem}')
                                                                  @description: 'Source system where document was created (S/4 or Legacy)';
          stepID                 : String;
          //R2.2 END
          

}

entity ShippingRequestEntityFollowOnDocs : cuid, managed {
  key shippingReqNo       : String(18)  @Core.Computed  @description: 'Unique identifier for the Shipping Request (system generated)';
  key initialDocumentNo   : String(10)  @description: 'Document number of the initial triggering document';
  key followOnDocumentNo  : String(20);
  key itemNo              : String      @description: 'Item Number';
      materialNumber      : String      @description: 'Material Number';
      materialDescription : String      @description: 'Detailed description of the material';
      quantity            : String      @description: 'Quantity of material requested/shipped';
      uom                 : String      @description: 'Unit of Measure (e.g., EA, KG, L)';
      batchNumber         : String      @description: 'Batch number for traceability of the material';
}



/**
 * Represents item-level details of a Shipping Request.
 * Captures material-specific information such as type, brand, quantity,
 * and batch. Acts as a child entity of ShippingRequest, holding
 * transactional line items for each request.
 */
entity ShippingRequestItem : cuid, managed {
  parent              : Association to ShippingRequest;

  followOnDocumentNo  : String(20)         @description: 'Reference GR or follow-on document number'  @title: 'Reference Document Number';
  itemNo              : String(20)         @description: 'Item number';
  materialNumber      : String             @description: 'Material Number';
  materialType        : String             @description: 'Type/category of the material';
  materialBrand       : String             @description: 'Brand associated with the material';
  materialDescription : String             @description: 'Detailed description of the material';
  quantity            : String             @description: 'Quantity of material requested/shipped';
  uom                 : String             @description: 'Unit of Measure (e.g., EA, KG, L)';
  batchNumber         : String             @description: 'Batch number for traceability of the material';
  status              : String default 'A' @description: 'Status representing Active or Inactive';

  AF_FZ_Mat           : String(20);
  RETAINBAG_Mat       : String(20);
  AF_FRSH_Mat         : String(20);
  // JGHJ-89513 R2.2 change start
  requestedDeliveryDate               : String        @description: 'Requested delivery date for the item';
  // JGHJ-89513 R2.2 change end

}

entity PoLock {
  key parentPO : String;
}

entity ShippingRequestQueue : cuid, managed {
  parentPO        : String;
  itemNo          : String;

  actionType      : String;        // CANCEL / UNCANCEL / UPDATE

  queueNo         : Integer;       // per PO sequence (1,2,3…)
  status          : String(50);    // P, IP, C, E
  quantity        : String;
  deliveryDate    : String;
  errorMessage    : String;
  wfInstanceId      : String(80)                               @description: 'Workflow Instance ID associated with this error, if available';
  virtual statusCriticality : Integer;
  errors       : Composition of many QueueRequestErrors
                   on errors.parent = $self;
}

entity QueueRequestErrors : cuid, managed {

  parent              : Association to ShippingRequestQueue @description: 'Reference to the parent Shipping Request Entity Document';
  errorMessage        : String                              @description: 'Error status of the document flow (e.g., Pending, Error, Resolved)';
  errorType           : String(100)                         @description: 'Type or category of the error (e.g., Master Data, PFC Check, Scenario)';
  timeStamp           : String                              @description: 'Timestamp indicating when the error was logged';
  wfInstanceId        : String(80)                          @description: 'Workflow Instance ID associated with this error, if available';
  virtual Criticality : Integer                             @description: 'UI criticality indicator for highlighting error severity';
}

/**
 * Represents user comments or notes linked to a Shipping Request.
 * Acts as a child entity, allowing multiple remarks, explanations, or
 * justifications to be stored against a single request.
 */
entity Comments : cuid, managed {
  parent   : Association to ShippingRequest @description: 'Reference to the parent Shipping Request';
  comments : String(500)                    @description: 'User-entered remarks or notes related to the Shipping Request';
}


/**
 * Represents error log details for a Shipping Request document.
 * Captures error status, type, and workflow instance information.
 * Acts as a child entity of ShippingRequestEntityDocs,
 * allowing multiple errors to be tracked for a single document.
 */
entity ShippingRequestErrors : cuid, managed {

          parent            : Association to ShippingRequestEntityDocs @description: 'Reference to the parent Shipping Request Entity Document';
          vcaErrorStatus    : String                                   @description: 'Error status of the document flow (e.g., Pending, Error, Resolved)';
          vcaErrorType      : String(100)                              @description: 'Type or category of the error (e.g., Master Data, PFC Check, Scenario)';
          vcaErrorTimeStamp : Timestamp                                @description: 'Timestamp indicating when the error was logged';
          wfInstanceId      : String(80)                               @description: 'Workflow Instance ID associated with this error, if available';
  virtual Criticality       : Integer                                  @description: 'UI criticality indicator for highlighting error severity';
}

//start - R2.2 Non VCA 76044
/**
* Configuration table for Non-VCA automation
* Drives sequence-based document creation logic
*/
@assert.unique: {
  NonVCA_unique: [
  scenarioID,
  process,
  sequence
]}
entity NonVCAScenarioConfig: cuid, managed {
  key scenarioID : String(10); // S1, S2
  key process    : String(20); // ASN, CBACK
  key sequence   : Integer; // Execution order
      variation  : Integer;
      step       : String(40); // SO, OBD, PO, IBD, SIT
      stepID     : String;
      action     : String(1); // L / I / A
      entityType : String(10);
}
//End - R2.2 Non VCA 76044

/**
 * Provides a summarized view of location-level details for a Shipping Request.
 * Aggregates data from ShippingRequestEntityDocs by grouping on key location-related
 * attributes such as entity type, legal entity, eco region, business partner, and plant.
 *
 * This view is primarily used for:
 *  - Displaying summarized location information in the Object Page
 *  - Supporting navigation and reporting of entity locations involved in a request
 */
view ShippingRequestEntityLocationSummary as
  select from ShippingRequestEntityDocs {
    key parent.shippingReqNo as shippingReqNo,
    key entityType,
    key legalEntity,
    key ecoRegion,
    key businessPartnerId,
    key plant,
    key entityRank,
    key bpName,
    key plantName
  // key documentSequence
  }
  group by
    parent.shippingReqNo,
    entityType,
    legalEntity,
    ecoRegion,
    businessPartnerId,
    plant,
    entityRank,
    bpName,
    plantName

  // documentSequence
  order by
    entityRank;
// documentSequence

/**
 * View: ShippingRequestWithErrors
 * Purpose: Combines ShippingRequest, related ShippingRequestEntityDocs, and ShippingRequestErrors into a single view
 * This allows easy access to all error-related information for a shipping request and its documents.
 */

// view ShippingRequestWithErrors as
//   select from ShippingRequest as sr
//   left outer join ShippingRequestEntityDocs as edoc
//     on edoc.parent.shippingReqNo = sr.shippingReqNo
//   inner join ShippingRequestErrors as err
//     on err.parent.ID = edoc.ID
//     or err.parent.ID = sr.ID
//   {
//         // Keys from ShippingRequest
//     key sr.shippingReqNo as shippingReqNo,
//     key err.parent.ID    as errParentID,
//     key sr.ID            as SRID,
//     key sr.initialDocumentNo,
//     key err.ID,

//         // Fields from ShippingRequest
//         // sr.referenceDocumentNo,
//         // sr.followOnDocumentNo,
//         // sr.status,
//         // sr.requestedDeliveryDate,
//         // sr.productFlowCatalogID,
//         // sr.productFlowID,

//         // Fields from EntityDocs

//         edoc.documentType,
//         edoc.documentNumber,

//         @UI.Hidden
//         edoc.errorStatus,
//         @UI.Hidden

//         edoc.errorDescription,
//         edoc.errorCreationDate,
//         edoc.errorResolutionDate @(title: '{i18n>ErrorResolutionDate}'),
//         // edoc.entityType,
//         // edoc.entityRank,
//         @UI.Hidden

//         edoc.documentSequence,

//         // Fields from Errors
//         err.vcaErrorStatus,
//         err.vcaErrorType,
//         @UI.Hidden

//         err.vcaErrorTimeStamp,
//         @UI.Hidden

//         err.Criticality,
//         err.createdAt,

//   }


view ShippingRequestWithErrors as

/* ===================================================== */
/* =============== DOCUMENT LEVEL ERRORS =============== */
/* ===================================================== */

select from ShippingRequest as sr
    inner join ShippingRequestEntityDocs as edoc
        on edoc.parent.shippingReqNo = sr.shippingReqNo
    inner join ShippingRequestErrors as err
        on err.parent.ID = edoc.ID
{
    /* ------------ Keys ------------ */
    key sr.shippingReqNo as shippingReqNo,
    key edoc.ID    as errParentID,
    key sr.ID            as SRID,
    key sr.initialDocumentNo,
    key err.ID,

    /* ------------ EntityDocs ------------ */
    edoc.documentType,
    edoc.documentNumber,
    edoc.followOnDocumentNo,

    @UI.Hidden
    edoc.errorStatus,

    @UI.Hidden
    edoc.errorDescription,

    edoc.errorCreationDate,
    edoc.errorResolutionDate @(title: '{i18n>ErrorResolutionDate}'),

    @UI.Hidden
    edoc.documentSequence,

    /* ------------ Errors ------------ */
    err.vcaErrorStatus,
    err.vcaErrorType,

    @UI.Hidden
    err.vcaErrorTimeStamp,

    @UI.Hidden
    err.Criticality,

    err.createdAt
}

union all


/* ===================================================== */
/* ================= HEADER LEVEL ERRORS =============== */
/* ===================================================== */

select from ShippingRequest as sr
    inner join ShippingRequestErrors as err
        on err.parent.ID = sr.ID
{
    /* ------------ Keys ------------ */
    key sr.shippingReqNo as shippingReqNo,
    key err.parent.ID    as errParentID,
    key sr.ID            as SRID,
    key sr.initialDocumentNo,
    key err.ID,

    /* ------------ No EntityDoc → cast NULL ------------ */
    cast(null as String(40)) as documentType,
    cast(null as String(40)) as documentNumber,
    cast(null as String(20)) as followOnDocumentNo,

    @UI.Hidden
    cast(null as String(10)) as errorStatus,

    @UI.Hidden
    cast(null as String(500)) as errorDescription,

    err.vcaErrorTimeStamp as errorCreationDate,

    cast(null as Timestamp)
        as errorResolutionDate @(title: '{i18n>ErrorResolutionDate}'),

    @UI.Hidden
    cast(0 as Integer) as documentSequence,

    /* ------------ Errors ------------ */
    err.vcaErrorStatus,
    err.vcaErrorType,

    @UI.Hidden
    err.vcaErrorTimeStamp,

    @UI.Hidden
    err.Criticality,

    err.createdAt
};

/**
 * Enriched view of Shipping Requests with "Ship From" and "Ship To" details.
 * Joins ShippingRequest with its related ShippingRequestEntityDocs to extract:
 *  - The first "Ship From" entity (lowest documentSequence)
 *  - The first "Ship To" entity (lowest documentSequence)
 * This view provides a convenient, denormalized dataset for UI consumption exposing both header-level and
 * location-level details in a single structure.
 */
view ShippingRequestWithLocations as
  select from ShippingRequest as sr
  left outer join (
    select from ShippingRequestEntityDocs
    where
      entityType = 'Ship From'
    order by
      documentSequence asc
    limit 1
  ) as sf
    on sf.parent.shippingReqNo = sr.shippingReqNo
  left outer join (
    select from ShippingRequestEntityDocs
    where
      entityType = 'Ship To'
    order by
      documentSequence asc
    limit 1
  ) as st
    on st.parent.shippingReqNo = sr.shippingReqNo
  {
        @UI.HiddenFilter: true
    key sr.ID,
        @title          : '{i18n>Shippingreqno}'
    key sr.shippingReqNo,
        sr.referenceDocumentNo,
    key sr.initialDocumentNo,
        @title          : '{i18n>FollowOnDocumentNumber}'
        sr.followOnDocumentNo,
        @title          : '{i18n>IntialDocumentType}'
        sr.initialDocumentType,
        sr.status,
        @UI.Hidden
        @UI.HiddenFilter: true
        sr.statusCriticality,
        @UI.Hidden
        @UI.HiddenFilter: true

        sr.priority,
        @UI.Hidden
        @UI.HiddenFilter: true
        sr.Criticality,

        @title          : '{i18n>RequestedDeliveryDate}'
        sr.requestedDeliveryDate,

        @title          : '{i18n>ScenarioID}'
        sr.scenarioID,

        @title          : '{i18n>ProductFlowCatalogID}'
        sr.productFlowCatalogID,

        @title          : '{i18n>ProductFlowID}'
        sr.productFlowID,

        @title          : '{i18n>UserID}'
        sr.userName,
        @UI.HiddenFilter: true
        @UI.Hidden
        sr.masterDataStatus,
        @UI.HiddenFilter: true
        @UI.Hidden
        sr.pfcCheckStatus,
        @UI.HiddenFilter: true
        @UI.Hidden
        sr.scenarioDeterminationCheckStatus,
        @UI.HiddenFilter: true
        @UI.Hidden
        sr.docFlowStateCheckStatus,
        @UI.HiddenFilter: true
        @UI.Hidden
        sr.mainCheckCriticality,
        sr.shipFromBusinessPartner,
        sr.shipFromPlant,
        sr.shipToBusinessPartner,
        sr.shipToPlant,
        @UI.Hidden
        @UI.HiddenFilter: true
        sr.pfcState,
        @UI.Hidden
        @UI.HiddenFilter: true
        sr.masterDataState,
        @UI.Hidden
        @UI.HiddenFilter: true
        sr.scenarioState,
        @UI.Hidden
        @UI.HiddenFilter: true

        sr.docFlowState,
        @UI.HiddenFilter: false
        sr.createdBy,
        @UI.HiddenFilter: false
        sr.createdAt,

        // Ship From Info
        @UI.HiddenFilter: true
        sf.errorStatusCriticality,
        // sf.businessPartnerId as shipFromBusinessPartner,
        // sf.plant             as shipFromPlant,

        @title          : '{i18n>ShipFromEcoRegion}'
        sf.ecoRegion   as shipFromEcoRegion,

        @title          : '{i18n>ShipFromLegalEntity}'
        sf.legalEntity as shipFromLegalEntity,


        // Ship To Info
        // st.businessPartnerId as shipToBusinessPartner,
        // st.plant             as shipToPlant,

        @title          : '{i18n>ShipToEcoRegion}'
        st.ecoRegion   as shipToEcoRegion,

        @title          : '{i18n>ShipToLegalEntity}'
        st.legalEntity as shipToLegalEntity,

        sr.items,
        sr.entity,
        sr.comments,
        sr.to_Locations,
        sr.to_prereqStatus,
        sr.allErrorLogs,
        sr.followToDocuments,
        sr.changeEvents,
        //Open Items JGHJ-87133 R2.2 change start
        sr.asnOrphans
        //Open Items JGHJ-87133 R2.2 change end

  }

/**
 * Extension of ShippingRequest with virtual and computed fields.
 * These fields are primarily used for UI representation,
 * providing computed status and priority indicators
 * without persisting them in the database.
 */
extend ShippingRequest {
  virtual statusCriticality    : Integer;
  virtual priority             : String(10) @Core.Computed;
  virtual Criticality          : Integer;
  virtual pfcState             : String;
  virtual scenarioState        : String;
  virtual masterDataState      : String;
  virtual docFlowState         : String;
  virtual mainCheckCriticality : Integer;
}

/**
 * Value Help (VH) view for Shipping Requests.Provides a distinct list of Shipping Request identifiers
 * for use in search helps, dropdowns, or input validations.
 * Only non-null Shipping Requests are considered.
 */
view ShippingRequest_VH as
  select from ShippingRequest {
    shippingReqNo
  }
  where
    shippingReqNo is not null
  group by
    shippingReqNo;

view ShippingRequest_VH1 as
  select from ShippingRequest {
    initialDocumentNo
  }
  where
    initialDocumentNo is not null
  group by
    initialDocumentNo;

view ShippingRequest_VH2 as
  select from ShippingRequest {
    referenceDocumentNo
  }
  where
    referenceDocumentNo is not null
  group by
    referenceDocumentNo;


/** View: ShippingRequestPrereqStatus
* Purpose: Flatten multiple prerequisite checks of a ShippingRequest into a single unified view
* Each check type (PFC, Scenario, Master Data) is represented as a separate row per shippingReqNo
* Includes status, error description, criticality, and a sort order for ordering rows
**/
view ShippingRequestPrereqStatus as
    select from ShippingRequest {
      key shippingReqNo                                  @(title: '{i18n>Shippingreqno}'),

      key cast(
            'pfcCheck' as String(30)
          )                           as checkType       @UI.Hidden,
          cast(
            'PFC Check' as String(50)
          )                           as checkLabel,
          pfcCheckStatus              as status,
          pfcCheckErrorDescription    as errorDescription,
          mainCheckCriticality        as mainCriticality @UI.Hidden,
          pfcCheckErrorCreationDate   as errorCreationDate,
          pfcCheckErrorResolutionDate as errorResolutionDate,


          cast(
            1 as Integer
          )                           as sortOrder       @UI.Hidden
    }
  union all
    select from ShippingRequest {
      key shippingReqNo,
      key cast(
            'scenarioCheck' as String(30)
          )                                   as checkType       @UI.Hidden,
          cast(
            'Scenario Check' as String(50)
          )                                   as checkLabel,
          scenarioDeterminationCheckStatus    as status,
          scenarioCheckStatusErrorDescription as errorDescription,
          mainCheckCriticality                as mainCriticality @UI.Hidden,
          scenarioCheckErrorCreationDate      as errorCreationDate,
          scenarioCheckErrorResolutionDate    as errorResolutionDate,

          cast(
            2 as Integer
          )                                   as sortOrder       @UI.Hidden
    }
  union all
    select from ShippingRequest {
      key shippingReqNo,
      key cast(
            'masterdataCheck' as String(30)
          )                             as checkType       @UI.Hidden,
          cast(
            'Master Data Check' as String(50)
          )                             as checkLabel,
          masterDataStatus              as status,
          masterDataErrorDesciption     as errorDescription,
          mainCheckCriticality          as mainCriticality @UI.Hidden,
          masterDataErrorCreationDate   as errorCreationDate,
          masterDataErrorResolutionDate as errorResolutionDate,

          cast(
            3 as Integer
          )                             as sortOrder       @UI.Hidden
    }
    order by
      sortOrder;

@assert.unique: {
    EmailNotify_unique: [
        Email,
        type
    ]
}
entity EmailNotify : cuid, managed {
      Email : String @description: 'Email Address';
  key type  : String @description: 'Type';
}

//Open Items JGHJ-87133 R2.2 change start
/**
 * Represents ASN orphan Document data
 * Captures unique legacy Doc number and Workflow IDs triggered from SBPA
 * Utilized for retrigger background job logic
 */
@assert.unique: {asnOrphanDocs_unique: [legacyDocNum]}
entity asnOrphanDocs : cuid, managed {
  legacyRefDocNum   : String @description: 'Reference Document Legacy Intercompany/Intracompany SO/PO';
  legacyDocNum      : String @description: 'Reference Document Legacy Outbound Delivery';
  workflowID        : String @description: 'SBPA Workflow Instance ID';
  initialDocumentNo : String @description: 'Initial Document Number of the related Shipping Request';
  error             : String @description: 'ASN validation error messages, multiple entries separated by newline';
}
//Open Items JGHJ-87133 R2.2 change end