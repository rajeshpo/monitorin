// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Value Chain Monitoring App
// Object Id       : ZBUVCM55155
// Release         : 1
// Version         : 0.01
// Description     : Value Chain Monitoring App
// ----------------------------------------------------------------------------*
// Descriptions: Provides service definitions, handlers, and utility functions for the Value Chain Monitoring Application.
// This module handles custom actions, and external API integration for managing Value Chain Monitoring Application// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
//  12/08/2026        ASS4       JGHJ-103722     Addition of Ship From Ship To From Header if it is not present in general info
// -------------------------------------------------------------------------------------------------------------------------*

const cds = require('@sap/cds');
const constants = require('./config/constants');
const logger = cds.log('vcm55155-program');
const dbOps = require('./operations/dbOps');
const textBundle = require('./_i18n/textBundle');
const utils = require('./utils/utils');
const {sendASNMail} = require('./operations/errormail');
const { log } = require('@sap/cds');

module.exports = async (srv) => {

  const { ShippingRequestEntityDocs, ShippingRequestErrors, ShippingRequest, ShippingRequestQueue, ShippingRequestItem, PoLock, ShippingRequestEntityFollowOnDocs, QueueRequestErrors} = cds.entities('jnj.com.zbuvcm55155')


  /**
   * Establishes a connection to the external service ZSD_VCM_PRODUCTFLOW
   * This service is used to handle various product flow related entity reads
   */
  let ZSD_VCM_PRODUCTFLOW = '';
  let ZUI_BILLINGDOCUMENTFS = '';

  try {

    // Connect to the abap service
    ZSD_VCM_PRODUCTFLOW = await cds.connect.to("ZSD_VCM_PRODUCTFLOW");
    ZUI_BILLINGDOCUMENTFS = await cds.connect.to("ZUI_BILLINGDOCUMENTFS");
  } catch (error) {
    logger.error(`${constants.BTPLoging}  ${constants.PFError}`, error.message);
    throw new Error(constants.DBErrorFail);
  }

  /**
 * Service handler for READ I_Type_VH
 * Returns Type constants directly without calling external service
 * URL: /zbuvcm55155/I_Type_VH
 */
  srv.on('READ', 'I_Type_VH', async (req) => {
    return constants.TypeDL;
  });

  /**
 * Email validation rules for EmailNotify entity:
 *  - CREATE → Email required (cannot be empty).
 *  - UPDATE → If Email is empty, keep old value.
 *  - Validate format of each email.
 *  - Reject duplicates (case-insensitive).
 *  - Save normalized comma-separated list.
 */
  srv.before(["CREATE", "UPDATE"], 'emailNotifyEntity', async (req) => {
    // If CREATE and Email is missing then throw error
    if (req.event === "CREATE" && (!req.data.Email || req.data.Email.trim() === "")) {
      return req.error(400, "Email field cannot be empty on creation.");
    }

    // If UPDATE and Email is empty → keep old value
    if (req.event === "UPDATE" && (!req.data.Email || req.data.Email.trim() === "")) {
      const existing = await SELECT.one.from('EmailNotify').where({ ID: req.data.ID });
      if (existing?.Email) {
        req.data.Email = existing.Email; // restore old value
      } else {
        return req.error(400, "No previous Email found. Cannot set empty.");
      }
      return;
    }

    // Split and trim
    const emails = req.data.Email.split(",").map(e => e.trim());

    // Regex for email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Find invalid emails
    const invalidEmails = emails.filter(e => !emailRegex.test(e));

    if (invalidEmails.length > 0) {
      return req.error(400, `Invalid email(s): ${invalidEmails.join(", ")}`);
    }

    // Check duplicates
    const uniqueEmails = new Set(emails);
    if (uniqueEmails.size !== emails.length) {
      return req.error(400, "Duplicate emails are not allowed.");
    }

    // Normalize back
    req.data.Email = Array.from(uniqueEmails).join(", ");
  });



  // READ handler for ShippingRequestWithErrors
  // - Excludes rows with vcaErrorType = 'Success'
  // - Sorts by errorCreationDate (latest first)

  srv.on('READ', 'ShippingRequestWithErrors', async (req, next) => {
    try {
      const { SELECT } = req.query;

      // Add filter: exclude vcaErrorType = 'Success'
      if (!SELECT.where) SELECT.where = [];
      SELECT.where.push({ ref: ['vcaErrorType'] }, '!=', { val: 'Success' });

      // Add sort: latest createdAt errorCreationDate first (default only — respect user sort)
       const hasUserSort = SELECT.orderBy?.some(o => o.implicit !== true);
      if (!hasUserSort) {
      SELECT.orderBy = [{ ref: ['createdAt'], sort: 'desc' }];
      }
      let a = await next()

      // // Deduplicate by parent_ID
      // const unique = [];
      // const seen = new Set();
      // for (let r of a) {
      //   if (!seen.has(r.ID)) {
      //     seen.add(r.ID);

      //     unique.push(r);
      //   }
      // }
      // for (let r of unique) {
      //   if (r.SRID && r.errParentID && r.SRID === r.errParentID) {
      //     r.documentType = null;
      //   }
      // }

      return a;

    } catch (err) {
      req.error(500, `Error fetching ShippingRequestWithErrors: ${err.message}`);
    }
  });

  /**
  * Service handler for getting material
  * URL:https://{host}:{port}/zbuvcm55155/ShippingRequestView()/getMaterialData()
 */
  srv.on('getMaterialData', async (req) => {
    const { ShippingRequestItem } = cds.entities;

    let { initialDocumentNo, shippingReqNo } = req.data
    // Fetch entity doc record
    const getMaterialData = await SELECT.one.from(ShippingRequestItem).where({ "parent_initialDocumentNo": initialDocumentNo, "parent_shippingReqNo": shippingReqNo, "status": "A" });
    if (!getMaterialData) {
      throw new Error(bundle.getText('NoDataFound'));
    }
    return getMaterialData
  })


  /**
   * Service handler for Adding Comments to Shipping Request 
   * New comments are updated in Hana DB from UI
   * based on odata http request
   * URL:https://{host}:{port}/zbuvcm55155/ShippingRequestView()/addComments()
  */
  srv.on('addComment', 'ShippingRequestView', async (req) => {
    logger.info('-----------addComment------------')
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    const { shippingReqNo, initialDocumentNo, ID } = req.params[0];

    try {
      await dbOps.addComment({
        comment: req.data.comment,
        ID,
        shippingReqNo,
        initialDocumentNo,
        bundle
      });
      logger.info(bundle.getText('CommentsAdded'));
    } catch (error) {
      logger.error(error);
      req.error(400, bundle.getText('FailedToAddComment'));
    }
  });

  /**
 * Service handler for READ ShippingRequestErrors
 * Forwards the query to CAP runtime
 * Then enriches results with Criticality
 */
  srv.after('each', 'ShippingRequestErrors', data => {
    switch (data.vcaErrorType) {
      case 'Error':
        data.Criticality = 1; // Red icon
        break;
      case 'Warning':
        data.Criticality = 2; // Yellow icon
        break;
      case 'Success':
        data.Criticality = 3; // Green/success
        break;
      default:
        data.Criticality = 0; // None
    }
  }
  );


  /**
   * Service handler for READ ShippingRequestPrereqStatus
   * Enhances the results after CAP has executed the query
   **/
  srv.after('READ', 'ShippingRequestPrereqStatus', (rows) => {
    if (!Array.isArray(rows)) return rows;

    // Define fixed order for checkType
    const orderMap = {
      pfcCheck: 1,
      scenarioCheck: 2,
      masterdataCheck: 3
    };

    rows.sort((a, b) => {
      // Sort first by shippingReqNo
      const byReq = String(a.shippingReqNo).localeCompare(String(b.shippingReqNo));
      if (byReq !== 0) return byReq;

      // Then by defined order
      const aOrder = orderMap[a.checkType] ?? 99;
      const bOrder = orderMap[b.checkType] ?? 99;
      return aOrder - bOrder;
    });

    rows.map(row => {
      if (row.status === "Error") {
        row.mainCriticality = 1
      } else if (row.status === "Warning" || row.status === 'Retriggered') {
        row.mainCriticality = 2
      } else if (row.status === "Success") {
        row.mainCriticality = 3
      }
      else {
        row.mainCriticality = 0
      }
    })

    return rows;
  });

 /**
 * On READ handler for ShippingRequestPrereqStatus
 * Maps error type, error description, and workflow instance ID to the underlying ShippingRequest table
 */

  srv.on('READ', 'ShippingRequestPrereqStatus', async (req, next) => {
    try {

      logger.info('READ ShippingRequestPrereqStatus triggered');

      const data = await next();

      logger.info(`Fetched ${data.length} rows from ShippingRequestPrereqStatus`);

      const checkConfig = {
        pfcCheck: {
          statusField: 'pfcCheckStatus',
          errorField: 'pfcCheckErrorDescription',
          dateField: 'pfcCheckErrorCreationDate'
        },
        scenarioCheck: {
          statusField: 'scenarioDeterminationCheckStatus',
          errorField: 'scenarioCheckStatusErrorDescription',
          dateField: 'scenarioCheckErrorCreationDate'
        },
        masterdataCheck: {
          statusField: 'masterDataStatus',
          errorField: 'masterDataErrorDesciption',
          dateField: 'masterDataErrorCreationDate'
        }
      };

      const prerequisites = {
        pfcCheck: null,

        scenarioCheck: {
          field: 'pfcCheckStatus',
          value: 'Success'
        },

        masterdataCheck: {
          field: 'scenarioDeterminationCheckStatus',
          value: 'Success'
        }
      };

      for (const row of data) {

        const shouldProcess =
          !row.status ||
          row.status.trim() === '' ||
          row.status === "Retriggered";

        if (!shouldProcess) {
          continue;
        }

        const shippingRequest = await SELECT.one
          .from(ShippingRequest)
          .columns('ID', 'wfInstanceId', 'pfcCheckStatus', 'scenarioDeterminationCheckStatus', 'masterDataStatus')
          .where({
            shippingReqNo: row.shippingReqNo
          });

        if (!shippingRequest?.wfInstanceId) {

          const workflow = await cds.connect.to("workflowService");

          let poTrigger = 'us10.jnj-im-dev-na.zvcm47421potriggerflowproject.zVCM47421_POTriggerFlowProcess';
          let businessKeypoTrigger = shippingRequest.initialDocumentNo;


          const subProcessResponses = await workflow.send({
            method: "GET",
            path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businessKeypoTrigger}&definitionId=${poTrigger}&$orderby=startedAt desc`
          });

          const subProcessResponse = subProcessResponses[0]

          if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
            logger.info("PO Trigger instance found")

            await UPDATE(ShippingRequest)
              .set({
                pfcCheckStatus: "Error",
                pfcCheckErrorDescription: "Technical Error",
                pfcCheckErrorCreationDate: new Date(),
                wfInstanceId: subProcessResponse?.id
              })
              .where({
                ID: ShippingRequest?.ID
              });

            await INSERT.into(ShippingRequestErrors).entries({
              ID: cds.utils.uuid(),
              parent_ID: shippingRequest.ID,
              vcaErrorStatus: "Technical Error",
              vcaErrorType: "Error",
              wfInstanceId: shippingRequest.wfInstanceId,
              vcaErrorTimeStamp: new Date()
            });

            logger.info(
              `Technical error generated for ${row.checkType} - Shipping Request ${shippingRequest.ID}`
            );
          }

          continue;
        }

        const prerequisite = prerequisites[row.checkType];

        if (prerequisite) {
          if (shippingRequest[prerequisite.field] !== prerequisite.value) {
            logger.info(
              `Skipping Technical Error update for ${row.checkType}. ` +
              `Prerequisite ${prerequisite.field} = '${shippingRequest[prerequisite.field]}'`
            );
            continue;
          }
        }

        const rootInstanceId = await utils.checkSubprocessWorkflowStatus(
          shippingRequest.wfInstanceId,
          shippingRequest.ID
        );

        if (!rootInstanceId) {
          continue;
        }

        const config = checkConfig[row.checkType];

        if (!config) {
          continue;
        }

        await UPDATE(ShippingRequest)
          .set({
            [config.statusField]: "Error",
            [config.errorField]: "Technical Error",
            [config.dateField]: new Date()
          })
          .where({
            ID: shippingRequest.ID
          });

        await INSERT.into(ShippingRequestErrors).entries({
          ID: cds.utils.uuid(),
          parent_ID: shippingRequest.ID,
          vcaErrorStatus: "Technical Error",
          vcaErrorType: "Error",
          wfInstanceId: shippingRequest.wfInstanceId,
          vcaErrorTimeStamp: new Date()
        });

        logger.info(
          `Technical error generated for ${row.checkType} - Shipping Request ${shippingRequest.ID}`
        );
      }

      return data;

    } catch (err) {
      req.error(500, `Error fetching ShippingRequestPrereqStatus: ${err.message}`);
    }
  });


  /**
 * On READ handler for ShippingRequestWithErrors
 * Maps error type values to Criticality levels
 */

  srv.on('READ', 'ShippingRequestWithErrors', async (req, next) => {
    try {
      const { SELECT } = req.query;

      // --- Ensure vcaErrorTimeStamp is always included ---
      if (SELECT?.columns) {
        const mustHave = ['vcaErrorTimeStamp'];
        mustHave.forEach(field => {
          if (!SELECT.columns.some(c => c.ref?.[0] === field)) {
            SELECT.columns.push({ ref: [field] });
          }
        });
      }

      // --- Fetch data from next handler (actual DB read) ---
      let rows = await next();
      if (!Array.isArray(rows)) return rows;

      // --- Post-process each row ---
      rows.forEach(row => {
        // Map vcaErrorTimeStamp → errorCreationDate (per-record timestamp, always takes precedence)
        if (row.vcaErrorTimeStamp) {
          row.errorCreationDate = row.vcaErrorTimeStamp;
        }
        
        // Set Criticality based on type
        if (row.vcaErrorType?.toLowerCase().includes('error')) {
          row.Criticality = 1; // Red
        } else if (row.vcaErrorType?.toLowerCase().includes('success')) {
          row.Criticality = 3; // Green
        } else if (row.vcaErrorType?.toLowerCase().includes('warning')) {
          row.Criticality = 2; // Yellow
        }
        else {
          row.Criticality = 0; // Neutral
        }

        // Optionally remove vcaErrorTimeStamp from response (hide from UI)
        delete row.vcaErrorTimeStamp;
      });

      return rows;
    } catch (err) {
      req.error(500, `Error fetching ShippingRequestWithErrors: ${err.message}`);
    }
  });


  /**
 * Service handler for READ EntityDocs
 * Forwards the query to the DB service
 * Then enriches results with criticality mapping
 */
  srv.after('each', 'EntityDocs', data => {
    switch (data.errorStatus) {
      case 'Error':
        data.errorStatusCriticality = 1; // Red icon
        break;
      case 'Pending':
        data.errorStatusCriticality = 2; // Yellow icon
        break;
      case 'NA':
        data.errorStatusCriticality = 2; // Yellow icon
        break;
      case 'Inactive':
        data.errorStatusCriticality = 2; // Yellow icon
        break;
      case 'Retriggered':
        data.errorStatusCriticality = 2; // Yellow icon
        break;
      case 'Success':
        data.errorStatusCriticality = 3; // Green/success
        break;
      case 'Waiting':
        data.errorStatusCriticality = 2; // Yellow icon
        break;
      default:
        data.errorStatusCriticality = 0; // None
    }
  }
  );

  // Defect JGHJ-103722 --- START

  /**
  * Service handler for READ ShippingRequestEntityLocationSummary
  */

  srv.on('READ', 'ShippingRequestEntityLocationSummary', async req => {
    try {

      const isUICall = !!req.data?.shippingReqNo;
      const isSBPACall = !isUICall;

      logger.info('Is UI Call:', isUICall);
      logger.info('Is SBPA Call:', isSBPACall);

      // UI Call
      let shippingRequestNumber = req.data?.shippingReqNo;

      // SBPA Call
      let sbpaFilters = [];

      if (isSBPACall) {
        const where = req.query?.SELECT?.where || [];
        logger.info('SBPA WHERE condition:', JSON.stringify(where));

        for (let i = 0; i < where.length; i++) {
          const field = where[i]?.ref?.[0];
          if (field && where[i + 1] === '=' && where[i + 2]?.val !== undefined) {
            sbpaFilters.push({
              field: field,
              value: where[i + 2].val
            });
          }
        }

        logger.info('Dynamic SBPA filters:', JSON.stringify(sbpaFilters));
      }

      // Fetch Location Data
      let locationData;

      if (isSBPACall) {
        let query = SELECT
          .from('ShippingRequestEntityLocationSummary');

        for (const filter of sbpaFilters) {
          query.where({
            [filter.field]: filter.value
          });
        }

        locationData = await query;

      } else {
        if (!shippingRequestNumber) {
          logger.warn('Shipping Request Number is missing for UI call');
          return [];
        }

        locationData = await SELECT
          .from('ShippingRequestEntityLocationSummary')
          .where({
            shippingReqNo: shippingRequestNumber
          });
      }

      logger.info('Location data from CDS view:', JSON.stringify(locationData));

      const result = [...(locationData || [])];

      if (isUICall) {
        //Defect JGHJ-116504 -- START
        const entityDocsSorted = await SELECT
          .from('ShippingRequestEntityDocs')
          .columns('entityType', 'stepID')
          .where({ parent_shippingReqNo: shippingRequestNumber })
          .orderBy('documentSequence');

        const legacyEntityTypeSet = new Set();

        const seenEntityTypes = new Set();

        for (const doc of entityDocsSorted) {
          if (!seenEntityTypes.has(doc.entityType)) {
            seenEntityTypes.add(doc.entityType);
            if (doc.stepID?.startsWith('L_')) {
              legacyEntityTypeSet.add(doc.entityType);
            }
          }
        }

        if (legacyEntityTypeSet.size > 0) {
          result.forEach(item => {
            if (legacyEntityTypeSet.has(item.entityType)) {
              item.legalEntity = '';
            }
          });
        }
        // Defect JGHJ-116504 -- END

        const shippingRequest = await SELECT.one
          .from('ShippingRequest')
          .columns(
            'shipFromBusinessPartnerName',
            'shipFromBusinessPartner',
            'shipFromPlantName',
            'shipFromPlant',
            'shipToBusinessPartnerName',
            'shipToBusinessPartner',
            'shipToPlantName',
            'shipToPlant',
            'shipFromEr',
            'shipFromeEoRegionName',
            'shipToEr',
            'shipToeEoRegionName'
          )
          .where({
            shippingReqNo: shippingRequestNumber
          });


        logger.info('Shipping Request data:', JSON.stringify(shippingRequest));

        if (shippingRequest) {

          const shipToDoc = await SELECT.one
            .from('ShippingRequestEntityDocs')
            .columns('legalEntity')
            .where({
              parent_shippingReqNo: shippingRequestNumber,
              entityType: 'Ship To'
            });

          const shipToLegalEntity = legacyEntityTypeSet.has('Ship To') ? '' : (shipToDoc?.legalEntity?.trim() || '');

          const hasShipFrom = result.some(
            item => item.entityType === 'Ship From'
          );

          const hasShipTo = result.some(
            item => item.entityType === 'Ship To'
          );

          const virtualEntityRanks = result
            .filter(item =>
              item.entityType?.startsWith('Virtual Entity')
            )
            .map(item => Number(item.entityRank))
            .filter(rank => !Number.isNaN(rank));

          const maxVERank = virtualEntityRanks.length
            ? Math.max(...virtualEntityRanks)
            : 0;

          const shipToRank = maxVERank + 1;


          if (!hasShipFrom) {
            result.push({
              shippingReqNo: shippingRequestNumber,
              entityType: 'Ship From',
              entityRank: 0,
              legalEntity: '',
              ecoRegion: shippingRequest.shipFromEr || shippingRequest.shipFromeEoRegionName || '',
              businessPartnerId: shippingRequest.shipFromBusinessPartner || '',
              plant: shippingRequest.shipFromPlant || '',
              bpName: shippingRequest.shipFromBusinessPartnerName || '',
              plantName: shippingRequest.shipFromPlantName || ''
            });
          }

          if (!hasShipTo) {
            result.push({
              shippingReqNo: shippingRequestNumber,
              entityType: 'Ship To',
              entityRank: shipToRank,
              legalEntity: shipToLegalEntity,
              ecoRegion: shippingRequest.shipToEr || shippingRequest.shipToeEoRegionName || '',
              businessPartnerId: shippingRequest.shipToBusinessPartner || '',
              plant: shippingRequest.shipToPlant || '',
              bpName: shippingRequest.shipToBusinessPartnerName || '',
              plantName: shippingRequest.shipToPlantName || ''
            });
          }
        }
      }

      const seen = new Set();

      const uniqueData = result.filter(item => {

        const duplicateKey = [
          item.shippingReqNo || '',
          item.entityType || '',
          item.legalEntity || '',
          item.ecoRegion || '',
          item.businessPartnerId || '',
          item.plant || '',
          item.entityRank ?? '',
          item.bpName || '',
          item.plantName || ''
        ].join('|');

        if (seen.has(duplicateKey)) {
          return false;
        }

        seen.add(duplicateKey);

        return true;
      });

      uniqueData.sort((a, b) => {

        const rankA = Number(a.entityRank ?? 999999);
        const rankB = Number(b.entityRank ?? 999999);

        if (rankA !== rankB) {
          return rankA - rankB;
        }

        return (
          Number(a.documentSequence || 0) -
          Number(b.documentSequence || 0)
        );
      });

      logger.info('Final ShippingRequestEntityLocationSummary data:', JSON.stringify(uniqueData));

      return uniqueData;

    } catch (error) {
      logger.error('Error in ShippingRequestEntityLocationSummary READ', error);
      throw error;
    }
  });

  /**
   * Service handler for READ ShippingRequestEntityLocationSummary
   * Forwards query + enriches results with sorting and deduplication
   */
  // srv.after('READ', 'ShippingRequestEntityLocationSummary', data => {
  //   if (!Array.isArray(data)) return;

  //   // Sort first
  //   data.sort((a, b) => {
  //     if (a.entityRank !== b.entityRank) {
  //       return a.entityRank - b.entityRank;
  //     }
  //     return (a.documentSequence || 0) - (b.documentSequence || 0);
  //   });

  //   // Remove duplicates based on entityType
  //   const seen = new Set();
  //   const uniqueData = data.filter(item => {
  //     if (seen.has(item.entityType)) {
  //       return false; // already seen this type
  //     }
  //     seen.add(item.entityType);
  //     return true;
  //   });

  //   // Mutate original array so CAP sends the deduplicated list
  //   data.length = 0;
  //   data.push(...uniqueData);

  //   logger.info(
  //     'Final Location Summary',
  //     JSON.stringify(data, null, 2)
  //   );
  // });

  // Defect JGHJ-103722 --- END

  /**
   * Action handler: getEntityDocs
   * Fetches all EntityDocs for a given shippingReqNo and initialDocumentNo.
   * @param {string} shippingReqNo         - Shipping Request Number (required)
   * @param {string} initialDocumentNo     - Initial Document Number (required)
   * @returns {Array} List of matching EntityDocs sorted by documentSequence
   */

  srv.on('getHeaderDetailsWithRef', async (req) => {
    const data = req.data;
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const headerData = await dbOps.getHeaderDetailsWithRef(data?.referenceDocumentNo, bundle);
      return headerData;
    } catch (error) {

      req.error(400, error.message || bundle.getText('Failed to fetch header details using reference document number'));
    }
  });

  /**
   * Service handler for READ EntityDocs
   * Sorts the result list by documentSequence
   */
  srv.on('READ', 'EntityDocs', async (req, next) => {
    try {
      //const { SELECT } = req.query;


      if (req.data && req.data?.parent_shippingReqNo && req.data?.parent_initialDocumentNo && req.data?.parent_shippingReqNo) {

        const entityDocs = await SELECT.from(ShippingRequestEntityDocs).where({
          parent_shippingReqNo: req.data?.parent_shippingReqNo,
          parent_initialDocumentNo: req.data?.parent_initialDocumentNo,
          parent_ID: req.data?.parent_ID
        });

        const pendingError = entityDocs.find(doc => (doc.errorStatus === "Pending" || doc.errorStatus === "Retriggered") && doc.wfInstanceId && doc.wfInstanceId !== '');

        if (pendingError && pendingError?.wfInstanceId) {

          // -------------------------------
          // STEP 1: Get rootInstanceId
          // -------------------------------
          const rootInstanceId = await utils.checkSubprocessWorkflowStatus(pendingError?.wfInstanceId, pendingError.ID);

          if (rootInstanceId) {
            if (pendingError.errorStatus !== "Error") {
              await UPDATE(ShippingRequestEntityDocs)
                .set({
                  errorStatus: "Error",
                  errorDescription: "Technical Error from Entity Docs",
                  errorCreationDate: new Date()
                })
                .where({
                  ID: pendingError?.ID
                });

              await UPDATE(ShippingRequest)
                .set({
                  docFlowStateCheckStatus: "Error",
                  status: "Error"
                })
                .where({
                  ID: pendingError?.parent_ID
                });


              await INSERT.into(ShippingRequestErrors).entries({
                ID: cds.utils.uuid(),
                parent_ID: pendingError?.ID,
                vcaErrorStatus: "Technical Error from EntityDocs",
                vcaErrorType: "Error",
                wfInstanceId: pendingError.wfInstanceId,
                vcaErrorTimeStamp: new Date()
              })

              logger.info(`Entity status updated to error for  entity Doc :${pendingError.ID}`);


            } else {
              logger.info(`Workflow instance ${pendingError.wfInstanceId} ${pendingError.ID}. No status change applied.`);
            }
          }
          // else {
          //   if (pendingError?.modifiedAt) {

          //     logger.info(`root instance not found for entity ${pendingError.ID}. Checking elapsed time since last modification...`)

          //     const
          //       modifiedAt = new Date(pendingError.modifiedAt);
          //     const currentTime = new Date();

          //     const diffInMinutes = (currentTime.getTime() -
          //       modifiedAt.getTime()) / (1000 * 60);

          //     if (diffInMinutes >= 5) {

          //       // if (
          //       //   pendingError.errorStatus !== "Error" ||
          //       //   pendingError.errorDescription !== "Technical Error"
          //       // ) {

          //         await UPDATE(ShippingRequestEntityDocs)
          //           .set({
          //             errorStatus: "Error",
          //             errorDescription: "Technical Error",
          //             errorCreationDate: new Date()
          //           })
          //           .where({
          //             ID: pendingError.ID
          //           });

          //         await UPDATE(ShippingRequest)
          //           .set({
          //             docFlowStateCheckStatus: "Error",
          //             status: "Error"
          //           })
          //           .where({
          //             ID: pendingError.parent_ID
          //           });

          //         await INSERT.into(ShippingRequestErrors).entries({
          //           ID: cds.utils.uuid(),
          //           parent_ID: pendingError.ID,
          //           vcaErrorStatus: "Technical Error",
          //           vcaErrorType: "Error",
          //           wfInstanceId: pendingError.wfInstanceId,
          //           vcaErrorTimeStamp: new Date()
          //         });

          //         logger.info(
          //           `Workflow instance not found for more than 5 minutes. Entity ${pendingError.ID} marked as Technical Error.`
          //         );
          //       // } else {
          //       //   logger.info(
          //       //     `Entity ${pendingError.ID} is already in Technical Error state.`
          //       //   );
          //       // }

          //     } else {
          //       logger.info(
          //         `Workflow instance not found for entity ${pendingError.ID}, but only ${diffInMinutes.toFixed(2)} minutes have elapsed.`
          //       );
          //     }
          //   }
          // }

        }

        const LegacyDoc = entityDocs.find(doc => doc.stepID == 'L_ICSO' || doc.stepID == 'L_ICISO');

        if (LegacyDoc?.documentNumber) {

          logger.info(
            `Previous document ${LegacyDoc.ID} is pending without workflow instance for more than 5 minutes.`
          );
          const workflow = await cds.connect.to("workflowService");

          let po_OBD = 'us10.jnj-im-dev-na.zvcm55147financialflowscenario3project.zVCM55147_FinancialFlowScenario3Process';
          let oBD_Trigger = LegacyDoc.parent_initialDocumentNo;

          let legacydoc=LegacyDoc?.documentNumber.trim()

          const subProcessResponses = await workflow.send({
            method: "GET",
            path: `/public/workflow/rest/v1/workflow-instances?status=ERRONEOUS&definitionId=${po_OBD}&attributes.salesorder=${legacydoc}`
          });

          logger.info(subProcessResponses)

          // let findLICSOStepID = await SELECT.one
          //   .from(ShippingRequestEntityDocs)
          //   .where({ parent_ID: LegacyDoc?.parent_ID, stepID: 'L_ICSO' });

          // let findICPO = await SELECT
          //   .from(ShippingRequestEntityDocs)
          //   .where({ parent_ID: findPrevDoc?.parent_ID, entityType: 'Virtual Entity 1', stepID: findICPOStepID?.stepID });

          const docNum = String(LegacyDoc?.documentNumber ?? '').trim();

          const refPOResponses = subProcessResponses.filter(item => {
            const businessKey = item?.businessKey;

            if (typeof businessKey !== "string") {
              return false;
            }

            const leftPart = businessKey.includes("-")
              ? businessKey.split("-")[0].trim()
              : businessKey.trim();

            // logger.info(`BusinessKey : ${businessKey}`);
            // logger.info(`Left Part   : '${leftPart}'`);
            // logger.info(`Doc Number  : '${docNum}'`);

            return leftPart === LegacyDoc?.documentNumber.trim();
          });

          logger.info(`Matched Responses: ${JSON.stringify(refPOResponses)}`);

          const documentMap = new Map();

          const getDocumentNumbers = refPOResponses
            .filter(r => typeof r.businessKey === "string")
            .map(r => {
              const docNo = r.businessKey.split("-").pop().trim();
              documentMap.set(docNo, r);
              return docNo;
            });

          const documentNumbers = [...new Set(getDocumentNumbers)];

          logger.info(documentNumbers);
          const existingDocs = await SELECT.from(ShippingRequestEntityDocs)
            .columns("documentNumber")
            .where({
              parent_ID: LegacyDoc.parent_ID,
              stepID: "L_OBD",
              documentNumber: { in: documentNumbers }
            });

          const existingDocSet = new Set(existingDocs.map(d => d.documentNumber));

          const currentTime = new Date();

          const isOlderThan5Minutes = refPOResponses.every(workflow => {
            const diffInMinutes =
              (currentTime.getTime() - new Date(workflow.startedAt).getTime()) / (1000 * 60);

            return diffInMinutes > 5;
          });

          for (let i = 0; i < documentNumbers.length; i++) {
            let docNo=documentNumbers[i]
            if (!existingDocSet.has(docNo) && isOlderThan5Minutes) {
              const document = documentMap.get(docNo);

              const existingOrphan = await SELECT.one.from(cds.entities.asnOrphanDocs)
                .where({
                  legacyRefDocNum:legacydoc.trim(),
                  legacyDocNum: docNo.trim(),
                  // initialDocumentNo:LegacyDoc?.parent_initialDocumentNo
                });

              if (existingOrphan) {
                logger.error(`Already exists in orphan wit OBD ${docNo} and legacy So ${legacydoc}`)
                continue;
              }

              let data = {
                ref_SO:legacydoc.trim(),
                OBD: docNo.trim(),
                wfID:document?.id,
                initialDocumentNo: LegacyDoc?.parent_initialDocumentNo
              }

              let insertIntoOrphan = await dbOps.createAsnOrphan(data, req, LegacyDoc?.parent_initialDocumentNo, "Technical error for OBD came but not updated. Test.")


              logger.info("Orphan inserted successfully!"); // Logs the entire refPOResponses object

            }
          }

        }

        const typeOfOrder = await SELECT.one
          .from(ShippingRequest)
          .columns("initialDocumentType")
          .where({
            shippingReqNo: req.data?.parent_shippingReqNo
          });

        if(typeOfOrder.initialDocumentType==='Purchase Order'){

        const followOnDocs = await SELECT
          .from(ShippingRequestEntityFollowOnDocs)
          .columns("followOnDocumentNo")
          .where({
            shippingReqNo: req.data?.parent_shippingReqNo
          });

        if (followOnDocs?.length > 1) {

          for (const doc of followOnDocs) {

            const records = await SELECT
              .from(ShippingRequestEntityDocs)
              .where`
                parent_ID = ${entityDocs[0].parent_ID}
                and isExceptionalDocument = false
                and (action = 'A' or action = 'L')
                and errorStatus not in ('Success', 'N/A', 'Inactive')
                and followOnDocumentNo = ${doc.followOnDocumentNo}
            `
              .orderBy('documentSequence asc');

            if (records.length > 0 && !records[0]?.parent_shippingReqNo?.includes('S')) {

              const findPreReqSuccess = await SELECT.one
                .from(ShippingRequest)
                .where({
                  ID: entityDocs[0]?.parent_ID
                });

              const isPreReqSuccess =
                findPreReqSuccess?.pfcCheckStatus === "Success" &&
                findPreReqSuccess?.scenarioDeterminationCheckStatus === "Success" &&
                (
                  findPreReqSuccess?.masterDataStatus === "Success" ||
                  findPreReqSuccess?.masterDataStatus === "Warning"
                );


              let findPrevDoc = await SELECT.one.from(ShippingRequestEntityDocs)
                .where({
                  parent_ID: entityDocs[0]?.parent_ID,
                  documentSequence: records[0].documentSequence - 1,
                  followOnDocumentNo :records[0]?.followOnDocumentNo
                });

              let found = false
              let i = 2;

              if (findPrevDoc?.errorStatus === 'Waiting') {
                while (!found && i<5) {
                  findPrevDoc = await SELECT.one.from(ShippingRequestEntityDocs)
                    .where({
                      parent_ID: entityDocs[0]?.parent_ID,
                      documentSequence: records[0].documentSequence - i,
                      followOnDocumentNo: records[0]?.followOnDocumentNo
                    });

                  if (findPrevDoc.errorStatus === 'Success') {
                     found = true
                  }
                  i++;
                }
              }

              // Previous document is Pending and has no workflow instance
                if (
                  (isPreReqSuccess && findPrevDoc?.errorStatus === "Success" && records[0].errorStatus === 'Pending' && records[0].wfInstanceId === null)
                ) {

                  const modifiedAt = new Date(findPrevDoc?.modifiedAt);
                  const currentTime = new Date();

                  const diffInMinutes =
                    (currentTime.getTime() - modifiedAt?.getTime()) / (1000 * 60);

                  if (diffInMinutes > 5 && isPreReqSuccess && findPrevDoc && records[0].stepID !== 'L_OBD') {

                    const workflow = await cds.connect.to("workflowService");

                    let poTrigger = 'us10.jnj-im-dev-na.zvcm47421potriggerflowproject.zVCM47421_POTriggerFlowProcess';
                    let businessKeypoTrigger = records[0].parent_initialDocumentNo;


                    const subProcessResponses = await workflow.send({
                      method: "GET",
                      path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businessKeypoTrigger}&definitionId=${poTrigger}&$orderby=startedAt desc`
                    });

                    const subProcessResponse = subProcessResponses[0]

                    if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
                      logger.info("PO Trigger instance found")

                      await UPDATE(ShippingRequestEntityDocs)
                        .set({
                          errorStatus: "Error",
                          errorDescription: "Technical Error",
                          errorCreationDate: new Date(),
                          wfInstanceId: subProcessResponse?.id
                        })
                        .where({
                          ID: records[0]?.ID
                        });

                      await INSERT.into(ShippingRequestErrors).entries({
                        ID: cds.utils.uuid(),
                        parent_ID: pendingError?.ID,
                        vcaErrorStatus: "Technical Error from EntityDocs and Po Trigger/followOnDoc",
                        vcaErrorType: "Error",
                        wfInstanceId:subProcessResponse?.id,
                        vcaErrorTimeStamp: new Date()
                      })
                    }
                    if ((subProcessResponse && subProcessResponse?.status == 'COMPLETED') || (subProcessResponse === undefined)) {
                      let reusableFlow = 'us10.jnj-im-dev-na.zvcm55147reusableflowscenario3project.zVCM_FlowOrchestrationMainProcess'
                      let reusable_key1 = records[0].parent_shippingReqNo
                      let reusable_key2 = records[0].followOnDocumentNo;

                      let businessKey = `${reusable_key1}-${reusable_key2}`

                      const subProcessResponses = await workflow.send({
                        method: "GET",
                        path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businessKey}&definitionId=${reusableFlow}&$orderby=startedAt desc`
                      });

                      const subProcessResponse = subProcessResponses[0]

                      if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
                        logger.info("PO Trigger instance found")

                        await UPDATE(ShippingRequestEntityDocs)
                          .set({
                            errorStatus: "Error",
                            errorDescription: "Technical Error",
                            errorCreationDate: new Date(),
                            wfInstanceId: subProcessResponse?.id
                          })
                          .where({
                            ID: records[0]?.ID
                          });

                        await INSERT.into(ShippingRequestErrors).entries({
                          ID: cds.utils.uuid(),
                          parent_ID: records[0]?.ID,
                          vcaErrorStatus: "Technical Error from EntityDocs and reusableFlow/followOnDoc",
                          vcaErrorType: "Error",
                          wfInstanceId: subProcessResponse?.id,
                          vcaErrorTimeStamp: new Date()
                        })
                      }

                      if ((subProcessResponse && subProcessResponse?.status === 'COMPLETED') || subProcessResponse === undefined) {
                        let sOConfirmation = 'us10.jnj-im-dev-na.zvcm55147financialflowscenario3project.zVCM55147_LegacySOConfirmationProcess'


                        let findICPOStepID = await SELECT.one
                          .from(ShippingRequestEntityDocs)
                          .where({ parent_ID: records[0]?.parent_ID, entityType: 'Ship To', action: 'T' });

                        let findICPO = await SELECT
                          .from(ShippingRequestEntityDocs)
                          .where({ parent_ID: records[0]?.parent_ID, entityType: 'Virtual Entity 1', stepID: findICPOStepID?.stepID });

                        let businessKeySOConfirmation = findICPO.documentNumber;

                        const subProcessResponses = await workflow.send({
                          method: "GET",
                          path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businessKeySOConfirmation}&definitionId=${sOConfirmation}&$orderby=startedAt desc`
                        });

                        const subProcessResponse = subProcessResponses[0]

                        if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
                          logger.info("PO Trigger instance found")

                          await UPDATE(ShippingRequestEntityDocs)
                            .set({
                              errorStatus: "Error",
                              errorDescription: "Technical Error",
                              errorCreationDate: new Date(),
                              wfInstanceId: subProcessResponse?.id
                            })
                            .where({
                              ID: records[0]?.ID
                            });

                          await INSERT.into(ShippingRequestErrors).entries({
                            ID: cds.utils.uuid(),
                            parent_ID: records[0]?.ID,
                            vcaErrorStatus: "Technical Error from EntityDocs and sOConfirmation/followOnDoc",
                            vcaErrorType: "Error",
                            wfInstanceId: subProcessResponse?.id,
                            vcaErrorTimeStamp: new Date()
                          })
                        }

                        if ((subProcessResponse && subProcessResponse?.status == 'COMPLETED') || (subProcessResponse === undefined)) {

                          let afterASNFlow = 'us10.jnj-im-dev-na.zvcm55147financialflowscenario3project.zVCM55147_FinancialFlowScenario3Process';

                          const getEntity = await SELECT.one.from(ShippingRequestEntityDocs).where({ parent_ID: records[0].parent_ID, action: 'T' })


                          let POStepIdtoLegacySOStepID = 'L_' + getEntity?.stepID?.replace(/PO$/, 'SO')

                          const getLegacySO = await SELECT.one.from(ShippingRequestEntityDocs).where({ parent_ID: records[0].parent_ID, stepID: POStepIdtoLegacySOStepID })

                          const getL_OBD = await SELECT.one.from(ShippingRequestEntityDocs).where({ parent_ID: records[0].parent_ID, stepID: 'L_OBD' })
                          if (!getLegacySO || !getL_OBD) {
                            logger.error("Not found getLegacySO or getL_OBD after ASN flow")

                          }

                          let businesKey = `${getLegacySO?.documentNumber}-${getL_OBD?.documentNumber}`

                          const subProcessResponses = await workflow.send({
                            method: "GET",
                            path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businesKey}&definitionId=${afterASNFlow}&$orderby=startedAt desc`
                          });

                          const subProcessResponse = subProcessResponses[0]

                          if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
                            logger.info("PO Trigger instance found")

                            await UPDATE(ShippingRequestEntityDocs)
                              .set({
                                errorStatus: "Error",
                                errorDescription: "Technical Error",
                                errorCreationDate: new Date(),
                                wfInstanceId: subProcessResponse?.id
                              })
                              .where({
                                ID: records[0]?.ID
                              });

                            await INSERT.into(ShippingRequestErrors).entries({
                              ID: cds.utils.uuid(),
                              parent_ID:records[0]?.ID,
                              vcaErrorStatus: "Technical Error from EntityDocs and afterASNFlow/followOnDoc ",
                              vcaErrorType: "Error",
                              wfInstanceId: subProcessResponse?.id,
                              vcaErrorTimeStamp: new Date()
                            })
                          }

                        }
                      }
                    }


                  }
                  // if (diffInMinutes > 5 && records[0].stepID === 'L_OBD') {
                  //   logger.info(
                  //     `Previous document ${findPrevDoc.ID} is pending without workflow instance for more than 5 minutes.`
                  //   );
                  //   const workflow = await cds.connect.to("workflowService");

                  //   let po_OBD = 'us10.jnj-im-dev-na.zvcm55147financialflowscenario3project.zVCM55147_FinancialFlowScenario3Process';
                  //   let oBD_Trigger = findPrevDoc.parent_initialDocumentNo;


                  //   const subProcessResponses = await workflow.send({
                  //     method: "GET",
                  //     path: `/public/workflow/rest/v1/workflow-instances?status=ERRONEOUS&definitionId=${po_OBD}`
                  //   });

                  //   logger.info(subProcessResponses)

                  //   let findLICSOStepID = await SELECT.one
                  //     .from(ShippingRequestEntityDocs)
                  //     .where({ parent_ID: findPrevDoc?.parent_ID, stepID: 'L_ICSO' });

                  //   // let findICPO = await SELECT
                  //   //   .from(ShippingRequestEntityDocs)
                  //   //   .where({ parent_ID: findPrevDoc?.parent_ID, entityType: 'Virtual Entity 1', stepID: findICPOStepID?.stepID });



                  //   const docNum = String(findLICSOStepID?.documentNumber ?? '').trim();

                  //   const refPOResponses = subProcessResponses.filter(item => {
                  //     const businessKey = item?.businessKey;

                  //     if (typeof businessKey !== "string") {
                  //       return false;
                  //     }

                  //     const leftPart = businessKey.includes("-")
                  //       ? businessKey.split("-")[0].trim()
                  //       : businessKey.trim();

                  //     logger.info(`BusinessKey : ${businessKey}`);
                  //     logger.info(`Left Part   : '${leftPart}'`);
                  //     logger.info(`Doc Number  : '${docNum}'`);

                  //     return leftPart === String(docNum).trim();
                  //   });

                  //   logger.info(`Matched Responses: ${JSON.stringify(refPOResponses)}`);


                  //   const documentMap = new Map();

                  //   const documentNumbers = refPOResponses
                  //     .filter(r => typeof r.businessKey === "string")
                  //     .map(r => {
                  //       const docNo = r.businessKey.split("-").pop().trim();
                  //       documentMap.set(docNo, r);
                  //       return docNo;
                  //     });

                  //   logger.info(documentNumbers);
                  //   const existingDocs = await SELECT.from(ShippingRequestEntityDocs)
                  //     .columns("documentNumber")
                  //     .where({
                  //       parent_ID: findPrevDoc.parent_ID,
                  //       stepID: "L_OBD",
                  //       documentNumber: { in: documentNumbers }
                  //     });

                  //   const existingDocSet = new Set(existingDocs.map(d => d.documentNumber));

                  //   const currentTime = new Date();

                  //   const isOlderThan5Minutes = refPOResponses.every(workflow => {
                  //     const diffInMinutes =
                  //       (currentTime.getTime() - new Date(workflow.startedAt).getTime()) / (1000 * 60);

                  //     return diffInMinutes > 5;
                  //   });



                  //   for (let i=0;i<documentNumbers;i++) {
                  //     if (!existingDocSet.has(docNo) && isOlderThan5Minutes) {
                  //       const document = documentMap.get(docNo);


                  //       const L_ICSO = await SELECT.one.from(ShippingRequestEntityDocs)
                  //         .columns("documentNumber")
                  //         .where({
                  //           parent_ID: findPrevDoc.parent_ID,
                  //           stepID: "L_ICSO"
                  //         });
                  //       if (!L_ICSO?.documentNumber) {
                  //         logger.error("L_ICSO is not found")
                  //         continue;
                  //       }

                  //       const existingOrphan = await SELECT.one.from(cds.entities.asnOrphanDocs)
                  //         .where({
                  //           legacyRefDocNum: L_ICSO.documentNumber,
                  //           legacyDocNum: docNo
                  //         });

                  //       if (existingOrphan) {
                  //         logger.error(`Already exists in orphan wit OBD ${docNo} and legacy So ${L_ICSO.documentNumber}`)
                  //         continue;
                  //       }

                  //       let data = {
                  //         ref_SO: L_ICSO.documentNumber,
                  //         OBD: docNo,
                  //         wfID: refPOResponses[i]?.id,
                  //         initialDocumentNo: findPrevDoc?.parent_initialDocumentNo
                  //       }

                  //       let insertIntoOrphan = await dbOps.createAsnOrphan(data, req, findPrevDoc?.parent_initialDocumentNo, "Technical error for OBD came but not updated. Test.")


                  //       logger.info("Orphan inserted successfully!"); // Logs the entire refPOResponses object

                  //     }
                  //   }
                  // }
                }
              
            }
          }

        } else {

        const records = await SELECT.from(ShippingRequestEntityDocs)
            .where`
        parent_ID = ${entityDocs[0]?.parent_ID}
        and isExceptionalDocument = false
        and (action = 'A' or action = 'L')
        and errorStatus not in ('Success', 'N/A', 'Inactive')`
            .orderBy('documentSequence asc');

          if (records[0]?.documentSequence === 1 && records[0].errorStatus === 'Pending' && records[0].wfInstanceId === null) {
            const shippingRequest = await SELECT.one
              .from(ShippingRequest)
              .columns(
                "ID",
                "modifiedAt",
                "masterDataStatus",
                "pfcCheckStatus",
                "scenarioDeterminationCheckStatus"
              )
              .where({
                ID: entityDocs[0].parent_ID
              });

            if (
              records.length > 0 &&
              records[0].documentSequence === 1 &&
              shippingRequest &&
              shippingRequest.pfcCheckStatus === "Success" &&
              shippingRequest.scenarioDeterminationCheckStatus === "Success" &&
              (
                shippingRequest.masterDataStatus === "Success" ||
                shippingRequest.masterDataStatus === "Warning"
              )
            ) {
              const diffInMinutes =
                (Date.now() - new Date(shippingRequest.modifiedAt).getTime()) / (1000 * 60);

              if (diffInMinutes > 5) {

                 const workflow = await cds.connect.to("workflowService");

                  let poTrigger = 'us10.jnj-im-dev-na.zvcm47421potriggerflowproject.zVCM47421_POTriggerFlowProcess';
                  let businessKeypoTrigger = records[0].parent_initialDocumentNo;

                  const subProcessResponses = await workflow.send({
                    method: "GET",
                    path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businessKeypoTrigger}&definitionId=${poTrigger}&$orderby=startedAt desc`
                  });

                  const subProcessResponse = subProcessResponses[0]

                  if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
                    logger.info("PO Trigger instance found")

                    await UPDATE(ShippingRequestEntityDocs)
                      .set({
                        errorStatus: "Error",
                        errorDescription: "Technical Error",
                        errorCreationDate: new Date(),
                        wfInstanceId: subProcessResponse?.id
                      })
                      .where({
                        ID: records[0]?.ID
                      });

                    await INSERT.into(ShippingRequestErrors).entries({
                      ID: cds.utils.uuid(),
                      parent_ID: records[0]?.ID,
                      vcaErrorStatus: "Technical Error from EntityDocs and poTrigger",
                      vcaErrorType: "Error",
                      wfInstanceId:subProcessResponse?.id,
                      vcaErrorTimeStamp: new Date()
                    })
                  }

                logger.info(
                  `Document ${records[0].documentNumber} marked as Technical Error because automation did not start for docs within 5 minutes.`
                );
              }
            }
          }

          if (records[0]?.parent_shippingReqNo?.includes('S') && records[0].errorStatus === 'Pending' && records[0].wfInstanceId === null) {
            let findSalesJOM = await SELECT.one.from(ShippingRequest).columns("documentType").where({ ID: records[0]?.parent_ID })

            if (findSalesJOM?.documentType === 'Sales Order') {
              const workflow = await cds.connect.to("workflowService");

              let JOMChargebackWorkflowTrigger = 'us10.jnj-im-dev-na.zvcm70962jomchargebackproject.ZVCM70962_JOMChargebackWorkflow';
              let businessKeyJOMChargebackWorkflowTrigger = records[0].parent_initialDocumentNo;


              const subProcessResponses = await workflow.send({
                method: "GET",
                path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businessKeyJOMChargebackWorkflowTrigger}&definitionId=${JOMChargebackWorkflowTrigger}&$orderby=startedAt desc`
              });

              const subProcessResponse = subProcessResponses[0]

              if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
                logger.info("PO Trigger instance found")

                await UPDATE(ShippingRequestEntityDocs)
                  .set({
                    errorStatus: "Error",
                    errorDescription: "Technical Error",
                    errorCreationDate: new Date(),
                    wfInstanceId: subProcessResponse?.id
                  })
                  .where({
                    ID: records[0]?.ID
                  });

                await INSERT.into(ShippingRequestErrors).entries({
                  ID: cds.utils.uuid(),
                  parent_ID: records[0]?.ID,
                  vcaErrorStatus: "Technical Error from EntityDocs and JOM",
                  vcaErrorType: "Error",
                  wfInstanceId: subProcessResponse?.id,
                  vcaErrorTimeStamp: new Date()
                })
              }
            } else {
              logger.info(`Found JOM but it is not Sales Order`)
            }
          }

          if (records.length > 0 && !records[0]?.parent_shippingReqNo?.includes('S')) {

            const findPreReqSuccess = await SELECT.one
              .from(ShippingRequest)
              .where({
                ID: entityDocs[0]?.parent_ID
              });

            const isPreReqSuccess =
              findPreReqSuccess?.pfcCheckStatus === "Success" &&
              findPreReqSuccess?.scenarioDeterminationCheckStatus === "Success" &&
              (
                findPreReqSuccess?.masterDataStatus === "Success" ||
                findPreReqSuccess?.masterDataStatus === "Warning"
              );

            let findPrevDoc = await SELECT.one.from(ShippingRequestEntityDocs)
              .where({
                parent_ID: entityDocs[0]?.parent_ID,
                documentSequence: records[0].documentSequence - 1
              });

              let found = false
              let i = 2;

              let isBeforeOBD = false;
              let previousDocsSuccess = false;

              if (findPrevDoc?.errorStatus === 'Waiting') {
                while (!found && i<5) {
                  findPrevDoc = await SELECT.one.from(ShippingRequestEntityDocs)
                    .where({
                      parent_ID: entityDocs[0]?.parent_ID,
                      documentSequence: records[0].documentSequence - i,
                      followOnDocumentNo: records[0]?.followOnDocumentNo
                    });

                  if (findPrevDoc.errorStatus === 'Success') {
                    found = true
                    // Get L_OBD sequence
                    const obdDoc = await SELECT.one
                      .from(ShippingRequestEntityDocs)
                      .columns("documentSequence")
                      .where({
                        parent_ID: entityDocs[0]?.parent_ID,
                        stepID: 'L_OBD'
                      });

                    const obdSequence = obdDoc?.documentSequence;
                    const currentSequence = records[0]?.documentSequence;

                    isBeforeOBD =
                      obdSequence !== undefined &&
                      currentSequence !== undefined &&
                      currentSequence < obdSequence;

                    if (isBeforeOBD) {
                      previousDocsSuccess = true;
                    }
                  }
                  i++;
                }
              }

      
              // Previous document is Pending and has no workflow instance
              if (
                (findPrevDoc?.errorStatus === "Success" && records[0].errorStatus === 'Pending' && records[0].wfInstanceId === null)
              ) {

                const modifiedAt = new Date(findPrevDoc?.modifiedAt);
                const currentTime = new Date();

                const diffInMinutes =
                  (currentTime.getTime() - modifiedAt?.getTime()) / (1000 * 60);

                if (diffInMinutes > 5 && isPreReqSuccess && findPrevDoc && records[0].stepID !== 'L_OBD' && isBeforeOBD && previousDocsSuccess) {

                  const workflow = await cds.connect.to("workflowService");

                  let poTrigger = 'us10.jnj-im-dev-na.zvcm47421potriggerflowproject.zVCM47421_POTriggerFlowProcess';
                  let businessKeypoTrigger = records[0].parent_initialDocumentNo;

                  const subProcessResponses = await workflow.send({
                    method: "GET",
                    path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businessKeypoTrigger}&definitionId=${poTrigger}&$orderby=startedAt desc`
                  });

                  const subProcessResponse = subProcessResponses[0]

                  if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
                    logger.info("PO Trigger instance found")

                    await UPDATE(ShippingRequestEntityDocs)
                      .set({
                        errorStatus: "Error",
                        errorDescription: "Technical Error",
                        errorCreationDate: new Date(),
                        wfInstanceId: subProcessResponse?.id
                      })
                      .where({
                        ID: records[0]?.ID
                      });

                    await INSERT.into(ShippingRequestErrors).entries({
                      ID: cds.utils.uuid(),
                      parent_ID: records[0]?.ID,
                      vcaErrorStatus: "Technical Error from EntityDocs and poTrigger",
                      vcaErrorType: "Error",
                      wfInstanceId:subProcessResponse?.id,
                      vcaErrorTimeStamp: new Date()
                    })
                  }
                  if ((subProcessResponse && subProcessResponse?.status == 'COMPLETED') || (subProcessResponse === undefined)) {
                    let reusableFlow = 'us10.jnj-im-dev-na.zvcm55147reusableflowscenario3project.zVCM_FlowOrchestrationMainProcess'
                    let reusable_key1 = records[0].parent_shippingReqNo
                    let reusable_key2 = records[0].followOnDocumentNo;

                    let businessKey=`${reusable_key1}-${reusable_key2}`

                    const subProcessResponses = await workflow.send({
                      method: "GET",
                      path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businessKey}&definitionId=${reusableFlow}&$orderby=startedAt desc`
                    });

                    const subProcessResponse = subProcessResponses[0]

                    if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
                      logger.info("PO Trigger instance found")

                      await UPDATE(ShippingRequestEntityDocs)
                        .set({
                          errorStatus: "Error",
                          errorDescription: "Technical Error",
                          errorCreationDate: new Date(),
                          wfInstanceId: subProcessResponse?.id
                        })
                        .where({
                          ID: records[0]?.ID
                        });

                      await INSERT.into(ShippingRequestErrors).entries({
                        ID: cds.utils.uuid(),
                        parent_ID: records[0]?.ID,
                        vcaErrorStatus: "Technical Error from EntityDocs and reusableFlow",
                        vcaErrorType: "Error",
                        wfInstanceId: subProcessResponse?.id,
                        vcaErrorTimeStamp: new Date()
                      })
                    }

                    if ((subProcessResponse && subProcessResponse?.status === 'COMPLETED') || subProcessResponse === undefined) {
                      let sOConfirmation = 'us10.jnj-im-dev-na.zvcm55147financialflowscenario3project.zVCM55147_LegacySOConfirmationProcess'

                      let findICPOStepID = await SELECT.one
                        .from(ShippingRequestEntityDocs)
                        .where({ parent_ID: records[0]?.parent_ID, entityType: 'Ship To', action: 'T' });

                      let findICPO = await SELECT
                        .one.from(ShippingRequestEntityDocs)
                        .where({ parent_ID: records[0]?.parent_ID, entityType: 'Virtual Entity 1', stepID: findICPOStepID?.stepID });

                      let businessKeySOConfirmation = findICPO?.documentNumber;

                      const subProcessResponses = await workflow.send({
                        method: "GET",
                        path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businessKeySOConfirmation}&definitionId=${sOConfirmation}&$orderby=startedAt desc`
                      });

                      const subProcessResponse = subProcessResponses[0]

                      if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
                        logger.info("PO Trigger instance found")

                        await UPDATE(ShippingRequestEntityDocs)
                          .set({
                            errorStatus: "Error",
                            errorDescription: "Technical Error",
                            errorCreationDate: new Date(),
                            wfInstanceId: subProcessResponse?.id
                          })
                          .where({
                            ID: records[0]?.ID
                          });

                        await INSERT.into(ShippingRequestErrors).entries({
                          ID: cds.utils.uuid(),
                          parent_ID: records[0]?.ID,
                          vcaErrorStatus: "Technical Error from EntityDocs and sOConfirmation",
                          vcaErrorType: "Error",
                          wfInstanceId: subProcessResponse?.id,
                          vcaErrorTimeStamp: new Date()
                        })
                      }

                      if ((subProcessResponse && subProcessResponse?.status == 'COMPLETED') || (subProcessResponse === undefined)) {

                        let afterASNFlow = 'us10.jnj-im-dev-na.zvcm55147financialflowscenario3project.zVCM55147_FinancialFlowScenario3Process';

                        const getEntity = await SELECT.one.from(ShippingRequestEntityDocs).where({ parent_ID: records[0].parent_ID, action: 'T' })

                        let POStepIdtoLegacySOStepID = 'L_' + getEntity?.stepID?.replace(/PO$/, 'SO')

                        const getLegacySO = await SELECT.one.from(ShippingRequestEntityDocs).where({ parent_ID: records[0].parent_ID, stepID: POStepIdtoLegacySOStepID })

                        const getL_OBD = await SELECT.one.from(ShippingRequestEntityDocs).where({ parent_ID: records[0].parent_ID, stepID: 'L_OBD' })
                        if (!getLegacySO || !getL_OBD) {
                          logger.error("Not found getLegacySO or getL_OBD after ASN flow")

                        }

                        let businesKey = `${getLegacySO?.documentNumber}-${getL_OBD?.documentNumber}`

                        const subProcessResponses = await workflow.send({
                          method: "GET",
                          path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${businesKey}&definitionId=${afterASNFlow}&$orderby=startedAt desc`
                        });

                        const subProcessResponse = subProcessResponses[0]

                        if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED') {
                          logger.info("PO Trigger instance found")

                          await UPDATE(ShippingRequestEntityDocs)
                            .set({
                              errorStatus: "Error",
                              errorDescription: "Technical Error",
                              errorCreationDate: new Date(),
                              wfInstanceId: subProcessResponse?.id
                            })
                            .where({
                              ID: records[0]?.ID
                            });

                          await INSERT.into(ShippingRequestErrors).entries({
                            ID: cds.utils.uuid(),
                            parent_ID: records[0]?.ID,
                            vcaErrorStatus: "Technical Error from EntityDocs and afterASNFlow",
                            vcaErrorType: "Error",
                            wfInstanceId: subProcessResponse?.id,
                            vcaErrorTimeStamp: new Date()
                          })
                        }
                      }
                    }
                  }
                }
                // if (diffInMinutes > 5 && records[0].stepID === 'L_OBD') {
                //   logger.info(
                //     `Previous document ${findPrevDoc.ID} is pending without workflow instance for more than 5 minutes.`
                //   );
                //   const workflow = await cds.connect.to("workflowService");

                //   let po_OBD = 'us10.jnj-im-dev-na.zvcm55147financialflowscenario3project.zVCM55147_FinancialFlowScenario3Process';
                //   let oBD_Trigger = findPrevDoc.parent_initialDocumentNo;


                //   const subProcessResponses = await workflow.send({
                //     method: "GET",
                //     path: `/public/workflow/rest/v1/workflow-instances?status=ERRONEOUS&definitionId=${po_OBD}`
                //   });

                //   logger.info(subProcessResponses)

                //   let findLICSOStepID = await SELECT.one
                //     .from(ShippingRequestEntityDocs)
                //     .where({ parent_ID: findPrevDoc?.parent_ID, stepID: 'L_ICSO' });

                //   // let findICPO = await SELECT
                //   //   .from(ShippingRequestEntityDocs)
                //   //   .where({ parent_ID: findPrevDoc?.parent_ID, entityType: 'Virtual Entity 1', stepID: findICPOStepID?.stepID });

                //   const docNum = String(findLICSOStepID?.documentNumber ?? '').trim();

                //   const refPOResponses = subProcessResponses.filter(item => {
                //     const businessKey = item?.businessKey;

                //     if (typeof businessKey !== "string") {
                //       return false;
                //     }

                //     const leftPart = businessKey.includes("-")
                //       ? businessKey.split("-")[0].trim()
                //       : businessKey.trim();

                //     // logger.info(`BusinessKey : ${businessKey}`);
                //     // logger.info(`Left Part   : '${leftPart}'`);
                //     // logger.info(`Doc Number  : '${docNum}'`);

                //     return leftPart === String(docNum).trim();
                //   });

                //   logger.info(`Matched Responses: ${JSON.stringify(refPOResponses)}`);

                //   const documentMap = new Map();

                //   const documentNumbers = refPOResponses
                //     .filter(r => typeof r.businessKey === "string")
                //     .map(r => {
                //       const docNo = r.businessKey.split("-").pop().trim();
                //       documentMap.set(docNo, r);
                //       return docNo;
                //     });

                //   logger.info(documentNumbers);
                //   const existingDocs = await SELECT.from(ShippingRequestEntityDocs)
                //     .columns("documentNumber")
                //     .where({
                //       parent_ID: findPrevDoc.parent_ID,
                //       stepID: "L_OBD",
                //       documentNumber: { in: documentNumbers }
                //     });

                //   const existingDocSet = new Set(existingDocs.map(d => d.documentNumber));

                //   const currentTime = new Date();

                //   const isOlderThan5Minutes = refPOResponses.every(workflow => {
                //     const diffInMinutes =
                //       (currentTime.getTime() - new Date(workflow.startedAt).getTime()) / (1000 * 60);

                //     return diffInMinutes > 5;
                //   });

                //   for (let i=0;i<documentNumbers;i++) {
                //     if (!existingDocSet.has(docNo) && isOlderThan5Minutes) {
                //       const document = documentMap.get(docNo);

                //       const L_ICSO = await SELECT.one.from(ShippingRequestEntityDocs)
                //         .columns("documentNumber")
                //         .where({
                //           parent_ID: findPrevDoc.parent_ID,
                //           stepID: "L_ICSO"
                //         });
                //       if (!L_ICSO?.documentNumber) {
                //         logger.error("L_ICSO is not found")
                //         continue;
                //       }

                //       const existingOrphan = await SELECT.one.from(cds.entities.asnOrphanDocs)
                //         .where({
                //           legacyRefDocNum: L_ICSO.documentNumber,
                //           legacyDocNum: docNo
                //         });

                //       if (existingOrphan) {
                //         logger.error(`Already exists in orphan wit OBD ${docNo} and legacy So ${L_ICSO.documentNumber}`)
                //         continue;
                //       }

                //       let data = {
                //         ref_SO: L_ICSO.documentNumber,
                //         OBD: docNo,
                //         wfID: refPOResponses[i]?.id,
                //         initialDocumentNo: findPrevDoc?.parent_initialDocumentNo
                //       }

                //       let insertIntoOrphan = await dbOps.createAsnOrphan(data, req, findPrevDoc?.parent_initialDocumentNo, "Technical error for OBD came but not updated. Test.")


                //       logger.info("Orphan inserted successfully!"); // Logs the entire refPOResponses object

                //     }
                //   }
                // }
              }
            
          }
        }
      }

      }
      if (req.query.SELECT?.columns) {
        const mustHave = ['documentSequence', 'isExceptionalDocument'];
        mustHave.forEach(field => {
          if (!req.query.SELECT.columns.some(c => c.ref?.[0] === field)) {
            req.query.SELECT.columns.push({ ref: [field] });
          }
        });
      }

      // Force DB-side sorting
      req.query.SELECT.orderBy = [{ ref: ['documentSequence'], sort: 'asc' }];

      let data = await next();

      // if (Array.isArray(data)) {
      //   // Optional: filter out exceptional docs
      //   data = data.filter(row => row.isExceptionalDocument !== true);
      // }

      return data;
    } catch (err) {
      logger.error(500, `Error fetching EntityDocs: ${err.message}`);
    }
  });

  /**
   * READ handler for Shipping Request Queue
   */
  srv.on('READ', 'ShippingRequestQueue', async (req, next) => {
    const parentPO = req.data?.parentPO;
    if (!parentPO) return next();

    try {
      const inProgressItems = await SELECT
        .from(ShippingRequestQueue)
        .where({ parentPO, status: 'In Progress' });

      const itemsWithWf = inProgressItems.filter(item => item.wfInstanceId && item.wfInstanceId !== '');

      const itemsWithNoWf = inProgressItems.filter(item => item.wfInstanceId === '' || item.wfInstanceId === null);

      for (const item of itemsWithNoWf) {

        if (item.actionType === 'CANCEL' || item.actionType === 'UNCANCEL') {
          const workflow = await cds.connect.to("workflowService");

          let poCancel = 'us10.jnj-im-dev-na.zvcm55144cancellationofdocumentsinautomationproject.zVCM55144_CancellationOfDocumentsInAutomationProcess';
          let poCancelTrigger = item.ID;


          const subProcessResponses = await workflow.send({
            method: "GET",
            path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${poCancelTrigger}&definitionId=${poCancel}&$orderby=startedAt desc`
          });

          const subProcessResponse = subProcessResponses[0]

          const currentTime = new Date();

          const diffInMinutes =
            (currentTime.getTime() - new Date(subProcessResponse.startedAt).getTime()) / (1000 * 60);


          if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED' && diffInMinutes > 5) {
            logger.info("PO Trigger instance found")

            await UPDATE(ShippingRequestQueue)
              .set({
                status: "Error",
                errorMessage: "Technical Error",
                wfInstanceId: subProcessResponse?.id
              })
              .where({
                ID: item?.ID
              });

            await INSERT.into(QueueRequestErrors)
              .entries({
                ID: cds.utils(),
                parent_ID: item?.ID,
                errorType: "Error",
                errorMessage: "Technical Error",
                wfInstanceId: subProcessResponse?.id
              })
          }

        }

        if (item.actionType === 'ItemQuantityChanged') {
          const workflow = await cds.connect.to("workflowService");

          let ItemQuantityChangedDefinition = 'us10.jnj-im-dev-na.zvcm47421pochangeflowproject.qUantityChangeProcess';
          let ItemQuantityChangedTrigger = item.ID;


          const subProcessResponses = await workflow.send({
            method: "GET",
            path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${ItemQuantityChangedTrigger}&definitionId=${ItemQuantityChangedDefinition}&$orderby=startedAt desc`
          });

          const subProcessResponse = subProcessResponses[0]

          const currentTime = new Date();

          const diffInMinutes =
            (currentTime.getTime() - new Date(subProcessResponse.startedAt).getTime()) / (1000 * 60);


          if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED' && diffInMinutes > 5) {
            logger.info("PO Trigger instance found")

            await UPDATE(ShippingRequestQueue)
              .set({
                status: "Error",
                errorMessage: "Technical Error",
                wfInstanceId: subProcessResponse?.id
              })
              .where({
                ID: item?.ID
              });

            await INSERT.into(QueueRequestErrors)
              .entries({
                ID: cds.utils(),
                parent_ID: item?.ID,
                errorType: "Error",
                errorMessage: "Technical Error",
                wfInstanceId: subProcessResponse?.id
              })
          }

        }

        if (item.actionType === 'ItemDeliveryDateChanged') {
          const workflow = await cds.connect.to("workflowService");

          let ItemDeliveryDateChangedDefinition = 'us10.jnj-im-dev-na.zvcm47421pochangeflowproject.deleveryDateChange';
          let ItemDeliveryDateChangedTrigger = item.ID;


          const subProcessResponses = await workflow.send({
            method: "GET",
            path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${ItemDeliveryDateChangedTrigger}&definitionId=${ItemDeliveryDateChangedDefinition}&$orderby=startedAt desc`
          });

          const subProcessResponse = subProcessResponses[0]

          const currentTime = new Date();

          const diffInMinutes =
            (currentTime.getTime() - new Date(subProcessResponse.startedAt).getTime()) / (1000 * 60);


          if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED' && diffInMinutes > 5) {
            logger.info("PO Trigger instance found")

            await UPDATE(ShippingRequestQueue)
              .set({
                status: "Error",
                errorMessage: "Technical Error",
                wfInstanceId: subProcessResponse?.id
              })
              .where({
                ID: item?.ID
              });

            await INSERT.into(QueueRequestErrors)
              .entries({
                ID: cds.utils(),
                parent_ID: item?.ID,
                errorType: "Error",
                errorMessage: "Technical Error",
                wfInstanceId: subProcessResponse?.id
              })
          }

        }
        if (item.actionType === 'ItemAdd') {
          const workflow = await cds.connect.to("workflowService");

          let ItemAddDefinition = 'us10.jnj-im-dev-na.zvcm47421pochangeflowproject.zVCM47421_NewLineItemAddition';
          let ItemAddTrigger = item.ID;


          const subProcessResponses = await workflow.send({
            method: "GET",
            path: `/public/workflow/rest/v1/workflow-instances?status=RUNNING&status=ERRONEOUS&status=COMPLETED&businessKey=${ItemAddTrigger}&definitionId=${ItemAddDefinition}&$orderby=startedAt desc`
          });

          const subProcessResponse = subProcessResponses[0]

          const currentTime = new Date();

          const diffInMinutes =
            (currentTime.getTime() - new Date(subProcessResponse.startedAt).getTime()) / (1000 * 60);


          if (subProcessResponse && subProcessResponse?.status !== 'COMPLETED' && diffInMinutes > 5) {
            logger.info("PO Trigger instance found")

            await UPDATE(ShippingRequestQueue)
              .set({
                status: "Error",
                errorMessage: "Technical Error",
                wfInstanceId: subProcessResponse?.id
              })
              .where({
                ID: item?.ID
              });

            await INSERT.into(QueueRequestErrors)
              .entries({
                ID: cds.utils(),
                parent_ID: item?.ID,
                errorType: "Error",
                errorMessage: "Technical Error",
                wfInstanceId: subProcessResponse?.id
              })
          }

        }

      }





      for (const item of itemsWithWf) {
        try {
          const rootInstanceId = await utils.checkSubprocessWorkflowStatus(item.wfInstanceId, item.ID);

          if (rootInstanceId) {
            await UPDATE(ShippingRequestQueue)
              .set({ status: 'Error', errorMessage: 'Technical Error' })
              .where({ ID: item.ID });

            await UPDATE(ShippingRequest)
              .set({ status: 'Error' })
              .where({ initialDocumentNo: item.parentPO });

            logger.info(`Queue item ${item.ID} updated to Error (Technical Error) for PO: ${item.parentPO}`);
            try {
              await srv.send('QueueInError', { queueId: item.ID });
            } catch (queueErr) {
              logger.error(`QueueInError failed for queue ${item.ID}: ${queueErr.message}`);
            }
          }
        } catch (itemErr) {
          logger.error(`SBPA check failed for queue item ${item.ID}: ${itemErr.message}`);
        }
      }
    } catch (err) {
      logger.error('Inside ShippingRequestQueue catch', err.message);
    }

    return next();
  });

  srv.after('each', 'ShippingRequestQueue', (data) => {
    switch (data.status) {
      case 'Error':       data.statusCriticality = 1; break; // Red
      case 'Completed':   data.statusCriticality = 3; break; // Green
      case 'In Progress':
      case 'Retriggered': data.statusCriticality = 2; break; // Orange
      case 'To Process':  data.statusCriticality = 5; break; // Blue 
      default:            data.statusCriticality = 0;        // Neutral
    }
  });

  /**
   * READ handler for Business Partner Value Help
   */
  srv.on('READ', "I_BP_VH", (req) => ZSD_VCM_PRODUCTFLOW.run(req.query));
  srv.on('READ', "I_BPST_VH", (req) => ZUI_BILLINGDOCUMENTFS.run(req.query));

  /**
   * READ handler for Plant Value Help
   */
  srv.on('READ', "I_P_VH", (req) => ZSD_VCM_PRODUCTFLOW.run(req.query));

  /**
   * READ handler for Processing Stage Value Help
   * Returns predefined constant values
   */
  srv.on('READ', 'I_ProcessingStage_VH', async (req) => {
    return constants.ProcessingStage;
  });


  /**
    * After READ handler for ShippingRequestView (per record)
 * - Calculates priority & criticality based on requestedDeliveryDate
 * - Maps status → statusCriticality (for UI semantic colors/icons)
 * - Handles special case: if status=Error → priority = 'N/A'
 */
  srv.on('READ', 'ShippingRequestView', async (req, next) => {
    const { SELECT } = req.query;

    if (SELECT?.columns) {
      const mustHave = [
        'pfcCheckStatus',
        'scenarioDeterminationCheckStatus',
        'masterDataStatus',
        'docFlowStateCheckStatus'
      ];

      mustHave.forEach(field => {
        if (!SELECT.columns.some(c => c.ref?.[0] === field)) {
          SELECT.columns.push({ ref: [field] });
        }
      });
    }
    //change under Defect: JGHJ-76460**Start
    /* ---------- detect REAL user sorting ---------- */
    const hasUserSort = SELECT.orderBy?.some(o => o.implicit !== true);

    /* ---------- apply default ONLY if no user sort ---------- */
    if (!hasUserSort) {
      SELECT.orderBy = [{ ref: ['shippingReqNo'], sort: 'desc' }];
    }
    //change under Defect: JGHJ-76460**End

    return next();
  });

  srv.after('each', 'ShippingRequestView', (data, req) => {
    logger.info('READ ShippingRequestView triggered');
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    let { requestedDeliveryDate } = data;

    function normalize(val) {
      if (!val) return "None";
      const v = val.toLowerCase();
      if (v.includes("error")) return "Error";
      if (v.includes("success")) return "Success";
      if (v.includes("warning")) return "Warning";
      return "None"; // fallback for Pending/Unknown
    }

    data.pfcState = normalize(data?.pfcCheckStatus);
    data.scenarioState = normalize(data?.scenarioDeterminationCheckStatus);
    data.masterDataState = normalize(data?.masterDataStatus);
    data.docFlowState = normalize(data?.docFlowStateCheckStatus);

    // if (data.pfcState === "Error" || data.scenarioState === "Error" || data.masterDataState === "Error" || data.docFlowState === "Error") {
    //   data.status = bundle.getText('Error')
    // } else if (data.pfcState === "Success" && data.scenarioState === "Success" && data.masterDataState === "Success" && data.docFlowState === "Success") {
    //   data.status = bundle.getText('Completed')
    // } else if (data.pfcState === "None" && data.scenarioState === "None" && data.masterDataState === "None" && data.docFlowState === "None") {
    //   data.status = bundle.getText("InProgress")

    // } else {
    //   data.status = bundle.getText("InProgress")
    // }

    switch (data.status) {
      case 'Error':
        data.statusCriticality = 1; // Red icon
        break;
      case 'In Progress':
        data.statusCriticality = 2; // Yellow icon
        break;
      case 'Completed':
        data.statusCriticality = 3; // Green/success
        break;
      default:
        data.statusCriticality = 0; // None
    }

    if (data.status === bundle.getText('Error') && requestedDeliveryDate) {
      data.priority = 'N/A';
      data.Criticality = 0; // Neutral
    } else {
      const { priority, criticality } = calculatePriority(requestedDeliveryDate);
      data.priority = priority;
      data.Criticality = criticality;
    }

  });

  srv.on("updateShippingRequestItem", async (req) => {
    try {
      const { payload } = req.data;

      if (!payload?.ID) {
        return req.error(400, "ID is required for update");
      }

      // Check if item exists
      const existing = await SELECT.one.from('ShippingRequestItem').where({ ID: payload.ID });
      if (!existing) {
        return req.error(404, `ShippingRequestItem with ID ${payload.ID} not found`);
      }

      // Merge: only update provided fields
      const updatedFields = {};
      for (const key in payload) {
        if (payload[key] !== undefined && key !== "ID") {
          updatedFields[key] = payload[key];
        }
      }

      if (Object.keys(updatedFields).length === 0) {
        return req.error(400, "No valid fields provided for update");
      }

      // Perform partial update
      await UPDATE('ShippingRequestItem')
        .set(updatedFields)
        .where({ ID: payload.ID });

      // Return updated record
      const updated = await SELECT.one.from('ShippingRequestItem').where({ ID: payload.ID });
      return updated;

    } catch (error) {
      console.error("Error in updateShippingRequestItem:", error);
      return req.error(500, `Failed to update ShippingRequestItem: ${error.message}`);
    }
  });


  /* =======================================================
       MAIN ENTRY
    ======================================================= */
  srv.on("ShippingRequestItemCancellationAndPoChange", async (req) => {

    const tx = cds.tx(req);

    try {
      const { payload } = req.data;

      if (!payload?.purchaseOrder) {
        return req.error(400, "cancelPO required");
      }

      const PO = payload.purchaseOrder;
      const ITEM = payload.purchaseOrderItem;

      /* ACTION TYPE */
      let actionType = payload.type;

      /* =======================================================
         1 ENSURE LOCK ROW EXISTS
      ======================================================= */
      await tx.run(
        INSERT.into(PoLock).entries({ parentPO: PO })
      ).catch((err) => {
        console.log(err)
      }); // ignore duplicate

      /* =======================================================
         2 LOCK ONLY THIS PO
      ======================================================= */
      const lockTable = "JNJ_COM_ZBUVCM55155_POLOCK";

      await tx.run(`
        SELECT 1
        FROM "${lockTable}"
        WHERE "PARENTPO" = ?
        FOR UPDATE
      `, [PO]);

      /* =======================================================
         3 GET NEXT QUEUE NUMBER (SAFE)
      ======================================================= */

      const next = await tx.run(`
        SELECT COALESCE(MAX("QUEUENO"),0) + 1 as NEXT
        FROM "JNJ_COM_ZBUVCM55155_SHIPPINGREQUESTQUEUE"
        WHERE "PARENTPO" = ?
      `, [PO]);

      const queueNo = next[0].NEXT;

      /* =======================================================
         4 INSERT QUEUE ENTRY
      ======================================================= */
      await tx.run(
        INSERT.into(ShippingRequestQueue).entries({
          parentPO: PO,
          itemNo: ITEM,
          actionType,
          payload: JSON.stringify(payload),
          queueNo,
          status: 'To Process',
          quantity:payload?.quantity||'',
          deliveryDate:payload?.deliveryDate || ''
        })
      );

      /* =======================================================
         5 CLAIM NEXT JOB (FIFO)
      ======================================================= */
      const job = await claimNextQueue(tx, PO);

      const result = {
        message: "Queued successfully",
        queueNo
      };

      /* =======================================================
         6 TRIGGER AFTER COMMIT
      ======================================================= */
      if (job) {
        await tx.run(
          UPDATE(ShippingRequestQueue)
            .set({ status: 'In Progress' })
            .where({ ID: job.ID })
        );

        setImmediate(() => initiateWorkflow(job));
      }

      return result;

    } catch (error) {
      console.error("Queue Insert Failed:", error);
      req.reject(500, error.message);
    }
  });


  /* =======================================================
     CLAIM NEXT (STRICT FIFO PER PO)
  ======================================================= */
  async function claimNextQueue(tx, PO) {

    /* BLOCK IF ANY RUNNING */
     const running = await tx.run(
      SELECT.one.from(ShippingRequestQueue)
        .columns('ID')
        .where({
          parentPO: PO,
          status: { in: ['In Progress', 'Retriggered'] }
        })
    );

    if (running) return null;

    /* PICK LOWEST QUEUE */
    const next = await tx.run(
      SELECT.one.from(ShippingRequestQueue)
        .where({ parentPO: PO, status: 'To Process' })
        .orderBy({ queueNo: 'asc' })
    );

    if (!next) return null;

    /* MARK IN PROGRESS */
    return next;
  }


  
  /* =======================================================
     CLAIM ERROR NEXT (STRICT FIFO PER PO)
  ======================================================= */
  async function claimErrorNextQueue(tx, PO,queueNo,req) {

    /* BLOCK IF ANY RUNNING */
    const running = await tx.run(
      SELECT.one.from(ShippingRequestQueue)
        .columns('ID')
        .where({
          parentPO: PO,
          status: { in: ['In Progress', 'Retriggered'] }
        })
    );
    if (running) {
     throw new Error(`Cannot retrigger. Queue ${running.ID} is currently in progress for PO ${PO}`);
    }

    /* PICK LOWEST QUEUE */
    // const firstError = await tx.run(
    //   SELECT.one.from(ShippingRequestQueue)
    //     .where({
    //       parentPO: PO,
    //       status: 'Error'
    //     })
    //     .orderBy('queueNo asc')
    // );

    let next = null;


    next = await tx.run(
      SELECT.one.from(ShippingRequestQueue)
        .where({
          parentPO: PO,
          status: 'Error',
          queueNo: { '>': queueNo }
        })
        .orderBy('queueNo asc')
    );

    if (!next) return null;

    return next;
  }


  /* =======================================================
     WORKFLOW TRIGGER
  ======================================================= */
  async function initiateWorkflow(job) {

    try {
      const workflow = await cds.connect.to("workflowService");

      const context = {
        queueId: job.ID,       // UUID
        queueNo: job.queueNo,
        purchaseOrder: job.parentPO,
        purchaseOrderItem: job.itemNo,
        actionType: job.actionType
      };

      console.log("WORKFLOW PAYLOAD:", context);

      let definitionId = ''

      if (job.actionType === "CANCEL" || job.actionType === "UNCANCEL") {
        definitionId = constants.PO_WORKFLOW_CANCEL;

      } else if (job.actionType === "ItemQuantityChanged") {
        if (job.quantity == null) {
          throw new Error("Quantity missing for ItemQuantityChanged");
        }
        definitionId = constants.PO_QUANTITY_CHANGE;
        context.quantity = job.quantity;

      } else if (job.actionType === "ItemDeliveryDateChanged") {
        if (job.deliveryDate == null) {
          throw new Error("Quantity missing for ItemQuantityChanged");
        }
        definitionId = constants.PO_DELIVERYDATE_CHANGE;
        context.deliveryDate = job.deliveryDate;

      } else if (job.actionType === "ItemAdd") {
        definitionId = constants.LINE_ITEM_ADDITION;
      }

      else {
        throw new Error(`Job ${job.parentPO} and ${job.itemNo} has no action type!`);
      }

      await workflow.post(
        '/workflow/rest/v1/workflow-instances',
        {
          definitionId: definitionId,
          context
        }
      );

      console.log(`Workflow started for Queue ${job.queueNo}`);

    } catch (e) {
      console.error("Workflow trigger failed:", e);
    }
  }

  /* =======================================================
     SBPA CALLBACK
  ======================================================= */
  srv.on("QueueCompleted", async (req) => {

    const tx = cds.tx(req);
    let nextJob={};

    try {
      const { queueId, flag } = req.data;

      if (!queueId) {
        return req.error(400, "queueId required");
      }

      /* GET */
      const job = await tx.run(
        SELECT.one.from(ShippingRequestQueue)
          .where({ ID: queueId })
      );

      if (!job) {
        return req.error(404, "Queue not found");
      }

      /* COMPLETE */
      //Check for Item Cancel Scenario
      if (flag === 'S') {
        await tx.run(
          UPDATE(ShippingRequestQueue)
            .set({ status: 'Completed', errorMessage: 'Line item cancelled' })
            .where({ ID: queueId })
        );
        const itemAddExists = await tx.run(
          SELECT.one.from(ShippingRequestQueue)
            .columns('ID')
            .where({ parentPO: job.parentPO, itemNo: job.itemNo, actionType: 'ItemAdd', queueNo: { '<': job.queueNo } })
        );
        if (itemAddExists) {
          await tx.run(
            UPDATE(ShippingRequestQueue)
              .set({ status: 'Completed', errorMessage: 'PFC Failed: Line Item cancelled with CANCEL event' })
              .where({ parentPO: job.parentPO, itemNo: job.itemNo, actionType: 'ItemAdd', queueNo: { '<': job.queueNo } })
          );
        }
      } else {
        await tx.run(
          UPDATE(ShippingRequestQueue)
            .set({ status: 'Completed'})
            .where({ ID: queueId })
        );
      }
      
     if(job.actionType==="CANCEL"){
       await tx.run(
        UPDATE(ShippingRequestItem).set({
          status:"CL"
        }).where({parent_initialDocumentNo:job.parentPO,itemNo:job.itemNo})
      )
     }
     
     if(job.actionType==="UNCANCEL"){
       await tx.run(
        UPDATE(ShippingRequestItem).set({
          status:"A"
      }).where({parent_initialDocumentNo:job.parentPO,itemNo:job.itemNo})

        )
      }

      /* NEXT */
       nextJob = await claimNextQueue(tx, job.parentPO);

      if (nextJob) {
        
        setImmediate(() => initiateWorkflow(nextJob));
        await tx.run(
          UPDATE(ShippingRequestQueue)
            .set({ status: 'In Progress' })
            .where({ ID: nextJob.ID })
        );
      }

      return { message: `Queue ${nextJob?.queueNo} completed for ${nextJob?.parentPO} and ${nextJob?.itemNo}` };

    } catch (error) {
      console.error(`Queue ${nextJob?.queueNo} failed for ${nextJob?.parentPO} and ${nextJob?.itemNo}`, error);
      req.reject(500, error.message);
    }
  });

   /* =======================================================
     SBPA CALLBACK
  ======================================================= */
  srv.on("QueueInError", async (req) => {

    const tx = cds.tx(req);
    let nextJob={};

    try {
      const { queueId } = req.data;

      if (!queueId) {
        return req.error(400, "queueId required");
      }

      /* GET */
      const job = await tx.run(
        SELECT.one.from(ShippingRequestQueue)
          .where({ ID: queueId })
      );

      if (!job) {
        return req.error(404, "Queue not found");
      }

      /* NEXT */
       nextJob = await claimNextQueue(tx, job.parentPO);
      if (nextJob) {
      
        setImmediate(() => initiateWorkflow(nextJob));
         await tx.run(
          UPDATE(ShippingRequestQueue)
            .set({ status: 'In Progress' })
            .where({ ID: nextJob.ID })
        );
      } else {
        let errorJob = await claimErrorNextQueue(tx, job.parentPO, job.queueNo,req);
        if (errorJob && errorJob.status === "Error" && errorJob.wfInstanceId && errorJob.wfInstanceId !== '') {
          setImmediate(async () => {
            try {
              const wfResult = await utils.InitiateSubProcessWorkFlowInstance(req, errorJob.wfInstanceId, errorJob.ID, true);
              if (!wfResult) {
                logger.warn(`Workflow not started for queue ${errorJob.ID} — reverting to Error`);
                const revertTx = cds.tx();
                await revertTx.run(UPDATE(ShippingRequestQueue).set({ status: 'Error', errorMessage: 'Could not initiate reprocess workflow. Workflow instance may have expired.' }).where({ ID: errorJob.ID }));
                await revertTx.commit();
              }
            } catch (e) {
              logger.error(`InitiateSubProcessWorkFlowInstance failed for queue ${errorJob.ID}: ${e.message}`);
              const recoveryTx = cds.tx();
              await recoveryTx.run(UPDATE(ShippingRequestQueue).set({ status: 'Error', errorMessage: e.message }).where({ ID: errorJob.ID }));
              await recoveryTx.commit();
            }
          });
          await tx.run(
            UPDATE(ShippingRequestQueue)
              .set({ status: 'Retriggered' })
              .where({ ID: errorJob.ID })
          );

        } else {
          console.log(`No next job found for PO ${job.parentPO} after error in queue ${job.queueNo}`);
        }
      }
      return { message: `Queue ${nextJob?.queueNo} started for ${nextJob?.parentPO} and ${nextJob?.itemNo}` };

    } catch (error) {
      console.error(`Queue ${nextJob?.queueNo} failed for ${nextJob?.parentPO} and ${nextJob?.itemNo}`, error);
      req.reject(500, error.message);
    }
  });

  function calculatePriority(requestedDeliveryDate) {
    if (!requestedDeliveryDate) return { priority: 'N/A', criticality: 0 };

    const today = new Date();
    const deliveryDate = new Date(requestedDeliveryDate);
    const diffDays = Math.floor(
      (deliveryDate.setHours(0, 0, 0, 0) - today.setHours(0, 0, 0, 0)) /
      (1000 * 60 * 60 * 24)
    );

    if (diffDays <= 0) return { priority: 'Critical', criticality: 1 };
    if (diffDays <= 6) return { priority: 'High', criticality: 2 };
    if (diffDays <= 12) return { priority: 'Medium', criticality: 3 };
    return { priority: 'Low', criticality: 3 };
  }

  /**
 * Service handler for custom action/function getLocationSummary
 *Fetches location summary records for a given Shipping Request,
 * removes duplicates based on entityType + entityRank, and returns
 * a cleaned-up list ordered by entityRank.
 * @param {object} req - CAP request context
 * @param {string} req.data.shippingReqNo - Shipping Request Number
 * @returns {Promise<Array>} Unique list of location summary records
 */
  srv.on('getLocationSummary', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    const shippingReqNo = req.data.shippingReqNo.slice(1, -1);

    try {
      const result = await dbOps.getLocationSummary(shippingReqNo, bundle);
      return result;
    } catch (error) {
      req.error(400, error.message || bundle.getText('FailedToLoadLocationSummary'));
    }
  });


  /**
  * Creates a new ShippingRequest with items.
  * @param {import('@sap/cds/apis/services').Request} req - CAP request
  * @param {object} req.data.payload - Header and items payload
  * @returns {Promise<{shippingReqNo: string}>} Newly created Shipping Request number
  */
  srv.on('createShippingRequest', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {

      const payload = req.data.payload;
      const result = await dbOps.createShippingRequest(payload, bundle, ZSD_VCM_PRODUCTFLOW);
      return result;
    } catch (error) {
      req.error(500, error.message || bundle.getText('FailedToCreateShippingRequest'));
    }
  })

  /**
  * Updates a ShippingRequest header.
  * @param {import('@sap/cds/apis/services').Request} req - CAP request
  * @param {object} req.data.payload - Fields to update, must include shippingReqNo and initialDocumentNo
  * @returns {Promise<object>} Updated ShippingRequest record
  */
  srv.on('updateheaderdata', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data.payload;
      const result = await dbOps.updateHeaderData(data, ZSD_VCM_PRODUCTFLOW, bundle);
      return result;
    } catch (error) {
      logger.error(error);
      return req.error(500, `${bundle.getText('FailedToUpdateHeader')} ${error.message}`);
    }
  });

  /**
   * updateEntitytable
   * Updates a ShippingRequestEntityDocs record based on plant, shippingReqNo, initialDocumentNo, and documentType.
   * Only the documentNumber can be updated; validates required fields and ensures at least one update field is provided.
   * @param {import('@sap/cds/apis/services').Request} req - CAP request context
   * @param {object} req.data.payload - Payload with required keys: plant, shippingReqNo, initialDocumentNo, documentType, optional documentNumber
   * @returns {Promise<string>} Confirmation message
   */

  srv.on('updateEntitytable', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data.payload;
      const result = await dbOps.updateEntityTable(data, bundle, req);
      return result;
    } catch (error) {
      logger.error(error);
      return req.error(500, `${bundle.getText('FailedToUpdateEntityDocument')} ${error.message}`);
    }
  });
  /**
   * updateCancellation
   * Updates a ShippingRequestEntityDocs record based on ID.
   * @param {import('@sap/cds/apis/services').Request} req - CAP request context
   * @param {object} req.data.payload - Payload with required keys: ID, errorStatus, errorDescription
   * @returns {Promise<string>} Confirmation message
   */

  srv.on('updateCancellation', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data.payload;
      const result = await dbOps.updateCancellation(data, bundle, req);
      return result;
    } catch (error) {
      logger.error(error);
      return req.error(500, `${bundle.getText('FailedToUpdateEntityDocument')} ${error.message}`);
    }
  });

  /**
 * Updates error info for a ShippingRequestEntityDocs record and inserts a ShippingRequestErrors entry if needed.
 * @param {import('@sap/cds/apis/services').Request} req - CAP request context
 * @param {object} req.data.payload - Payload: shippingReqNo, initialDocumentNo, documentSequence, errorStatus, errorDescription, vcaErrorStatus, vcaErrorType, wfInstanceId
 * @returns {Promise<boolean>} True if update succeeded
 */
  srv.on('updateErrorTable', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data.payload;
      const result = await dbOps.updateErrorTable(data, bundle);
      return result;
    } catch (err) {
      req.error(500, `${bundle.getText('UpdateFailed')} ${err.message}`);
    }
  })


  /**
* Updates ShippingRequest header and child entities (items, Ship From, Virtual Entities, Ship To) based on PFC check data.
* @param {import('@sap/cds/apis/services').Request} req - CAP request
* @param {object} req.data.payload - Payload containing ShippingReqId, initialDocumentNo, PfcCatId, ProdId, optional Matnr, MatBrand, Ship From/To info, and VirtualEntity array
* @returns {Promise<string>} 'Success' if update completes
*/
  srv.on('updatePFCCheck', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data.payload;
      const result = await dbOps.updatePFCCheck(data, bundle, req);
      return result;
    } catch (error) {
      logger.error(error);
      req.error(500, error.message || bundle.getText('ErrorUpdatingPFCCheck'));
    }
  });



  /**
  * updateScenarioSteps
  * Updates scenario steps for a ShippingRequest:
  * deletes previous entity docs, rebuilds Ship From, Virtual Entities, Ship To,
  * assigns ranks, enriches with BP/Plant info, and inserts updated docs.
  * @param {import('@sap/cds/apis/services').Request} req - CAP request
  * @param {object} req.data.payload - Payload with shippingReqNo, initialDocumentNo, and steps [{Steps, Sequence, EntityType}]
  * @returns {Promise<{message: string}>} Confirmation message
  */

  srv.on('updateScenarioSteps', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data.payload || req.data;
      const result = await dbOps.updateScenarioSteps(data, req, ZSD_VCM_PRODUCTFLOW, bundle);
      return result;
    } catch (error) {
      logger.error(error);
      req.error(500, error.message || bundle.getText('ErrorUpdatingScenarioSteps'));
    }
  });


  srv.on('updateScenario3Steps', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data.payload || req.data;
      const result = await dbOps.updateScenario3Steps(data, req, ZSD_VCM_PRODUCTFLOW, bundle);
      return result;
    } catch (error) {
      logger.error(error);
      req.error(500, error.message || bundle.getText('ErrorUpdatingScenarioSteps'));
    }
  });

  srv.on('processLegacyOutbound', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    
    try {
      // throw new Error('Testing')
      const data = req.data.payload;
      //Open Items JGHJ-87133 R2.2 change start
      if (!process.env?.ASNCHECK) {
        logger.info('Inside ASN logic');
        const asnLogicCheck = await dbOps.asnCheck(data, req, bundle);
        if (asnLogicCheck.status === false) {
          //email notification logic
          await sendASNMail(req, data, asnLogicCheck.messages, 'VALIDATION_ERROR');
          logger.info('Inside ASN Insert response');
          return {
            message : bundle.getText('asnOrphanInsert'),
            flag: constants.statusF
          }
        }
      }
      //Open Items JGHJ-87133 R2.2 change end
      logger.info('Outside ASN logic');
      const result = await dbOps.processLegacyOutbound(data, req, bundle);
      return result;
    } catch (error) {
      logger.error('Inside processLegacyOutbound catch', error);
      //email notification logic
      await sendASNMail(req, req.data.payload, [error.message], 'TECHNICAL_ERROR');
      req.error(500, error.message || bundle.getText('ErrorUpdatingScenarioSteps'));
    }
  });

  /**
 * Custom action handler to update exceptional documents
 * 
 * - Validates incoming payload (ID and steps array)
 * - Fetches parent ShippingRequest by ID
 * - Maps steps to ShippingRequestEntityDocs entries with default values
 * - Inserts new exceptional document records into the database
 * - Returns the parent ID
 */
  srv.on('updateExceptionalDocs', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data.payload;

      const result = await dbOps.updateExceptionalDocs(data, ZSD_VCM_PRODUCTFLOW, bundle);
      return result; // { ID }
    } catch (error) {
      logger.error(error);
      req.error(500, error.message || bundle.getText('ErrorUpdatingExceptionalDocuments'));
    }
  });


  srv.on('remanufacturingDocs', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data.payload;

      const result = await dbOps.remanufacturingDocs(data, ZSD_VCM_PRODUCTFLOW, bundle);
      return result; // { ID }
    } catch (error) {
      logger.error(error);
      req.error(500, error.message || bundle.getText('ErrorUpdatingExceptionalDocuments'));
    }
  });

  srv.on('retainBagDocs', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const data = req.data.payload;

      const result = await dbOps.retainBagDocs(data, bundle);
      return result; // { ID }
    } catch (error) {
      logger.error(error);
      req.error(500, error.message || bundle.getText('ErrorUpdatingInRetainBag'));
    }
  });


  /**
   * READ handler for FeatureControl
   *
   * - Determines whether a certain operation should be hidden based on user roles
   * - Checks if the current user has a specific role
   * - Returns a simple object with the `operationHidden` flag
   */

  srv.on('READ', 'FeatureControl', async (req) => {
    let operationHidden = true

    if (req.user.is('XS2-VCM-APP-MONIT-MNT') || req.user.is('XS2-VCM-APP-MONIT-SCA')) {
      operationHidden = false
    }

    return {
      operationHidden: operationHidden
    }
  })

  /**
* Custom function handler to get Legal Entity details for AT 
* 
* - Fetches ShippingRequestEntityDocs by initialDocumentNo and referenceDocumentNo
* - Converts the Row Entity Data to Column Entity Data
* - Returns the converted Entity Data to AT
*/
  srv.on('getLegalEntityDetails', async (req) => {

    try {
      logger.info("---------- Legal Entity API called from AT ---------")
      const locale = req.user.locale;
      const bundle = textBundle.getTextBundle(locale);
      const { initialDocumentNo, referenceDocumentNo } = req.data;
      let entityDocsForAT = await dbOps.getEntityDocsForAT(initialDocumentNo, referenceDocumentNo, bundle)
      logger.info("---------- Legal Entity recieved from DB ---------")
      let convertToAT = utils.convertForAT(entityDocsForAT)
      logger.info("---------- Legal Entity converted and returned to AT ---------")
      await utils.getPODetails(convertToAT)
      return convertToAT
    } catch (error) {
      logger.error(error);
      req.error(500, error.message || bundle.getText('ErrorInGettingEntityDocumentForAT'));
    }
  })

  /**
* Custom action handler to get Header details for AT 
* 
* - Fetches ShippingRequestEntityDocs by initialDocumentNo and referenceDocumentNo
* - Converts the Row Entity Data to Column Entity Data
* - Returns the converted Entity Data to AT
*/
  srv.on('getHeaderDetails', async (req) => {

    try {
      logger.info("---------- Header API called from AT ---------")
      const locale = req.user.locale;
      const bundle = textBundle.getTextBundle(locale);
      const aHeaderReqAt = req.data.payload;
      const headerData = await dbOps.getHeaderForAT(aHeaderReqAt, bundle)
      await utils.updateMaterailDescription(headerData)
      return utils.transformExact(headerData, bundle)

    } catch (error) {
      logger.error(error);
      req.error(500, error.message || bundle.getText('ErrorInGettingHeaderForAT'));
    }
  })

  /**
   * Action handler for "runShippingRequestReprocessJob"
   *
   * - Triggers the Shipping Request reprocessing logic asynchronously
   * - Executes the reprocess job in the background using setTimeout
   *   to avoid blocking the request-response cycle
   * - Delegates the actual reprocessing logic to
   *   `utils.runBackgroundReprocessJob`
   * - Immediately returns control to the caller while the job
   *   continues in the background
   */

  //R2.2 Start
  srv.on('runShippingRequestReprocessJob', async (req) => {
    // Run background job after 100ms
    setTimeout(() => utils.runBackgroundReprocessJob(req), 100);
    return;
  });
  //R2.2 END

  /**
   * Action handler for "Reprocess"
   *
   * - Checks if required identifiers are provided (ID, shippingReqNo, initialDocumentNo)
   * - Determines whether the top-level Shipping Request or its Entity Docs have errors
   * - If errors exist, restarts the corresponding workflow using the Workflow Instance ID
   * - Returns a message about the action performed
   */
  // srv.on('Reprocess', async (req) => {
  //   const locale = req.user.locale;
  //   const bundle = textBundle.getTextBundle(locale);
  //   let wFlag = 0;
  //   try {
  //     const data = req.params?.[0];
  //     if (!data) throw new Error(bundle.getText('RequestParametersareMissing'));

  //     const { shippingReqNo, initialDocumentNo, ID } = data;
  //     if (!ID || !shippingReqNo || !initialDocumentNo) {
  //       throw new Error(bundle.getText('MissingKeys'));
  //     }

  //     const { ShippingRequest, ShippingRequestEntityDocs } = cds.entities;

  //     const getShipingReq = await SELECT.one
  //       .from(ShippingRequest)
  //       .where({ ID, shippingReqNo, initialDocumentNo });

  //     if (!getShipingReq) {
  //       throw new Error(`${bundle.getText('ShippingRequestNotFound')} ${ID}`);
  //     }

  //     const statusFields = [
  //       "pfcCheckStatus",
  //       "masterDataStatus",
  //       "scenarioDeterminationCheckStatus"
  //     ];

  //     // Case 1: Top-level errors or master data warning
  //     const hasError =
  //       statusFields
  //         .some(status => getShipingReq[status] === "Error");
  //     const hasWarning = getShipingReq.masterDataStatus === "Warning";

  //     if(hasWarning){
  //       wFlag = 1;
  //     }

  //     if (hasError || hasWarning) {
  //       if (!getShipingReq.wfInstanceId) {
  //         throw new Error(bundle.getText('WorkflowInstanceIDMissing'));
  //       }
  //       let flag=true;
  //       const wfResult = await utils.InitiateSubProcessWorkFlowInstance(req, getShipingReq.wfInstanceId, getShipingReq.ID, flag, wFlag);

  //       if (!wfResult) {
  //         throw new Error('Could not initiate reprocess workflow. Workflow instance may have expired or is in an invalid state.');
  //       }

  //       const fieldsToRetrigger = statusFields.filter(
  //         field => getShipingReq[field] === "Error" ||
  //                  (field === "masterDataStatus" && getShipingReq[field] === "Warning")
  //       );

  //       const updatePayload = {};

  //       fieldsToRetrigger.forEach(field => {
  //         updatePayload[field] = "Retriggered";
  //       });

  //       updatePayload.status = "In Progress"
  //       await UPDATE(ShippingRequest)
  //         .set(updatePayload)
  //         .where({ ID });

  //       logger.info(`${bundle.getText('WorkflowRestartedForShippingRequest')} for ${ID}`)


  //       // return { message: bundle.getText('WorkflowRestartedForShippingRequest'), ID };
  //     }

  //     // Case 2: Entity Docs errors
  //     const entityDocs = await SELECT.from(ShippingRequestEntityDocs).where({
  //       parent_shippingReqNo: shippingReqNo,
  //       parent_initialDocumentNo: initialDocumentNo,
  //       parent_ID: ID
  //     });

  //     // Check for record if its Pending and has wfId then trigger new SubProcess Task 
  //     const pendingError = entityDocs.find(doc => doc.errorStatus === "Error" && doc.wfInstanceId && doc.wfInstanceId !== '');
  //     const flag = true;
  //     if (pendingError) {

  //       const wfResult = await utils.InitiateSubProcessWorkFlowInstance(req, pendingError.wfInstanceId, pendingError.ID, flag);

  //       if (wfResult) {
  //         await UPDATE(ShippingRequestEntityDocs)
  //           .set({ errorStatus: "Retriggered" })
  //           .where({
  //             ID: pendingError?.ID
  //           });

  //         await UPDATE(ShippingRequest)
  //           .set({ status: "In Progress", docFlowStateCheckStatus: 'In Progress' })
  //           .where({
  //             ID: pendingError?.parent_ID
  //           });

  //         req.info(bundle.getText('Reprocessinginitiated'));
  //       } else {
  //         throw new Error(`Could not initiate reprocess workflow for document: ${pendingError.documentType || pendingError.ID}. Workflow instance may have expired or is in an invalid state.`);
  //       }

  //     }

  //     // Reset header if stuck at Error with no active pre-req or entity doc errors
  //     if (!hasError && !pendingError && getShipingReq.status === 'Error') {
  //       await UPDATE(ShippingRequest)
  //         .set({ status: 'In Progress' })
  //         .where({ ID });
  //     }

  //     // Case 3: Change Events Queue errors
  //     let POWorkflowId = await SELECT
  //       .from(ShippingRequestQueue)
  //       .columns('ID', 'wfInstanceId', 'status', 'queueNo', 'parentPO')
  //       .where({ parentPO: initialDocumentNo })
  //       .orderBy('queueNo asc');

  //     const inProgress = POWorkflowId.find(x => x.status === "In Progress");
  //     if (inProgress) {
  //       throw new Error(`There is already an in-progress workflow for PO`);
  //     }

  //     const errorWithWF = POWorkflowId.find(x => (x.status === "Error" || x.status === "Retriggered") && x.wfInstanceId);
  //     if (errorWithWF) {
  //       const result = await utils.InitiateSubProcessWorkFlowInstance(req, errorWithWF.wfInstanceId, errorWithWF.ID, flag);
  //       if (result) {
  //         await UPDATE(ShippingRequestQueue)
  //           .set({ status: "Retriggered" })
  //           .where({ ID: errorWithWF.ID });
  //         req.info('Reprocessing initiated for PO: ' + errorWithWF.parentPO);
  //       } else {
  //         req.warn('Workflow could not be started for PO: ' + initialDocumentNo);
  //       }
  //       return { message: bundle.getText('WorkflowRestartedForChangeEvents'), ID };
  //     }

  //     const errorWithoutWF = POWorkflowId.find(x => x.status === "Error" && !x.wfInstanceId);
  //     if (errorWithoutWF) {
  //       throw new Error(`There is an error workflow for PO: ${errorWithoutWF.parentPO} but no workflow instance ID is available.`);
  //     }

  //     return { message: bundle.getText('NoErrorFoundEntityDocs'), ID };

  //   } catch (err) {
  //     req.error({
  //       code: "REPROCESS_FAILED",
  //       message: err.message,
  //       target: "Reprocess"
  //     });
  //   }
  // });

  // Refactored 'Reprocess' handler
  // Each case (prerequisites, entity docs, PO change events) now runs in its
  // own independent transaction via cds.tx({user,tenant,locale}, fn). A plain
  // context snapshot is used instead of req itself (req.tx is read-only, so
  // passing req directly throws "Cannot assign to read only property 'tx'").
  // A failure in one case
  // no longer rolls back UPDATEs already committed by another case.
  //
  // NOTE: this assumes the same top-of-file requires/imports as the original
  // file (cds, textBundle, utils, logger, ShippingRequestQueue, etc).


  srv.on('Reprocess', async (req) => {

    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);

    const data = req.params?.[0];

    if (!data) {
      return req.error({
        code: 'REPROCESS_FAILED',
        message: bundle.getText('RequestParametersareMissing'),
        target: 'Reprocess'
      });
    }

    const {
      shippingReqNo,
      initialDocumentNo,
      ID
    } = data;

    if (!ID || !shippingReqNo || !initialDocumentNo) {
      return req.error({
        code: 'REPROCESS_FAILED',
        message: bundle.getText('MissingKeys'),
        target: 'Reprocess'
      });
    }

    const {
      ShippingRequest,
      ShippingRequestEntityDocs,
      ShippingRequestQueue
    } = cds.entities;

    const outcome = {
      messages: [],
      errors: []
    };


    // =========================================================
    // GET SHIPPING REQUEST
    // =========================================================

    const getShippingReq = await SELECT.one
      .from(ShippingRequest)
      .where({
        ID,
        shippingReqNo,
        initialDocumentNo
      });

    if (!getShippingReq) {
      return req.error({
        code: 'REPROCESS_FAILED',
        message:
          `${bundle.getText('ShippingRequestNotFound')} ${ID}`,
        target: 'Reprocess'
      });
    }


    const statusFields = [
      'pfcCheckStatus',
      'masterDataStatus',
      'scenarioDeterminationCheckStatus'
    ];

    const hasError = statusFields.some(
      status => getShippingReq[status] === 'Error'
    );

    // const hasWarning =
    //   getShippingReq.masterDataStatus === 'Warning';


    // =========================================================
    // 1. PREREQUISITES
    // =========================================================

    try {

      if (hasError) {

        // const wFlag = hasWarning ? 1 : 0;

        if (!getShippingReq.wfInstanceId) {
          throw new Error(
            bundle.getText('WorkflowInstanceIDMissing')
          );
        }


        // -----------------------------------------------------
        // IMPORTANT:
        // NO DB TRANSACTION IS OPEN HERE
        // SBPA call can take time without holding DB connection
        // -----------------------------------------------------

        const wfResult =
          await utils.InitiateSubProcessWorkFlowInstance(
            req,
            getShippingReq.wfInstanceId,
            getShippingReq.ID,
            true
          );


        if (!wfResult) {
          throw new Error(
            'Could not initiate reprocess workflow. ' +
            'Workflow instance may have expired or is in an invalid state.'
          );
        }


        // -----------------------------------------------------
        // Prepare update
        // -----------------------------------------------------

        const fieldsToRetrigger = statusFields.filter(
          field =>
            getShippingReq[field] === 'Error' ||
            (
              field === 'masterDataStatus' &&
              getShippingReq[field] === 'Warning'
            )
        );

        const updatePayload = {};

        fieldsToRetrigger.forEach(field => {
          updatePayload[field] = 'Retriggered';
        });

        updatePayload.status = 'In Progress';


        // -----------------------------------------------------
        // SHORT DB TRANSACTION
        // -----------------------------------------------------

        const prereqTx = cds.tx();

        try {

          await prereqTx.run(
            UPDATE(ShippingRequest)
              .set(updatePayload)
              .where({
                ID
              })
          );

          await prereqTx.commit();

        } catch (txError) {

          await prereqTx.rollback();

          throw txError;
        }


        logger.info(
          `${bundle.getText(
            'WorkflowRestartedForShippingRequest'
          )} for ${ID}`
        );

        outcome.messages.push(
          bundle.getText(
            'WorkflowRestartedForShippingRequest'
          )
        );
      }

    } catch (e) {

      logger.error(
        `[Prerequisites] Reprocess failed for ${ID}: ${e.message}`
      );

      outcome.errors.push({
        stage: 'prerequisites',
        message: e.message
      });
    }



    // =========================================================
    // 2. ENTITY DOCS
    // =========================================================

    try {

      // -------------------------------------------------------
      // READ ONLY
      // No long-running transaction
      // -------------------------------------------------------

      const wFlag = 3;
      const entityDocs = await SELECT
        .from(ShippingRequestEntityDocs)
        .where({
          parent_shippingReqNo: shippingReqNo,
          parent_initialDocumentNo: initialDocumentNo,
          parent_ID: ID
        })
        .orderBy('documentSequence asc');


      const pendingErrors = entityDocs.filter(
        doc =>
          doc.errorStatus === 'Error' &&
          doc.wfInstanceId
      );


      if (pendingErrors.length > 0) {

        let retriggeredCount = 0;
        const txErrors = [];

        for (const pendingError of pendingErrors) {

          let wfResult;


          // -----------------------------------------------------
          // SBPA CALL
          // NO DB TRANSACTION OPEN
          // -----------------------------------------------------

          if (
            getShippingReq.initialDocumentType ===
            'Purchase Order' || (getShippingReq.initialDocumentType ===
              'Sales Order' && pendingError.errorDescription.includes('Technical Error'))
          ) {

            wfResult =
              await utils.InitiateSubProcessWorkFlowInstance(
                req,
                pendingError.wfInstanceId,
                pendingError.ID,
                true,
                wFlag
              );

          } else {

            wfResult =
              await utils.InitiateWorkFLow(
                req,
                pendingError.wfInstanceId,
                'docLevel'
              );
          }


          if (!wfResult) {
            logger.warn(
              `Could not retrigger workflow for document: ` +
              `${pendingError.documentType || pendingError.ID}. ` +
              `Workflow instance may have expired or is in an invalid state.`
            );
            continue;
          }


          // -----------------------------------------------------
          // SHORT DB TRANSACTION
          // -----------------------------------------------------

          const entityTx = cds.tx();

          try {

            await entityTx.run(
              UPDATE(ShippingRequestEntityDocs)
                .set({
                  errorStatus: 'Retriggered'
                })
                .where({
                  ID: pendingError.ID
                })
            );


            await entityTx.run(
              UPDATE(ShippingRequest)
                .set({
                  status: 'In Progress',
                  docFlowStateCheckStatus: 'In Progress'
                })
                .where({
                  ID
                })
            );


            await entityTx.commit();

            retriggeredCount++;
            logger.info(`Reprocess: retriggered entity doc ${pendingError.ID} for SR ${ID}`);

          } catch (txError) {

            await entityTx.rollback();
            logger.error(`Reprocess: tx failed for entity doc ${pendingError.ID}: ${txError.message}`);
            txErrors.push(txError.message);
          }

        }

        if (retriggeredCount > 0) {
          outcome.messages.push(
            bundle.getText('Reprocessinginitiated')
          );
        } else {
          logger.warn(`Reprocess: all entity doc retriggers failed for SR ${ID}`);
          outcome.errors.push({
            stage: 'entityDocs',
            message: txErrors.length > 0
              ? txErrors[0]
              : 'Could not retrigger workflow for any errored entity document. Workflow instance may have expired or is in an invalid state.'
          });
        }

      } else {

        // -----------------------------------------------------
        // No pending entity document
        // Reset header if required
        // -----------------------------------------------------

        if (
          !hasError &&
          getShippingReq.status === 'Error'
        ) {

          const entityResetTx = cds.tx();

          try {

            await entityResetTx.run(
              UPDATE(ShippingRequest)
                .set({
                  status: 'In Progress'
                })
                .where({
                  ID
                })
            );

            await entityResetTx.commit();

          } catch (txError) {

            await entityResetTx.rollback();

            throw txError;
          }
        }
      }

    } catch (e) {

      logger.error(
        `[EntityDocs] Reprocess failed for ${ID}: ${e.message}`
      );

      outcome.errors.push({
        stage: 'entityDocs',
        message: e.message
      });
    }



    // =========================================================
    // 3. PO CHANGE EVENTS
    // =========================================================

    try {

      // -------------------------------------------------------
      // READ QUEUE
      // -------------------------------------------------------

      const POWorkflowIds = await SELECT
        .from(ShippingRequestQueue)
        .columns(
          'ID',
          'wfInstanceId',
          'status',
          'queueNo',
          'parentPO'
        )
        .where({
          parentPO: initialDocumentNo
        })
        .orderBy('queueNo asc');


      // -------------------------------------------------------
      // Check if workflow already running
      // -------------------------------------------------------

      const inProgress = POWorkflowIds.find(
        x => x.status === 'In Progress'
      );


      if (inProgress) {
        throw new Error(
          'There is already an in-progress workflow for PO'
        );
      }


      // -------------------------------------------------------
      // Find workflow that can be retriggered
      // -------------------------------------------------------

      const errorWithWF = POWorkflowIds.find(
        x =>
          (
            x.status === 'Error' ||
            x.status === 'Retriggered'
          ) &&
          x.wfInstanceId
      );


      if (errorWithWF) {


        // -----------------------------------------------------
        // SBPA CALL
        // NO DB TRANSACTION OPEN
        // -----------------------------------------------------

        const result =
          await utils.InitiateSubProcessWorkFlowInstance(
            req,
            errorWithWF.wfInstanceId,
            errorWithWF.ID,
            true,
            'queue'
          );


        if (!result) {

          throw new Error(
            `Workflow could not be started for PO: ` +
            `${initialDocumentNo}`
          );
        }


        // -----------------------------------------------------
        // SHORT DB TRANSACTION
        // -----------------------------------------------------

        const poChangeTx = cds.tx();

        try {

          await poChangeTx.run(
            UPDATE(ShippingRequestQueue)
              .set({
                status: 'Retriggered'
              })
              .where({
                ID: errorWithWF.ID
              })
          );


          await poChangeTx.commit();

        } catch (txError) {

          await poChangeTx.rollback();

          throw txError;
        }


        outcome.messages.push(
          bundle.getText(
            'WorkflowRestartedForChangeEvents'
          )
        );


      } else {


        // -----------------------------------------------------
        // Error exists but no WF ID
        // -----------------------------------------------------

        const errorWithoutWF =
          POWorkflowIds.find(
            x =>
              x.status === 'Error' &&
              !x.wfInstanceId
          );


        if (errorWithoutWF) {

          throw new Error(
            `There is an error workflow for PO: ` +
            `${errorWithoutWF.parentPO} ` +
            `but no workflow instance ID is available.`
          );
        }
      }


    } catch (e) {

      logger.error(
        `[POChangeEvents] Reprocess failed for ${ID}: ${e.message}`
      );

      outcome.errors.push({
        stage: 'poChangeEvents',
        message: e.message
      });
    }



    // =========================================================
    // FINAL RESPONSE
    // =========================================================

    outcome.errors.forEach(e => {

      req.warn({
        code: 'REPROCESS_PARTIAL_FAILURE',
        message: `[${e.stage}] ${e.message}`,
        target: 'Reprocess'
      });

    });


    outcome.messages.forEach(m => {
      req.info(m);
    });


    if (
      !outcome.messages.length &&
      !outcome.errors.length
    ) {

      return {
        message:
          bundle.getText('NoErrorFoundEntityDocs'),
        ID
      };
    }


    return {
      ID,
      messages: outcome.messages,
      errors: outcome.errors
    };

  });

  // Start -R2.2 Non VCA 76044
  /**
 * Creates a new ShippingRequest with items.
 * @param {import('@sap/cds/apis/services').Request} req - CAP request
 * @param {object} req.data.payload - Header and items payload
 * @returns {Promise<{shippingReqNo: string}>} Newly created Shipping Request number
 */
  srv.on('createscashippingRequest', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const payload = req.data.payload;
      const result = await dbOps.createscashippingRequest(payload, bundle, ZSD_VCM_PRODUCTFLOW, req);
      return result;
    } catch (error) {
      req.error(500, error.message || bundle.getText('FailedTocreatescashippingRequest'));
    }
  })
  //End - R2.2 Non VCA 76044

  // Function to Update the GR
  srv.on('runGRBatchJob', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);

    try {
      const result = await dbOps.runGRBatchJob(bundle, req);
      return result;

    } catch (error) {
      req.error(500, error.message || 'Failed to execute GR Batch Job');
    }
  });

  //Open Items JGHJ-87133 R2.2 change start
  srv.on('runASNBatchJob', async (req) => {

    try {
      logger.info('Inside runASNBatchJob');
      const asnOrphanData = await dbOps.asnOrphanData('', req);
      if (asnOrphanData && asnOrphanData.length > 0) {
        // SBPA call for each wfID - sequential to avoid exceeding DB connection pool

        for (const record of asnOrphanData.filter(r => r.workflowID)) {
          // await utils.InitiateWorkFLow(req, record.workflowID, 'docLevel');
           await utils.InitiateSubProcessWorkFlowInstance(
            req,
            record.workflowID,
            record.ID,
            true,
            2
          );
        }
      }
      return req.reply();
    } catch (ex) {
      logger.error('Inside runASNBatchJob catch', ex.message);
      req.error(500, ex.message);
    }
  });
  
//Open Items JGHJ-87133 R2.2 change end
  // Function to Update the AP
  srv.on('runAPBatchJob', async (req) => {
    try {
      const result = await dbOps.runAPInvoiceBatchJob({ req, ShippingRequestEntityDocs, ShippingRequestEntityFollowOnDocs });
      return result;

    } catch (error) {
      logger.error(error);
      //req.error(400, error.message);
      return req.reject(400, error.message);
    }
  });


  srv.on('reprocessQueueItem', async (req) => {
   
    let {PO}=req.data;
    let flag=true;
    try {
      
      let POWorkflowId = await SELECT
        .from(ShippingRequestQueue)
        .columns('ID', 'wfInstanceId', 'status', 'queueNo')
        .where({ parentPO: PO })
        .orderBy('queueNo asc');
      const inProgress = POWorkflowId.find(x => x.status === "In Progress" || x.status === "Retriggered");

      if (inProgress) {
        throw new Error(
          `There is already an in-progress workflow for PO`
        );
      
      }

      const errorWithWF = POWorkflowId.find(
        x => x.status === "Error" && x.wfInstanceId
      );

      if (errorWithWF) {
        const result = await utils.InitiateSubProcessWorkFlowInstance(req, errorWithWF.wfInstanceId, errorWithWF.ID, flag);
        if (result) {
          await UPDATE(ShippingRequestQueue)
            .set({ status: "Retriggered" })
            .where({ ID: errorWithWF.ID });
          req.info('Reprocessing initiated for PO: ' + errorWithWF.parentPO);
        } else {
          req.warn('Workflow could not be started for PO: ' + PO);
        }
        return;
      }

      const errorWithoutWF = POWorkflowId.find(
        x => x.status === "Error" && !x.wfInstanceId
      );

      if (errorWithoutWF) {
        throw new Error(
          `There is an error workflow for PO: ${errorWithoutWF.parentPO} but no workflow instance ID is available.`
        );
      }

      if (!POWorkflowId?.wfInstanceId) {
        throw new Error('Workflow instance ID is missing for PO: ' + PO);
      }

     return 
    } catch (error) {
      console.error(`Error reprocessing queue item`, error);
      req.error(500, error.message || "Error reprocessing queue item");
    }
  });

  srv.on('QueueSuccessMsg', async (req) => {
    const locale = req.user.locale;
    const bundle = textBundle.getTextBundle(locale);
    try {
      const { queueID, errorMessage, documentNumber } = req.data;

      if (!queueID) {
        return req.error(400, bundle.getText('queueIdRequired'));
      }

      await UPDATE(ShippingRequestQueue)
        .set({ status: 'In Progress', errorMessage: errorMessage })
        .where({ ID: queueID });

      await INSERT.into(QueueRequestErrors).entries({
        ID: cds.utils.uuid(),
        timeStamp: new Date(),
        errorType: "Success",
        wfInstanceId: '',
        errorMessage: errorMessage,
        parent_ID: queueID
      });
      logger.info(`QueueSuccessMsg triggered for QueueID line 1885: ${queueID}, documentNumber: ${documentNumber}, errorMessage: ${errorMessage}`);

      if (documentNumber) {
        await UPDATE(ShippingRequestEntityDocs)
          .set({ errorDescription: 'PO has been changed for more details check change events tab. (' + new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC)' })
          .where({ documentNumber });
      }

      return { message: "Queue item updated Successfully" };

    } catch (error) {
      console.error(`Error updating queue item status`, error);
      req.error(500, error.message || bundle.getText('ErrorUpdatingQueueItemStatus'));
    }
  });

  srv.on('UPDATE', 'EntityDocs', async (req, next) => {
    const data = req.data;
    logger.info('Incoming UPDATE payload:', JSON.stringify(data));
    await next();
  });

  srv.on('UPDATE', 'ShippingRequest', async (req, next) => {
    const data = req.data;
    logger.info('Incoming UPDATE payload:', JSON.stringify(data));
    await next();
  });

}
