// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Value Chain Monitoring App
// Object Id       : ZBUVCM55155
// Release         : 1
// Version         : 0.01
// Description     : Value Chain Monitoring App
// ----------------------------------------------------------------------------*
// Descriptions: Function implementation for util file.
// Change Log:
//    Date       |     Author           |   Change Id   |  Change Description
//  28-04-2026     RChitike@ITS.JNJ.com   JGHJ-87955      Cancelling Old workflow instance once reprocessed with technical error
// ----------------------------------------------------------------------------*

const { app, default: cds } = require('@sap/cds');
const logger = cds.log('vcm55155-program');
const constant = require('../config/constants.js');
const constants = require('../config/constants.js');
const textBundle = require('../_i18n/textBundle.js');
const { ShippingRequestEntityDocs, ShippingRequestErrors,ShippingRequestQueue} = cds.entities('jnj.com.zbuvcm55155')

'use strict';
module.exports = {
    convertForAT: function (payload) {
        if (!payload) return [];

        const entities = Array.isArray(payload.entity) ? payload.entity : [];

        // Explicit mapping: documentType -> output column (camelCase)
        const docTypeToCol = constant.ATMAPPING

        // Mapping from doc column -> date/status columns
        const metaForCol = constant.ATMETA

        const headers = constant.ATHEADERS;

        const groups = {};

        for (const d of entities) {
            const rank = d.entityRank ?? '';
            const plant = d.plant ?? '';
            const key = `${rank}||${plant}`;

            if (!groups[key]) {
                const r = {};
                for (const h of headers) r[h] = '';
                r.soNumber = payload.initialDocumentNo ?? '';
                r.cquenceNumber = payload.referenceDocumentNo ?? '';
                r.entityRank = rank;
                r.legalEntity = d.legalEntity ?? '';
                r.plant = plant;
                r.plantName = d.plantName;
                r.businessPartnerId = d.businessPartnerId ?? '';
                r.businessPartnerName = d.bpName ?? '';
                groups[key] = r;
            }

            const row = groups[key];
            const dt = (d.documentType || '').trim();
            const col = docTypeToCol[dt];
            if (!col) continue; // strict: skip unmapped types

            const hasDocNumber = d.documentNumber && String(d.documentNumber).trim() !== '';
            const hasDate = d.creationDate && String(d.creationDate).trim() !== '';
            const hasStatus = d.errorStatus && String(d.errorStatus).trim() !== '';

            const descVal = (d.errorDescription ?? '').toString();
            const hasDescription = descVal.trim() !== '';
            // fill document column
            if (hasDocNumber && !row[col]) row[col] = String(d.documentNumber);

            // fill date column
            const meta = metaForCol[col];
            if (meta && meta.dateCol && hasDate && !row[meta.dateCol]) {
                row[meta.dateCol] = d.creationDate;
            }

            // fill status column
            if (meta && meta.statusCol) {
                if (hasStatus && !row[meta.statusCol]) {
                    row[meta.statusCol] = String(d.errorStatus);
                } else if (!row[meta.statusCol] && (hasDocNumber || hasDate)) {
                    row[meta.statusCol] = 'Created';
                }
            }

            // fill error description column 
            if (meta && meta.descriptionCol) {
                if (hasDescription && !row[meta.descriptionCol]) {
                    row[meta.descriptionCol] = descVal;
                } else if (!row[meta.descriptionCol] && (hasDocNumber || hasDate)) {
                    // leave as empty string; change to a default if you prefer
                    row[meta.descriptionCol] = row[meta.descriptionCol] ?? '';
                }
            }

            if (row.salesOrderStatus && row.salesOrderStatus.toLowerCase().includes('error') || row.salesOrderStatus.toLowerCase() === 'failed') {
                row.salesOrderError = 'SO creation Failed';
            }
            if (row.purchaseOrderStatus && row.purchaseOrderStatus.toLowerCase().includes('error') || row.purchaseOrderStatus.toLowerCase() === 'failed') {
                row.purchaseOrderError = 'PO creation Failed';
            }
            if (row.ibdStatus && row.ibdStatus.toLowerCase().includes('error') || row.ibdStatus.toLowerCase() === 'failed') {
                row.ibdError = 'Inbound Delivery creation Failed';
            }
            if (row.outboundDeliveryStatus && row.outboundDeliveryStatus.toLowerCase().includes('error') || row.outboundDeliveryStatus.toLowerCase() === 'failed') {
                row.outboundDeliveryError = 'Outbound Delivery creation Failed';
            }
            if (row.customerInvoiceStatus && row.customerInvoiceStatus.toLowerCase().includes('error') || row.customerInvoiceStatus.toLowerCase() === 'failed') {
                row.customerInvoiceError = 'Customer Invoice Creation Failed';
            }
            if (row.btfpStatus && row.btfpStatus.toLowerCase().includes('error') || row.btfpStatus.toLowerCase() === 'failed') {
                row.btfpError = 'Finished Product Batch Creation failed';
            }
        }

        // sort by numeric entityRank
        const out = Object.values(groups).sort((a, b) => {
            const A = Number(a.entityRank || 0), B = Number(b.entityRank || 0);
            return A - B;
        });
        out[0].ibd = payload.followOnDocumentNo
        out[0].ibdStatus = payload.followOnDocumentNo ? "Success" : "Pending";
        // ensure all headers exist
        return out.map(r => {
            const o = {};
            for (const h of headers) o[h] = r[h] !== undefined ? r[h] : '';
            return o;
        });
    },

    // transformExact: function (input, bundle) {
    //     const findDocExact = (entities = [], rank, exactDocumentType) => {
    //         if (!Array.isArray(entities)) return null;
    //         return entities.find(e => {
    //             if (!e) return false;
    //             const dt = e.documentType == null ? "" : String(e.documentType).trim();
    //             return (e.entityRank === rank) && (dt === exactDocumentType);
    //         }) || null;
    //     };

    //     return (Array.isArray(input) ? input : []).map(header => {
    //         const entities = Array.isArray(header.entity) ? header.entity : [];
    //         const items = Array.isArray(header.items) ? header.items : [];

    //         const subconDoc = findDocExact(entities, 1, "Subcontracting PO");
    //         const AFPO_Doc = findDocExact(entities, 1, "Apheresis PO");
    //         const OBD_Doc = findDocExact(entities, 3, "OUTBOUND DELIVERY");
    //         const AR_Doc = findDocExact(entities, 3, "AR INVOICE");
    //         const PGI_Doc = findDocExact(entities, 1, "GOODS ISSUE");
    //         const FP_BT_V1_Doc = findDocExact(entities, 1, "Finished Product Batch");
    //         const APH_BT_V1_Doc = findDocExact(entities, 1, "Apheresis Batch");
    //         const RT_BT_V1_Doc = findDocExact(entities, 1, "Retain Bag Batch");

    //         const subconPO_V1 = subconDoc?.documentNumber ?? "";
    //         const AFPO_V1 = AFPO_Doc?.documentNumber ?? "";
    //         const OBD_V3 = OBD_Doc?.documentNumber ?? "";
    //         const AR_V3 = AR_Doc?.documentNumber ?? "";
    //         const PGINumber = PGI_Doc?.documentNumber ?? "";
    //         const FP_BT_V1 = FP_BT_V1_Doc?.documentNumber ?? "";
    //         const APH_BT = APH_BT_V1_Doc?.documentNumber ?? "";
    //         const RT_BT = RT_BT_V1_Doc?.documentNumber ?? "";

    //         const PGIDetails = entities.filter(x => x.documentNumber === PGINumber && x.entityRank === 1);
    //         const PGI_Date = PGIDetails?.[0]?.creationDate || null;

    //         const IBD_V1 = header.followOnDocumentNo;
    //         const IBD_Status = IBD_V1 ? "Success" : "Pending";

    //         const batchNumber = (items[0] && items[0].batchNumber != null) ? String(items[0].batchNumber) : "";
    //         const materialNumber = (items[0] && items[0].materialNumber != null) ? String(items[0].materialNumber) : "";
    //         const materialDescription = (items[0] && items[0].materialDescription != null) ? String(items[0].materialDescription) : "";

    //         // const Status = header.status ? String(header.status) : "";

    //         // ---- wfInstanceId logic ----
    //         let wfInstanceId = "";

    //         if (header.status === "Error" && header.wfInstanceId) {
    //             wfInstanceId = header.wfInstanceId;
    //         } else {
    //             // Use first found doc that has wfInstanceId, even if documentNumber is empty
    //             const docWithWF = [subconDoc, AFPO_Doc, OBD_Doc, AR_Doc, PGI_Doc, FP_BT_V1_Doc, APH_BT_V1_Doc, RT_BT_V1_Doc]
    //                 .find(doc => doc?.wfInstanceId);
    //             if (docWithWF) {
    //                 wfInstanceId = docWithWF.wfInstanceId;
    //             }
    //         }

    //         // ---- Error description logic ----
    //         // let errorDescription = [subconDoc, AFPO_Doc, OBD_Doc, AR_Doc, PGI_Doc, FP_BT_V1_Doc, APH_BT_V1_Doc, RT_BT_V1_Doc].find(doc => doc?.errorDescription)?.errorDescription || "";
    //         // let Status = errorDescription ? "Error" : "Success"
    //         const docs = [subconDoc, AFPO_Doc, OBD_Doc, AR_Doc, PGI_Doc, FP_BT_V1_Doc, APH_BT_V1_Doc, RT_BT_V1_Doc];

    //         // Find the first document that has an error
    //         const errorDoc = docs.find(doc => doc?.errorDescription);

    //         let Error = '', errorDescription= '';
    //         if (errorDoc) {
    //             if (errorDoc === AFPO_Doc) {
    //                 Error = 'Apheresis PO creation failed';
    //                 errorDescription = errorDoc.errorDescription
    //             } else if (errorDoc === AR_Doc) {
    //                 Error = 'AR Invoice creation failed';
    //                 errorDescription = errorDoc.errorDescription
    //             } else if (errorDoc === subconDoc) {
    //                 Error = 'Subcontracting PO creation failed';
    //                 errorDescription = errorDoc.errorDescription
    //             }
    //             else if (errorDoc === OBD_Doc) {
    //                 Error = 'Outbound Delivery creation failed';
    //                 errorDescription = errorDoc.errorDescription
    //             }
    //             else if (errorDoc === PGI_Doc) {
    //                 Error = 'Post Goods Issue creation failed';
    //                 errorDescription = errorDoc.errorDescription
    //             }
    //             else if (errorDoc === FP_BT_V1_Doc) {
    //                 Error = 'Finished Product Batch creation failed';
    //                 errorDescription = errorDoc.errorDescription
    //             }
    //             else if (errorDoc === APH_BT_V1_Doc) {
    //                 Error = 'Apheresis Batch creation failed';
    //                 errorDescription = errorDoc.errorDescription
    //             }
    //             else if (errorDoc === RT_BT_V1_Doc) {
    //                 Error = 'Retain Bag Batch creation failed';
    //                 errorDescription = errorDoc.errorDescription
    //             }
    //         }
    //         let Status = Error ? "Error": "Success"
    //         return {
    //             initialDocumentNo: header.initialDocumentNo == null ? "" : String(header.initialDocumentNo),
    //             referenceDocumentNo: header.referenceDocumentNo == null ? "" : String(header.referenceDocumentNo),
    //             batchNumber,
    //             materialNumber,
    //             materialDescription,
    //             wfInstanceId,
    //             RT_BT,
    //             APH_BT,
    //             FP_BT_V1,
    //             subconPO_V1,
    //             AFPO_V1,
    //             IBD_V1,
    //             IBD_Status,
    //             OBD_V3,
    //             AR_V3,
    //             Status,
    //             PGI_Date,
    //             Error,
    //             errorDescription
    //         };
    //     });
    // },


    transformExact: function (input, bundle) {
        const findDocExact = (entities = [], rank, exactDocumentType) => {
            if (!Array.isArray(entities)) return null;
            return entities.find(e => {
                if (!e) return false;
                const dt = e.documentType == null ? "" : String(e.documentType).trim();
                return (e.entityRank === rank) && (dt === exactDocumentType);
            }) || null;
        };

        return (Array.isArray(input) ? input : []).map(header => {

            const entities = Array.isArray(header.entity) ? header.entity : [];
            const items = Array.isArray(header.items) ? header.items : [];
            // Finished Product Batch
            const FP_BT_V1_Doc = findDocExact(entities, 1, "Finished Product Batch");
            const FP_BT_V2_Doc = findDocExact(entities, 2, "Finished Product Batch");
            const FP_BT_V3_Doc = findDocExact(entities, 3, "Finished Product Batch");

            // Apheresis Batch
            const APH_BT_V1_Doc = findDocExact(entities, 1, "Apheresis Batch");
            const APH_BT_V2_Doc = findDocExact(entities, 2, "Apheresis Batch");
            const APH_BT_V3_Doc = findDocExact(entities, 3, "Apheresis Batch");

            // Retain Bag Batch
            const RT_BT_V1_Doc = findDocExact(entities, 1, "Retain Bag Batch");
            const RT_BT_V2_Doc = findDocExact(entities, 2, "Retain Bag Batch");
            const RT_BT_V3_Doc = findDocExact(entities, 3, "Retain Bag Batch");

            // --- PO / Order Documents ---

            // Subcontracting PO (Subcon PO)
            const subconDoc_V1 = findDocExact(entities, 1, "Subcontracting PO");
            const subconDoc_V2 = findDocExact(entities, 2, "Subcontracting PO");
            const subconDoc_V3 = findDocExact(entities, 3, "Subcontracting PO");

            // Apheresis PO (AFPO)
            const AFPO_Doc_V1 = findDocExact(entities, 1, "Apheresis PO");
            const AFPO_Doc_V2 = findDocExact(entities, 2, "Apheresis PO");
            const AFPO_Doc_V3 = findDocExact(entities, 3, "Apheresis PO");

            // Intercompany SO
            const ICSO_Doc_V1 = findDocExact(entities, 1, "INTERCOMPANY SO");
            const ICSO_Doc_V2 = findDocExact(entities, 2, "INTERCOMPANY SO");
            const ICSO_Doc_V3 = findDocExact(entities, 3, "INTERCOMPANY SO");

            // Intercompany PO
            const ICPO_Doc_V1 = findDocExact(entities, 1, "INTERCOMPANY PO");
            const ICPO_Doc_V2 = findDocExact(entities, 2, "INTERCOMPANY PO");
            const ICPO_Doc_V3 = findDocExact(entities, 3, "INTERCOMPANY PO");

            // --- Goods Movement Documents ---

            // Goods Receipt (GR / GOOD RECEIPT)
            // Note: Assuming 'Good Receipt' and 'GOODS RECEIPT' are the same document type for extraction
            const GR_Doc_V1 = findDocExact(entities, 1, "Good Receipt") || findDocExact(entities, 1, "GOODS RECEIPT");
            const GR_Doc_V2 = findDocExact(entities, 2, "Good Receipt") || findDocExact(entities, 2, "GOODS RECEIPT");
            const GR_Doc_V3 = findDocExact(entities, 3, "Good Receipt") || findDocExact(entities, 3, "GOODS RECEIPT");

            // Quality To UD (UD: Usage Decision)
            const Quality_TO_UD_V1 = findDocExact(entities, 1, "Quality To UD");
            const Quality_TO_UD_V2 = findDocExact(entities, 2, "Quality To UD");
            const Quality_TO_UD_V3 = findDocExact(entities, 3, "Quality To UD");



            // Outbound Delivery (OBD)
            const OBD_Doc_V1 = findDocExact(entities, 1, "OUTBOUND DELIVERY");
            const OBD_Doc_V2 = findDocExact(entities, 2, "OUTBOUND DELIVERY");
            const OBD_Doc_V3 = findDocExact(entities, 3, "OUTBOUND DELIVERY");

            // Goods Issue (PGI)
            const PGI_Doc_V1 = findDocExact(entities, 1, "GOODS ISSUE");
            const PGI_Doc_V2 = findDocExact(entities, 2, "GOODS ISSUE");
            const PGI_Doc_V3 = findDocExact(entities, 3, "GOODS ISSUE");

            // --- Invoice Documents ---

            // AR Invoice
            const AR_INV_Doc_V1 = findDocExact(entities, 1, "AR INVOICE");
            const AR_INV_Doc_V2 = findDocExact(entities, 2, "AR INVOICE");
            const AR_INV_Doc_V3 = findDocExact(entities, 3, "AR INVOICE");

            // AP Invoice
            const AP_INV_Doc_V1 = findDocExact(entities, 1, "AP INVOICE");
            const AP_INV_Doc_V2 = findDocExact(entities, 2, "AP INVOICE");
            const AP_INV_Doc_V3 = findDocExact(entities, 3, "AP INVOICE");

            // const FP_BT_V1_Doc = findDocExact(entities, 1, "Finished Product Batch");
            // const APH_BT_V1_Doc = findDocExact(entities, 1, "Apheresis Batch");
            // const RT_BT_V1_Doc = findDocExact(entities, 1, "Retain Bag Batch");
            // const subconDoc = findDocExact(entities, 1, "Subcontracting PO");
            // const AFPO_Doc = findDocExact(entities, 1, "Apheresis PO");
            // const GR_Doc=findDocExact(entities,1,"Good Receipt")
            // const Quality_UD=findDocExact(entities,1,"Quality To UD")


            // const PGI_Doc = findDocExact(entities, 1, "GOODS ISSUE");

            // const OBD_Doc = findDocExact(entities, 3, "OUTBOUND DELIVERY");
            // const AR_Doc = findDocExact(entities, 3, "AR INVOICE");
            // const AP_Doc = findDocExact(entities, 3, "AP INVOICE");



            // const subconPO_V1 = subconDoc?.documentNumber ?? "";
            // const AFPO_V1 = AFPO_Doc?.documentNumber ?? "";
            // const OBD_V3 = OBD_Doc?.documentNumber ?? "";
            // const AR_V3 = AR_Doc?.documentNumber ?? "";
            // const AP_V3=AP_Doc?.documentNumber??"";
            // const PGINumber = PGI_Doc?.documentNumber ?? "";
            // const FP_BT_V1 = FP_BT_V1_Doc?.documentNumber ?? "";
            // const APH_BT = APH_BT_V1_Doc?.documentNumber ?? "";
            // const RT_BT = RT_BT_V1_Doc?.documentNumber ?? "";


            // --- Batch Documents ---
            const FP_BT_V1 = FP_BT_V1_Doc?.documentNumber ?? "";
            const FP_BT_V2 = FP_BT_V2_Doc?.documentNumber ?? "";
            const FP_BT_V3 = FP_BT_V3_Doc?.documentNumber ?? "";

            const APH_BT_V1 = APH_BT_V1_Doc?.documentNumber ?? "";
            const APH_BT_V2 = APH_BT_V2_Doc?.documentNumber ?? "";
            const APH_BT_V3 = APH_BT_V3_Doc?.documentNumber ?? "";

            const RT_BT_V1 = RT_BT_V1_Doc?.documentNumber ?? "";
            const RT_BT_V2 = RT_BT_V2_Doc?.documentNumber ?? "";
            const RT_BT_V3 = RT_BT_V3_Doc?.documentNumber ?? "";

            // --- PO / Order Documents ---
            const subconPO_V1 = subconDoc_V1?.documentNumber ?? "";
            const subconPO_V2 = subconDoc_V2?.documentNumber ?? "";
            const subconPO_V3 = subconDoc_V3?.documentNumber ?? "";

            const AFPO_V1 = AFPO_Doc_V1?.documentNumber ?? "";
            const AFPO_V2 = AFPO_Doc_V2?.documentNumber ?? "";
            const AFPO_V3 = AFPO_Doc_V3?.documentNumber ?? "";

            const ICSO_V1 = ICSO_Doc_V1?.documentNumber ?? "";
            const ICSO_V2 = ICSO_Doc_V2?.documentNumber ?? "";
            const ICSO_V3 = ICSO_Doc_V3?.documentNumber ?? "";

            const ICPO_V1 = ICPO_Doc_V1?.documentNumber ?? "";
            const ICPO_V2 = ICPO_Doc_V2?.documentNumber ?? "";
            const ICPO_V3 = ICPO_Doc_V3?.documentNumber ?? "";

            // --- Goods Movement Documents ---
            const GR_V1 = GR_Doc_V1?.documentNumber ?? "";
            const GR_V2 = GR_Doc_V2?.documentNumber ?? "";
            const GR_V3 = GR_Doc_V3?.documentNumber ?? "";
            const GR_V1_status = GR_Doc_V1?.errorStatus ?? "";

            const Quality_UD_V1 = Quality_TO_UD_V1?.documentNumber ?? "";
            const Quality_UD_V2 = Quality_TO_UD_V2?.documentNumber ?? "";
            const Quality_UD_V3 = Quality_TO_UD_V3?.documentNumber ?? "";


            const OBD_V1 = OBD_Doc_V1?.documentNumber ?? "";
            const OBD_V2 = OBD_Doc_V2?.documentNumber ?? "";
            const OBD_V3 = OBD_Doc_V3?.documentNumber ?? "";
            const OBD_V3_create_date = OBD_Doc_V3?.creationDate ?? "";

            const PGI_V1 = PGI_Doc_V1?.documentNumber ?? "";
            const PGI_V2 = PGI_Doc_V2?.documentNumber ?? "";
            const PGI_V3 = PGI_Doc_V3?.documentNumber ?? "";
            const GI_V2_status = PGI_Doc_V2?.errorStatus ?? "";
            const GI_V3_status = PGI_Doc_V3?.errorStatus ?? "";

            // --- Invoice Documents ---
            const AR_INV_V1 = AR_INV_Doc_V1?.documentNumber ?? "";
            const AR_INV_V2 = AR_INV_Doc_V2?.documentNumber ?? "";
            const AR_INV_V3 = AR_INV_Doc_V3?.documentNumber ?? "";

            const AP_INV_V1 = AP_INV_Doc_V1?.documentNumber ?? "";
            const AP_INV_V2 = AP_INV_Doc_V2?.documentNumber ?? "";
            const AP_INV_V3 = AP_INV_Doc_V3?.documentNumber ?? "";

            const PGIDetails = entities.filter(x => x.documentNumber === PGI_V1?.documentNumber && x.entityRank === 1);
            const PGI_Date = PGIDetails?.[0]?.creationDate || null;

            const IBD_V1 = header.followOnDocumentNo;
            const IBD_Status = IBD_V1 ? "Success" : "Pending";

            const batchNumber = (items[0] && items[0].batchNumber != null) ? String(items[0].batchNumber) : "";
            const materialNumber = (items[0] && items[0].materialNumber != null) ? String(items[0].materialNumber) : "";
            const materialDescription = (items[0] && items[0].materialDescription != null) ? String(items[0].materialDescription) : "";

            // const Status = header.status ? String(header.status) : "";

            // ---- wfInstanceId logic ----
            let wfInstanceId = "";

            if (header.status === "Error" && header.wfInstanceId) {
                wfInstanceId = header.wfInstanceId;
            } else {
                // Use first found doc that has wfInstanceId, even if documentNumber is empty
                // const docWithWF = [subconDoc, AFPO_Doc, OBD_Doc, AR_Doc, PGI_Doc, FP_BT_V1_Doc, APH_BT_V1_Doc, RT_BT_V1_Doc]
                // .find(doc => doc?.wfInstanceId);


                // Consolidate all V1, V2, and V3 document objects into a single array
                const docWithWF = [
                    // Batch Documents
                    FP_BT_V1_Doc, FP_BT_V2_Doc, FP_BT_V3_Doc,
                    APH_BT_V1_Doc, APH_BT_V2_Doc, APH_BT_V3_Doc,
                    RT_BT_V1_Doc, RT_BT_V2_Doc, RT_BT_V3_Doc,

                    // PO / Order Documents
                    subconDoc_V1, subconDoc_V2, subconDoc_V3,
                    AFPO_Doc_V1, AFPO_Doc_V2, AFPO_Doc_V3,
                    ICSO_Doc_V1, ICSO_Doc_V2, ICSO_Doc_V3,
                    ICPO_Doc_V1, ICPO_Doc_V2, ICPO_Doc_V3,

                    // Goods Movement Documents
                    GR_Doc_V1, GR_Doc_V2, GR_Doc_V3,
                    Quality_UD_V1, Quality_UD_V2, Quality_UD_V3,
                    OBD_Doc_V1, OBD_Doc_V2, OBD_Doc_V3,
                    PGI_Doc_V1, PGI_Doc_V2, PGI_Doc_V3,

                    // Invoice Documents
                    AR_INV_Doc_V1, AR_INV_Doc_V2, AR_INV_Doc_V3,
                    AP_INV_Doc_V1, AP_INV_Doc_V2, AP_INV_Doc_V3
                ].filter(doc => doc !== null).find(doc => doc?.wfInstanceId); // Remove all null entries where a document wasn't found
                if (docWithWF) {
                    wfInstanceId = docWithWF.wfInstanceId;
                }
            }

            // ---- Error description logic ----
            // let errorDescription = [subconDoc, AFPO_Doc, OBD_Doc, AR_Doc, PGI_Doc, FP_BT_V1_Doc, APH_BT_V1_Doc, RT_BT_V1_Doc].find(doc => doc?.errorDescription)?.errorDescription || "";
            // let Status = errorDescription ? "Error" : "Success"
            // const docs = [subconDoc, AFPO_Doc, OBD_Doc, AR_Doc, PGI_Doc, FP_BT_V1_Doc, APH_BT_V1_Doc, RT_BT_V1_Doc];
            const docs = [
                // Batch Documents
                FP_BT_V1_Doc, APH_BT_V1_Doc, RT_BT_V1_Doc, subconDoc_V1, AFPO_Doc_V1, GR_Doc_V1, Quality_UD_V1, ICSO_Doc_V1, OBD_Doc_V1, PGI_Doc_V1, AR_INV_Doc_V1,
                ICPO_Doc_V2, GR_Doc_V2, AP_INV_Doc_V2, ICSO_Doc_V2, OBD_Doc_V2, PGI_Doc_V2, AR_INV_Doc_V2,

                ICPO_Doc_V3, GR_Doc_V3, AP_INV_Doc_V3, OBD_Doc_V3, PGI_Doc_V3, AR_INV_Doc_V3

            ].filter(doc => doc !== '')
            // Find the first document that has an error
            const errorDoc = docs.find(doc => doc?.errorStatus === "Error" && doc?.errorDescription);
            let sucessDocs
            if (!errorDoc) {
                // Assuming 'docs' is the array containing all your document objects (V1, V2, V3, etc.)

                sucessDocs = docs
                    .reverse() // Reverse the copied array
                    .find(doc => doc?.errorStatus === "Success" && doc?.errorDescription); // Find the first match (which is the last in the original array);

            }

            let Error = '', errorDescription = '';
            // if (errorDoc) {
            //     if (errorDoc === AFPO_Doc) {
            //         Error = 'Apheresis PO creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     } else if (errorDoc === AR_Doc) {
            //         Error = 'AR Invoice creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     } else if (errorDoc === subconDoc) {
            //         Error = 'Subcontracting PO creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            //     else if (errorDoc === OBD_Doc) {
            //         Error = 'Outbound Delivery creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            //     else if (errorDoc === PGI_Doc) {
            //         Error = 'Post Goods Issue creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            //     else if (errorDoc === FP_BT_V1_Doc) {
            //         Error = 'Finished Product Batch creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            //     else if (errorDoc === APH_BT_V1_Doc) {
            //         Error = 'Apheresis Batch creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            //     else if (errorDoc === RT_BT_V1_Doc) {
            //         Error = 'Retain Bag Batch creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            // }
            // if (errorDoc) {
            //     if (errorDoc === AFPO_Doc_V1) {
            //         Error = 'Apheresis PO creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     } else if (errorDoc === AR_INV_V1) {
            //         Error = 'AR Invoice creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     } else if (errorDoc === subconDoc_V1) {
            //         Error = 'Subcontracting PO creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            //     else if (errorDoc === OBD_Doc_V1) {
            //         Error = 'Outbound Delivery creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            //     else if (errorDoc === PGI_V1) {
            //         Error = 'Post Goods Issue creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            //     else if (errorDoc === FP_BT_V1_Doc) {
            //         Error = 'Finished Product Batch creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            //     else if (errorDoc === APH_BT_V1_Doc) {
            //         Error = 'Apheresis Batch creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            //     else if (errorDoc === RT_BT_V1_Doc) {
            //         Error = 'Retain Bag Batch creation failed';
            //         errorDescription = errorDoc.errorDescription
            //     }
            // }



            if (errorDoc) {
                // NOTE: Use a temporary array of the document objects to compare against,
                // as comparing against individual variables (AFPO_Doc_V1, AFPO_Doc_V2, etc.)
                // is the most direct way to check which specific document object matched errorDoc.

                // --- PO / Order Documents ---
                if ([AFPO_Doc_V1, AFPO_Doc_V2, AFPO_Doc_V3].includes(errorDoc)) {
                    Error = 'Apheresis PO creation failed';
                    errorDescription = errorDoc.errorDescription;
                }
                else if ([subconDoc_V1, subconDoc_V2, subconDoc_V3].includes(errorDoc)) {
                    Error = 'Subcontracting PO creation failed';
                    errorDescription = errorDoc.errorDescription;
                }
                else if ([ICSO_Doc_V1, ICSO_Doc_V2, ICSO_Doc_V3].includes(errorDoc)) {
                    Error = 'Intercompany SO creation failed';
                    errorDescription = errorDoc.errorDescription;
                }
                else if ([ICPO_Doc_V1, ICPO_Doc_V2, ICPO_Doc_V3].includes(errorDoc)) {
                    Error = 'Intercompany PO creation failed';
                    errorDescription = errorDoc.errorDescription;
                }

                // --- Goods Movement Documents ---
                else if ([OBD_Doc_V1, OBD_Doc_V2, OBD_Doc_V3].includes(errorDoc)) {
                    Error = 'Outbound Delivery creation failed';
                    errorDescription = errorDoc.errorDescription;
                }
                else if ([PGI_Doc_V1, PGI_Doc_V2, PGI_Doc_V3].includes(errorDoc)) {
                    Error = 'Post Goods Issue creation failed';
                    errorDescription = errorDoc.errorDescription;
                }
                else if ([GR_Doc_V1, GR_Doc_V2, GR_Doc_V3].includes(errorDoc)) {
                    Error = 'Goods Receipt failed';
                    errorDescription = errorDoc.errorDescription;
                }
                else if ([Quality_TO_UD_V1, Quality_TO_UD_V2, Quality_TO_UD_V3].includes(errorDoc)) {
                    Error = 'Quality Usage Decision failed';
                    errorDescription = errorDoc.errorDescription;
                }

                // --- Batch Documents ---
                else if ([FP_BT_V1_Doc, FP_BT_V2_Doc, FP_BT_V3_Doc].includes(errorDoc)) {
                    Error = 'Finished Product Batch creation failed';
                    errorDescription = errorDoc.errorDescription;
                }
                else if ([APH_BT_V1_Doc, APH_BT_V2_Doc, APH_BT_V3_Doc].includes(errorDoc)) {
                    Error = 'Apheresis Batch creation failed';
                    errorDescription = errorDoc.errorDescription;
                }
                else if ([RT_BT_V1_Doc, RT_BT_V2_Doc, RT_BT_V3_Doc].includes(errorDoc)) {
                    Error = 'Retain Bag Batch creation failed';
                    errorDescription = errorDoc.errorDescription;
                }

                // --- Invoice Documents ---
                else if ([AR_INV_Doc_V1, AR_INV_Doc_V2, AR_INV_Doc_V3].includes(errorDoc)) {
                    Error = 'AR Invoice creation failed';
                    errorDescription = errorDoc.errorDescription;
                }
                else if ([AP_INV_Doc_V1, AP_INV_Doc_V2, AP_INV_Doc_V3].includes(errorDoc)) {
                    Error = 'AP Invoice creation failed';
                    errorDescription = errorDoc.errorDescription;
                }
            }
            let Status = Error ? "Error" : "Success"

            if (Error === "" && errorDescription === '') {
                Error = sucessDocs?.errorStatus
                errorDescription = sucessDocs?.errorDescription
            }
            return {
                initialDocumentNo: header.initialDocumentNo == null ? "" : String(header.initialDocumentNo),
                referenceDocumentNo: header.referenceDocumentNo == null ? "" : String(header.referenceDocumentNo),
                batchNumber,
                materialNumber,
                materialDescription,
                wfInstanceId,
                V1: FP_BT_V1_Doc?.legalEntity,
                V2: OBD_Doc_V2?.legalEntity,
                V3: OBD_Doc_V3?.legalEntity || "",
                RT_BT: RT_BT_V1,
                APH_BT: APH_BT_V1,
                FP_BT_V1: FP_BT_V1,
                subconPO_V1: subconPO_V1,
                AFPO_V1: AFPO_V1,
                IBD_V1,
                IBD_Status,
                OBD_V2: OBD_V2,
                AR_V2: AR_INV_V2,
                AP_V2: AP_INV_V2,
                OBD_V3: OBD_V3,
                AR_V3: AR_INV_V3,
                AP_V3: AP_INV_V3,
                OBD_V2_create_date: OBD_Doc_V2?.creationDate ?? "",
                OBD_V3_create_date,
                GR_V1_status,
                Status,
                PGI_Date,
                Error: Error ? Error : "",
                errorDescription: errorDescription ? errorDescription : "",
                GI_V2_status,
                GI_V3_status
            };




        });
    },

    updateMaterailDescription: async function (headers) {
        const queries = this.buildMaterialQueries(headers)
        const ZSD_VCM_PRODUCTFLOW = await cds.connect.to("ZSD_VCM_PRODUCTFLOW")
        // Run them all in one cds.run
        const results = await ZSD_VCM_PRODUCTFLOW.run(queries)
        results.forEach((res, i) => {
            const item = headers
                .flatMap(h => h.items)
                .filter(it => it.materialNumber)[i]

            if (item) {
                item.materialDescription = res[0]?.ProductName || null
            }
        })
    },
    buildMaterialQueries: function (headers) {
        const queries = []

        for (const header of headers) {
            if (!Array.isArray(header.items)) continue

            for (const item of header.items) {
                if (!item.materialNumber) continue

                // Build SELECT query for this material
                const q = SELECT.from('Material')
                    .columns('ProductName')
                    .where({ Product: item.materialNumber })

                queries.push(q)
            }
        }

        return queries
    },
    getPODetails: async function (legalEntityData) {
        const ZAPI_PURCHASEORDER_PROCESS_SRV = await cds.connect.to("ZAPI_PURCHASEORDER_PROCESS_SRV");
        for (const legalEntity of legalEntityData) {
            // Helper function to safely fetch PO type or return ""
            const getPOType = async (poNumber) => {
                if (!poNumber) return "";
                const result = await ZAPI_PURCHASEORDER_PROCESS_SRV.run(
                    SELECT.from("A_PurchaseOrder")
                        .columns("PurchaseOrderType")
                        .where({ PurchaseOrder: poNumber })
                );
                return result?.[0]?.PurchaseOrderType || "";
            };

            // Fetch and assign values
            legalEntity.apPOType = await getPOType(legalEntity.apPO);
            legalEntity.apPODescription = legalEntity.apPOType ? "Apheresis PO" : "";

            legalEntity.subconPOType = await getPOType(legalEntity.subconPO);
            legalEntity.suconPODescription = legalEntity.subconPOType ? "Subcontracting PO" : "";

            legalEntity.flashPOType = await getPOType(legalEntity.flashPO);
            legalEntity.flashPODescription = legalEntity.flashPOType ? "INTERCOMPANY PO" : "";
        }
    },
    /**
   * Starts or resumes a workflow instance
   *
   * @param {object} req - The CAP request object
   * @param {string} wfInstanceId - The workflow instance ID to start/resume
   * @returns {Promise<object>} - Response from the workflow service
   */
    // InitiateWorkFLow: async function (req, wfInstanceId) {

    //     try {
    //         const workflow = await cds.connect.to("workflowService");

    //         const response = await workflow.tx(req).patch(`${constants.workflowURL}${wfInstanceId}`, {
    //             "status": "RUNNING"
    //         })

    //         return response;

    //     } catch (error) {
    //         logger.debug(error)
    //     }
    // },

    InitiateWorkFLow: async function (req, wfInstanceId, type) {
        const locale = req.user.locale;
        const bundle = textBundle.getTextBundle(locale);
        const workflow = await cds.connect.to("workflowService");

        if (type === 'docLevel') {
            try {
                const definitionId = 'us10.jnj-im-dev-na.zvcmreusablewaitforapierrorhandlerproject.zVCM_ReusableWaitForAPIErrorHandlerProcess';
                const waitApiUrl = '/unified/v1/triggers/api/us10.jnj-im-dev-na.zvcmreusablewaitforapierrorhandlerproject.cAPMWaitForAPIErrorHandler';
                let response = ''

                let waitApiInfo = await workflow.send({
                    method: "GET",
                    path: `/${constants.workflowURL}?businessKey=${wfInstanceId}&definitionId=${definitionId}`
                })

                if (waitApiInfo && Array.isArray(waitApiInfo) && waitApiInfo?.length > 0) {
                    response = await workflow.tx(req).post(`${waitApiUrl}`, {
                        "executionId": waitApiInfo[0]?.id
                    })

                    return response;
                } else {
                    throw new Error(bundle.getText('IssueinTriggeringWorkflow!'))
                }

            } catch (error) {
                logger.debug(error)
                throw error;
            }
        } else if(type === 'cancelASN') { 
            try {
                const response = await workflow.tx(req).patch(`${constants.workflowURL}${wfInstanceId}`, {
                    "status": "CANCELED"
                })

                return response;

            } catch (error) {
                logger.debug(error)
                throw new Error(`${bundle.getText('IssueinTriggeringWorkflow')}: ${error.message}`);
            }
        } else {
            try {
                const response = await workflow.tx(req).patch(`${constants.workflowURL}${wfInstanceId}`, {
                    "status": "RUNNING"
                })

                return response;

            } catch (error) {
                logger.debug(error)
                throw new Error(`${bundle.getText('IssueinTriggeringWorkflow')}: ${error.message}`);
            }
        }
    },
    checkSubprocessWorkflowStatus:async function (subProcessInstanceId,ID,flag){
        const workflow = await cds.connect.to("workflowService");
          const subProcessResponse = await workflow.send({
                method: "GET",
                path: `/public/workflow/rest/v1/workflow-instances?id=${subProcessInstanceId}`
            });

            if (!subProcessResponse || !Array.isArray(subProcessResponse) || subProcessResponse.length === 0) {
                logger.info(`Sub process instance not found for entity:${ID}`);
                return;
            }

        const subProcessData = subProcessResponse[0];

        // Validate status = ERRONEOUS
        if (!flag) {
            if (subProcessData.status === 'ERRONEOUS') {
                logger.info(`Sub process is in ERRONEOUS state entity: ${ID}`)
                return subProcessData.rootInstanceId;
            } 
            //Validate Status is Completed but one of the child/parent workflow is in Erroneous state
            else if (subProcessData.status !== 'ERRONEOUS'){

                logger.info(`Sub process is in COMPLETED state entity: ${ID}`)

                let rootProcessResponse = await workflow.send({
                method: "GET",
                path: `/public/workflow/rest/v1/workflow-instances?rootInstanceId=${subProcessData.rootInstanceId}&status=ERRONEOUS`
                });

                if (!rootProcessResponse || rootProcessResponse.length > 0) {

                    logger.info(`Sub process is in COMPLETED state but one of it's child/parent workflows is in ERRONEOUS state entity: ${ID}`)

                    return rootProcessResponse[0].rootInstanceId;
                }
                else {

                    let rootProcessResponse1 = await workflow.send({
                        method: "GET",
                        path: `/public/workflow/rest/v1/workflow-instances?rootInstanceId=${subProcessData.rootInstanceId}&status=RUNNING&definitionId=us10.jnj-im-dev-na.zvcmreusablewaitforapierrorhandlerproject.zVCM_ReusableWaitForAPIErrorHandlerProcess`
                    });

                    if (rootProcessResponse1?.length) {
                        // await UPDATE(ShippingRequestEntityDocs)
                        //     .set({
                        //         errorStatus: "Error",
                        //         errorDescription: "Technical Error from rootProcessResponse1 found from wait for API ",
                        //         errorCreationDate: new Date(),
                        //         // wfInstanceId: subProcessData.rootInstanceId
                        //     })
                        //     .where({
                        //         ID: ID
                        //     });

                        // await INSERT.into(ShippingRequestErrors).entries({
                        //     ID: cds.utils.uuid(),
                        //     parent_ID: ID,
                        //     vcaErrorStatus: "Technical Error",
                        //     vcaErrorType: "Error",
                        //     // wfInstanceId: pendingError.wfInstanceId,
                        //     vcaErrorTimeStamp: new Date()
                        // })

                        // logger.info(`Entity status updated to error for  entity Doc :${pendingError.ID}`);
                        return subProcessData.rootInstanceId
                    }


                    return;
                }
            }
            else {
                return;
            }
        }
        
        return subProcessData.rootInstanceId;
    },
    InitiateSubProcessWorkFlowInstance: async function (req, subProcessInstanceId, ID, flag,wflag,queue) {
        const locale = req.user.locale;
        const bundle = textBundle.getTextBundle(locale);

        const workflow = await cds.connect.to("workflowService");
        const wfTx = workflow.tx(req);
        const tx = cds.tx();

        try {
            // -------------------------------------------------------
            // STEP 1: Get Root Workflow Instance ID
            // -------------------------------------------------------
            const rootInstanceId = await module.exports.checkSubprocessWorkflowStatus(
                subProcessInstanceId,
                ID,
                flag
            );

            if (!rootInstanceId) {
                logger.info(`Root workflow instance ID not found for entity: ${ID}`);
                return false;
            }

            // -------------------------------------------------------
            // STEP 2: Get Root Workflow Details
            // -------------------------------------------------------
            const rootInstanceResponse = await wfTx.get(
                `/public/workflow/rest/v1/workflow-instances?id=${rootInstanceId}`
            );

            if (!Array.isArray(rootInstanceResponse) || rootInstanceResponse.length === 0) {
                logger.info(`Root workflow instance not found for entity: ${ID}`);
                return false;
            }

            const rootInstance = rootInstanceResponse[0];
            const definitionId = rootInstance.definitionId;
            const rootStatus = rootInstance.status;

            if (!definitionId) {
                logger.info(`Definition ID not found for entity: ${ID}`);
                return false;
            }

            // -------------------------------------------------------
            // STEP 3: Get Workflow Context
            // -------------------------------------------------------
            const context = await wfTx.get(
                `/public/workflow/rest/v1/workflow-instances/${rootInstanceId}/context/startEvent`
            );

            if (!context) {
                logger.info(`Workflow context not found for entity: ${ID}`);
                return false;
            }

            // -------------------------------------------------------
            // STEP 4: Trigger New Workflow
            // -------------------------------------------------------
            context.retriggered = "retriggered";

            // if(wflag === 1){
            //     context.retriggered = "Master data retriggered";
            // }

            const newWorkflow = await wfTx.post(
                `/public/workflow/rest/v1/workflow-instances`,
                {
                    definitionId,
                    context
                }
            );

            if (!newWorkflow?.id) {
                logger.error(`Failed to create new workflow for entity: ${ID}`);
                return false;
            }

            logger.info(
                `New workflow ${newWorkflow.id} created successfully for entity: ${ID}`
            );

            // -------------------------------------------------------
            // STEP 5: Cancel Old Workflow (if not already cancelled)
            // -------------------------------------------------------
            if (rootStatus !== "CANCELED" && rootStatus !== "COMPLETED") {
                await wfTx.patch(
                    `/public/workflow/rest/v1/workflow-instances/${rootInstanceId}`,
                    {
                        status: "CANCELED"
                    }
                );

                logger.info(
                    `Old workflow ${rootInstanceId} cancelled successfully.`
                );
            } else {
                logger.info(
                    `Old workflow ${rootInstanceId} already cancelled. Skipping PATCH.`
                );
            }

            // -------------------------------------------------------
            // STEP 6: Update Database with New Workflow ID
            // -------------------------------------------------------
            let table=queue?ShippingRequestQueue:ShippingRequestEntityDocs
            if( wflag===2){
                await tx.run(
                    UPDATE(cds.entities.asnOrphanDocs)
                        .set({
                            workflowID: newWorkflow.id
                        })
                        .where({
                            ID
                        })
                );
 
            }
            if(table && wflag && wflag!==2){
                await tx.run(
                    UPDATE(table)
                        .set({
                            wfInstanceId: newWorkflow.id
                        })
                        .where({
                            ID
                        })
                );

                logger.info(
                    `Updated ShippingRequestEntityDocs with workflow ID ${newWorkflow.id} for entity: ${ID}`
                );
            }
            await tx.commit();
            return true;

        } catch (error) {
            await tx.rollback();
            logger.error(error);

            throw new Error(
                `${bundle.getText("IssueinTriggeringWorkflow")}: ${error.message}`
            );
        }
    },

    //R2.2 Start
    runBackgroundReprocessJob: async function (req) {
        const LOG = cds.log(constants.SR_REPROCESS_JOB);
        LOG.info(constants.ReprocessJobStarted);

        const { ShippingRequest, ShippingRequestEntityDocs, ShippingRequestQueue } = cds.entities;

        /* ------------------- 1. Fetch TOP-LEVEL errors ------------------- */
        const topLevelErrors = await SELECT
            .from(ShippingRequest)
            .columns('ID', 'shippingReqNo', 'initialDocumentNo')
            .where([
                '(',
                { ref: ['pfcCheckStatus'] }, '=', { val: 'Error' }, 'or',
                { ref: ['masterDataStatus'] }, '=', { val: 'Error' }, 'or',
                { ref: ['scenarioDeterminationCheckStatus'] }, '=', { val: 'Error' },
                ')'
            ]);

        /* ------------------- 2. Fetch DOC-LEVEL errors ------------------- */
        const docLevelErrors = await SELECT
            .from(ShippingRequestEntityDocs)
            .columns(
                'parent.ID as ID',
                'parent.shippingReqNo as shippingReqNo',
                'parent.initialDocumentNo as initialDocumentNo'
            )
            .where({ errorStatus: 'Error' });

        /* ------------------- 3. Merge (remove duplicates) ------------------- */
        const mergedMap = new Map();
        [...topLevelErrors, ...docLevelErrors].forEach(r => {
            if (!mergedMap.has(r.ID)) {
                mergedMap.set(r.ID, r);
            }
        });

        const errorRequests = [...mergedMap.values()];
        if (!errorRequests.length) {
            LOG.info(constants.NoShippingRequestsinError);
            return;
        }

        LOG.info(`${constants.TotalSRstoreprocess}: ${errorRequests.length}`);

        /* ------------------- 4. Batching ------------------- */
        const BATCH_SIZE = 5;
        const success = [];
        const failed = [];

        const chunk = (arr, size) =>
            Array.from({ length: Math.ceil(arr.length / size) }, (_, i) =>
                arr.slice(i * size, i * size + size)
            );

        const batches = chunk(errorRequests, BATCH_SIZE);

        /* ------------------- 5. Process batches ------------------- */
        for (const batch of batches) {
            LOG.info(`${constants.Processingbatch}: (${batch.length})`);
            await Promise.all(
                batch.map(async (reqData) => {
                    const srNo = reqData.shippingReqNo;
                    try {
                        LOG.info(`${constants.ReprocessingSR}: ${srNo}`);
                        // NEW transaction per SR (background-safe)
                        await cds.tx(async (tx) => {
                            await module.exports.reprocessShippingRequest(req,tx, reqData);
                        });
                        success.push(srNo);
                        LOG.info(`SR ${srNo}: ${constants.reprocessedsuccessfully}`);
                    } catch (err) {
                        failed.push({ srNo, error: err.message });
                        LOG.error(`SR ${srNo}: ${constants.failed} | ${err.message}`);
                    }
                })
            );
        }

        /* ------------------- 6. Summary ------------------- */
        LOG.info('--------------------------------------------');
        LOG.info(`Successful SRs : ${success.length}`);
        LOG.info(`Failed SRs     : ${failed.length}`);
        LOG.info('--------------------------------------------');
        
        /* ------------------- 7. Change Events Queue Reprocess ------------------- */
        const errorQueueItems = await SELECT
            .from(ShippingRequestQueue)
            .columns('ID', 'wfInstanceId', 'status', 'queueNo', 'parentPO')
            .where({ status: 'Error' })
            .orderBy('queueNo asc');

        if (errorQueueItems.length) {
            const queueBatches = chunk(errorQueueItems, BATCH_SIZE);

            for (const batch of queueBatches) {
                await Promise.all(
                    batch.map(async (item) => {
                        const PO = item.parentPO;
                        try {
                            if (item.wfInstanceId) {
                                const result = await module.exports.InitiateSubProcessWorkFlowInstance(req, item.wfInstanceId, item.ID, true);
                                if (result) {
                                    await UPDATE(ShippingRequestQueue)
                                        .set({ status: 'Retriggered' })
                                        .where({ ID: item.ID });
                                    LOG.info(`Reprocessing initiated for PO: ${PO}`);
                                } else {
                                    LOG.warn(`Workflow not started for queue item ${item.ID}, PO: ${PO} — status unchanged`);
                                }
                            } else {
                                LOG.info(`Error queue item for PO: ${PO} has no wfInstanceId available`);
                            }
                        } catch (err) {
                            LOG.error(`Error reprocessing queue item for PO ${PO}: ${err.message}`);
                        }
                    })
                );
            }
        }

    },
    //R2.2 END

    reprocessShippingRequest: async (req, tx, data) => {
        logger.info(`Reprocessing Shipping Request: ${data.shippingReqNo}`);
        const locale = req.user.locale;
        const bundle = textBundle.getTextBundle(locale);
        const { ID } = data;
        const { ShippingRequest, ShippingRequestEntityDocs } = cds.entities;

        const sr = await tx.run(
            SELECT.one.from(ShippingRequest).where({ ID })
        );
        if (!sr) throw new Error(bundle.getText('ShippingRequestnotfound'));

        const statusFields = [
            'pfcCheckStatus',
            'masterDataStatus',
            'scenarioDeterminationCheckStatus'
        ];

        /* ------------------- TOP-LEVEL ERROR ------------------- */
        const erroredFields = statusFields.filter(f => sr[f] === 'Error');

        if (erroredFields.length) {
            if (!sr.wfInstanceId) {
                throw new Error(bundle.getText('WorkflowInstanceIDmissing'));
            }

            await module.exports.InitiateWorkFLow(req, sr.wfInstanceId, 'docLevel');

            const updatePayload = {
                status: 'In Progress'
            };

            erroredFields.forEach(f => {
                updatePayload[f] = 'Retriggered';
            });

            await tx.run(
                UPDATE(ShippingRequest)
                    .set(updatePayload)
                    .where({ ID })
            );
            logger.info(`Workflow retriggered for Shipping Request for top level: ${data.shippingReqNo}`);
            return;
        }

        /* ------------------- DOC-LEVEL ERROR ------------------- */

        

        const pendingError = await tx.run(
            SELECT.one.from(ShippingRequestEntityDocs).where({
                parent_ID: ID,
                errorStatus: "Error",
                wfInstanceId: { '!=': '' }
            })
        );

         if (pendingError) {

        const wfResult = await module.exports.InitiateSubProcessWorkFlowInstance(req, pendingError.wfInstanceId, pendingError.ID);

        if (wfResult) {
          await UPDATE(ShippingRequestEntityDocs)
            .set({ errorStatus: "Retriggered" })
            .where({
              ID: pendingError?.ID
            });

          await UPDATE(ShippingRequest)
            .set({ status: "In Progress", docFlowStateCheckStatus: 'In Progress' })
            .where({
              ID: pendingError?.parent_ID
            });

          logger.info(`Subprocess workflow retriggered for Shipping Request: ${data.shippingReqNo}`);
        } else {
          logger.warn(`Workflow not started for entity doc ${pendingError.ID} — status unchanged`);
        }
        return
      }

      const errorDoc = await tx.run(
            SELECT.one.from(ShippingRequestEntityDocs).where({
                parent_ID: ID,
                errorStatus: "Error",
                wfInstanceId: { '!=': '' }
            })
        );


        if (!errorDoc) return;

        if (!errorDoc.wfInstanceId) {
            throw new Error(bundle.getText('WorkflowInstanceIDmissingforentity'));
        }

        await module.exports.InitiateWorkFLow(req, errorDoc.wfInstanceId, 'docLevel');

        await tx.run(
            UPDATE(ShippingRequestEntityDocs)
                .set({ errorStatus: 'Retriggered' })
                .where({ ID: errorDoc.ID })
        );

        await tx.run(
            UPDATE(ShippingRequest)
                .set({
                    status: 'In Progress',
                    docFlowStateCheckStatus: 'In Progress'
                })
                .where({ ID })
        );
        logger.info(`Workflow retriggered for Shipping Request: ${data.shippingReqNo}`);

        return
    }

}
