// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Value Chain Monitoring App
// Object Id       : ZBUVCM55155
// Release         : 1
// Version         : 0.01
// Description     : Value Chain Monitoring App
// ----------------------------------------------------------------------------*
// Descriptions: Function implementation to execute the logic for hana database.
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
//  28-04-2026    RChitike       JGHJ-92926     Updated error description for outbound delivery document
// ----------------------------------------------------------------------------*

const cds = require('@sap/cds');
// const constants = require('./config/constants');
const logger = cds.log('vcm55155-program');
const dbClass = require("sap-hdbext-promisfied");
const hdbext = require("@sap/hdbext");
const servicejs = require('../zbuvcm55155service');
const { InitiateWorkFLow, InitiateWorkFLow1 } = require('../utils/utils');
const { action } = require('@sap/cds/lib/core/classes');
const { header } = require('@sap/cds/lib/i18n/locale');
const constants = require('../config/constants');

const { Comments, ShippingRequestEntityDocs, ShippingRequest, ShippingRequestItem, ShippingRequestErrors, ShippingRequestEntityFollowOnDocs, NonVCAScenarioConfig, asnOrphanDocs } = cds.entities;
'use strict';
module.exports = {

  /**
     * Inserts a new comment into the Comments entity
     * @param {Object} commentData - Object containing comment details
     * @param {string} commentData.comment - Comment text
     * @param {string} commentData.ID - Parent ID
     * @param {string} commentData.shippingReqNo - Parent shipping request number
     * @param {string} commentData.initialDocumentNo - Parent initial document number
     */
  addComment: async ({ comment, ID, shippingReqNo, initialDocumentNo, bundle }) => {
    try {
      return await INSERT.into(Comments).entries({
        comments: comment,
        parent_ID: ID,
        parent_shippingReqNo: shippingReqNo,
        parent_initialDocumentNo: initialDocumentNo
      });
    } catch (err) {
      console.error(bundle.getText('DBInsertError'), err);
      throw err;
    }
  },

  /**
  * Fetch all entity docs for a given initian Document number and reference no
  * @param {string} initialDocumentNo - The initial document number 
  * @param {string} referenceDocumentNo - The cQuence number  
  * @returns {Promise<Array>} - List of entity documents
  */
  getEntityDocsForAT: async (initialDocumentNo, referenceDocumentNo, bundle) => {

    try {
      return await SELECT.one.from(ShippingRequest, (sReq) => {
        sReq.initialDocumentNo,
          sReq.referenceDocumentNo,
          sReq.followOnDocumentNo,
          sReq.entity((entity) => {
            entity.documentType,
              entity.documentNumber,
              entity.creationDate,
              entity.entityType,
              entity.entityRank,
              entity.legalEntity,
              entity.plantName,
              entity.plant,
              entity.businessPartnerId,
              entity.bpName,
              entity.documentSequence,
              entity.errorStatus,
              entity.errorDescription
          })
      }).where({ initialDocumentNo, referenceDocumentNo })
    } catch (err) {
      console.error(bundle.getText('DBReadError'), err);
      throw err;
    }
  },

  /**
  * Fetch all header data for array of initial document number and reference document number
  * @param {string} aHeaderReqAt - The array of initial document number and reference document
  * @returns {Promise<Array>} - List of all header data
  */
  getHeaderForAT: async (aHeaderReqAt, bundle) => {

    try {
      const queries = aHeaderReqAt.map((header) =>
        SELECT.from(ShippingRequest, (sReq) => {
          sReq.initialDocumentNo,
            sReq.referenceDocumentNo,
            sReq.status,
            sReq.pfcState,
            sReq.pfcCheckStatus,
            sReq.scenarioDeterminationCheckStatus,
            sReq.masterDataStatus,
            sReq.docFlowStateCheckStatus,
            sReq.wfInstanceId,
            sReq.followOnDocumentNo

          sReq.entity((entity) => {
            entity.documentType,
              entity.documentNumber,
              entity.entityType,
              entity.entityRank,
              entity.legalEntity,
              entity.documentSequence,
              entity.errorStatus,
              entity.errorDescription,
              entity.plant,
              entity.wfInstanceId,
              entity.creationDate
          }),
            sReq.items((item) => {
              item.batchNumber,
                item.materialNumber
            })
        }).where(header)
      );

      const data = await cds.run(queries)
      return data.flat()
    } catch (err) {
      console.error(bundle.getText('DBReadError'), err);
      throw err;
    }
  },

  /**
   * Fetch all entity docs for a given parent ID
   * @param {string} parentID - The parent ShippingRequest ID
   * @returns {Promise<Array>} - List of entity documents
   */
  getHeaderDetailsWithRef: async (referenceDocumentNo, bundle) => {
    if (!referenceDocumentNo) {
      throw new Error(bundle.getText('Reference Doc should be present!'));
    }

    try {
      const data = await SELECT.from(ShippingRequest)
        .where({ referenceDocumentNo })
      if (data.length) {
        return data

      }
      return { ID: "" }

    } catch (err) {
      console.error(bundle.getText('DBReadError'), err);
      throw err;
    }
  },

  /**
   * Get location summary and shipping request info for a given shippingReqNo
   * @param {string} shippingReqNo - The shipping request number
   * @returns {Promise<{uniqueResult: Array, result1: Array}>}
   */
  getLocationSummary: async (shippingReqNo, bundle) => {
    if (!shippingReqNo) {
      throw new Error(bundle.getText('ShippingReqNoIsRequired'));
    }

    try {
      // Query location summary
      const result = await SELECT.from('ShippingRequestEntityLocationSummary')
        .where({ shippingReqNo: shippingReqNo })
        .orderBy('entityRank');

      // Query basic shipping request details
      const result1 = await SELECT.columns(
        'shipFromBusinessPartnerName', 'shipFromBusinessPartner',
        'shipFromPlantName', 'shipFromPlant',
        'shipToBusinessPartnerName', 'shipToBusinessPartner',
        'shipToPlantName', 'shipToPlant'
      )
        .from('ShippingRequest')
        .where({ shippingReqNo });
      const docs = await SELECT.from('ShippingRequestEntityDocs')
        .where({ parent_shippingReqNo: shippingReqNo });

      const followOnDocSet = new Set();
      let followOnDocFoundOne = null
      for (let i = 0; i < docs.length; i++) {
        const followOnDocNo = docs[i].followOnDocumentNo;

        if (followOnDocNo) {
          followOnDocSet.add(followOnDocNo);
        }
      }

      if (followOnDocSet.size === 1) {
        followOnDocFoundOne = [...followOnDocSet][0];
      }

      const distinctFollowOnCount = followOnDocSet.size;
      const followOnDocFound = distinctFollowOnCount > 1;

      // Deduplicate based on entityType + entityRank
      const seen = new Set();
      const uniqueResult = result
        .filter(row => {
          const key = `${row.entityType}_${row.entityRank}`;
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        })
        .filter(unique => unique?.entityType !== bundle.getText('ShipFrom') && unique?.entityType !== bundle.getText('ShipTo'));

      return { uniqueResult, result1, followOnDocFound: followOnDocFound, followOnDocFoundOne: followOnDocFoundOne };

    } catch (err) {
      console.error(bundle.getText('DBErrorInGetLocationSummary'), err);
      throw err;
    }
  },

  /**
  * Creates a new Shipping Request along with its items
  * @param {object} payload - The shipping request payload
  * @returns {Promise<{ID: string, shippingReqNo: string}>}
  */
  createShippingRequest: async (payload, bundle, ZSD_VCM_PRODUCTFLOW) => {

    if (!payload) throw new Error(bundle.getText('PayloadIsRequired'));

    try {

      if (payload.initialDocumentNo) {

        const existingReq = await SELECT.one
          .from(ShippingRequest)
          .where({ initialDocumentNo: payload.initialDocumentNo });

        if (existingReq) {
          throw new Error(`Shipping Request ${existingReq?.shippingReqNo} already exists `);
        }

      }
      // Connect to DB and get next shipping request ID
      const db = await cds.connect.to('db');
      const dbConn = new dbClass(await dbClass.createConnection(db.options.credentials));

      const sp = await dbConn.loadProcedurePromisified(hdbext, null, 'getshippingrequest');
      const output = await dbConn.callProcedurePromisified(sp, []);
      let seqNum = parseInt(output.results[0].ID, 10);

      const maxExisting = await SELECT.one.from(ShippingRequest)
        .columns('shippingReqNo')
        .where(`shippingReqNo like 'V%'`)
        .orderBy('shippingReqNo desc');

      if (maxExisting?.shippingReqNo) {
        const maxNum = parseInt(maxExisting.shippingReqNo.substring(1), 10);
        if (seqNum <= maxNum) {
          logger.warn(`Sequence behind manual inserts (seq: ${seqNum}, max in DB: ${maxNum}). Using ${maxNum + 1}.`);
          seqNum = maxNum + 1;
        }
      }

      const nextID = `V${seqNum}`;
      // DEFECT - JGHJ-92366 - START
      const id = cds.utils.uuid();
      // DEFECT - JGHJ-92366 - END
      payload.shippingReqNo = nextID;
      logger.debug(bundle.getText('PayloadWithNewShippingReqNo'), payload);


      //  Collect unique BPs and Plants
      const bpSet = new Set();
      const plantSet = new Set();

      //R2.2 Start
      if (payload?.shipFromBusinessPartner) bpSet.add(payload.shipFromBusinessPartner.trim());
      if (payload?.shipToBusinessPartner) bpSet.add(payload.shipToBusinessPartner.trim());
      //R2.2 End

      if (payload?.shipFromPlant) plantSet.add(payload.shipFromPlant.trim());
      if (payload?.shipToPlant) plantSet.add(payload.shipToPlant.trim());

      //  Single S/4 calls
      let bpCountryKeyMassList = [];
      let plantCountryKeyMassList = [];

      if (bpSet.size) {
        bpCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(
          //R2.2 Start
          SELECT.from('Massbpplantcntrykey').where({ BusinessPartner: { in: [...bpSet] } })
          //R2.2 End
        );
      }
      if (plantSet.size) {
        plantCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(
          //R2.2 Start
          SELECT.from('Massplantbpcntrykey').where({ Plant: { in: [...plantSet] } })
          //R2.2 End
        );
      }

      //  Build lookup maps
      const bpMap = {};
      bpCountryKeyMassList.forEach(b => { bpMap[b.BusinessPartner] = b.BusinessPartnerName; });

      const plantMap = {};
      plantCountryKeyMassList.forEach(p => { plantMap[p.Plant] = p.PlantName; });

      //R2.2 Start
      payload.shipFromBusinessPartnerName = bpMap[payload?.shipFromBusinessPartner] || "";
      //R2.2 End
      payload.shipFromPlantName = plantMap[payload?.shipFromPlant] || "";

      //R2.2 Start
      payload.shipToBusinessPartnerName = bpMap[payload?.shipToBusinessPartner] || "";
      //R2.2 End
      payload.shipToPlantName = plantMap[payload?.shipToPlant] || "";
      // DEFECT - JGHJ-92366 - START
      payload.ID = id
      // DEFECT - JGHJ-92366 - END
      // // Insert shipping request without items first
      await INSERT.into(ShippingRequest).entries({
        ...payload,
        items: []
      });

      const items = payload.items || [];

      // materials needing S4 lookup
      const materialsToFetch = [
        ...new Set(
          items.map(i => String(i.materialNumber).trim())
        )
      ];
      let materialMap = new Map();

      if (materialsToFetch.length) {
        const materialData = await ZSD_VCM_PRODUCTFLOW.run(
          SELECT.from('Material').where({ Product: materialsToFetch })
        );

        // Build lookup map
        materialData.forEach(m => {
          materialMap.set(m.Product, {
            materialDescription: m.ProductName,
            materialType: m.ProductType
          });
        });
      }


      // Fetch the latest inserted shipping request
      // DEFECT - JGHJ-92366 - START
      const latestReq = await SELECT.one.from(ShippingRequest)
        .where({ ID: id, shippingReqNo: nextID, initialDocumentNo: payload.initialDocumentNo })
        .orderBy('createdAt desc');
      // DEFECT - JGHJ-92366 - END

      if (!latestReq) throw new Error(bundle.getText('FailedToRetrieveTheLatestShippingRequest'));

      const shippingReqNo = latestReq.shippingReqNo;

      const itemsWithReqNo = (items || []).map(item => {
        const materialKey = item.materialNumber?.trim();
        const s4Data = materialMap.get(materialKey) || {};

        return {
          ...item,

          // populate only if missing
          materialDescription:
            item.materialDescription || s4Data.materialDescription,

          materialType:
            item.materialType || s4Data.materialType,

          parent_shippingReqNo: shippingReqNo,
          parent_ID: latestReq.ID,
          parent_initialDocumentNo: latestReq.initialDocumentNo
        };
      });


      if (itemsWithReqNo.length) {
        await INSERT.into(ShippingRequestItem).entries(itemsWithReqNo);
      }

      return { ID: latestReq.ID, shippingReqNo };

    } catch (err) {
      logger.error(bundle.getText('ErrorInCreateShippingRequest'), err);
      throw err;
    }
  },

  /**
 * Update header data for a Shipping Request
 * @param {object} data - Payload containing the fields to update
 * @returns {Promise<string>} - Success message
 */
  updateHeaderData: async (data, ZSD_VCM_PRODUCTFLOW, bundle) => {
    try {
      if (!data?.ID) {
        throw new Error(bundle.getText("IDIsMissing"));
      }

      // Fetch existing request
      const getShipingReq = await SELECT.from(ShippingRequest).where({ ID: data?.ID });
      if (!getShipingReq) {
        throw new Error(bundle.getText("NoShippingRequestIDIsFound"));
      }

      const updateFields = {
        wfInstanceId: data.wfInstanceId || "",
        pfcCheckErrorDescription: data.pfcCheckErrorDescription ? data.pfcCheckErrorDescription : undefined,
        masterDataErrorDesciption: data.masterDataStatus === 'Success' ? '' : (data.masterDataErrorDesciption || undefined),
        scenarioCheckStatusErrorDescription: data.scenarioCheckStatusErrorDescription ? data.scenarioCheckStatusErrorDescription : undefined,
      };

      [
        "initialDocumentType",
        "referenceDocumentNo",
        "followOnDocumentNo",
        "status",
        "requestedDeliveryDate",
        "scenarioID",
        "masterDataStatus",
        "scenarioDeterminationCheckStatus",
        "pfcCheckStatus",
        "docFlowStateCheckStatus",
        "productFlowCatalogID",
        "productFlowID",
        "creationDate",
        "userName",
        "masterDataErrorResolutionDate",
        "pfcCheckErrorResolutionDate",
        "scenarioCheckErrorResolutionDate"
      ].forEach(field => {
        if (data[field]) updateFields[field] = data[field];
      });


      // Merge existing + new data
      let merged = { ...getShipingReq, ...data };

      // Collect all check statuses
      const {
        pfcCheckStatus,
        scenarioDeterminationCheckStatus,
        masterDataStatus,
        docFlowStateCheckStatus
      } = merged;

      logger.info({
        pfcCheckStatus,
        scenarioDeterminationCheckStatus,
        masterDataStatus,
        docFlowStateCheckStatus
      }, "Status of header checks")

      let computedStatus = "In Progress"; // default

      // Rule 1: If any one is Error
      if ([pfcCheckStatus, scenarioDeterminationCheckStatus, masterDataStatus, docFlowStateCheckStatus]
        .some(st => st?.toLowerCase().includes("error"))) {
        computedStatus = "Error";
      }

      const errorMap = [
        { type: "PFC Check", status: pfcCheckStatus, description: data.pfcCheckErrorDescription },
        { type: "Scenario Determination Check", status: scenarioDeterminationCheckStatus, description: data.scenarioCheckStatusErrorDescription },
        { type: "Master Data Check", status: masterDataStatus, description: data.masterDataErrorDesciption },
      ];

      const errorEntries = errorMap.filter(e =>
        e.status?.toLowerCase().includes("error") ||
        e.status?.toLowerCase().includes("warning")
      );


      //  Rule 2: If any are errors
      if (errorEntries.length > 0) {
        computedStatus = masterDataStatus === 'Warning' ? 'In Progress' : 'Error';

        // Instead of deleting, we just append new error logs
        const errorLogs = errorEntries.map(e => ({
          ID: cds.utils.uuid(),
          parent_ID: data.ID,
          vcaErrorStatus: e.description || "Unknown error",
          vcaErrorType: e.status === 'Error' ? "Error" : "Warning",
          wfInstanceId: data.wfInstanceId,
          vcaErrorTimeStamp: new Date()
        }));

        await INSERT.into(ShippingRequestErrors).entries(errorLogs);
      }

      // Rule 3: If first 3 are Success but docFlow not yet Success
      else if ([pfcCheckStatus, scenarioDeterminationCheckStatus, masterDataStatus]
        .every(st => st?.toLowerCase().includes("success"))) {
        computedStatus = "In Progress";
      }
      updateFields.status = computedStatus;


      // ---------------- Ship From ----------------
      if (data.shipFromBusinessPartner || data.shipFromPlant) {
        const existingDocs = await SELECT.from(ShippingRequestEntityDocs).where({ parent_ID: data?.ID });

        let bpFromName = [];
        let plantFromName = [];

        if (data.shipFromBusinessPartner) {
          bpFromName = await ZSD_VCM_PRODUCTFLOW.run(
            SELECT.from("countrybpkey").where({ BusinessPartner: { in: [data.shipFromBusinessPartner.trim()] } })
          );
          updateFields.shipFromBusinessPartner = data.shipFromBusinessPartner;
          updateFields.shipFromBusinessPartnerName = bpFromName[0]?.BusinessPartnerName || "";
        }
        if (data.shipFromPlant) {
          plantFromName = await ZSD_VCM_PRODUCTFLOW.run(
            SELECT.from("countryplantkey").where({ Plant: { in: [data.shipFromPlant.trim()] } })
          );
          updateFields.shipFromPlant = data.shipFromPlant;
          updateFields.shipFromPlantName = plantFromName[0]?.plantName || "";
        }

        const updatableDocs = existingDocs.filter(doc => ["Ship From"].includes(doc.entityType));

        if (updatableDocs.length) {
          updatableDocs.forEach(doc => {
            if (data.shipFromBusinessPartner && doc.entityType === "Ship From") {
              doc.businessPartnerId = data.shipFromBusinessPartner;
              doc.bpName = bpFromName[0]?.BusinessPartnerName || "";
            }
            if (data.shipFromPlant && doc.entityType === "Ship From") {
              doc.plant = data.shipFromPlant;
              doc.plantName = plantFromName[0]?.plantName || "";
            }
          });

          try {
            await UPDATE(ShippingRequestEntityDocs).set(updatableDocs).where({ ID: data?.ID });
          } catch (err) {
            logger.debug("Error updating ShipFrom docs:", err);
          }
        }
      }

      // ---------------- Ship To ----------------
      if (data.shipToBusinessPartner || data.shipToPlant) {

        const existingDocs = await SELECT.from(ShippingRequestEntityDocs).where({ parent_ID: data?.ID });

        let bpToName = [];
        let plantToName = [];

        if (data.shipToBusinessPartner) {

          bpToName = await ZSD_VCM_PRODUCTFLOW.run(
            SELECT.from("countrybpkey").where({ BusinessPartner: { in: [data.shipToBusinessPartner.trim()] } })
          );
          updateFields.shipToBusinessPartnerName = bpToName[0]?.BusinessPartnerName || "";
          updateFields.shipToBusinessPartner = data.shipToBusinessPartner;
        }
        if (data.shipToPlant) {

          plantToName = await ZSD_VCM_PRODUCTFLOW.run(
            SELECT.from("countryplantkey").where({ Plant: { in: [data.shipToPlant.trim()] } })
          );
          updateFields.shipToPlantName = plantToName[0]?.plantName || "";
          updateFields.shipToPlant = data.shipToPlant;
        }

        const updatableDocs = existingDocs.filter(doc => ["Ship To"].includes(doc.entityType));

        if (updatableDocs.length) {
          updatableDocs.forEach(doc => {
            if (data.shipToBusinessPartner && doc.entityType === "Ship To") {
              doc.businessPartnerId = data.shipToBusinessPartner;
              doc.bpName = bpToName[0]?.BusinessPartnerName || "";
            }
            if (data.shipToPlant && doc.entityType === "Ship To") {
              doc.plant = data.shipToPlant;
              doc.plantName = plantToName[0]?.plantName || "";
            }
          });

          try {
            await UPDATE(ShippingRequestEntityDocs).set(updatableDocs).where({ ID: data?.ID });
          } catch (err) {
            logger.debug("Error updating ShipTo docs:", err);
          }
        }
      }

      // Final update
      logger.info(updateFields, "updateFields for updateHeaderData")
      const result = await UPDATE(ShippingRequest).set(updateFields).where({ ID: data?.ID });
      if (result === 0) {
        throw new Error(bundle.getText("NoMatchingRecordFoundForUpdate"));
      }

      return `${bundle.getText("ShippingRequest")} ${data?.shippingReqNo} ${bundle.getText("withID")} ${data?.ID} ${bundle.getText("RecordUpdatedSuccessfully")}`;
    } catch (error) {
      logger.error("updateHeaderData failed:", error);
      throw error; // rethrow so CAP returns proper error response
    }
  },



  /**
 * Update fields for ShippingRequestEntityDocs
 * Also inserts a success record in ShippingRequestErrors if documentNumber is provided
 * @param {object} data - Payload with update information
 * @returns {Promise<object>} - Updated record reference { ID }
 */
  updateEntityTable: async (data, bundle, req) => {
    const tx = cds.tx(req)
    try {

      logger.info(`Payload for Updating Entity Table document ${data?.ID}`, JSON.stringify(data))
      if (!data?.ID) {
        throw new Error(bundle.getText("IDIsMissing"));
      }
      if (!data?.documentNumber) {
        throw new Error(bundle.getText("DocumentNumberIsMissing"));
      }

      // Validate entity exists
      const currentEntity = await tx.run(
        SELECT.one.from(ShippingRequestEntityDocs)
          .where({ ID: data?.ID })
      );

      if (!currentEntity) {
        throw new Error(bundle.getText("NoDataFound"));
      }

      // Prepare fields to update
      const updateFields = {};
      const apiCalls = []; // store API calls to be executed after DB commit

      if (data.documentNumber) {
        // Defect JGHJ-86311 --- START
        if (currentEntity.parent_shippingReqNo.toUpperCase().startsWith("S")) {
          let stepID = currentEntity.stepID.trim().toUpperCase();
          let documentNumber = data.documentNumber;
          logger.info(`StepID: ${stepID}, DocumentNumber: ${documentNumber} for Legal Entity update check`);

          // Fetch Legal Entity based on stepID and document number
          let legalEntity = await module.exports.updateLegalEntity(stepID, documentNumber);
          logger.info(`Fetched Legal Entity: ${legalEntity} for StepID: ${stepID} and DocumentNumber: ${documentNumber}`);

          // Update Legal Entity
          if (legalEntity) {
            await UPDATE(ShippingRequestEntityDocs)
              .set({
                legalEntity: legalEntity
              })
              .where({
                ID: currentEntity.ID
              });
          }
          // Defect JGHJ-86311 --- END
        }
        // Get all docs for this parent
        const docs = await tx.run(
          SELECT.from(ShippingRequestEntityDocs)
            .where({ parent_ID: currentEntity.parent_ID })
        );

        if (docs.length > 0) {
          // Find the doc with max sequence
          const maxDoc = docs.reduce((prev, curr) =>
            (curr.documentSequence ?? 0) > (prev.documentSequence ?? 0) ? curr : prev
          );

          const getItem = await tx.run(
            SELECT.one.from(ShippingRequestItem).where({
              parent_ID: currentEntity.parent_ID
            })
          )
          const currDoc = await tx.run(
            SELECT.one.from(ShippingRequestEntityDocs)
              .where({ ID: data.ID })
          );

          if (currDoc.stepID.trim().toUpperCase() === "BT_FP") {
            // logic to send batch to AT
            apiCalls.push({
              endpoint: "/zbudel109r2/updateBatchNo",
              payload: {
                SAP_SONum: getItem?.parent_initialDocumentNo || "",
                SO_Item: getItem?.itemNo || "",
                BatchNo: data.documentNumber || "",
                Plant: currDoc.plant,
                Material: getItem?.materialNumber || ""
              }
            });
          }
          //find  legal entity of this doc
          // Defect JGHJ-112394--START  
          if (currDoc.stepID.trim().toUpperCase() === "OBD" && (currDoc.legalEntity === "6162" || (currDoc.legalEntity === "6014" && currDoc.isExceptionalDocument === true))) {
            const payload = {
              SAP_SONum: getItem?.parent_initialDocumentNo || "",
              SO_Item: getItem?.itemNo || "",
              SAP_Obd_Num: data.documentNumber,
              GI_V3_Status: ""
            };
            logger.info("outbound delivery API called from VCM", JSON.stringify(payload));
            apiCalls.push({
              endpoint: "/zbudel109r2/updateOutboundDel",
              payload: payload
            });
          }

            if (currDoc.stepID.trim().toUpperCase() === "GI" && (currDoc.legalEntity === "6162" || (currDoc.legalEntity === "6014" && currDoc.isExceptionalDocument === true))) {
            const payload = {
              SAP_SONum: getItem?.parent_initialDocumentNo || "",
              SO_Item: getItem?.itemNo || "",
              SAP_Obd_Num: "",
              GI_V3_Status: constants.successStatus
            };
            logger.info("Goods Issue API called from VCM", JSON.stringify(payload));
 
            apiCalls.push({
              endpoint: "/zbudel109r2/updateOutboundDel",
              payload: payload
            });
          }
          // Defect JGHJ-112394--END     
          if (data.documentNumber === 'REJT') {
            // Step 1: Identify docs to mark as NA
            let docsTobeNA = docs.filter(
              doc => doc.isExceptionalDocument === false && doc.isAT === false
            );

            // Defect JGHJ-95952 --- START
            // To get document sequence of Quality UD
            let udStep = docs.find(
              doc => doc.stepID.trim().toUpperCase() === 'QT_UD'
            );

            // Identify AT docs to mark as NA
            let docsToBeNAForAT = docs.filter(
              doc => doc.isAT === true && doc.isExceptionalDocument === true && doc.documentSequence > udStep.documentSequence
            );

            // Step 2: Get all IDs to update
            let idsToUpdate = docsTobeNA.map(doc => doc.ID);

            // Push AT document IDs also
            idsToUpdate.push(...docsToBeNAForAT.map(doc => doc.ID));

            // Defect JGHJ-95952 --- END

            // Step 3: Include Material Transfer doc if present
            let materialTransferDoc = docs.find(
              doc => doc.stepID.trim().toUpperCase() === 'IM_TR' && doc.errorStatus === 'Pending'
            );

            let MaterialTransferRetainBag = docs.find(doc => doc.stepID.trim().toUpperCase() === 'IM_TR_RB' && doc.errorStatus === 'Pending')
            if (MaterialTransferRetainBag) {
              idsToUpdate.push(MaterialTransferRetainBag.ID)
            }
            if (materialTransferDoc) {
              idsToUpdate.push(materialTransferDoc.ID);
            }

            // Step 4: Perform the DB update
            await tx.run(
              UPDATE(ShippingRequestEntityDocs)
                .set({
                  documentNumber: 'N/A',
                  errorStatus: 'N/A'
                })
                .where({ ID: { in: idsToUpdate } })
            );
          }

          if (data.documentNumber === 'ACCP') {

            let idsToUpdate = []

            let materialTransferDoc = docs.find(
              doc => doc.stepID.trim().toUpperCase() === 'IM_TR' && doc.errorStatus === 'Pending'
            );
            if (materialTransferDoc) {
              idsToUpdate.push(materialTransferDoc.ID);
            }

            let MaterialTransferRetainBag = docs.find(doc => doc.stepID.trim().toUpperCase() === 'IM_TR_RB' && doc.errorStatus === 'Pending')
            if (MaterialTransferRetainBag) {
              idsToUpdate.push(MaterialTransferRetainBag.ID)
            }
            await tx.run(
              UPDATE(ShippingRequestEntityDocs)
                .set({
                  documentNumber: 'N/A',
                  errorStatus: 'N/A'
                })
                .where({ ID: { in: idsToUpdate } })
            );
          }

          if (data.documentNumber === 'ALTU') {
            // Step 1: Identify docs to mark as NA
            let docsTobeNA = docs.filter(
              doc => doc.stepID.trim().toUpperCase() === 'API'
            );

            // Step 2: Get all IDs to update
            let idsToUpdate = docsTobeNA.map(doc => doc.ID);

            // Step 3: Perform the DB update
            await tx.run(
              UPDATE(ShippingRequestEntityDocs)
                .set({
                  documentNumber: 'N/A',
                  errorStatus: 'N/A'
                })
                .where({ ID: { in: idsToUpdate } })
            );
          }

        }


        // Insert into errors only if docNumber is provided
        await tx.run(
          INSERT.into(ShippingRequestErrors).entries({
            ID: cds.utils.uuid(),
            parent_ID: data?.ID,
            vcaErrorStatus: data.errorDescription,
            vcaErrorType: bundle.getText("Success"),
            wfInstanceId: "",
            vcaErrorTimeStamp: new Date()
          })
        );

        // Update document fields
        updateFields.documentNumber = data.documentNumber;
        updateFields.errorStatus = bundle.getText("Success");
        updateFields.errorDescription = data.errorDescription;
        updateFields.wfInstanceId = "";
        updateFields.creationDate = new Date();
        updateFields.errorResolutionDate = new Date()
      }

      if (data.documentType) updateFields.documentType = data.documentType;
      if (data.legalEntity) updateFields.legalEntity = data.legalEntity;
      if (data.documentYear) updateFields.documentYear = data.documentYear;
      if (data.documentYear) updateFields.documentYear = data.documentYear;

      logger.info(`Updated feilds for Updating Entity Table document ${data?.ID}`, JSON.stringify(updateFields))


      if (Object.keys(updateFields).length === 0) {
        throw new Error(bundle.getText("NoUpdateFieldsProvided"));
      }

      // ================= Re-fetch latest documents =================
      const latestDocs = await tx.run(
        SELECT.from(ShippingRequestEntityDocs)
          .where({ parent_ID: currentEntity.parent_ID })
      );

      const filterlatestdoc = latestDocs.filter(doc => doc.ID != data.ID && doc.errorStatus !== 'Inactive' && doc.errorStatus !== 'N/A');

      // ================= Validation =================
      const allDocsInSuccess = filterlatestdoc.every(
        doc => doc.errorStatus === 'Success'
      );

      const currentDocSuccess = updateFields.errorStatus === 'Success';

      let validatedMaxDoc = false;
      if (allDocsInSuccess && currentDocSuccess) {
        validatedMaxDoc = true;
      }

      // Update ShippingRequest header state
      await tx.run(
        UPDATE(ShippingRequest).set({
          status: validatedMaxDoc || data.documentNumber === 'REJT' ? 'Completed' : "In Progress",
          docFlowStateCheckStatus:
            validatedMaxDoc ? "Success" : "In Progress",

        }).where({ ID: currentEntity.parent_ID })
      );

      const result = await tx.run(
        UPDATE(ShippingRequestEntityDocs)
          .set(updateFields)
          .where({ ID: data?.ID })
      );

      if (result === 0) {
        throw new Error(bundle.getText("NoMatchingRecordFoundForUpdate"));
      }

      // Commit all the DB Transactions
      await tx.commit();


      // Trigger external API calls only after the DB transaction successfully commits.  
      // This event runs outside the transactional context, so DB changes remain safe even if APIs fail.  
      // This ensures clean decoupling of post-commit side effects from core business logic.
      req.on('succeeded', async () => {
        try {
          const batchAtService = await cds.connect.to("bacthAtService");
          // assume you prepared apiCalls array earlier
          await Promise.all(apiCalls.map(api => batchAtService.post(api.endpoint, api.payload)));
        } catch (err) {
          logger.error("Post-commit API calls failed:", err);
        }
      });

      return { ID: currentEntity?.ID };

    } catch (error) {
      logger.error(`Updating Entity Table document Failed for ${data?.ID}`, JSON.stringify(error))

      await tx.rollback()
      console.error("updateEntityTable error:", error);
      throw new Error(error.message || bundle.getText("UnexpectedError"));
    }
  },

  /**
* Update fields for ShippingRequestEntityDocs
* Also inserts a success record in ShippingRequestErrors if documentNumber is provided
* @param {object} data - Payload with update information
* @returns {Promise<object>} - Updated record reference { ID }
*/
  updateCancellation: async (data, bundle, req) => {
    const tx = cds.tx(req)
    try {

      logger.info(`Payload for Updating Entity Table document for cancellation ${data?.ID}`, JSON.stringify(data))
      if (!data?.ID) {
        throw new Error(bundle.getText("IDIsMissing"));
      }

      // Validate entity exists
      const currentEntity = await tx.run(
        SELECT.one.from(ShippingRequestEntityDocs)
          .where({ ID: data?.ID })
      );

      if (!currentEntity) {
        throw new Error(bundle.getText("NoDataFound"));
      }

      // Prepare fields to update
      const updateFields = {};

      if (currentEntity) {
        // Get all docs for this parent
        // Insert into errors only if docNumber is provided
        // await tx.run(
        //   INSERT.into(ShippingRequestErrors).entries({
        //     ID: cds.utils.uuid(),
        //     parent_ID: data?.ID,
        //     vcaErrorStatus: data.errorDescription,
        //     vcaErrorType: bundle.getText("Success"),
        //     wfInstanceId: "",
        //     vcaErrorTimeStamp: new Date()
        //   })
        // );

        updateFields.errorStatus = data.errorStatus;
        updateFields.errorDescription = data.errorDescription;
        // updateFields.wfInstanceId = "";
        // updateFields.creationDate = new Date();
        // updateFields.errorResolutionDate = new Date()
      }

      // if (data.documentType) updateFields.documentType = data.documentType;
      // if (data.legalEntity) updateFields.legalEntity = data.legalEntity;
      // if (data.documentYear) updateFields.documentYear = data.documentYear;
      // if (data.documentYear) updateFields.documentYear = data.documentYear;

      logger.info(`Updated feilds for Updating Entity Table document ${data?.ID}`, JSON.stringify(updateFields))

      if (Object.keys(updateFields).length === 0) {
        throw new Error(bundle.getText("NoUpdateFieldsProvided"));
      }

      const result = await tx.run(
        UPDATE(ShippingRequestEntityDocs)
          .set(updateFields)
          .where({ ID: data?.ID })
      );

      await INSERT.into(ShippingRequestErrors).entries({
        ID: cds.utils.uuid(),
        parent_ID: data?.ID,
        vcaErrorStatus: data.errorDescription,
        vcaErrorType: data.errorStatus,
        // wfInstanceId: data.wfInstanceId,
        vcaErrorTimeStamp: new Date()
      });

      if (result === 0) {
        throw new Error(bundle.getText("NoMatchingRecordFoundForUpdate"));
      }

      // Commit all the DB Transactions
      await tx.commit();

      return { ID: currentEntity?.ID };

    } catch (error) {
      logger.error(`Updating Entity Table document Failed for ${data?.ID}`, JSON.stringify(error))

      await tx.rollback()
      console.error("updateEntityTable error:", error);
      throw new Error(error.message || bundle.getText("UnexpectedError"));
    }
  },

  /**
 * Update error table and entity docs for a given ShippingRequestEntityDoc record.
 * 
 * - Updates `ShippingRequest.docFlowStateCheckStatus`
 * - Updates `ShippingRequestEntityDocs.errorStatus` & error details
 * - Inserts a record into `ShippingRequestErrors` if status != success
 * 
 * @param {Object} data - Payload with ID, errorStatus, errorDescription, wfInstanceId
 * @returns {Object} Result with updated entity ID
 */
  updateErrorTable: async (data, bundle) => {
    try {
      if (!data?.ID) {
        throw new Error(bundle.getText('IDIsMissing'));
      }

      // Fetch entity doc record
      const getEntity = await SELECT.one.from(ShippingRequestEntityDocs).where({ ID: data.ID });
      if (!getEntity) {
        throw new Error(bundle.getText('NoDataFound'));
      }

      // Update ShippingRequest header state
      const result1 = await UPDATE(ShippingRequest).set({
        docFlowStateCheckStatus: data.errorStatus || "",
        status: "Error"
      }).where({ ID: getEntity.parent_ID });

      // Update ShippingRequestEntityDocs with error details
      const result = await UPDATE(ShippingRequestEntityDocs).set({
        errorStatus: data.errorStatus,
        errorDescription: data.errorDescription,
        wfInstanceId: data.wfInstanceId,
        errorCreationDate: data.errorStatus?.toLowerCase() !== bundle.getText('success') ? new Date() : "",
        errorResolutionDate: data.errorStatus?.toLowerCase() === bundle.getText('success') ? new Date() : "",
      }).where({ ID: data.ID });

      // Insert into error table if failure
      if (data.errorStatus?.toLowerCase() !== bundle.getText('success')) {
        await INSERT.into(ShippingRequestErrors).entries({
          ID: cds.utils.uuid(),
          parent_ID: getEntity.ID,
          vcaErrorStatus: data.errorDescription,
          vcaErrorType: data.errorStatus,
          wfInstanceId: data.wfInstanceId,
          vcaErrorTimeStamp: new Date()
        });
      }

      if (result === 0 || result1 === 0) {
        throw new Error(bundle.getText('NoShippingRequestErrorFound'));
      }

      return { ID: getEntity.ID };
    } catch (error) {
      console.error(bundle.getText('UpdateErrorTableFailed'), error);
      throw error;
    }
  },

  /**
 * Update Product Flow Catalog Check (PFC Check)
 * Updates header, items, and entities for a ShippingRequest
 * @param {object} data - Payload with update information
 * @returns {Promise<object>} - Updated record reference { ID }
 */
  updatePFCCheck: async (data, bundle, req) => {

    if (!data?.ID) throw new Error(bundle.getText('IDIsMissing'));

    // Fetch existing children
    const getPreviousItems = await SELECT.from(ShippingRequestItem).where({ parent_ID: data?.ID });
    const getPreviousDocs = await SELECT.from(ShippingRequestEntityDocs).where({ parent_ID: data?.ID });

    // Fetch correct ship-to plant from PFC catalog (47419) to override SBPA payload
    let catalogShipToPlant = "";
    if (data.PfcCatId) {
      try {
        const pfcService = await cds.connect.to("pfcservice");
        const catalogHeaders = await pfcService.tx(req).post('/zbuvcm47419/getSinglePfcData', { CatId: data.PfcCatId });
        catalogShipToPlant = catalogHeaders?.value?.[0]?.PlantSTo || "";
        logger.info('Ship To plant value inside updatePFCCheck', catalogShipToPlant);
      } catch (err) {
        logger.warn(`PFC catalog lookup failed for ${data.PfcCatId}: ${err.message}`);
      }
    }

    // Build the header data
    const updatedHeaderData = {
      productFlowCatalogID: data.PfcCatId,
      productFlowID: data.ProdId,
      shipToPlant: catalogShipToPlant,
      items: [],
      entity: []
    };

    // Add material if not present
    const findMaterial = getPreviousItems.find(item => item.materialNumber === data.Matnr);
    if (!findMaterial && data.Matnr) {
      getPreviousItems.push({
        followOnDocumentNo: '',
        itemNo: data.itemNo,
        materialNumber: data.Matnr,
        materialType: '',
        materialBrand: data.MatBrand,
        materialDescription: '',
        quantity: '',
        uom: '',
        batchNumber: ''
      });
    }

    updatedHeaderData.items = getPreviousItems || [];
    updatedHeaderData.entity = getPreviousDocs || [];

    // --- Ship From
    if (data.BpSFrom || data.PlantSFrom || data.ErSFrom) {
      updatedHeaderData.entity.push({
        entityType: bundle.getText('ShipFrom'),
        entityRank: 0,
        documentSequence: -1,
        followOnDocumentNo: '',
        businessPartnerId: data.BpSFrom || '',
        plant: data.PlantSFrom || '',
        ecoRegion: data.ErSFrom || '',
        legalEntity: ''
      });
    }

    // --- Virtual Entities
    if (Array.isArray(data.VirtualEntity) && data.VirtualEntity.length > 0) {
      let count = 1;
      const sortedVirtualEntities = data.VirtualEntity.sort((a, b) => Number(a.SeqNo) - Number(b.SeqNo));

      for (const ve of sortedVirtualEntities) {
        updatedHeaderData.entity.push({
          entityType: `${bundle.getText('VirtualEntity')} ${count}`,
          entityRank: count,
          followOnDocumentNo: '',
          plant: ve.VirtualEntity || '',
          // businessPartnerId:ve.VE_BP||"",
          legalEntity: ve.legalEntity || '',
          documentSequence: -1
        });
        count++;
      }
    }

    // --- Ship To
    if (data.BpSTo || data.PlantSTo || data.ErSTo) {
      updatedHeaderData.entity.push({
        entityType: bundle.getText('ShipTo'),
        entityRank: updatedHeaderData.entity.filter(e => e.entityType.startsWith('Virtual')).length + 1,
        followOnDocumentNo: '',
        businessPartnerId: data.BpSTo || '',
        plant: data.PlantSTo || '',
        ecoRegion: data.ErSTo || '',
        legalEntity: '',
        documentSequence: -1
      });
    }

    // --- Update whole record with children
    const result = await UPDATE(ShippingRequest)
      .set(updatedHeaderData)
      .where({ ID: data?.ID });

    if (result === 0) throw new Error(`${bundle.getText('NoShippingRequestFoundWithID')} ${data?.ID}`);

    return { ID: data?.ID };
  },

  /**
* Update Steps in shippingRequestEntityDocs for a shippingRequest
* @param {object} data - Input payload from the request (IDs, steps, status, etc.)
* @param {object} req  - CAP request object (user, tx, error handling)
* @param {object} ZSD_VCM_PRODUCTFLOW - Remote service/destination for S/4 calls
 * @returns {{ message: string }} - Success message after scenario steps updated successfully
*/
  updateScenarioSteps: async (data, req, ZSD_VCM_PRODUCTFLOW, bundle) => {

    try {
      const parentID = data?.ID;
      if (!parentID) throw new Error(bundle.getText('IDIsMissing'));

      //  Get all existing docs for this parent
      const [existingDocs, shipingReq] = await Promise.all([
        SELECT.from(ShippingRequestEntityDocs).where({ parent_ID: parentID }),
        SELECT.one.from(ShippingRequest).where({ ID: parentID })
      ]);

      //  Cleanup temporary docs
      await DELETE.from(ShippingRequestEntityDocs).where({
        parent_ID: data?.ID,
        documentSequence: -1
      });

      let virtualEntities = [];

      //  Extract ShipFrom, ShipTo, and Virtual Entities
      for (let doc of existingDocs) {
        // here we are filtering Virtual Entities only
        if (doc.entityType !== "Ship From" && doc.entityType !== "Ship To") {

          //here exceptional docs will have no legalEntity and businessPartnerId
          // So whenever it finds any legalEntity or businness
          const existingVE = virtualEntities.find(
            ve => ve.entityType === doc.entityType && ve.plant === doc.plant?.trim()
            // && ve.businessPartnerId===doc.businessPartnerId?.trim()
          );
          virtualEntities.push({
            plant: doc.plant?.trim(),
            legalEntity: doc.legalEntity && doc.legalEntity.trim() !== ""
              ? doc.legalEntity
              : existingVE?.legalEntity || null,  // keep old value if exists
            entityType: doc.entityType,
            // businessPartnerId:doc.VirtualEntityBP?.trim()||""
          });
        }
      }

      // //  Collect unique ecoRegion codes
      // const ecoCodes = [
      //   shipFromData.ecoRegion,
      //   shipToData.ecoRegion
      // ].filter(Boolean); // remove null/undefined

      // const uniqueEcoCodes = [...new Set(ecoCodes)];

      // //  Call remote function with ecoCodes
      // let ecoRegions = [];
      // if (uniqueEcoCodes.length > 0) {
      //   ecoRegions = await pfcDest.tx(req).post('/zbuvcm47419/getEcoRegions', { codes: uniqueEcoCodes });
      // }

      // //  Create a lookup map for easy assignment
      // const ecoRegionMap = {};
      // for (let e of ecoRegions) {
      //   ecoRegionMap[e.EcoRegCode] = e.EcoRegName;
      // }

      // //  Assign ecoRegionName back to your objects
      // if (shipFromData.ecoRegion) {
      //   shipFromData.ecoRegionName = ecoRegionMap[shipFromData.ecoRegion] || "";
      // }
      // if (shipToData.ecoRegion) {
      //   shipToData.ecoRegionName = ecoRegionMap[shipToData.ecoRegion] || "";
      // }


      //  Collect unique Plants
      const plantSet = new Set();

      for (const ve of virtualEntities) {
        if (ve.plant) plantSet.add(ve.plant);
      }

      //  Single S/4 calls
      // let bpCountryKeyMassList = [];
      let plantCountryKeyMassList = [];

      //R2.2 Start
      if (plantSet.size) {
        plantCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(
          SELECT.from('Massplantbpcntrykey').where({ Plant: { in: [...plantSet] } })
        );
      }
      //R2.2 End
      // if (bpSet.size) {
      //   bpCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(
      //     SELECT.from('countrybpkey').where({ BusinessPartner: { in: [...bpSet] } })
      //   );
      // }

      //  Build lookup maps
      //R2.2 Start
      const bpMap = {};
      const plantToBpMap = {};
      const plantMap = {};
      plantCountryKeyMassList.forEach(p => { plantMap[p.Plant] = p.PlantName; });
      const bpList = [];
      let bpCountryKeyMassList = []
      for (const row of plantCountryKeyMassList) {
        if (row.BusinessPartner) {
          bpList.push(row.BusinessPartner)
          plantToBpMap[row.Plant] = row.BusinessPartner;
        }
      }
      if (bpList?.length) {
        bpCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(
          SELECT.from('countrybpkey').where({ BusinessPartner: { in: bpList } })
        );
      }
      bpCountryKeyMassList.forEach(b => { bpMap[b.BusinessPartner] = b.BusinessPartnerName; });
      //R2.2 End

      const allDocs = [];

      //  Build docs from steps
      for (let step of data.steps) {
        const baseDoc = {
          parent_ID: parentID,
          parent_shippingReqNo: data.shippingReqNo,
          parent_initialDocumentNo: data.initialDocumentNo,
          followOnDocumentNo: '',
          documentType: step.Steps,
          documentNumber: '',
          errorStatus: bundle.getText('Pending'),
          errorDescription: '',
          errorCreationDate: '',
          errorResolutionDate: '',
          documentSequence: step.Sequence,
          transactionDesc: step.transactionDesc || '',
          ecoRegion: '',
          businessPartnerId: '',
          plant: '',
          legalEntity: '',
          vcaAction: step.vcaAction,
          vcaDocSystem: step.vcaDocSystem,
          stepID: step.stepID,
          action: step.Action || ''
        };

        if (step.Entity === 'SF') {
          allDocs.push({
            ...baseDoc,
            ID: cds.utils.uuid(),
            entityType: bundle.getText('ShipFrom'),
            entityRank: 0,

            // ecoRegion: shipFromData?.ecoRegion || "",
            // ecoRegionName: shipFromData?.ecoRegionName || "",
            businessPartnerId: shipingReq.shipFromBusinessPartner || "",
            plant: shipingReq.shipFromPlant || "",
            bpName: shipingReq.shipFromBusinessPartnerName || "",
            plantName: shipingReq.shipFromPlantName || ""
          });
        } else if (step?.Entity?.startsWith('VE')) {
          let VE = parseInt(step?.Entity?.replace("VE", ""), 10);
          let findVE = virtualEntities?.find(ve => ve.entityType === `${bundle.getText('VirtualEntity')} ${VE}`);
          //R2.2 Start
          const bp = plantToBpMap[findVE?.plant] || "";
          //R2.2 End
          allDocs.push({
            ...baseDoc,
            ID: cds.utils.uuid(),
            entityType: `${bundle.getText('VirtualEntity')} ${VE}`,
            entityRank: VE,
            plant: findVE?.plant || "",
            plantName: plantMap[findVE?.plant] || "",
            //R2.2 Start
            businessPartnerId: bp,
            bpName: bpMap[bp] || "",
            //R2.2 End
            legalEntity: findVE?.legalEntity || ""

          });
        } else if (step.Entity === 'ST') {
          allDocs.push({
            ...baseDoc,
            ID: cds.utils.uuid(),
            entityType: bundle.getText('ShipTo'),
            entityRank: null,
            businessPartnerId: shipingReq.shipToBusinessPartner || "",
            bpName: shipingReq.shipToBusinessPartnerName || "",
            plant: shipingReq.shipToPlant || "",
            plantName: shipingReq.shipToPlantName || "",
            // ecoRegion: shipToData?.ecoRegion || "",
            // ecoRegionName: shipToData?.ecoRegionName || "",
          });
        }
      }

      //  Assign Ship To rank after last VE
      const distinctCount =
        new Set(virtualEntities.map(ve => ve.entityType)).size + 1;

      allDocs.forEach(doc => {
        if (doc.entityType === bundle.getText('ShipTo')) {
          doc.entityRank = distinctCount;
        }
      });


      let finalSteps = []

      let firstStep = allDocs.find(step => step.action === 'I/M' && step.documentSequence === 1)
      let stepCounter = 1
      if (firstStep) {
        finalSteps.push({
          ...firstStep,
          documentSequence: stepCounter
        })
        stepCounter++
      }

      let remaininDocs = allDocs
        .filter(step => step.action !== 'I/M' && step.documentSequence !== 1)
        .sort((a, b) => a.documentSequence - b.documentSequence);

      // exceptional docs to get here and update it sequence
      let filteredExistingDocs = existingDocs
        .filter(step => step.documentSequence !== -1)
        .sort((a, b) => a.documentSequence - b.documentSequence);

      if (filteredExistingDocs) {
        filteredExistingDocs.map((step) => {
          //R2.2 Start
          let bp = plantToBpMap[step.plant] || ""
          //R2.2 End
          finalSteps.push({
            ...step,
            entityRank: 1,
            documentSequence: stepCounter,
            //R2.2 Start
            businessPartnerId: plantToBpMap[step.plant] || "",
            bpName: bpMap[bp] || ""
            //R2.2 End
          })
          stepCounter++
        })

      }
      if (remaininDocs) {
        remaininDocs.map(step => {
          finalSteps.push({
            ...step,
            documentSequence: stepCounter
          })
          stepCounter++
        })
      }
      //removing exceptional from db because we are pushing existing docs o final steps anyhow
      if (filteredExistingDocs?.length) {
        await DELETE.from(ShippingRequestEntityDocs).where({
          parent_ID: parentID,
          isExceptionalDocument: true
        });
      }

      //  Insert all docs
      if (finalSteps?.length) {
        await INSERT.into(ShippingRequestEntityDocs).entries(finalSteps);
      }

      return { message: bundle.getText('ScenarioStepsUpdatedSuccessfully') };
    } catch (error) {
      console.error(error);
      throw error;
    }
  },


  /**
* Update Steps in shippingRequestEntityDocs for a shippingRequest
* @param {object} data - Input payload from the request (IDs, steps, status, etc.)
* @param {object} req  - CAP request object (user, tx, error handling)
* @param {object} ZSD_VCM_PRODUCTFLOW - Remote service/destination for S/4 calls
* @returns {{ message: string }} - Success message after scenario steps updated successfully
*/

  updateScenario3Steps: async (data, req, ZSD_VCM_PRODUCTFLOW, bundle) => {

    try {
      const parentID = data?.ID;
      if (!parentID) throw new Error(bundle.getText('IDIsMissing'));

      //  Get all existing docs for this parent
      const [existingDocs, shipingReq] = await Promise.all([
        SELECT.from(ShippingRequestEntityDocs).where({ parent_ID: parentID }),
        SELECT.one.from(ShippingRequest).where({ ID: parentID })
      ]);

      //  Cleanup temporary docs
      await DELETE.from(ShippingRequestEntityDocs).where({
        parent_ID: data?.ID,
        documentSequence: -1
      });

      let virtualEntities = [];

      //  Extract ShipFrom, ShipTo, and Virtual Entities
      for (let doc of existingDocs) {
        // here we are filtering Virtual Entities only
        if (doc.entityType !== "Ship From" && doc.entityType !== "Ship To") {

          //here exceptional docs will have no legalEntity and businessPartnerId
          // So whenever it finds any legalEntity or businness
          const existingVE = virtualEntities.find(
            ve => ve.entityType === doc.entityType && ve.plant === doc.plant?.trim()
            // && ve.businessPartnerId===doc.businessPartnerId?.trim()
          );
          virtualEntities.push({
            plant: doc.plant?.trim(),
            legalEntity: doc.legalEntity && doc.legalEntity.trim() !== ""
              ? doc.legalEntity
              : existingVE?.legalEntity || null,  // keep old value if exists
            entityType: doc.entityType,
            // businessPartnerId:doc.VirtualEntityBP?.trim()||""
          });
        }
      }

      // //  Collect unique ecoRegion codes
      // const ecoCodes = [
      //   shipFromData.ecoRegion,
      //   shipToData.ecoRegion
      // ].filter(Boolean); // remove null/undefined

      // const uniqueEcoCodes = [...new Set(ecoCodes)];

      // //  Call remote function with ecoCodes
      // let ecoRegions = [];
      // if (uniqueEcoCodes.length > 0) {
      //   ecoRegions = await pfcDest.tx(req).post('/zbuvcm47419/getEcoRegions', { codes: uniqueEcoCodes });
      // }

      // //  Create a lookup map for easy assignment
      // const ecoRegionMap = {};
      // for (let e of ecoRegions) {
      //   ecoRegionMap[e.EcoRegCode] = e.EcoRegName;
      // }

      // //  Assign ecoRegionName back to your objects
      // if (shipFromData.ecoRegion) {
      //   shipFromData.ecoRegionName = ecoRegionMap[shipFromData.ecoRegion] || "";
      // }
      // if (shipToData.ecoRegion) {
      //   shipToData.ecoRegionName = ecoRegionMap[shipToData.ecoRegion] || "";
      // }


      //  Collect unique Plants
      const plantSet = new Set();

      for (const ve of virtualEntities) {
        if (ve.plant) plantSet.add(ve.plant);
      }

      //  Single S/4 calls
      // let bpCountryKeyMassList = [];
      let plantCountryKeyMassList = [];

      //R2.2 Start
      if (plantSet.size) {
        plantCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(
          SELECT.from('Massplantbpcntrykey').where({ Plant: { in: [...plantSet] } })
        );
      }
      //R2.2 End
      // if (bpSet.size) {
      //   bpCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(
      //     SELECT.from('countrybpkey').where({ BusinessPartner: { in: [...bpSet] } })
      //   );
      // }

      //  Build lookup maps
      //R2.2 Start
      const bpMap = {};
      const plantToBpMap = {};
      const plantMap = {};
      plantCountryKeyMassList.forEach(p => { plantMap[p.Plant] = p.PlantName; });
      const bpList = [];
      let bpCountryKeyMassList = []
      for (const row of plantCountryKeyMassList) {
        if (row.BusinessPartner) {
          bpList.push(row.BusinessPartner)
          plantToBpMap[row.Plant] = row.BusinessPartner;
        }
      }
      if (bpList?.length) {
        bpCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(
          SELECT.from('countrybpkey').where({ BusinessPartner: { in: bpList } })
        );
      }
      bpCountryKeyMassList.forEach(b => { bpMap[b.BusinessPartner] = b.BusinessPartnerName; });
      //R2.2 End

      const allDocs = [];

      const ZSD_VCM_PREREQAPI = await cds.connect.to("ZSD_VCM_PREREQAPI");

      const legEntityData = await ZSD_VCM_PREREQAPI.tx(req).get(`/FetchT001K`);


      //  Build docs from steps
      for (let step of data.steps) {
        const baseDoc = {
          parent_ID: parentID,
          parent_shippingReqNo: data.shippingReqNo,
          parent_initialDocumentNo: data.initialDocumentNo,
          followOnDocumentNo: '',
          documentType: step.Steps,
          documentNumber: '',
          errorStatus: bundle.getText('Pending'),
          errorDescription: '',
          errorCreationDate: '',
          errorResolutionDate: '',
          documentSequence: step.Sequence,
          transactionDesc: step.transactionDesc || '',
          ecoRegion: '',
          businessPartnerId: '',
          plant: '',
          legalEntity: '',
          vcaAction: step.vcaAction,
          vcaDocSystem: step.vcaDocSystem,
          stepID: step.stepID,
          action: step.Action || ''
        };

        if (step.Entity === 'SF') {

          // const matchingLE = legEntityData.find(le => le.ValuationArea.trim() === shipingReq.shipToPlant?.trim());

          allDocs.push({
            ...baseDoc,
            ID: cds.utils.uuid(),
            entityType: bundle.getText('ShipFrom'),
            entityRank: 0,

            // ecoRegion: shipFromData?.ecoRegion || "",
            // ecoRegionName: shipFromData?.ecoRegionName || "",
            businessPartnerId: shipingReq.shipFromBusinessPartner || "",
            plant: shipingReq.shipFromPlant || "",
            bpName: shipingReq.shipFromBusinessPartnerName || "",
            plantName: shipingReq.shipFromPlantName || "",
            // legalEntity: matchingLE ? matchingLE.CompanyCode : ""
          });
        } else if (step?.Entity?.startsWith('VE')) {
          let VE = parseInt(step?.Entity?.replace("VE", ""), 10);
          let findVE = virtualEntities?.find(ve => ve.entityType === `${bundle.getText('VirtualEntity')} ${VE}`);
          //R2.2 Start
          const bp = plantToBpMap[findVE?.plant] || "";
          //R2.2 End
          allDocs.push({
            ...baseDoc,
            ID: cds.utils.uuid(),
            entityType: `${bundle.getText('VirtualEntity')} ${VE}`,
            entityRank: VE,
            plant: findVE?.plant || "",
            plantName: plantMap[findVE?.plant] || "",
            //R2.2 Start
            businessPartnerId: bp,
            bpName: bpMap[bp] || "",
            //R2.2 End
            legalEntity: findVE?.legalEntity || ""

          });
        } else if (step.Entity === 'ST') {
          const matchingLE = legEntityData.find(le => le.ValuationArea.trim() === shipingReq.shipToPlant?.trim());

          allDocs.push({
            ...baseDoc,
            ID: cds.utils.uuid(),
            entityType: bundle.getText('ShipTo'),
            entityRank: null,
            businessPartnerId: shipingReq.shipToBusinessPartner || "",
            bpName: shipingReq.shipToBusinessPartnerName || "",
            plant: shipingReq.shipToPlant || "",
            plantName: shipingReq.shipToPlantName || "",
            // ecoRegion: shipToData?.ecoRegion || "",
            // ecoRegionName: shipToData?.ecoRegionName || "",
            legalEntity: matchingLE ? matchingLE.CompanyCode : ""
          });
        }
      }

      //  Assign Ship To rank after last VE
      const distinctCount =
        new Set(virtualEntities.map(ve => ve.entityType)).size + 1;

      allDocs.forEach(doc => {
        if (doc.entityType === bundle.getText('ShipTo')) {
          doc.entityRank = distinctCount;
        }
      });


      let finalSteps = []

      let firstStep = allDocs.find(step => step.action === 'I/M' && step.documentSequence === 1)
      let stepCounter = 1
      if (firstStep) {
        finalSteps.push({
          ...firstStep,
          documentSequence: stepCounter
        })
        stepCounter++
      }

      let remaininDocs = allDocs
        // .filter(step => step.action !== 'I/M' && step.documentSequence !== 1)
        .sort((a, b) => a.documentSequence - b.documentSequence);

      // exceptional docs to get here and update it sequence
      let filteredExistingDocs = existingDocs
        .filter(step => step.documentSequence !== -1)
        .sort((a, b) => a.documentSequence - b.documentSequence);

      if (filteredExistingDocs) {
        filteredExistingDocs.map((step) => {
          //R2.2 Start
          let bp = plantToBpMap[step.plant] || ""
          //R2.2 End
          finalSteps.push({
            ...step,
            entityRank: 1,
            documentSequence: stepCounter,
            //R2.2 Start
            businessPartnerId: plantToBpMap[step.plant] || "",
            bpName: bpMap[bp] || ""
            //R2.2 End
          })
          stepCounter++
        })

      }
      if (remaininDocs) {
        remaininDocs.map(step => {
          finalSteps.push({
            ...step,
            documentSequence: stepCounter
          })
          stepCounter++
        })
      }
      //removing exceptional from db because we are pushing existing docs o final steps anyhow
      if (filteredExistingDocs?.length) {
        await DELETE.from(ShippingRequestEntityDocs).where({
          parent_ID: parentID,
          isExceptionalDocument: true
        });
      }

      //  Insert all docs
      if (finalSteps?.length) {

        const preparedSteps = finalSteps.map(step => ({
          ...step,
          documentNumber:
            // step.stepID === "ICPO"&& 
            step.action === "T"
              ? data.initialDocumentNo
              : step.documentNumber,
          errorStatus:
            // step.stepID === "ICPO"&& 
            step.action === "T" ? "Success" : step.errorStatus,
          errorDescription:
            // step.stepID === "ICPO"&& 
            step.action === "T" ? `Successfully Created ${step.documentType} - ${step.documentNumber}` : step.errorDescription,
          creationDate:
            // step.stepID === "ICPO"&& 
            step.action === "T" ? new Date() : step.creationDate
        }));


        await INSERT.into(ShippingRequestEntityDocs).entries(preparedSteps);

        let ICPO_doc = preparedSteps.find(doc =>
          // doc.stepID==="ICPO" && 
          doc.action === "T")

        if (ICPO_doc) {
          await INSERT.into(ShippingRequestErrors).entries({
            ID: cds.utils.uuid(),
            parent_ID: ICPO_doc?.ID,
            vcaErrorStatus: ICPO_doc.errorDescription,
            vcaErrorType: bundle.getText("Success"),
            wfInstanceId: "",
            vcaErrorTimeStamp: new Date()
          })
        }
      }

      return { message: bundle.getText('ScenarioStepsUpdatedSuccessfully') };
    } catch (error) {
      console.error(error);
      throw error;
    }
  },
  //Open Items JGHJ-87133 R2.2 change start
  asnCheck: async (data, req, bundle) => {
    const resObj = { messages: [], status: true };
    logger.info('Inside asnCheck');
    const tx = cds.tx(req);
    let parentID; let shippingReqNo, initialDocumentNo;
    try {
      const payload = data;
      const wfID = payload[0].wfID;
      const obd = payload[0].OBD.trim();
      const asnOrphanData = await module.exports.asnOrphanData(obd, req);
      if (asnOrphanData.length) {
        // Exclude current workflow
        const orphanWorkflows = asnOrphanData.filter(
          item => item.workflowID !== wfID
        );

        for (const workflow of orphanWorkflows) {
          // Update orphan record
          await module.exports.updateAsnOrphan(workflow.workflowID, wfID, req);

          // // Cancel old workflow instance
          // await InitiateWorkFLow(req, workflow.workflowID, 'cancelASN');
        }
      }
      // Fetch SO record first to obtain parentID for prerequisite check
      const soCheck = await tx.run(SELECT.one.from(ShippingRequestEntityDocs).where({ documentNumber: payload[0].ref_SO.trim() }));

      if (soCheck) {
        parentID = soCheck.parent_ID;
        shippingReqNo = soCheck.parent_shippingReqNo;
        initialDocumentNo = soCheck?.parent_initialDocumentNo;

        //Check 1: Prerequisite check - all docs before L_OBD must be successful before comparing with PO
        // Failure = prereqs not yet created: send email only, do not show in Error Logs (null initialDocumentNo)
        const shippingRequest = await tx.run(
          SELECT.one.from(ShippingRequestEntityDocs)
            .where({ parent_ID: parentID, stepID: constants.stepID_OBD })
        );

        if (!shippingRequest) {
          const message = bundle.getText('stepidErr');
          logger.warn(message);
          await module.exports.createAsnOrphan(payload[0], req, null, message);
          resObj.status = false;
          resObj.messages.push(message);
          return resObj;
        }

        const currentSeq = shippingRequest.documentSequence;
        const failedPrevious = await tx.run(
          SELECT.from(ShippingRequestEntityDocs)
            .where({
              errorStatus: { '!=': constants.successStatus },
              documentSequence: { '<': currentSeq },
              parent_ID: parentID,
              parent_shippingReqNo: shippingReqNo
            })
        );

        if (failedPrevious.length) {
          const message = bundle.getText('validationStatusCheck');
          logger.warn(message);
          await module.exports.createAsnOrphan(payload[0], req, null, message);
          resObj.status = false;
          resObj.messages.push(message);
          return resObj;
        }
      }

      //Check 2: SO check in DB (shows in Error Logs)
      if (!soCheck) {
        const message = bundle.getText('validationErrSOCheck');
        logger.warn(message);
        await module.exports.createAsnOrphan(payload[0], req, initialDocumentNo, message);
        resObj.status = false;
        resObj.messages.push(message);
        return resObj;
      }

      //Check 3: Check if item is active
      for (const element of payload) {
        const itemNo = element.itemNo.replace(/^0+/, '');
        const getItemData = await tx.run(SELECT.one.from(ShippingRequestItem).where({
          itemNo: itemNo,
          parent_ID: parentID,
          parent_shippingReqNo: shippingReqNo
        }));
        if (!getItemData || (getItemData.status !== constants.activeStatus)) {
          const message = bundle.getText('validationItemCheck', [itemNo]);
          logger.warn(message);
          resObj.status = false;
          resObj.messages.push(message);
        } else {
          //Check 4: Check the quantity table
          const shippingRequests = await tx.run(
            SELECT.from(ShippingRequestEntityDocs)
              .where(`
      parent_ID = '${parentID}'
      AND stepID = '${constants.stepID_OBD}'
      AND followOnDocumentNo IS NOT NULL
      AND TRIM(followOnDocumentNo) <> ''
    `)
          );
          const parentInitialDocumentNo =
            shippingRequests[0]?.parent_initialDocumentNo;
          const followOnDocNos = shippingRequests.map(
            item => item.followOnDocumentNo
          );
          let previousASNQty = 0;
          if (followOnDocNos.length > 0) {

            const followOnDocs = await tx.run(
              SELECT.from(ShippingRequestEntityFollowOnDocs).where({
                itemNo: itemNo,
                initialDocumentNo: parentInitialDocumentNo,
                followOnDocumentNo: { in: followOnDocNos }
              })
            );

            for (const doc of followOnDocs) {
              previousASNQty += parseInt(doc.quantity || 0);
            }
          }
          const allowedQty = parseInt(getItemData.quantity || 0);
          const currentASNQty = parseInt(element.quantity || 0);
          const totalQty = previousASNQty + currentASNQty;
          if (totalQty > allowedQty) {
            const message = bundle.getText('validationQuantityCheck', [itemNo]);
            logger.warn(message);
            resObj.status = false;
            resObj.messages.push(message);
          }
        }
      }
      if (resObj.messages.length > 0) {
        const allErrors = resObj.messages.join('\n');
        await module.exports.createAsnOrphan(payload[0], req, initialDocumentNo, allErrors);
      } else {
        // JGHJ-116504: Update legalEntity for all Legacy (L_) entity docs using portId from ASN payload
        const portId = payload[0].portId;
        if (portId) {
          await tx.run(
            UPDATE(ShippingRequestEntityDocs)
              .set({ legalEntity: portId })
              .where({ parent_ID: parentID, stepID: { like: 'L_%' } })
          );
          logger.info(`legalEntity updated to ${portId} for L_ docs of parent: ${parentID}`);
        }
        await module.exports.deleteAsnOrphan(payload[0].OBD, req);
      }
      return resObj;
    } catch (ex) {
      logger.error('Inside asnCheck catch', ex.message);
      await module.exports.createAsnOrphan(data[0], req, initialDocumentNo, ex.message);
      throw ex;
    }
  },

  //INSERT ASN Orphan data - only 1 entry per req
  createAsnOrphan: async (data, req, initialDocumentNo, message) => {
    logger.info('Inside ASN orphan Create');
    const tx = cds.tx(req);
    try {
      // Check if orphan already exists
      const existingOrphan = await tx.run(
        SELECT.one.from(asnOrphanDocs).where({
          legacyDocNum: data.OBD
        })
      );
      if (!existingOrphan) {
        await tx.run(INSERT.into(asnOrphanDocs).entries({
          legacyRefDocNum: data.ref_SO.trim(),
          legacyDocNum: data.OBD.trim(),
          workflowID: data.wfID,
          initialDocumentNo: initialDocumentNo || null,
          error: message || null
        }));
        logger.info(`ASN orphan created successfully for OBD: ${data.OBD}`);
      } else if (message) {
        // Update error on reprocessing failure so latest error is always stored
        await tx.run(UPDATE(asnOrphanDocs).set({ error: message, initialDocumentNo: initialDocumentNo }).where({ legacyDocNum: data.OBD }));
        logger.info(`ASN orphan error updated for OBD: ${data.OBD}`);
      }
    } catch (ex) {
      logger.error('Inside asn orphan create catch', ex.message);
      throw new Error(`Failed to create ASN Orphan: ${ex.message}`);
    }
  },


  //GET ASN orphan data
  asnOrphanData: async (obd, req) => {
    logger.info('Inside ASN orphan Read');
    const tx = cds.tx(req);
    try {
      if (obd !== '') {
        return await tx.run(
          SELECT.from(asnOrphanDocs).where({
            legacyDocNum: obd
          })
        );
      } else {
        return await tx.run(
          SELECT.from(asnOrphanDocs)
        );
      }
    } catch (ex) {
      logger.error('Inside asn orphan read catch', ex.message);
      throw new Error(`Failed to read ASN Orphan: ${ex.message}`);
    }
  },

  //DELETE ASN orphan data on successful processing
  deleteAsnOrphan: async (obd, req) => {
    logger.info('Inside ASN orphan Delete');
    const tx = cds.tx(req);
    try {
      await tx.run(DELETE.from(asnOrphanDocs).where({ legacyDocNum: obd }));
      logger.info(`ASN orphan deleted for OBD: ${obd}`);
    } catch (ex) {
      logger.error('Inside asn orphan delete catch', ex.message);
      throw new Error(`Failed to delete ASN Orphan: ${ex.message}`);
    }
  },

  //UPDATE ASN orphan data
  updateAsnOrphan: async (oldWfID, newWfID, req) => {
    logger.info('Inside ASN orphan Update');
    const tx = cds.tx(req);

    try {
      await tx.run(
        UPDATE(asnOrphanDocs).set({ workflowID: newWfID }).where({ workflowID: oldWfID })
      );
      logger.info(`ASN orphan updated: workflowID changed from ${oldWfID} to ${newWfID}`);
    } catch (ex) {
      logger.error('Inside asn orphan update catch', ex.message);
      throw new Error(`Failed to update ASN Orphan: ${ex.message}`);
    }
  },
  //Open Items JGHJ-87133 R2.2 change end

  processLegacyOutbound: async (data, req, bundle) => {
    const tx = cds.tx(req);
    let shippingRequest;

    try {
      const payload = data;

      if (!payload || payload.length === 0) {
        throw new Error('Payload is empty');
      }

      const ref_SO = payload[0].ref_SO;
      const OBD = payload[0].OBD;

      /* --------------------------------------------------
         0. Find Shipping Request
      -------------------------------------------------- */

      const getEntity = await tx.run(SELECT.one.from(ShippingRequestEntityDocs).where({ documentNumber: ref_SO }));


      if (!getEntity) {
        throw new Error(`Reference Purchase Order: ${ref_SO} not found in VCM!`)
      }

      let POStepIdtoLegacySO = getEntity?.stepID
      shippingRequest = await tx.run(
        SELECT.one.from(ShippingRequestEntityDocs).where({ documentNumber: ref_SO, stepID: POStepIdtoLegacySO })
      );

      if (!shippingRequest) {
        throw new Error('ShippingRequest not found for ref_SO ' + ref_SO);
      }

      const parentID = shippingRequest.parent_ID;
      const shippingReqNo = shippingRequest.parent_shippingReqNo;

      const removeLeadingZeros = (val) => {
        // if nothing comes → save empty string
        if (val === null || val === undefined || val === '') {
          return '';
        }

        const str = String(val);

        // remove leading zeros only
        return str.replace(/^0+/, '');
      };


      /* --------------------------------------------------
         1. Insert payload into FollowOn table
      -------------------------------------------------- */
      for (let i = 0; i < payload.length; i++) {
        const item = payload[i];

        await tx.run(
          INSERT.into(ShippingRequestEntityFollowOnDocs).entries({
            shippingReqNo,
            initialDocumentNo: shippingRequest.parent_initialDocumentNo,
            followOnDocumentNo: OBD,
            itemNo: removeLeadingZeros(item.itemNo),
            materialNumber: item.materialNumber,
            quantity: item.quantity,
            batchNumber: item.batch,
            uom: item.unit
          })
        );
      }

      /* --------------------------------------------------
         2. Fetch existing docs
      -------------------------------------------------- */
      const docs = await tx.run(
        SELECT.from(ShippingRequestEntityDocs)
          .where({ parent_ID: parentID })
          .orderBy('documentSequence')
      );

      await tx.run(
        UPDATE(ShippingRequestEntityDocs)
          .set({
            errorStatus: 'Waiting'
          })
          .where({
            parent_ID: parentID,
            action: { in: ['L', 'I', 'M'] },
            errorStatus: { '!=': bundle.getText("Success") }
          })
      );

      if (!docs || docs.length === 0) {
        throw new Error('No documents found');
      }

      /* --------------------------------------------------
         2A. Initialize STEP COUNTER (IMPORTANT)
      -------------------------------------------------- */
      // let stepCounter = docs[docs.length - 1].documentSequence || 0;

      /* --------------------------------------------------
         3. Find legacy doc and check followOn
      -------------------------------------------------- */
      let legacyDoc = null;
      let legacySeq = null;
      let hasFollowOn = false;

      for (let i = 0; i < docs.length; i++) {
        if (docs[i].followOnDocumentNo) {
          hasFollowOn = true;
        }

        if (docs[i].documentType === 'Legacy Outbound Delivery') {
          legacyDoc = docs[i];
          legacySeq = docs[i].documentSequence;
        }
      }

      if (!legacyDoc) {
        throw new Error('Legacy Outbound Delivery not found');
      }

      /* --------------------------------------------------
         4A. No followOnDocumentNo → UPDATE existing docs
      -------------------------------------------------- */
      if (!hasFollowOn) {

        // Update legacy document number
        await tx.run(
          UPDATE(ShippingRequestEntityDocs)
            .set({ documentNumber: OBD, followOnDocumentNo: OBD, errorStatus: bundle.getText("Success"), errorDescription: `Legacy Outbound Delivery created successfully -${OBD}`, creationDate: new Date(), errorCreationDate: null })
            .where({ ID: legacyDoc.ID })
        );

        await INSERT.into(ShippingRequestErrors).entries({
          ID: cds.utils.uuid(),
          parent_ID: legacyDoc.ID,
          vcaErrorStatus: `Legacy Outbound Delivery created successfully -${OBD}`,
          vcaErrorType: bundle.getText("Success"),
          wfInstanceId: "",
          vcaErrorTimeStamp: new Date()
        })


        // Update documents after legacy
        for (let i = 0; i < docs.length; i++) {
          if (docs[i].documentSequence > legacySeq) {
            await tx.run(
              UPDATE(ShippingRequestEntityDocs)
                .set({ followOnDocumentNo: OBD })
                .where({ ID: docs[i].ID })
            );
          }
        }
      }

      /* --------------------------------------------------
         4B. followOnDocumentNo exists → INSERT new docs
      -------------------------------------------------- */
      else {

        const existingFollowOn = await tx.run(
          SELECT.one
            .from(ShippingRequestEntityDocs)
            .where({
              parent_ID: parentID,
              followOnDocumentNo: OBD
            })
        );

        if (existingFollowOn) {
          throw new Error(
            `FollowOnDocumentNo ${OBD} already exists for this Shipping Request`
          );
        }

        const latestFollowOn = await tx.run(
          SELECT.one
            .from(ShippingRequestEntityDocs)
            .columns('followOnDocumentNo')
            .where({
              parent_ID: parentID,
              followOnDocumentNo: { '!=': null }
            })
            .orderBy({ ref: ['creationDate'], sort: 'desc' })
        );

        if (!latestFollowOn) {
          throw new Error('No previous followOnDocument set found');
        }

        const previousDocsSet = await tx.run(
          SELECT.from(ShippingRequestEntityDocs)
            .where({
              parent_ID: parentID,
              followOnDocumentNo: latestFollowOn.followOnDocumentNo
            })
            .orderBy('documentSequence')
        );

        function uniqueDocs(docs) {
          const map = new Map();

          for (const doc of docs) {

            // define logical uniqueness
            const key = [
              doc.documentType,
              doc.stepID,
              doc.action
            ].map(v => (v ?? '').toString().trim()).join('|');

            // keep FIRST occurrence only
            if (!map.has(key)) {
              map.set(key, doc);
            }
          }

          return Array.from(map.values());
        }

        // const uniquePreviousDocs = uniqueDocs(previousDocsSet);


        let newLegacyID = cds.utils.uuid();

        await tx.run(
          INSERT.into(ShippingRequestEntityDocs).entries({
            ...previousDocsSet.find(d => d.documentType === 'Legacy Outbound Delivery'),
            ID: newLegacyID,
            documentNumber: OBD,
            followOnDocumentNo: OBD,
            errorStatus: "Success",
            errorDescription: `Legacy Outbound Delivery created successfully -${OBD}`
          })
        );

        await INSERT.into(ShippingRequestErrors).entries({
          ID: cds.utils.uuid(),
          parent_ID: newLegacyID,
          vcaErrorStatus: `Legacy Outbound Delivery created successfully -${OBD}`,
          vcaErrorType: bundle.getText("Success"),
          wfInstanceId: "",
          vcaErrorTimeStamp: new Date()
        })

        /* ---- Create NEW docs after legacy ---- */
        // for (let i = 0; i < docs.length; i++) {
        //   if (docs[i].documentSequence > legacySeq) {

        //     // stepCounter++;
        //     const isWaitingAction = docs[i].action === 'L' || docs[i].action === 'I' || docs[i].action === 'M';

        //     await tx.run(
        //       INSERT.into(ShippingRequestEntityDocs).entries({
        //         ...docs[i],
        //         ID: cds.utils.uuid(),
        //         followOnDocumentNo: OBD,
        //         documentNumber: '',
        //         errorStatus: isWaitingAction ? 'Waiting' : 'Pending',
        //         errorDescription: '',
        //         errorCreationDate: null,
        //         errorResolutionDate: null
        //       })
        //     );
        //   }
        // }

        for (const doc of previousDocsSet) {

          if (doc.documentType === 'Legacy Outbound Delivery') continue;

          const isWaitingAction =
            doc.action === 'L' ||
            doc.action === 'I' ||
            doc.action === 'M';

          await tx.run(
            INSERT.into(ShippingRequestEntityDocs).entries({
              ...doc,
              ID: cds.utils.uuid(),
              followOnDocumentNo: OBD,
              documentNumber: '',
              errorStatus: isWaitingAction ? 'Waiting' : 'Pending',
              errorDescription: '',
              errorCreationDate: null,
              errorResolutionDate: null,
              creationDate: null
            })
          );

        }


        let ICPO = await tx.run(
          SELECT.one.from(ShippingRequestEntityDocs)
            .where({
              parent_ID: parentID,
              followOnDocumentNo: OBD,
              stepID: 'ICPO'
            })
        );
        if (ICPO && ICPO?.errorStatus === 'Pending') {
          await tx.run(
            UPDATE(ShippingRequestEntityDocs)
              .set({ documentNumber: ICPO?.parent_initialDocumentNo, errorStatus: "Success", errorResolutionDate: new Date() })
              .where({
                ID: ICPO?.ID,
                parent_ID: parentID,
                followOnDocumentNo: OBD,
                stepID: 'ICPO'
              })
          );
          await INSERT.into(ShippingRequestErrors).entries({
            ID: cds.utils.uuid(),
            parent_ID: ICPO.ID,
            vcaErrorStatus: "ICPO updated Successfully",
            vcaErrorType: bundle.getText("Success"),
            wfInstanceId: "",
            vcaErrorTimeStamp: new Date()
          })
        }
      }

      return {
        message: 'Legacy Outbound processing completed',
        ID: parentID,
        flag: constants.statusS
      };

    } catch (error) {
      //asn orphan insert logic
      await module.exports.createAsnOrphan(data[0], req, shippingRequest?.parent_initialDocumentNo, error.message);
      console.error(error);
      throw error;
    }
  },



  /**
   * Update Exceptional Documents
   * Inserts exceptional documents (steps) linked to a ShippingRequest.
   * @param {object} data - Payload containing ID of the ShippingRequest and steps to insert.
   * @param {string} data.ID - The parent ShippingRequest ID.
   * @param {Array<object>} data.steps - Array of step objects to insert.
   * @throws {Error} If ID is missing, not found, or steps array is invalid.
   * @returns {Promise<object>} - Returns the reference of the updated ShippingRequest { ID }.
   */
  updateExceptionalDocs: async (data, ZSD_VCM_PRODUCTFLOW, bundle) => {
    // this is updating only VE1 docs 2a,b,c docs
    if (!data?.ID) {
      throw new Error(bundle.getText('IDIsMissing'));
    }

    const getEntity = await SELECT.one.from(ShippingRequest).where({ ID: data.ID });

    if (!getEntity) {
      throw new Error(bundle.getText('NoDataFound'));
    }

    if (!Array.isArray(data.steps)) {
      throw new Error(bundle.getText('StepsDataIsMissingNotArray'));
    }
    const Plant = data.steps?.[0]?.plant;

    let plantName = "";
    if (Plant) {
      const result = await ZSD_VCM_PRODUCTFLOW.run(
        SELECT.one.from('countryplantkey').where({ Plant: Plant })
      );
      plantName = result?.PlantName || "";
    }
    const docsToInsert = data.steps.map(step => ({
      documentSequence: step.Sequence,
      documentType: step.transactionDesc,
      entityType: `${bundle.getText('VirtualEntity')} 1`,
      entityRank: 1,
      plant: step.plant || "",
      plantName: plantName,
      transactionDesc: step.transactionDesc,
      legalEntity: step.legalEntity || "",
      isAT: true,
      isExceptionalDocument: true,
      ID: cds.utils.uuid(),
      parent_ID: data?.ID,
      parent_shippingReqNo: getEntity.shippingReqNo,
      parent_initialDocumentNo: getEntity.initialDocumentNo,
      // errorStatus: step.status==="Active"?"Pending":"N/A",
      stepID: step.stepID

    }));

    await INSERT.into(ShippingRequestEntityDocs).entries(docsToInsert);

    return { ID: data.ID };
  },


  remanufacturingDocs: async (data, ZSD_VCM_PRODUCTFLOW, bundle) => {
    if (!data?.ID) throw new Error(bundle.getText('IDIsMissing'));

    const getEntity = await SELECT.one
      .from(ShippingRequest)
      .where({ ID: data.ID });

    if (!getEntity) throw new Error(bundle.getText('NoDataFound'));

    if (!Array.isArray(data.steps))
      throw new Error(bundle.getText('StepsDataIsMissingNotArray'));

    /* ---------------- STEP 1: Fetch existing docs ---------------- */
    const existingDocs = await SELECT
      .from(ShippingRequestEntityDocs)
      .where({ parent_ID: data.ID });

    await DELETE.from(ShippingRequestEntityDocs).where({ parent_ID: data.ID });

    const findVE1Doc = existingDocs.find(
      d => d.entityType === 'Virtual Entity 1'
    );

    let nextSeq = 1;
    const sortedExceptionalSteps = data.steps.sort((a, b) => Number(a.Sequence) - Number(b.Sequence))

    /* ---------------- STEP 3: New remanufacturing docs (START FROM 1) ---------------- */
    const docsToInsert = sortedExceptionalSteps.map(step => ({
      ID: cds.utils.uuid(),
      documentSequence: nextSeq++,
      documentType: step.transactionDesc,
      transactionDesc: step.transactionDesc,
      entityType: `${bundle.getText('VirtualEntity')} 1`,
      entityRank: 1,
      plant: step.plant || '',
      plantName: findVE1Doc?.plantName || '',
      legalEntity: findVE1Doc?.legalEntity || step.legalEntity || '',
      isAT: true,
      isExceptionalDocument: true,
      parent_ID: data.ID,
      parent_shippingReqNo: getEntity.shippingReqNo,
      parent_initialDocumentNo: getEntity.initialDocumentNo,
      errorStatus: step.status === 'Active' ? 'Pending' : 'N/A',
      stepID: step.stepID

    }));

    /* ---------------- STEP 4: Clone flash docs (NEXT SEQ) ---------------- */
    const flashDocsToClone = existingDocs
      .filter(d => d.isExceptionalDocument === false && d.isAT === false)
      .sort((a, b) => a.documentSequence - b.documentSequence);

    const newFlashDocs = flashDocsToClone.map(doc => ({
      ID: cds.utils.uuid(),
      documentSequence: nextSeq++,
      documentType: doc.documentType,
      transactionDesc: doc.transactionDesc || '',
      plant: doc.plant,
      plantName: doc.plantName,
      businessPartnerId: doc.businessPartnerId,
      bpName: doc.bpName,
      ecoRegion: doc.ecoRegion,
      ecoRegionName: doc.ecoRegionName,
      legalEntity: doc.legalEntity,
      isExceptionalDocument: doc.isExceptionalDocument,
      isAT: doc.isAT,
      entityType: doc.entityType,
      entityRank: doc.entityRank,
      parent_ID: data.ID,
      parent_shippingReqNo: getEntity.shippingReqNo,
      parent_initialDocumentNo: getEntity.initialDocumentNo,
      followOnDocumentNo: '',
      documentNumber: '',
      errorStatus: bundle.getText('Pending'),
      errorDescription: '',
      errorCreationDate: null,
      errorResolutionDate: null,
      stepID: doc.stepID,
      action: doc.action
    }));

    /* ---------------- STEP 5: Insert new docs ---------------- */

    const updatedExistingDocs = existingDocs
      .sort((a, b) => Number(a.documentSequence) - Number(b.documentSequence))
      .map(doc => ({
        ...doc,
        ID: cds.utils.uuid(), // create new UUIDs since old ones are deleted
        documentSequence: nextSeq++,
        errorStatus: "Inactive",
      }));

    // 5 Insert all new docs in order
    await INSERT.into(ShippingRequestEntityDocs).entries([
      ...docsToInsert,
      ...newFlashDocs,
      ...updatedExistingDocs
    ]);

    return { ID: data.ID };
  },


  retainBagDocs: async (data, bundle) => {

    if (!data?.ID) throw new Error(bundle.getText('IDIsMissing'));

    const getEntity = await SELECT.one
      .from(ShippingRequest)
      .where({ ID: data.ID });

    if (!getEntity) throw new Error(bundle.getText('NoDataFound'));

    if (data.steps?.length && !Array.isArray(data.steps)) {
      throw new Error(bundle.getText('StepsDataIsMissingNotArray'));
    }

    /* ---------------- 1. Fetch existing docs ---------------- */
    const existingDocs = await SELECT
      .from(ShippingRequestEntityDocs)
      .where({ parent_ID: data.ID });

    /* ---------------- 2. Delete existing ---------------- */
    await DELETE.from(ShippingRequestEntityDocs)
      .where({ parent_ID: data.ID });

    let nextSeq = 1;
    let docsToInsert = [];

    /* ============================================================
       PART A – Exceptional Docs (Only if withSteps = true)
    ============================================================ */

    if (data.steps?.length) {

      const findVE1Doc = existingDocs.find(
        d => d.entityType === 'Virtual Entity 1'
      );

      const sortedSteps = data.steps
        .sort((a, b) => Number(a.Sequence) - Number(b.Sequence));

      const exceptionalDocs = sortedSteps.map(step => ({
        ID: cds.utils.uuid(),
        documentSequence: nextSeq++,
        documentType: step.transactionDesc,
        transactionDesc: step.transactionDesc,
        entityType: `${bundle.getText('VirtualEntity')} 1`,
        entityRank: 1,
        plant: step.plant || '',
        plantName: findVE1Doc?.plantName || '',
        legalEntity: findVE1Doc?.legalEntity || step.legalEntity || '',
        isAT: true,
        isExceptionalDocument: true,
        parent_ID: data.ID,
        parent_shippingReqNo: getEntity.shippingReqNo,
        parent_initialDocumentNo: getEntity.initialDocumentNo,
        errorStatus: step.status === 'Active' ? 'Pending' : 'N/A',
        stepID: step.stepID,
        action: step.action || ''
      }));

      docsToInsert.push(...exceptionalDocs);
    }

    /* ============================================================
       PART B – Flash Docs (common for both flows)
    ============================================================ */

    const flashDocsToClone = existingDocs
      .filter(doc => !doc.isExceptionalDocument && !doc.isAT)
      .sort((a, b) => Number(a.documentSequence) - Number(b.documentSequence));

    const newFlashDocs = flashDocsToClone.map(doc => ({
      ID: cds.utils.uuid(),
      documentSequence: nextSeq++,
      documentType: doc.documentType,
      transactionDesc: doc.transactionDesc || '',
      plant: doc.plant,
      plantName: doc.plantName,
      businessPartnerId: doc.businessPartnerId,
      bpName: doc.bpName,
      ecoRegion: doc.ecoRegion,
      ecoRegionName: doc.ecoRegionName,
      legalEntity: doc.legalEntity,
      isExceptionalDocument: doc.isExceptionalDocument,
      isAT: doc.isAT,
      entityType: doc.entityType,
      entityRank: doc.entityRank,
      parent_ID: data.ID,
      parent_shippingReqNo: getEntity.shippingReqNo,
      parent_initialDocumentNo: getEntity.initialDocumentNo,
      followOnDocumentNo: '',
      documentNumber: '',
      errorStatus: bundle.getText('Pending'),
      errorDescription: '',
      errorCreationDate: null,
      errorResolutionDate: null,
      stepID: doc.stepID,
      action: doc.action || ''
    }));

    docsToInsert.push(...newFlashDocs);

    /* ============================================================
       PART C – Reinsert Old Docs as Inactive
    ============================================================ */

    const updatedExistingDocs = existingDocs
      .sort((a, b) => Number(a.documentSequence) - Number(b.documentSequence))
      .map(doc => ({
        ...doc,
        ID: cds.utils.uuid(),
        documentSequence: nextSeq++,
        errorStatus: "Inactive"
      }));

    docsToInsert.push(...updatedExistingDocs);

    /* ---------------- 3. Final Insert ---------------- */

    await INSERT.into(ShippingRequestEntityDocs)
      .entries(docsToInsert);

    return {
      ID: data.ID,
      totalInserted: docsToInsert.length
    };
  },

  // reprocessShippingRequest: async (req, data) => {

  //   const { shippingReqNo, initialDocumentNo, ID } = data;

  //   if (!ID || !shippingReqNo || !initialDocumentNo) {
  //     throw new Error('Missing required keys');
  //   }

  //   const { ShippingRequest, ShippingRequestEntityDocs } = cds.entities;

  //   const getShipingReq = await SELECT.one
  //     .from(ShippingRequest)
  //     .where({ ID, shippingReqNo, initialDocumentNo });

  //   if (!getShipingReq) {
  //     throw new Error(`Shipping Request not found ${ID}`);
  //   }

  //   // Case 1: Top-level errors
  //   const hasError =
  //     ["pfcCheckStatus", "masterDataStatus", "scenarioDeterminationStatus"]
  //       .some(status => getShipingReq[status] === "Error");

  //   if (hasError) {
  //     if (!getShipingReq.wfInstanceId) {
  //       throw new Error('Workflow Instance ID missing');
  //     }
  //     await InitiateWorkFLow(req, getShipingReq.wfInstanceId);
  //     return;
  //   }

  //   // Case 2: Entity Docs errors
  //   const entityDocs = await SELECT.from(ShippingRequestEntityDocs).where({
  //     parent_shippingReqNo: shippingReqNo,
  //     parent_initialDocumentNo: initialDocumentNo,
  //     parent_ID: ID
  //   });

  //   const errorDoc = entityDocs.find(doc => doc.errorStatus === "Error");

  //   if (!errorDoc) return;

  //   if (!errorDoc.wfInstanceId) {
  //     throw new Error(`Workflow Instance ID missing for Entity ${errorDoc.ID}`);
  //   }

  //   await InitiateWorkFLow(req, errorDoc.wfInstanceId);

  //   await UPDATE(ShippingRequestEntityDocs)
  //     .set({ errorStatus: "Retriggered" })
  //     .where({ ID: errorDoc.ID });
  //   if(errorDoc.ID==='2cb6e86b-1ec7-4806-8d40-acd75698250e'){
  //     console.log('ji')
  //   }
  //   await UPDATE(ShippingRequest)
  //     .set({
  //       status: "In Progress",
  //       docFlowStateCheckStatus: 'In Progress'
  //     })
  //     .where({ ID });
  // },


  // start - R2.2 Non VCA 76044
  createscashippingRequest: async (payload, bundle, ZSD_VCM_PRODUCTFLOW) => {
    if (!payload) throw new Error(bundle.getText('PayloadIsRequired'));

    const { ShippingRequest, ShippingRequestItem, ShippingRequestEntityDocs, NonVCAScenarioConfig } = cds.entities

    try {
      // Connect to DB and get next shipping request ID
      const db = await cds.connect.to('db');
      const dbConn = new dbClass(await dbClass.createConnection(db.options.credentials));

      const sp = await dbConn.loadProcedurePromisified(hdbext, null, 'nonvcagetshippingrequest');
      const output = await dbConn.callProcedurePromisified(sp, []);
      let seqNum = parseInt(output.results[0].ID, 10);

      const maxExisting = await SELECT.one.from(ShippingRequest)
        .columns('shippingReqNo')
        .where(`shippingReqNo like 'S%'`)
        .orderBy('shippingReqNo desc');

      if (maxExisting?.shippingReqNo) {
        const maxNum = parseInt(maxExisting.shippingReqNo.substring(1), 10);
        if (seqNum <= maxNum) {
          logger.warn(`Sequence behind manual inserts (seq: ${seqNum}, max in DB: ${maxNum}). Using ${maxNum + 1}.`);
          seqNum = maxNum + 1;
        }
      }

      const nextID = `S${seqNum}`;

      payload.shippingReqNo = nextID;
      logger.debug(bundle.getText('PayloadWithNewShippingReqNo'), payload);

      //  Collect unique BPs and Plants
      const bpSet = new Set();
      const plantSet = new Set();
      let isChargeBack = null

      if (payload?.shipFromBusinessPartner) bpSet.add(payload.shipFromBusinessPartner.trim());
      if (payload?.shipToBusinessPartner) bpSet.add(payload.shipToBusinessPartner.trim());

      if (payload?.shipFromPlant) plantSet.add(payload.shipFromPlant.trim());
      if (payload?.shipToPlant) plantSet.add(payload.shipToPlant.trim());
      if (payload?.soType) isChargeBack = payload?.soType;

      //  Single S/4 calls
      let bpCountryKeyMassList = [];
      let plantCountryKeyMassList = [];

      if (bpSet.size) {
        bpCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(
          SELECT.from('Massbpplantcntrykey').where({ BusinessPartner: { in: [...bpSet] } })
        );
      }
      if (plantSet.size) {
        plantCountryKeyMassList = await ZSD_VCM_PRODUCTFLOW.run(
          SELECT.from('Massplantbpcntrykey').where({ Plant: { in: [...plantSet] } })
        );
      }

      //  Build lookup maps
      const bpMap = {};
      bpCountryKeyMassList.forEach(b => { bpMap[b.BusinessPartner] = b.BusinessPartnerName; });

      const plantMap = {};
      plantCountryKeyMassList.forEach(p => { plantMap[p.Plant] = p.PlantName; });

      payload.shipFromBusinessPartnerName = bpMap[payload?.shipFromBusinessPartner] || "";
      payload.shipFromPlantName = plantMap[payload?.shipFromPlant] || "";
      payload.shipToBusinessPartnerName = bpMap[payload?.shipToBusinessPartner] || "";
      payload.shipToPlantName = plantMap[payload?.shipToPlant] || "";
      if (isChargeBack) {
        payload.scenarioID = isChargeBack === 'ZCR' ? 'Charge Back Credit' : 'Charge Back Debit';
      } else {
        payload.scenarioID = 'ASN';
      }



      // // Insert shipping request without items first
      await INSERT.into(ShippingRequest).entries({
        ...payload,
        items: [],
        entity: []
      });

      const items = payload.items || [];

      // materials needing S4 lookup
      const materialsToFetch = [
        ...new Set(
          items.map(i => String(i.materialNumber).trim())
        )
      ];
      let materialMap = new Map();

      if (materialsToFetch.length) {
        const materialData = await ZSD_VCM_PRODUCTFLOW.run(
          SELECT.from('Material').where({ Product: materialsToFetch })
        );

        // Build lookup map
        materialData.forEach(m => {
          materialMap.set(m.Product, {
            materialDescription: m.ProductName,
            materialType: m.ProductType
          });
        });
      }


      // Fetch the latest inserted shipping request
      const latestReq = await SELECT.one.from(ShippingRequest)
        .where({ userName: payload.userName })
        .orderBy('createdAt desc');

      if (!latestReq) throw new Error(bundle.getText('FailedToRetrieveTheLatestShippingRequest'));

      const shippingReqNo = latestReq.shippingReqNo;

      const itemsWithReqNo = (items || []).map(item => {
        const materialKey = item.materialNumber?.trim();
        const s4Data = materialMap.get(materialKey) || {};

        return {
          ...item,

          // populate only if missing
          materialDescription:
            item.materialDescription || s4Data.materialDescription,

          materialType:
            item.materialType || s4Data.materialType,

          parent_shippingReqNo: shippingReqNo,
          parent_ID: latestReq.ID,
          parent_initialDocumentNo: latestReq.initialDocumentNo
        };
      });

      if (itemsWithReqNo.length) {
        await INSERT.into(ShippingRequestItem).entries(itemsWithReqNo);
      }


      //Prepare & Insert DOCUMENTS (SAME PATTERN) 

      // Read scenario configuration
      let scenarioSteps = null
      let scenarioID = 'S1'
      if (isChargeBack) {
        scenarioID = isChargeBack === 'ZCR' ? 'S3' : 'S2';
        scenarioSteps = await cds.run(
          SELECT.from(NonVCAScenarioConfig).where({ scenarioID: scenarioID, process: 'CBACK' }).orderBy('sequence asc'));
      } else {
        let BeforeSTscenarioSteps = await cds.run(
          SELECT.from(NonVCAScenarioConfig).where({ scenarioID: scenarioID, process: 'ASN' }).orderBy('sequence asc'));

        scenarioSteps = BeforeSTscenarioSteps.map(step => {
          if (!step.stepID.includes("L_")) {
            step.plant = latestReq.shipToPlant,
              // JGHJ-89692
              step.entityType = 'Ship To'
            // JGHJ-89692

          }
          return step
        })
      }

      const documents = [];

      /* ---------------- HEADER DOCUMENTS ---------------- */

      for (const step of scenarioSteps) {
        documents.push({
          parent_shippingReqNo: shippingReqNo,
          parent_ID: latestReq.ID,
          parent_initialDocumentNo: latestReq.initialDocumentNo,
          documentType: step.step,
          stepID: step.stepID,
          documentSequence: step.sequence,
          errorStatus: 'Pending',
          action: step.action || '',
          entityType: step.entityType || null,
          plant: step.plant || ''
        });
      }

      documents.sort((a, b) => a.documentSequence - b.documentSequence);

      // 2. Update only matching records
      if (isChargeBack) {
        let soLegalEntity = '';
        let productionPlant = '';
        const SALESORDER = await cds.connect.to("ZAPI_SALES_ORDER_SRV");
        const response = await SALESORDER.run(
          SELECT.from('A_SalesOrderItem')
            .where({ SalesOrder: latestReq.initialDocumentNo })
        );
        if (response?.length) {
          productionPlant = response[0].ProductionPlant;
          logger.info(`Fetched production plant for SO ${latestReq.initialDocumentNo}: ${productionPlant}`);
          const ZSD_VCM_PREREQAPI = await cds.connect.to("ZSD_VCM_PREREQAPI");
          const legalEntityResponse = await ZSD_VCM_PREREQAPI.run(
            SELECT.from('FetchT001K')
              .where({ ValuationArea: `${productionPlant}` })
          );
          soLegalEntity = legalEntityResponse[0].CompanyCode;
        }

        //3. Setting the Trigger doc Document Number  
        documents.forEach(doc => {
          if (doc.stepID === "ICSO" && doc.action === "T") {
            doc.documentNumber = latestReq.initialDocumentNo;
            doc.errorStatus = "Success";
            doc.errorDescription = `Sales Order Created successfully - ${latestReq.initialDocumentNo}`;
            doc.creationDate = latestReq.createdAt;
            doc.legalEntity = soLegalEntity;
          }
        });

        if (documents.length) {

          // 4.  Inserting  records in   ShippingRequestEntityDocs Table 
          await INSERT.into(ShippingRequestEntityDocs).entries(documents);
          let ICSO_doc = await SELECT.one.from(ShippingRequestEntityDocs).where({
            action: "T",
            documentNumber: latestReq.initialDocumentNo
          })

          // 5.  Inserting deep records in   ShippingRequestErrors Table for first Document
          if (ICSO_doc) {
            await INSERT.into(ShippingRequestErrors).entries({
              ID: cds.utils.uuid(),
              parent_ID: ICSO_doc?.ID,
              vcaErrorStatus: ICSO_doc.errorDescription,
              vcaErrorType: bundle.getText("Success"),
              wfInstanceId: "",
              vcaErrorTimeStamp: new Date()
            })

          }
        }

      } else {
        let poLegalEntity = '';
        const PURCHASEORDER = await cds.connect.to("PURCHASEORDER");
        const response = await PURCHASEORDER.run(
          SELECT.from('PurchaseOrder')
            .where({ PurchaseOrder: latestReq.initialDocumentNo })
        );
        if (response?.length) {
          poLegalEntity = response[0]?.CompanyCode;
        }
        logger.info(`Fetched legal entity for PO ${latestReq.initialDocumentNo}: ${poLegalEntity}`);
        documents.forEach(async doc => {
          if (doc.stepID === "ICPO" && doc.action === "T") {

            doc.documentNumber = latestReq.initialDocumentNo;
            doc.errorStatus = "Success";
            doc.errorDescription = `Purchase Order Created Successfully - ${latestReq.initialDocumentNo}`;
            doc.creationDate = latestReq.createdAt;
            doc.legalEntity = poLegalEntity;
          }
          // Defect JGHJ-86311
          // if (!doc.stepID?.includes('L_') && latestReq.initialDocumentType === 'Purchase Order') {
          //   doc.legalEntity = '';
          // }
        });

        if (documents.length) {

          await INSERT.into(ShippingRequestEntityDocs).entries(documents);

          let ICPO_doc = await SELECT.one.from(ShippingRequestEntityDocs).where({
            action: "T",
            documentNumber: latestReq.initialDocumentNo
          })
          //let ICPO_doc=documents.find(doc=>doc.stepID==="ICPO" && doc.action==="T")

          if (ICPO_doc) {
            await INSERT.into(ShippingRequestErrors).entries({
              ID: cds.utils.uuid(),
              parent_ID: ICPO_doc?.ID,
              vcaErrorStatus: ICPO_doc.errorDescription,
              vcaErrorType: bundle.getText("Success"),
              wfInstanceId: "",
              vcaErrorTimeStamp: new Date()
            })
          }

        }
      }


      // 3. Insert


      return { ID: latestReq.ID, shippingReqNo };

    } catch (err) {
      logger.error(bundle.getText('ErrorIncreatescashippingRequest'), err);
      throw err;
    }
  },

  //End - R2.2 Non VCA 76044

  //  GR Batch Job Processing

  runGRBatchJob: async (bundle, req) => {
    const { ShippingRequestEntityDocs, ShippingRequestEntityFollowOnDocs } = cds.entities;
    try {
      // Fetch TAVARC table from constants service and filter IC step IDs in-memory
      const VCM_CONSTANTS_CAP = await cds.connect.to("VCM_CONSTANTS_CAP");
      const tvarcData = await VCM_CONSTANTS_CAP.tx(req).send('GET', '/zbuvcm55154/TAVARC');
      const icStepIDs = (tvarcData?.value || [])
        .filter(row => row.VarName === 'BATCHJOB_DOCTYPE')
        .map(row => row.Low)
        .filter(Boolean);
      logger.info(`IC step IDs fetched: ${icStepIDs}`);
      const icStepIDCondition = icStepIDs.map(id => `stepID = '${id}'`).join(' OR ');

      //  Fetch all GR records that are eligible for processing
      const grRecords = await SELECT.from(ShippingRequestEntityDocs)
        .where(`
   stepID = '${constants.GR}'
   AND errorStatus = '${constants.Waiting}'
   AND action = '${constants.I}'
   AND (
     documentNumber IS NULL
     OR documentNumber = ''
   )

`);
      if (!grRecords || grRecords.length === 0) {
        logger.info(constants.NoValidGRRecordsarepresent);
        return constants.NoValidGRRecordsarepresent;
      }
      logger.info(`GR Batch Job started → Total records: ${grRecords.length}`);
      // payload for OData service
      const { headerEntries, idMapping } = await (async () => {
        const results = (await Promise.all(grRecords.map(async rec => {
          const { ID, parent_initialDocumentNo, followOnDocumentNo } = rec;
          // Fetch corresponding IBD record
          const ibdRecord = await SELECT.one.from(ShippingRequestEntityDocs)
            .where({ stepID: constants.IBD, followOnDocumentNo, });
          // Extract inbound delivery document number
          const inboundDelivery = ibdRecord?.documentNumber ?? "";

          //Defect JGHJ-107546 Start //
          const legalEntity = ibdRecord?.legalEntity ?? "";
          //Fetching the ICPO or ICFPO record using dynamic step IDs from constant table
          const legalEntityCondition = legalEntity ? `AND legalEntity = '${legalEntity}'` : '';
          const icpoRecord = await SELECT.one.from(ShippingRequestEntityDocs)
            .where(`
              (${icStepIDCondition})
              AND parent_initialDocumentNo = '${parent_initialDocumentNo}'
              ${legalEntityCondition}
            `);
          const ICPONumber = icpoRecord?.documentNumber ?? "";
          // Defect JGHJ-107546 End //

          // Skip records where no IC PO found
          if (!ICPONumber) {
            logger.info(`No IC PO found for PO: ${parent_initialDocumentNo}, legalEntity: ${legalEntity}, skipping GR record: ${ID}`);
            return null;
          }

          // Fetching Purchase Order Item from follow-on table
          const followOnData = await SELECT.one.from(ShippingRequestEntityFollowOnDocs)
            .columns(constants.itemNo)
            .where({ followOnDocumentNo });
          const purchaseOrderItem = String(followOnData?.itemNo ?? "");
          // Returning header for OData payload and mapping for DB update later
          return {
            header: {
              PurchaseDummy: "",
              PurchaseOrder: ICPONumber,
              PurchaseOrderItem: purchaseOrderItem.replace(/^0+/, ''),
              GoodsMovementType: constants.value,
              DeliveryDocument: inboundDelivery || '',
              MaterialDocument: ""
            },
            // Mapping to link response back to DB records
            mapping: {
              ID,
              PurchaseOrder: ICPONumber,
              PurchaseOrderItem: purchaseOrderItem,
              DeliveryDocument: inboundDelivery
            }
          };
        }))).filter(r => r !== null);
        // Separate headers and mapping arrays
        return {
          headerEntries: results.map(r => r.header),
          idMapping: results.map(r => r.mapping),
        };
      })();
      // Final payload sent to OData service
      const payload = {
        PurchaseDummy: "",
        _header: headerEntries
      };
      const ZSD_VCM_AUTOMATIONFLW = await cds.connect.to(constants.ZSD_VCM_AUTOMATIONFLW);
      // calling external ODATA service
      const response = await ZSD_VCM_AUTOMATIONFLW.tx().post(constants.BatchGR, payload);
      logger.info(response);
      // Filter successful records
      const validEntries = (response?._header || []).filter(
        entry => entry.MaterialDocument !== ''
      );
      logger.info(
        `Valid response records: ${validEntries.length}`
      );
      //Normalizing the Po Item
      const normalize = (val) => {
        const cleaned = String(val || "").replace(/^0+/, '');
        return cleaned === "" ? "0" : cleaned;
      };
      //Prepare updates
      const updates = validEntries.map(entry => {
        const match = idMapping.find(m =>
          m.PurchaseOrder === entry.PurchaseOrder &&
          normalize(m.PurchaseOrderItem) === normalize(entry.PurchaseOrderItem) &&
          m.DeliveryDocument === entry.DeliveryDocument
        );
        if (match) {
          // Combine CreationDate and CreationTime from S4 into a single timestamp
          const grCreationDateTime = entry.CreationDate && entry.CreationTime
            ? new Date(`${entry.CreationDate}T${entry.CreationTime}`)
            : new Date();
          return {
            ID: match.ID,
            documentNumber: entry.MaterialDocument,
            creationDate: grCreationDateTime,
            documentYear: entry.MaterialDocumentYear
          };
        }
        return null;
      }).filter(Boolean);

      //  Update HANA DB with valid records
      if (updates.length > 0) {
        await Promise.all(
          updates.map(row =>
            UPDATE(ShippingRequestEntityDocs)
              .set({
                documentNumber: row.documentNumber,
                errorStatus: constants.errorStatus,
                errorDescription: constants.errordescription + row.documentNumber,
                creationDate: row.creationDate,
                documentYear: row.documentYear
              })
              .where({
                ID: row.ID
              })
          )
        );
        logger.info(`Updated ${updates.length} records successfully in HANA DB`);
        await module.exports.checkAndUpdateHeaderStatus(grRecords.map(r => r.parent_ID));
        return `${constants.updated} ${updates.length} ${constants.recordsuccessfull}`
      } else {
        logger.info(`No successful GR updates found: ${validEntries.length} records sent from S4`);
        return `${constants.Nogrfound} ${validEntries.length} ${constants.recordsfromS4}`
      }

      // Error handling
    } catch (error) {
      logger.error(`Batch Job Failed: ${error.message}`);
      throw error;
    }
  },

  // AP Invoice Batch:
  async runAPInvoiceBatchJob(options = {}) {

    const { req, ShippingRequestEntityDocs, ShippingRequestEntityFollowOnDocs } = options;

    try {

      const VCM_CONSTANTS_CAP = await cds.connect.to("VCM_CONSTANTS_CAP");

      // Fetch TAVARC table from constants service and filter IC step IDs in-memory
      const tvarcData = await VCM_CONSTANTS_CAP.tx(req).send('GET', '/zbuvcm55154/TAVARC');
      //let responsee = await VCM_CONSTANTS_CAP.tx(req).get('/zbuvcm55154/FetchDoctype');
      const icStepIDs = (tvarcData?.value || [])
        .filter(row => row.VarName === 'BATCHJOB_DOCTYPE')
        .map(row => row.Low)
        .filter(Boolean);
      logger.info(`IC step IDs fetched: ${icStepIDs}`);
      const icStepIDCondition = icStepIDs.map(id => `stepID = '${id}'`).join(' OR ');

      // Step 1: Fetch API Records

      const records = await SELECT.from(ShippingRequestEntityDocs)
        .where(`
   stepID = '${constants.API}'
   AND errorStatus = '${constants.Waiting}'
   AND action = '${constants.I}'
   AND (
     documentNumber IS NULL
     OR documentNumber = ''

   )
`);

      // Step 2: Build payload + mapping only for valid PO records
      const filteredRecordsNested = await Promise.all(

        records.map(async rec => {

          const followOnDoc = rec.followOnDocumentNo;
          const initialPoNumber = rec.parent_initialDocumentNo;
          const legalEntity = rec.legalEntity;
          const ShippingReqno = rec.parent_shippingReqNo;

          // Fetch ALL PO Items
          const itemData = await SELECT
            .from(ShippingRequestEntityFollowOnDocs)
            .where({
              followOnDocumentNo: followOnDoc
              //shippingReqNo: ShippingReqno
            });

          logger.info("itemData length", itemData.length);

          // Fetch Intercompany PO
          const OriginalPONumber = await SELECT.one
            .from(ShippingRequestEntityDocs)
            .where(`
              (${icStepIDCondition})
              AND parent_shippingReqNo = '${ShippingReqno}'
              AND legalEntity = '${legalEntity}'
            `);

          // Skip if no Intercompany PO found
          if (!OriginalPONumber?.documentNumber) {
            return [];
          }

          const OrgPoNumber = OriginalPONumber.documentNumber;

          // LOOP ALL ITEMS
          return itemData.map(item => {

            const itemNumber = String(item?.itemNo ?? "")
              .replace(/^0+/, '');

            const RefQuantity = Number(item?.quantity ?? 0);

            return {

              header: {
                AP_Dummy: "",
                AssignmentReference: "",
                AccountingDocument: "",
                PurchaseOrder: OrgPoNumber,
                ReferenceQuan: RefQuantity,
                ReferenceUnit: "",
                PurchaseOrderItem: itemNumber,
                CompanyCode: legalEntity
              },

              mapping: {
                ID: rec.ID,
                PurchaseOrder: OrgPoNumber,
                PurchaseOrderItem: itemNumber,
                legalEntity: legalEntity,
                TriggeringPo: initialPoNumber,
                followOnDoc: followOnDoc,
                ReferenceQuan: RefQuantity
              }

            };

          });

        })

      );

      // Flatten array
      // const filteredRecords = filteredRecordsNested.flat();

      // Remove null records
      const validFilteredRecords = filteredRecordsNested.flat();  //filteredRecords.filter(Boolean);

      // Check after filtering only
      if (!validFilteredRecords.length) {

        return {
          message: constants.NoAPrecord
        };

      }

      logger.info(
        `AP Batch Job started → Total valid records: ${validFilteredRecords.length}`
      );

      const headerEntries = validFilteredRecords.map(r => r.header);

      const idMapping = validFilteredRecords.map(r => r.mapping);

      // Step 3: API call
      const APInvoiceBatch = await cds.connect.to(constants.ZSD_VCM_AUTOMATIONFLW);

      const payload = {
        AP_Dummy: "",
        _header: headerEntries
      };

      logger.info("Payload Details", payload);

      const response = await APInvoiceBatch.tx().post(constants.BatchAP, payload);

      logger.info("Response:", JSON.stringify(response));

      // Step 4: Normalize response
      const resultArray =
        response?.value ||
        response?.d?.results ||
        response?._header ||
        [];

      // Step 5: Filter valid records
      const validEntries = resultArray.filter(
        entry => entry.AccountingDocument
      );

      logger.info(`Valid AP records: ${validEntries.length}`);

      // Step 6: Matching
      const updates = await Promise.all(

        validEntries.map(async entry => {

          const match = idMapping.find(m =>

            m.PurchaseOrder === entry.PurchaseOrder &&
            m.PurchaseOrderItem === entry.PurchaseOrderItem &&
            m.legalEntity === entry.CompanyCode &&
            m.ReferenceQuan === entry.ReferenceQuan

          );

          if (match) {

            // Step 1 : Get PO Items and Quantities
            const AR_POITEMS = await SELECT
              .from(ShippingRequestEntityFollowOnDocs)
              .where({
                followOnDocumentNo: match.followOnDoc
              });

            logger.info("AR_POITEMS", AR_POITEMS);

            // Step 2 : Get All AR Invoice Records
            const LegacyARInvoices = await SELECT
              .from(ShippingRequestEntityDocs)
              .where(`
          parent_initialDocumentNo = '${match.TriggeringPo}'
          AND followOnDocumentNo = '${match.followOnDoc}'
          AND errorStatus = '${constants.Waiting}'
          AND stepID = '${constants.L_ARI}'
          AND action = '${constants.I}'
          AND (
              documentNumber IS NULL
              OR documentNumber = ''
          )
      `);

            logger.info("LegacyARInvoices", LegacyARInvoices);

            // Handle AP-only scenario
            if (LegacyARInvoices.length === 0) {
              return [{
                AP_ID: match.ID,
                // AR_ID: null,
                documentNumber: entry.AccountingDocument,
                lastchangedatetime: entry.lastchangedatetime,
                AssignmentReference: entry.AssignmentReference,
                documentYear: entry.FiscalYear || ''
              }];
            }

            // Step 3 : Map AR IDs with PO Items
            return LegacyARInvoices.map((invoice, index) => ({

              // AP Invoice Update
              AP_ID: match.ID,

              // AR Invoice Update
              AR_ID: invoice.ID,

              // PO Item Details
              itemNo: AR_POITEMS[index]?.itemNo || "",
              quantity: AR_POITEMS[index]?.quantity || "",

              // Update Fields
              documentNumber: entry.AccountingDocument,
              lastchangedatetime: entry.lastchangedatetime,
              AssignmentReference: entry.AssignmentReference,
              documentYear: entry.FiscalYear || ''

            }));
          }

          return null;

        })

      ).then(results => results.flat().filter(Boolean));

      // Step 7: Bulk Update
      if (updates.length > 0) {

        const filteredUpdates = (  //Checking whether AP document already exists:
          await Promise.all(
            updates.map(async (row) => {

              const existingAPDoc = await SELECT.one
                .from(ShippingRequestEntityDocs)
                .where(`
                        documentNumber = '${row.documentNumber}'
                        and ID != '${row.AP_ID}'
                    `);

              if (existingAPDoc) {
                logger.info(`AP Document ${row.documentNumber} already exists. Skipping update.`);
                return null;
              }
              return row;
            })
          )
        ).filter(Boolean);

        await Promise.all(

          filteredUpdates.flatMap(row => {    // updates

            const updatePromises = [];

            // AP Invoice Update
            updatePromises.push(

              UPDATE(ShippingRequestEntityDocs)
                .set({
                  documentNumber: row.documentNumber,
                  errorStatus: constants.errorStatus,
                  errorDescription:
                    constants.errordescriptionAP + row.documentNumber,
                  creationDate: row.lastchangedatetime,
                  documentYear: row.documentYear
                })
                .where({
                  ID: row.AP_ID
                })

            );
            // AR Invoice Update
            if (row.AR_ID) {

              updatePromises.push(

                UPDATE(ShippingRequestEntityDocs)
                  .set({
                    documentNumber: row.AssignmentReference,
                    errorStatus: constants.errorStatus,
                    errorDescription:
                      constants.errordescriptionAR +
                      row.AssignmentReference,
                    creationDate: row.lastchangedatetime,
                    documentYear: row.documentYear
                  })
                  .where({
                    ID: row.AR_ID
                  })
              );

            }
            return updatePromises;
          })
        );
        logger.info(
          `Updated ${updates.length} AP and AR records successfully in HANA DB`
        );
        await module.exports.checkAndUpdateHeaderStatus(records.map(r => r.parent_ID));
        return `${constants.updated} ${updates.length} ${constants.recordsuccessfull}`;
      } else {

        logger.info(
          `No successful AP updates found: ${validEntries.length} records sent from S4`
        );
        return `${constants.NoAPfound} ${validEntries.length} ${constants.recordsfromS4}`;
      }

    } catch (error) {

      logger.error(`Batch Job Failed: ${error.message}`);

      throw error;

    }

  },

  // Defect JGHJ-86311
  async updateLegalEntity(stepID, documentNumber) {
    let poLegalEntity = '';
    let soLegalEntity = '';
    let deliveryLegalEntity = '';
    let apLegalEntity = '';
    let arLegalEntity = '';
    let grLegalEntity = '';
    if (stepID === "ICPO" || stepID === "R_ICPO") {
      try {
        const PURCHASEORDER = await cds.connect.to("PURCHASEORDER");
        const response = await PURCHASEORDER.run(
          SELECT.from('PurchaseOrder')
            .where({ PurchaseOrder: documentNumber })
        );
        if (response?.length) {
          poLegalEntity = response[0]?.CompanyCode;
        }
        logger.info(`Fetched legal entity for PO ${documentNumber}: ${poLegalEntity}`);
      } catch (err) {
        logger.error(`Error fetching purchase order details: ${err.message}`);
      }
      return poLegalEntity;
    }
    if (stepID === "ICSO") {
      try {
        let productionPlant = '';
        const SALESORDER = await cds.connect.to("ZAPI_SALES_ORDER_SRV");
        const response = await SALESORDER.run(
          SELECT.from('A_SalesOrderItem')
            .where({ SalesOrder: documentNumber })
        );
        if (response?.length) {
          productionPlant = response[0].ProductionPlant;
          logger.info(`Fetched production plant for SO ${documentNumber}: ${productionPlant}`);
          const ZSD_VCM_PREREQAPI = await cds.connect.to("ZSD_VCM_PREREQAPI");
          const legalEntityResponse = await ZSD_VCM_PREREQAPI.run(
            SELECT.from('FetchT001K')
              .where({ ValuationArea: `${productionPlant}` })
          );
          soLegalEntity = legalEntityResponse[0].CompanyCode;
        }
        logger.info(`Fetched legal entity for SO ${documentNumber}: ${soLegalEntity}`);
      } catch (err) {
        logger.error(`Error fetching sales order details: ${err.message}`);
      }
      return soLegalEntity;
    }
    if (stepID === "IBD" || stepID === "OBD") {
      try {
        let plant = '';
        const DELIVERY = await cds.connect.to("ZAPI_OUTBOUND_DELIVERY_SRV");
        const response = await DELIVERY.run(
          SELECT.from('A_OutbDeliveryItem')
            .where({ DeliveryDocument: documentNumber })
        );
        if (response?.length) {
          plant = response[0].Plant;
          logger.info(`Fetched plant for Delivery ${documentNumber}: ${plant}`);
          const ZSD_VCM_PREREQAPI = await cds.connect.to("ZSD_VCM_PREREQAPI");
          const delLegalEntityResponse = await ZSD_VCM_PREREQAPI.run(
            SELECT.from('FetchT001K')
              .where({ ValuationArea: `${plant}` })
          );
          deliveryLegalEntity = delLegalEntityResponse[0].CompanyCode;
        }
        logger.info(`Fetched legal entity for Delivery ${documentNumber}: ${deliveryLegalEntity}`);
      } catch (err) {
        logger.error(`Error fetching delivery document details: ${err.message}`);
      }
      return deliveryLegalEntity;
    }
    if (stepID === "API") {
      try {
        const APINVOICE = await cds.connect.to("ZAPI_SUPPLIERINVOICE_PROCESS_SRV");
        const response = await APINVOICE.run(
          SELECT.from("A_SupplierInvoice")
            .where({ SupplierInvoice: documentNumber })
        );
        if (response?.length) {
          apLegalEntity = response[0].CompanyCode;
        }
        logger.info(`Fetched legal entity for AP Invoice ${documentNumber}: ${apLegalEntity}`);
      } catch (err) {
        logger.error(`Error fetching AP invoice details: ${err.message}`);
      }
      return apLegalEntity;
    }
    if (stepID === "ARI") {
      try {
        const ARINVOICE = await cds.connect.to('ZAPI_BILLING_DOCUMENT_SRV1')
        const response = await ARINVOICE.run(
          SELECT.from('A_BillingDocument')
            .where({ BillingDocument: documentNumber })
        );
        logger.info(
          `ARI Response: ${JSON.stringify(response)}`
        );
        if (response?.length) {
          arLegalEntity = response[0].CompanyCode;
        }
        logger.info(`Fetched legal entity for AR Invoice ${documentNumber}: ${arLegalEntity}`);
      } catch (err) {
        logger.error(`Error fetching AR invoice details: ${err.message}`);
      }
      return arLegalEntity;
    }
    if (stepID === "GR") {
      try {
        let plant = '';
        const GRINVOICE = await cds.connect.to("ZAPI_MATERIAL_DOCUMENT_SRV");
        const response = await GRINVOICE.run(
          SELECT.from('A_MaterialDocumentItem')
            .where({ MaterialDocument: documentNumber })
        );
        if (response?.length) {
          plant = response[0].Plant || '';
          logger.info(`Fetched plant for GR ${documentNumber}: ${plant}`);
          const ZSD_VCM_PREREQAPI = await cds.connect.to("ZSD_VCM_PREREQAPI");
          const grLegalEntityResponse = await ZSD_VCM_PREREQAPI.run(
            SELECT.from('FetchT001K')
              .where({ ValuationArea: `${plant}` })
          );
          grLegalEntity = grLegalEntityResponse[0].CompanyCode;
        }
        logger.info(`Fetched legal entity for GR ${documentNumber}: ${grLegalEntity}`);
      } catch (err) {
        logger.error(`Error fetching goods receipt details: ${err.message}`);
      }
      return grLegalEntity;
    }
  },

  async checkAndUpdateHeaderStatus(parentIDs) {
    const uniqueIDs = [...new Set(parentIDs.filter(Boolean))];
    await Promise.all(uniqueIDs.map(async (parentId) => {

      const activeDocs = await SELECT.from(ShippingRequestEntityDocs)
       .where(`parent_ID = '${parentId}' AND errorStatus NOT IN ('Inactive', 'N/A')`);
 
      const allDocsSuccess = activeDocs.length > 0 && activeDocs.every(d => d.errorStatus === 'Success');

      if (allDocsSuccess) {
        await UPDATE(ShippingRequest)
          .set({ status: 'Completed', docFlowStateCheckStatus: 'Success' })
          .where({ ID: parentId });
        logger.info(`Header status updated to Completed for ShippingRequest ID: ${parentId}`);
      }
    }));
  }
}
