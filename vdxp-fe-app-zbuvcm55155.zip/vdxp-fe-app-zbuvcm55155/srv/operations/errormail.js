'use strict';
const cds = require('@sap/cds');
const logger = cds.log('vcm55155-program');
const constants = require('../config/constants');
const servicejs = require('../zbuvcm55155service');


// SEND ASN EMAIL
  async function sendASNMail(req, data, messages, type){
    logger.info('Inside sendASNMail');
    try {
      const emailBody = await module.exports.getASNEmailBody(data, messages, type);
      const dlList = await module.exports.fetchDLlist( req );
      const subject = type === 'VALIDATION_ERROR' ? `ASN Validation Failed - ${data[0]?.OBD || ''}`: `ASN Technical Error - ${data[0]?.OBD || ''}`;
      const emailPayload = {
        Email_Body: emailBody,
        Email_Subject: subject,
        Email_Recipients: dlList
      };

      await module.exports.callCPI( emailPayload );
      logger.info( 'ASN mail sent successfully');
    } catch (error) {
      logger.error('Error in sendASNMail',error.message);
    }
  }

  // GENERATE EMAIL BODY FOR ASN ORPHAN RECORDS
  async function getASNEmailBody(data, messages, type) {
    let html = [];
    html.push('<html>');
    html.push('<body>');
    html.push(`<p>Dear Team,</p>`);
    if (type === 'VALIDATION_ERROR') {
      html.push(`<p> ASN validation failed and orphan record created. </p> `);
    } else {
      html.push(` <p> Technical error occurred during ASN processing. </p>`);
    }

    // ERROR DETAILS
    html.push(` <h3>Error Details</h3>`);
    html.push('<ul>');
    for (const msg of messages) {
      html.push(`<li>${msg}</li> `);
    }
    html.push('</ul>');

    // ASN TABLE 
    html.push(` <h3>ASN Details</h3>`);
    html.push(`<table border="1" style=" border-collapse: collapse; width: 100%; " > `);
    html.push(`<tr> 
               <th>Workflow ID</th>
               <th>SO Number</th>
               <th>OBD</th>
               <th>Item No</th>
               <th>Quantity</th>
               </tr> `);

    for (const item of data) {
      html.push(` <tr>
                  <td>${item.wfID || ''}</td>
                  <td>${item.ref_SO || ''}</td>
                  <td>${item.OBD || ''}</td>
                  <td>${item.itemNo || ''}</td>
                  <td>${item.quantity || ''}</td>
                 </tr> `);
    }
    html.push('</table>');
    html.push(`<br> <p> Please review ASN orphan records. </p> `);
    html.push('</body>');
    html.push('</html>');
    return Buffer.from(html.join('\n'), 'utf-8').toString('base64');
  }

  // FETCH DL LIST
  async function fetchDLlist(req) {
    logger.info('Inside fetchDLlist');
    const tx = cds.tx(req);
    try {
      const dlData = await tx.run(SELECT.from("JNJ_COM_ZBUVCM55155_EMAILNOTIFY").where({ TYPE: constants.VCM }));
            const emails = [];
      for (const row of dlData) {
        if (row.EMAIL) {
          emails.push(...row.EMAIL.split(','));
        }
      }
      return [
        ...new Set(
          emails.map(
            item => item.trim()
          )
        )
      ].join(',');

    } catch (error) {
      logger.error('Error fetching DL list',
        error.message);
      throw error;
    }
  }

  // CPI CALL
  async function callCPI(emailPayload) {
    logger.info('Inside callCPI');
    try {
      const destApi = await cds.connect.to( constants.CPI_EMAIL_DESTINATION );
      const response = await destApi.send({
         method: 'POST',
         path: constants.CPI_DESTPATH,
         data: emailPayload,
         responseType: 'text',
          headers: { 'Content-Type': 'application/json', 'Accept': '*/*'}
        });

      logger.info( 'CPI Response', response );
      return response;
    } catch (error) {
      logger.error('Error during CPI call',error.message);
      throw error;
    }
  }

  module.exports = {callCPI, getASNEmailBody, fetchDLlist, sendASNMail};