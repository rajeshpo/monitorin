/* checksum : 62b0deed6d15d4dc08239d2d69ab4ad0 */
@cds.external : true
@m.IsDefaultEntityContainer : 'true'
@sap.message.scope.supported : 'true'
@sap.supported.formats : 'atom json xlsx'
service ZAPI_SALES_ORDER_SRV {
  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Sales Order Header'
  entity A_SalesOrder {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order Type'
    SalesOrderType : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Organization'
    SalesOrganization : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Distribution Channel'
    DistributionChannel : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Division'
    OrganizationDivision : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Group'
    SalesGroup : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Office'
    SalesOffice : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales District'
    SalesDistrict : String(6);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sold-to Party'
    SoldToParty : String(10);
    @sap.display.format : 'Date'
    @sap.label : 'Created On'
    @sap.quickinfo : 'Record Creation Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CreationDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Created By'
    @sap.quickinfo : 'Name of Person Responsible for Creating the Object'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CreatedByUser : String(12);
    @sap.display.format : 'Date'
    @sap.label : 'Changed On'
    @sap.quickinfo : 'Last Changed On'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    LastChangeDate : Date;
    @sap.label : 'Ext. Bus. Syst. ID'
    @sap.quickinfo : 'External Business System ID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    SenderBusinessSystemName : String(60);
    @sap.display.format : 'UpperCase'
    @sap.label : 'External Document ID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ExternalDocumentID : String(40);
    @odata.Type : 'Edm.DateTimeOffset'
    @odata.Precision : 7
    @sap.label : 'Time Stamp'
    @sap.quickinfo : 'UTC Time Stamp in Long Form (YYYYMMDDhhmmssmmmuuun)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    LastChangeDateTime : Timestamp;
    @odata.Type : 'Edm.DateTimeOffset'
    @odata.Precision : 7
    @sap.label : 'External Revision'
    @sap.quickinfo : 'Timestamp for Revision of External Calls'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ExternalDocLastChangeDateTime : Timestamp;
    @sap.label : 'Customer Reference'
    PurchaseOrderByCustomer : String(35);
    @sap.label : 'Customer Reference'
    @sap.quickinfo : 'Ship-to Party''s Customer Reference'
    PurchaseOrderByShipToParty : String(35);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Purchase Order Type'
    @sap.quickinfo : 'Customer Purchase Order Type'
    CustomerPurchaseOrderType : String(4);
    @sap.display.format : 'Date'
    @sap.label : 'Customer Ref. Date'
    @sap.quickinfo : 'Customer Reference Date'
    CustomerPurchaseOrderDate : Date;
    @sap.display.format : 'Date'
    @sap.label : 'Document Date'
    @sap.quickinfo : 'Document Date (Date Received/Sent)'
    SalesOrderDate : Date;
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Net Value'
    @sap.quickinfo : 'Net Value of the Sales Document in Document Currency'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    TotalNetAmount : Decimal(16, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Delivery Status'
    @sap.quickinfo : 'Delivery Status (All Items)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    OverallDeliveryStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Overall Block Status'
    @sap.quickinfo : 'Overall Block Status (Header)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    TotalBlockStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Order-Related Billing Status'
    @sap.quickinfo : 'Order-Related Billing Status (All Items)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    OverallOrdReltdBillgStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Reference Status'
    @sap.quickinfo : 'Reference Status (All Items)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    OverallSDDocReferenceStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Document Currency'
    @sap.quickinfo : 'SD Document Currency'
    @sap.semantics : 'currency-code'
    TransactionCurrency : String(5);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Order Reason'
    @sap.quickinfo : 'Order Reason (Reason for the Business Transaction)'
    SDDocumentReason : String(3);
    @sap.display.format : 'Date'
    @sap.label : 'Pricing Date'
    @sap.quickinfo : 'Date for Pricing and Exchange Rate'
    PricingDate : Date;
    @sap.label : 'Exchange Rate'
    @sap.quickinfo : 'Exchange Rate for Price Determination'
    PriceDetnExchangeRate : Decimal(9, 5);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Bill. Plan No.'
    @sap.quickinfo : 'Billing Plan Number / Invoicing Plan Number'
    BillingPlan : String(10);
    @sap.display.format : 'Date'
    @sap.label : 'Requested Delivery Date'
    RequestedDeliveryDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Shipping Conditions'
    ShippingCondition : String(2);
    @sap.label : 'Complete Delivery'
    @sap.quickinfo : 'Complete Delivery Defined for Each Sales Order'
    CompleteDeliveryIsDefined : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Shipping Type'
    ShippingType : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Block'
    @sap.quickinfo : 'Billing Block in SD Document'
    HeaderBillingBlockReason : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Delivery Block'
    @sap.quickinfo : 'Delivery Block (Document Header)'
    DeliveryBlockReason : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Deliv Date Rule'
    @sap.quickinfo : 'Delivery Date Rule'
    DeliveryDateTypeRule : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Incoterms'
    @sap.quickinfo : 'Incoterms (Part 1)'
    IncotermsClassification : String(3);
    @sap.label : 'Incoterms (Part 2)'
    IncotermsTransferLocation : String(28);
    @sap.label : 'Incoterms Location 1'
    IncotermsLocation1 : String(70);
    @sap.label : 'Incoterms Location 2'
    IncotermsLocation2 : String(70);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Incoterms Version'
    IncotermsVersion : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Price Group'
    CustomerPriceGroup : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Price List Type'
    PriceListType : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Terms of Payment'
    @sap.quickinfo : 'Terms of Payment Key'
    CustomerPaymentTerms : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Payment Method'
    PaymentMethod : String(1);
    @sap.display.format : 'Date'
    @sap.label : 'Fixed Value Date'
    FixedValueDate : Date;
    @sap.label : 'Assignment'
    @sap.quickinfo : 'Assignment Number'
    AssignmentReference : String(18);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Reference Document'
    @sap.quickinfo : 'Document Number of Reference Document'
    ReferenceSDDocument : String(10);
    @sap.label : 'Preceding Doc.Categ.'
    @sap.quickinfo : 'Document Category of Preceding SD Document'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ReferenceSDDocumentCategory : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Reference'
    @sap.quickinfo : 'Reference Document Number'
    AccountingDocExternalReference : String(16);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Acct Assmt Grp Cust.'
    @sap.quickinfo : 'Account Assignment Group for Customer'
    CustomerAccountAssignmentGroup : String(2);
    @sap.label : 'Exchng. Rate Accntg.'
    @sap.quickinfo : 'Exchange Rate for Postings to Financial Accounting'
    AccountingExchangeRate : Decimal(9, 5);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Group'
    CustomerGroup : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Group 1'
    AdditionalCustomerGroup1 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Group 2'
    AdditionalCustomerGroup2 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Group 3'
    AdditionalCustomerGroup3 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Group 4'
    AdditionalCustomerGroup4 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Group 5'
    AdditionalCustomerGroup5 : String(3);
    @sap.label : 'Relevant for POD'
    @sap.quickinfo : 'Relevant for POD processing'
    SlsDocIsRlvtForProofOfDeliv : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Alt.Tax Classific.'
    @sap.quickinfo : 'Alternative Tax Classification'
    CustomerTaxClassification1 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Class.2 Customer'
    @sap.quickinfo : 'Tax Classification 2 for Customer'
    CustomerTaxClassification2 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Class.3 Customer'
    @sap.quickinfo : 'Tax Classification 3 for Customer'
    CustomerTaxClassification3 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Class.4 Customer'
    @sap.quickinfo : 'Tax Classification 4 for Customer'
    CustomerTaxClassification4 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Class.5 Customer'
    @sap.quickinfo : 'Tax Classification 5 for Customer'
    CustomerTaxClassification5 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Class.6 Customer'
    @sap.quickinfo : 'Tax Classification 6 for Customer'
    CustomerTaxClassification6 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Class.7 Customer'
    @sap.quickinfo : 'Tax Classification 7 for Customer'
    CustomerTaxClassification7 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Class.8 Customer'
    @sap.quickinfo : 'Tax Classification 8 for Customer'
    CustomerTaxClassification8 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Class.9 Customer'
    @sap.quickinfo : 'Tax Classification 9 for Customer'
    CustomerTaxClassification9 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Departure C/R'
    @sap.quickinfo : 'Tax Departure Country/Region'
    TaxDepartureCountry : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Dest. Ctry/Reg.'
    @sap.quickinfo : 'Tax Destination Country/Region'
    VATRegistrationCountry : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Approval Request Reason'
    @sap.quickinfo : 'Approval Request Reason ID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    SalesOrderApprovalReason : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Approval Status'
    @sap.quickinfo : 'Document Approval Status'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    SalesDocApprovalStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Overall Status'
    @sap.quickinfo : 'Overall Processing Status (Header/All Items)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    OverallSDProcessStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Credit Status'
    @sap.quickinfo : 'Overall Status of Credit Checks'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    TotalCreditCheckStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Ovrl Delivery Status'
    @sap.quickinfo : 'Overall Delivery Status (All Items)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    OverallTotalDeliveryStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Rejection Status'
    @sap.quickinfo : 'Rejection Status (All Items)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    OverallSDDocumentRejectionSts : String(1);
    @sap.display.format : 'Date'
    @sap.label : 'Billing Date'
    BillingDocumentDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Contract Account'
    @sap.quickinfo : 'Contract Account Number'
    ContractAccount : String(12);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Addit. Value Days'
    @sap.quickinfo : 'Additional Value Days'
    AdditionalValueDays : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Supplement'
    @sap.quickinfo : 'Purchase order number supplement'
    CustomerPurchaseOrderSuplmnt : String(4);
    @sap.display.format : 'Date'
    @sap.label : 'Serv. Rendered Date'
    @sap.quickinfo : 'Date on which services are rendered'
    ServicesRenderedDate : Date;
    @sap.label : 'Protocol ID'
    ICSMProtocolID : String(30);
    @sap.display.format : 'Date'
    @sap.label : 'CS Order form Date'
    ZZ1_DEAFormDate_SDH : Date;
    @sap.label : 'Supplier CS Lic Num'
    @sap.quickinfo : 'Supplier CS License Number'
    ZZ1_SupplierDEANumber_SDH : String(10);
    @sap.label : 'CS Order form Number'
    ZZ1_DEAForm222Number_SDH : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Class Of Trade'
    ZZ1_ClasOfTrade_SDH : String(10);
    @sap.label : 'Receiver BOP'
    ZZ1_ControlSubStateLNo_SDH : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Ship to Party'
    ZZ1_SignaturePCship_SDH : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Signature Partner'
    ZZ1_SignaturePCsign_SDH : String(10);
    @sap.label : 'Receiver CS Lic Num'
    ZZ1_ReceiverDEANumb_SDH : String(10);
    @sap.label : 'Supplier BOP'
    ZZ1_SupplierBOP_SDH : String(10);
    @sap.label : 'GLN Number'
    ZZ1_GLNumber_SDH : String(20);
    to_BillingPlan : Association to A_SalesOrderBillingPlan {  };
    to_Item : Association to many A_SalesOrderItem {  };
    to_Partner : Association to many A_SalesOrderHeaderPartner {  };
    to_PaymentPlanItemDetails : Association to many A_SlsOrdPaymentPlanItemDetails {  };
    to_PrecedingProcFlowDoc : Association to many A_SalesOrderPrecdgProcFlow {  };
    to_PricingElement : Association to many A_SalesOrderHeaderPrElement {  };
    to_RelatedObject : Association to many A_SalesOrderRelatedObject {  };
    to_SubsequentProcFlowDoc : Association to many A_SalesOrderSubsqntProcFlow {  };
    to_Text : Association to many A_SalesOrderText {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Header Billing Plan'
  entity A_SalesOrderBillingPlan {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Bill. Plan No.'
    @sap.quickinfo : 'Billing/Invoicing Plan Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key BillingPlan : String(10) not null;
    @sap.display.format : 'Date'
    @sap.label : 'Start Date'
    @sap.quickinfo : 'Start Date of Billing/Invoicing Plan'
    BillingPlanStartDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Origin of Start Date'
    @sap.quickinfo : 'Rule for Origin of Start Date of Billing/Invoicing Plan'
    BillingPlanStartDateRule : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Reference'
    @sap.quickinfo : 'Reference Billing Plan Number / Invoicing Plan Number'
    ReferenceBillingPlan : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Category'
    @sap.quickinfo : 'Billing plan category'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanCategory : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Plan Type'
    @sap.quickinfo : 'Billing/Invoicing Plan Type'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanType : String(2);
    @sap.display.format : 'Date'
    @sap.label : 'End Date'
    @sap.quickinfo : 'End Date of Billing/Invoicing Plan'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanEndDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Origin End Date'
    @sap.quickinfo : 'Rule for Origin of End Date for Billing/Invoicing Plan'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanEndDateRule : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Search term'
    @sap.quickinfo : 'Sort field'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanSearchTerm : String(10);
    to_BillingPlanItem : Association to many A_SalesOrderBillingPlanItem {  };
    to_SalesOrder : Association to A_SalesOrder {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Header Billing Plan Item'
  entity A_SalesOrderBillingPlanItem {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Bill. Plan No.'
    @sap.quickinfo : 'Billing/Invoicing Plan Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key BillingPlan : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item'
    @sap.quickinfo : 'Item for billing plan/invoice plan/payment cards'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key BillingPlanItem : String(6) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Date Category'
    BillingPlanDateCategory : String(2);
    @sap.display.format : 'Date'
    @sap.label : 'Billing Date'
    BillingPlanBillingDate : Date;
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Billing Value'
    @sap.quickinfo : 'Value to be billed/calc. on date in billing/invoice plan'
    BillingPlanAmount : Decimal(16, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Currency'
    @sap.quickinfo : 'Currency Key'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'currency-code'
    TransactionCurrency : String(5);
    @sap.label : 'Invoice Percentage'
    @sap.quickinfo : 'Percentage of value to be invoiced'
    BillingPlanAmountPercent : Decimal(5, 2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Terms of Payment'
    @sap.quickinfo : 'Terms of Payment Key'
    CustomerPaymentTerms : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Type'
    @sap.quickinfo : 'Proposed Billing Type for an Order-Related Billing Document'
    ProposedBillingDocumentType : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Date Description'
    BillingPlanDateDescriptionCode : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Block'
    @sap.quickinfo : 'Billing Block for Billing/Invoicing Plan Date'
    BillingBlockReason : String(2);
    @sap.display.format : 'Date'
    @sap.label : 'Settlement Start Date'
    @sap.quickinfo : 'Settlement Start Date of Billing/Invoicing Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanServiceStartDate : Date;
    @sap.display.format : 'Date'
    @sap.label : 'Settlement End Date'
    @sap.quickinfo : 'Settlement End Date of Billing/Invoicing Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanServiceEndDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Status'
    @sap.quickinfo : 'Billing Status for Billing/Invoicing Plan Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanRelatedBillgStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Plan Type'
    @sap.quickinfo : 'Billing/Invoicing Plan Type'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanType : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Fixed Date'
    @sap.quickinfo : 'ID for Adopting Billing/Invoicing Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    AdoptingBillingDateID : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Rule'
    @sap.quickinfo : 'Rule in billing plan/invoice plan'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanBillingRule : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Usage'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanMilestoneUsage : String(5);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Correction Date'
    @sap.quickinfo : 'Indicator for Correction Date in Billing Plan'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillgPlnDteCorrectionRfndType : String(1);
    @sap.label : 'Accounting Exchange Rate'
    @sap.quickinfo : 'Exchange Rate for FI Postings'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    AccountingExchangeRate : Decimal(9, 5);
    @sap.label : 'Reason'
    @sap.quickinfo : 'Reason for Postponement'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PostponementReason : String(255);
    to_BillingPlan : Association to A_SalesOrderBillingPlan {  };
    to_SalesOrder : Association to A_SalesOrder {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Header Partner'
  entity A_SalesOrderHeaderPartner {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Partner Function'
    key PartnerFunction : String(2) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Partner Function'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PartnerFunctionInternalCode : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer'
    @sap.quickinfo : 'Customer Number'
    Customer : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Supplier'
    @sap.quickinfo : 'Account Number of Supplier'
    Supplier : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Personnel Number'
    Personnel : String(8);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Contact Person'
    @sap.quickinfo : 'Number of Contact Person'
    ContactPerson : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Business Partner'
    @sap.quickinfo : 'Business Partner Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ReferenceBusinessPartner : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Address Number'
    AddressID : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'VAT Registration No.'
    @sap.quickinfo : 'VAT Registration Number'
    VATRegistration : String(20);
    to_Address : Association to many A_SalesOrderPartnerAddress {  };
    to_SalesOrder : Association to A_SalesOrder {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Header Pricing Element'
  entity A_SalesOrderHeaderPrElement {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Step Number'
    key PricingProcedureStep : String(3) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Counter'
    @sap.quickinfo : 'Condition Counter'
    key PricingProcedureCounter : String(3) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition Type'
    ConditionType : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Valid From'
    @sap.quickinfo : 'Timestamp for Pricing'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PricingDateTime : String(14);
    @sap.display.format : 'Date'
    @sap.label : 'Cndn Pricing Date'
    @sap.quickinfo : 'Condition Pricing Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PriceConditionDeterminationDte : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Calculation Type'
    @sap.quickinfo : 'Calculation Type for Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionCalculationType : String(3);
    @sap.label : 'Condition Basis'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionBaseValue : Decimal(24, 9);
    @sap.label : 'Amount'
    @sap.quickinfo : 'Condition Amount or Percentage'
    ConditionRateValue : Decimal(24, 9);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Currency'
    @sap.quickinfo : 'Currency Key'
    @sap.semantics : 'currency-code'
    ConditionCurrency : String(5);
    @sap.unit : 'ConditionQuantitySAPUnit'
    @sap.label : 'Pricing Unit'
    @sap.quickinfo : 'Condition Pricing Unit'
    ConditionQuantity : Decimal(5, 0);
    @sap.label : 'Condition Unit'
    @sap.quickinfo : 'Condition Unit in the Document'
    @sap.semantics : 'unit-of-measure'
    ConditionQuantityUnit : String(3);
    @sap.label : 'SAP Condition Qty'
    @sap.quickinfo : 'SAP Unit Code for Condition Quantity'
    @sap.semantics : 'unit-of-measure'
    ConditionQuantitySAPUnit : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'ISO Condition Qty'
    @sap.quickinfo : 'ISO Unit Code for Condition Quantity'
    ConditionQuantityISOUnit : String(3);
    @sap.label : 'Condition Category'
    @sap.quickinfo : 'Condition Category (Examples: Tax, Freight, Price, Cost)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionCategory : String(1);
    @sap.label : 'Statistical'
    @sap.quickinfo : 'Condition is used for statistics'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionIsForStatistics : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Scale Type'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PricingScaleType : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition Origin'
    @sap.quickinfo : 'Origin of the Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionOrigin : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Group Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    IsGroupCondition : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition Record No.'
    @sap.quickinfo : 'Number of Condition Record'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionRecord : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Sequent.No. of Cond.'
    @sap.quickinfo : 'Sequential Number of the Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionSequentialNumber : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Code'
    @sap.quickinfo : 'Tax on sales/purchases code'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    TaxCode : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'W/Tax Code'
    @sap.quickinfo : 'Withholding Tax Code'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    WithholdingTaxCode : String(2);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Cond.Rounding Diff.'
    @sap.quickinfo : 'Rounding-Off Difference of the Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CndnRoundingOffDiffAmount : Decimal(6, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Condition Value'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionAmount : Decimal(16, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Document Currency'
    @sap.quickinfo : 'SD Document Currency'
    @sap.semantics : 'currency-code'
    TransactionCurrency : String(5);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition Control'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionControl : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Inactive Condition'
    @sap.quickinfo : 'Condition is Inactive'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionInactiveReason : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition Class'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionClass : String(1);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Counter'
    @sap.quickinfo : 'Condition Counter (Header)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PrcgProcedureCounterForHeader : String(3);
    @sap.label : 'Condition Factor'
    @sap.quickinfo : 'Factor for Condition Base Value'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    FactorForConditionBasisValue : Double;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Structure Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    StructureCondition : String(1);
    @sap.label : 'Condition Factor'
    @sap.quickinfo : 'Factor for Condition Basis (Period)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PeriodFactorForCndnBasisValue : Double;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Scale Basis'
    @sap.quickinfo : 'Scale Basis Indicator'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PricingScaleBasis : String(3);
    @sap.label : 'Scale Base Val.'
    @sap.quickinfo : 'Scale Base Value'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionScaleBasisValue : Decimal(24, 9);
    @sap.label : 'Scale Unit of Meas.'
    @sap.quickinfo : 'Condition Scale Unit of Measure'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'unit-of-measure'
    ConditionScaleBasisUnit : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Scale Currency'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'currency-code'
    ConditionScaleBasisCurrency : String(5);
    @sap.label : 'Intercomp.Billing'
    @sap.quickinfo : 'Condition for Intercompany Billing'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CndnIsRelevantForIntcoBilling : Boolean;
    @sap.label : 'Changed Manually'
    @sap.quickinfo : 'Condition Changed Manually'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionIsManuallyChanged : Boolean;
    @sap.label : 'UsedforVariantConfig'
    @sap.quickinfo : 'Condition Used for Variant Configuration'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionIsForConfiguration : Boolean;
    @sap.label : 'Variant Key'
    @sap.quickinfo : 'Variant Condition Key'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    VariantCondition : String(26);
    to_SalesOrder : Association to A_SalesOrder {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Sales Order Item'
  entity A_SalesOrderItem {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.text : 'SalesOrderItemText'
    @sap.label : 'Item'
    @sap.quickinfo : 'Sales Order Item'
    key SalesOrderItem : String(6) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Higher-Level Item'
    @sap.quickinfo : 'Higher-Level Item in Bill of Material Structures'
    HigherLevelItem : String(6);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Usage of HL Item'
    @sap.quickinfo : 'ID for higher-level item usage'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    HigherLevelItemUsage : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Item Category'
    @sap.quickinfo : 'Sales Document Item Category'
    SalesOrderItemCategory : String(4);
    @sap.label : 'Item Description'
    @sap.quickinfo : 'Short text for sales order item'
    SalesOrderItemText : String(40);
    @sap.label : 'Customer Reference'
    PurchaseOrderByCustomer : String(35);
    @sap.label : 'Customer Reference'
    @sap.quickinfo : 'Ship-to Party''s Customer Reference'
    PurchaseOrderByShipToParty : String(35);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Purchase Order Item'
    @sap.quickinfo : 'Item Number of the Underlying Purchase Order'
    UnderlyingPurchaseOrderItem : String(6);
    @sap.display.format : 'UpperCase'
    @sap.label : 'External Item ID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ExternalItemID : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material'
    @sap.quickinfo : 'Material Number'
    Material : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Material'
    @sap.quickinfo : 'Material Number Used by Customer'
    MaterialByCustomer : String(35);
    @sap.display.format : 'Date'
    @sap.label : 'Pricing Date'
    @sap.quickinfo : 'Date for Pricing and Exchange Rate'
    PricingDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Pricing Ref. Matl'
    @sap.quickinfo : 'Pricing Reference Material'
    PricingReferenceMaterial : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Bill. Plan No.'
    @sap.quickinfo : 'Billing Plan Number / Invoicing Plan Number'
    BillingPlan : String(10);
    @sap.unit : 'RequestedQuantitySAPUnit'
    @sap.label : 'Requested Quantity'
    RequestedQuantity : Decimal(15, 3);
    @sap.label : 'Requested Qty Unit'
    @sap.quickinfo : 'Unit of the Requested Quantity'
    @sap.semantics : 'unit-of-measure'
    RequestedQuantityUnit : String(3);
    @sap.label : 'SAP Code Req. Qty'
    @sap.quickinfo : 'SAP Unit Code for Requested Quantity'
    @sap.semantics : 'unit-of-measure'
    RequestedQuantitySAPUnit : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'ISO Code Req. Qty'
    @sap.quickinfo : 'ISO Unit Code for Requested Quantity'
    RequestedQuantityISOUnit : String(3);
    @sap.label : 'Sales Unit'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'unit-of-measure'
    OrderQuantityUnit : String(3);
    @sap.label : 'SAP Order Quantity'
    @sap.quickinfo : 'SAP Unit Code for Order Quantity'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'unit-of-measure'
    OrderQuantitySAPUnit : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'ISO Order Quantity'
    @sap.quickinfo : 'ISO Unit Code for Order Quantity'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    OrderQuantityISOUnit : String(3);
    @sap.unit : 'OrderQuantitySAPUnit'
    @sap.label : 'Confirmed Quantity'
    @sap.quickinfo : 'Cumulative Confirmed Quantity in Sales Unit'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConfdDelivQtyInOrderQtyUnit : Decimal(15, 3);
    @sap.unit : 'ItemWeightSAPUnit'
    @sap.label : 'Gross Weight'
    @sap.quickinfo : 'Gross Weight of the Item'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ItemGrossWeight : Decimal(15, 3);
    @sap.unit : 'ItemWeightSAPUnit'
    @sap.label : 'Net Weight'
    @sap.quickinfo : 'Net Weight of the Item'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ItemNetWeight : Decimal(15, 3);
    @sap.label : 'Unit of Weight'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'unit-of-measure'
    ItemWeightUnit : String(3);
    @sap.label : 'SAP Code Item Weight'
    @sap.quickinfo : 'SAP Unit Code for Item Weight'
    @sap.semantics : 'unit-of-measure'
    ItemWeightSAPUnit : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'ISO Code Item Weight'
    @sap.quickinfo : 'ISO Unit Code for Item Weight'
    ItemWeightISOUnit : String(3);
    @sap.unit : 'ItemVolumeSAPUnit'
    @sap.label : 'Volume'
    @sap.quickinfo : 'Volume of the item'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ItemVolume : Decimal(15, 3);
    @sap.label : 'Volume Unit'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'unit-of-measure'
    ItemVolumeUnit : String(3);
    @sap.label : 'SAP Code f Item Vol.'
    @sap.quickinfo : 'SAP Unit Code for Item Volume'
    @sap.semantics : 'unit-of-measure'
    ItemVolumeSAPUnit : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'ISO Unit Item Volume'
    @sap.quickinfo : 'ISO Unit Code for Item Volume'
    ItemVolumeISOUnit : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Document Currency'
    @sap.quickinfo : 'SD Document Currency'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'currency-code'
    TransactionCurrency : String(5);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Net Value'
    @sap.quickinfo : 'Net Value of the Document Item in Document Currency'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    NetAmount : Decimal(16, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Ovrl Reference Sts'
    @sap.quickinfo : 'Overall Reference Status (Item)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    TotalSDDocReferenceStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Reference Status'
    @sap.quickinfo : 'Reference Status (Item)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    SDDocReferenceStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Substitution Reason'
    @sap.quickinfo : 'Reason for Material Substitution'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    MaterialSubstitutionReason : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material Group'
    MaterialGroup : String(9);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Product Price Group'
    MaterialPricingGroup : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material Group 1'
    AdditionalMaterialGroup1 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material Group 2'
    AdditionalMaterialGroup2 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material Group 3'
    AdditionalMaterialGroup3 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material Group 4'
    AdditionalMaterialGroup4 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material Group 5'
    AdditionalMaterialGroup5 : String(3);
    @sap.display.format : 'Date'
    @sap.label : 'Billing Date'
    BillingDocumentDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Contract Account'
    @sap.quickinfo : 'Contract Account Number'
    ContractAccount : String(12);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Addit. Value Days'
    @sap.quickinfo : 'Additional Value Days'
    AdditionalValueDays : String(2);
    @sap.display.format : 'Date'
    @sap.label : 'Serv. Rendered Date'
    @sap.quickinfo : 'Date on which services are rendered'
    ServicesRenderedDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Batch'
    @sap.quickinfo : 'Batch Number'
    Batch : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Plant'
    @sap.quickinfo : 'Plant (Own or External)'
    ProductionPlant : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Original Plant'
    @sap.quickinfo : 'Original Plant in Plant Substitution'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    OriginalPlant : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Substitution Status'
    @sap.quickinfo : 'Substitution Status for Alternative-Based Confirmation (ABC)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    AltvBsdConfSubstitutionStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Storage Location'
    StorageLocation : String(4);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Delivery Group'
    @sap.quickinfo : 'Delivery Group (Items are delivered together)'
    DeliveryGroup : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Shipping Point'
    @sap.quickinfo : 'Shipping Point / Receiving Point'
    ShippingPoint : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Shipping Type'
    ShippingType : String(2);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Delivery Priority'
    DeliveryPriority : String(2);
    @sap.label : 'Fixed Date and Qty'
    @sap.quickinfo : 'Delivery Date and Quantity Fixed'
    DeliveryDateQuantityIsFixed : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Deliv Date Rule'
    @sap.quickinfo : 'Delivery Date Rule'
    DeliveryDateTypeRule : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Incoterms'
    @sap.quickinfo : 'Incoterms (Part 1)'
    IncotermsClassification : String(3);
    @sap.label : 'Incoterms (Part 2)'
    IncotermsTransferLocation : String(28);
    @sap.label : 'Incoterms Location 1'
    IncotermsLocation1 : String(70);
    @sap.label : 'Incoterms Location 2'
    IncotermsLocation2 : String(70);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Tax Amount'
    @sap.quickinfo : 'Tax Amount in Document Currency'
    TaxAmount : Decimal(14, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Classifc. Mat.'
    @sap.quickinfo : 'Tax Classification for Material'
    ProductTaxClassification1 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Classifc. Mat.'
    @sap.quickinfo : 'Tax Classification for Material'
    ProductTaxClassification2 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Classifc. Mat.'
    @sap.quickinfo : 'Tax Classification for Material'
    ProductTaxClassification3 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Classifc. Mat.'
    @sap.quickinfo : 'Tax Classification for Material'
    ProductTaxClassification4 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Classifc. Mat.'
    @sap.quickinfo : 'Tax Classification for Material'
    ProductTaxClassification5 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Classifc. Mat.'
    @sap.quickinfo : 'Tax Classification for Material'
    ProductTaxClassification6 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Classifc. Mat.'
    @sap.quickinfo : 'Tax Classification for Material'
    ProductTaxClassification7 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Classifc. Mat.'
    @sap.quickinfo : 'Tax Classification for Material'
    ProductTaxClassification8 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Classifc. Mat.'
    @sap.quickinfo : 'Tax Classification for Material'
    ProductTaxClassification9 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Acct Assmt Grp Mat.'
    @sap.quickinfo : 'Account Assignment Group for Material'
    MatlAccountAssignmentGroup : String(2);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Cost'
    @sap.quickinfo : 'Cost in Document Currency'
    CostAmount : Decimal(14, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Terms of Payment'
    @sap.quickinfo : 'Terms of Payment Key'
    CustomerPaymentTerms : String(4);
    @sap.display.format : 'Date'
    @sap.label : 'Fixed Value Date'
    FixedValueDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Group'
    CustomerGroup : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Reason for Rejection'
    @sap.quickinfo : 'Reason for Rejection of Sales Documents'
    SalesDocumentRjcnReason : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Block'
    @sap.quickinfo : 'Billing Block for Item'
    ItemBillingBlockReason : String(2);
    @sap.label : 'Relevant for POD'
    @sap.quickinfo : 'Relevant for POD processing'
    SlsDocIsRlvtForProofOfDeliv : Boolean;
    @sap.display.format : 'NonNegative'
    @sap.label : 'WBS Element'
    @sap.quickinfo : 'Work Breakdown Structure Element (WBS Element)'
    WBSElement : String(24);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Profit Center'
    ProfitCenter : String(10);
    @sap.label : 'Exchng. Rate Accntg.'
    @sap.quickinfo : 'Exchange Rate for Postings to Financial Accounting'
    AccountingExchangeRate : Decimal(9, 5);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Reference Document'
    @sap.quickinfo : 'Document Number of Reference Document'
    ReferenceSDDocument : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Reference Item'
    @sap.quickinfo : 'Item number of the reference item'
    ReferenceSDDocumentItem : String(6);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Overall Status'
    @sap.quickinfo : 'Overall Processing Status (Item)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    SDProcessStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Delivery Status'
    @sap.quickinfo : 'Delivery Status (Item)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    DeliveryStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Order-Related Billing Status'
    @sap.quickinfo : 'Order-Related Billing Status (Item)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    OrderRelatedBillingStatus : String(1);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Subtotal 1'
    @sap.quickinfo : 'Subtotal 1 from Pricing Procedure for Price Element'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    Subtotal1Amount : Decimal(14, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Subtotal 2'
    @sap.quickinfo : 'Subtotal 2 from Pricing Procedure for Price Element'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    Subtotal2Amount : Decimal(14, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Subtotal 3'
    @sap.quickinfo : 'Subtotal 3 from Pricing Procedure for Price Element'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    Subtotal3Amount : Decimal(14, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Subtotal 4'
    @sap.quickinfo : 'Subtotal 4 from Pricing Procedure for Price Element'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    Subtotal4Amount : Decimal(14, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Subtotal 5'
    @sap.quickinfo : 'Subtotal 5 from Pricing Procedure for Price Element'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    Subtotal5Amount : Decimal(14, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Subtotal 6'
    @sap.quickinfo : 'Subtotal 6 from Pricing Procedure for Price Element'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    Subtotal6Amount : Decimal(14, 3);
    @sap.label : 'DNS Duration (Days)'
    @sap.quickinfo : 'DNS Duration in Days'
    ICSMMinLifeSpanShip : Decimal(4, 0);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Requirement Segment'
    RequirementSegment : String(40);
    @sap.display.format : 'Date'
    @sap.label : 'Import Doc Valid Dt'
    @sap.quickinfo : 'Import Doc Validity Date'
    ZZ1_ImportDocValidDate_SDI : Date;
    @sap.label : 'Contract Price Element'
    ZZ1_ContractPriceEleme_SDI : String(50);
    @sap.display.format : 'Date'
    @sap.label : 'Ship lot Start date'
    ZZ1_ShiplotStartdate_SDI : Date;
    @sap.label : 'Controlled Substance'
    @sap.quickinfo : 'Controlled Substance Indicator'
    ZZ1_NarcoticsIndicat_SDI : String(10);
    @sap.display.format : 'Date'
    @sap.label : 'Ship lot End date'
    ZZ1_ShiplotEnddate_SDI : Date;
    @sap.display.format : 'Date'
    @sap.label : 'Export Expiry Date'
    @sap.quickinfo : 'Export Expiration Date'
    ZZ1_ExportExpirDate_SDI : Date;
    @sap.label : 'Export Permit/TID'
    ZZ1_ExportPermitTID_SDI : String(10);
    @sap.label : 'Contract Number'
    ZZ1_ContraactNumber_SDI : String(20);
    @sap.label : 'Import Document No'
    ZZ1_ImportDocumentNo_SDI : String(30);
    to_BillingPlan : Association to A_SalesOrderItemBillingPlan {  };
    to_Partner : Association to many A_SalesOrderItemPartner {  };
    to_PrecedingProcFlowDocItem : Association to many A_SalesOrderItmPrecdgProcFlow {  };
    to_PricingElement : Association to many A_SalesOrderItemPrElement {  };
    to_RelatedObject : Association to many A_SalesOrderItemRelatedObject {  };
    to_SalesOrder : Association to A_SalesOrder {  };
    to_ScheduleLine : Association to many A_SalesOrderScheduleLine {  };
    to_SubsequentProcFlowDocItem : Association to many A_SalesOrderItmSubsqntProcFlow {  };
    to_Text : Association to many A_SalesOrderItemText {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Item Billing Plan'
  entity A_SalesOrderItemBillingPlan {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item'
    @sap.quickinfo : 'Sales Order Item'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrderItem : String(6) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Bill. Plan No.'
    @sap.quickinfo : 'Billing/Invoicing Plan Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key BillingPlan : String(10) not null;
    @sap.label : 'Header Billing Plan'
    @sap.quickinfo : 'Indicator for Billing Plan on Header'
    BillingPlanIsInHeader : Boolean;
    @sap.display.format : 'Date'
    @sap.label : 'Start Date'
    @sap.quickinfo : 'Start Date of Billing/Invoicing Plan'
    BillingPlanStartDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Origin of Start Date'
    @sap.quickinfo : 'Rule for Origin of Start Date of Billing/Invoicing Plan'
    BillingPlanStartDateRule : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Reference'
    @sap.quickinfo : 'Reference Billing Plan Number / Invoicing Plan Number'
    ReferenceBillingPlan : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Category'
    @sap.quickinfo : 'Billing plan category'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanCategory : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Plan Type'
    @sap.quickinfo : 'Billing/Invoicing Plan Type'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanType : String(2);
    @sap.display.format : 'Date'
    @sap.label : 'End Date'
    @sap.quickinfo : 'End Date of Billing/Invoicing Plan'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanEndDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Origin End Date'
    @sap.quickinfo : 'Rule for Origin of End Date for Billing/Invoicing Plan'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanEndDateRule : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Search term'
    @sap.quickinfo : 'Sort field'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanSearchTerm : String(10);
    to_BillingPlanItem : Association to many A_SlsOrderItemBillingPlanItem {  };
    to_SalesOrder : Association to A_SalesOrder {  };
    to_SalesOrderItem : Association to A_SalesOrderItem {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Item Partner'
  entity A_SalesOrderItemPartner {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item'
    @sap.quickinfo : 'Sales Order Item'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrderItem : String(6) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Partner Function'
    key PartnerFunction : String(2) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Partner Function'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PartnerFunctionInternalCode : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer'
    @sap.quickinfo : 'Customer Number'
    Customer : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Supplier'
    @sap.quickinfo : 'Account Number of Supplier'
    Supplier : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Personnel Number'
    Personnel : String(8);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Contact Person'
    @sap.quickinfo : 'Number of Contact Person'
    ContactPerson : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Business Partner'
    @sap.quickinfo : 'Business Partner Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ReferenceBusinessPartner : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Address Number'
    AddressID : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'VAT Registration No.'
    @sap.quickinfo : 'VAT Registration Number'
    VATRegistration : String(20);
    to_Address : Association to many A_SalesOrderItemPartnerAddress {  };
    to_SalesOrder : Association to A_SalesOrder {  };
    to_SalesOrderItem : Association to A_SalesOrderItem {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Item Partner Address'
  entity A_SalesOrderItemPartnerAddress {
    @sap.display.format : 'UpperCase'
    @sap.label : 'SD Document'
    @sap.quickinfo : 'Sales and Distribution Document Number'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item (SD)'
    @sap.quickinfo : 'Item number of the SD document'
    key SalesOrderItem : String(6) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Partner Function'
    key PartnerFunction : String(2) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Address Version'
    @sap.quickinfo : 'Version ID for International Addresses'
    key AddressRepresentationCode : String(1) not null;
    @sap.label : 'Language Key'
    CorrespondenceLanguage : String(2);
    @sap.label : 'Full Name'
    @sap.quickinfo : 'Full Name of Person'
    AddresseeFullName : String(80);
    @sap.label : 'Name'
    @sap.quickinfo : 'Name 1'
    OrganizationName1 : String(40);
    @sap.label : 'Name 2'
    OrganizationName2 : String(40);
    @sap.label : 'Name 3'
    OrganizationName3 : String(40);
    @sap.label : 'Name 4'
    OrganizationName4 : String(40);
    @sap.label : 'City'
    CityName : String(40);
    @sap.label : 'District'
    DistrictName : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Postal Code'
    @sap.quickinfo : 'City postal code'
    PostalCode : String(10);
    @sap.label : 'Street'
    StreetName : String(60);
    @sap.label : 'Street Address Non-Deliverable Reason'
    @sap.quickinfo : 'Street 2'
    StreetPrefixName1 : String(40);
    @sap.label : 'Street 3'
    StreetPrefixName2 : String(40);
    @sap.label : 'Street 4'
    StreetSuffixName1 : String(40);
    @sap.label : 'Street 5'
    StreetSuffixName2 : String(40);
    @sap.label : 'House Number'
    HouseNumber : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region Key'
    Country : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Region'
    @sap.quickinfo : 'Region (State, Province, County)'
    Region : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Title Key'
    @sap.quickinfo : 'Form-of-Address Key'
    FormOfAddress : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Jurisdiction'
    TaxJurisdiction : String(15);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Transportation Zone'
    @sap.quickinfo : 'Transportation zone to or from which the goods are delivered'
    TransportZone : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'PO Box'
    POBox : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'PO Box Postal Code'
    POBoxPostalCode : String(10);
    @sap.label : 'E-Mail Address'
    EmailAddress : String(241);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region'
    @sap.quickinfo : 'Country/Region for Telephone/Fax Number'
    MobilePhoneCountry : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Telephone'
    @sap.quickinfo : 'Telephone No.: Dialing Code and Number'
    MobileNumber : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region'
    @sap.quickinfo : 'Country/Region for Telephone/Fax Number'
    PhoneNumberCountry : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Telephone'
    @sap.quickinfo : 'Telephone No.: Dialing Code and Number'
    PhoneNumber : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Extension'
    @sap.quickinfo : 'Telephone no.: Extension'
    PhoneExtensionNumber : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region'
    @sap.quickinfo : 'Country/Region for Telephone/Fax Number'
    FaxNumberCountry : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Fax'
    @sap.quickinfo : 'Fax Number: Dialing Code and Number'
    FaxAreaCodeSubscriberNumber : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Extension'
    @sap.quickinfo : 'Fax no.: Extension'
    FaxExtensionNumber : String(10);
    to_Partner : Association to A_SalesOrderItemPartner {  };
    to_SalesOrder : Association to A_SalesOrder {  };
    to_SalesOrderItem : Association to A_SalesOrderItem {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Item Pricing Element'
  entity A_SalesOrderItemPrElement {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item'
    @sap.quickinfo : 'Sales Order Item'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrderItem : String(6) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Step Number'
    key PricingProcedureStep : String(3) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Counter'
    @sap.quickinfo : 'Condition Counter'
    key PricingProcedureCounter : String(3) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition Type'
    ConditionType : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Valid From'
    @sap.quickinfo : 'Timestamp for Pricing'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PricingDateTime : String(14);
    @sap.display.format : 'Date'
    @sap.label : 'Cndn Pricing Date'
    @sap.quickinfo : 'Condition Pricing Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PriceConditionDeterminationDte : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Calculation Type'
    @sap.quickinfo : 'Calculation Type for Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionCalculationType : String(3);
    @sap.label : 'Condition Basis'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionBaseValue : Decimal(24, 9);
    @sap.label : 'Amount'
    @sap.quickinfo : 'Condition Amount or Percentage'
    ConditionRateValue : Decimal(24, 9);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Currency'
    @sap.quickinfo : 'Currency Key'
    @sap.semantics : 'currency-code'
    ConditionCurrency : String(5);
    @sap.unit : 'ConditionQuantitySAPUnit'
    @sap.label : 'Pricing Unit'
    @sap.quickinfo : 'Condition Pricing Unit'
    ConditionQuantity : Decimal(5, 0);
    @sap.label : 'Condition Unit'
    @sap.quickinfo : 'Condition Unit in the Document'
    @sap.semantics : 'unit-of-measure'
    ConditionQuantityUnit : String(3);
    @sap.label : 'SAP Condition Qty'
    @sap.quickinfo : 'SAP Unit Code for Condition Quantity'
    @sap.semantics : 'unit-of-measure'
    ConditionQuantitySAPUnit : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'ISO Condition Qty'
    @sap.quickinfo : 'ISO Unit Code for Condition Quantity'
    ConditionQuantityISOUnit : String(3);
    @sap.label : 'Condition Category'
    @sap.quickinfo : 'Condition Category (Examples: Tax, Freight, Price, Cost)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionCategory : String(1);
    @sap.label : 'Statistical'
    @sap.quickinfo : 'Condition is used for statistics'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionIsForStatistics : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Scale Type'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PricingScaleType : String(1);
    @sap.label : 'Accruals'
    @sap.quickinfo : 'Condition is Relevant for Accrual (e.g. Freight)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    IsRelevantForAccrual : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Invoice List Cond.'
    @sap.quickinfo : 'Condition for Invoice List'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CndnIsRelevantForInvoiceList : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition Origin'
    @sap.quickinfo : 'Origin of the Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionOrigin : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Group Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    IsGroupCondition : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition Record No.'
    @sap.quickinfo : 'Number of Condition Record'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionRecord : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Sequent.No. of Cond.'
    @sap.quickinfo : 'Sequential Number of the Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionSequentialNumber : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Code'
    @sap.quickinfo : 'Tax on sales/purchases code'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    TaxCode : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'W/Tax Code'
    @sap.quickinfo : 'Withholding Tax Code'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    WithholdingTaxCode : String(2);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Cond.Rounding Diff.'
    @sap.quickinfo : 'Rounding-Off Difference of the Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CndnRoundingOffDiffAmount : Decimal(6, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Condition Value'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionAmount : Decimal(16, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Document Currency'
    @sap.quickinfo : 'SD Document Currency'
    @sap.semantics : 'currency-code'
    TransactionCurrency : String(5);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition Control'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionControl : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Inactive Condition'
    @sap.quickinfo : 'Condition is Inactive'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionInactiveReason : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition Class'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionClass : String(1);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Counter'
    @sap.quickinfo : 'Condition Counter (Header)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PrcgProcedureCounterForHeader : String(3);
    @sap.label : 'Condition Factor'
    @sap.quickinfo : 'Factor for Condition Base Value'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    FactorForConditionBasisValue : Double;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Structure Condition'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    StructureCondition : String(1);
    @sap.label : 'Condition Factor'
    @sap.quickinfo : 'Factor for Condition Basis (Period)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PeriodFactorForCndnBasisValue : Double;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Scale Basis'
    @sap.quickinfo : 'Scale Basis Indicator'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PricingScaleBasis : String(3);
    @sap.label : 'Scale Base Val.'
    @sap.quickinfo : 'Scale Base Value'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionScaleBasisValue : Decimal(24, 9);
    @sap.label : 'Scale Unit of Meas.'
    @sap.quickinfo : 'Condition Scale Unit of Measure'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'unit-of-measure'
    ConditionScaleBasisUnit : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Scale Currency'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'currency-code'
    ConditionScaleBasisCurrency : String(5);
    @sap.label : 'Intercomp.Billing'
    @sap.quickinfo : 'Condition for Intercompany Billing'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CndnIsRelevantForIntcoBilling : Boolean;
    @sap.label : 'Changed Manually'
    @sap.quickinfo : 'Condition Changed Manually'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionIsManuallyChanged : Boolean;
    @sap.label : 'UsedforVariantConfig'
    @sap.quickinfo : 'Condition Used for Variant Configuration'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ConditionIsForConfiguration : Boolean;
    @sap.label : 'Variant Key'
    @sap.quickinfo : 'Variant Condition Key'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    VariantCondition : String(26);
    to_SalesOrder : Association to A_SalesOrder {  };
    to_SalesOrderItem : Association to A_SalesOrderItem {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.updatable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Item Related Object'
  entity A_SalesOrderItemRelatedObject {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item'
    @sap.quickinfo : 'Sales Order Item'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrderItem : String(6) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Sequence Number'
    @sap.quickinfo : 'Sequence Number of the Related Object of an SD Document'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SDDocRelatedObjectSequenceNmbr : String(4) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Related Object Type'
    @sap.quickinfo : 'Type of the Related Object of an SD Document'
    SDDocumentRelatedObjectType : String(5);
    @sap.label : 'System of Reltd Obj.'
    @sap.quickinfo : 'System of the Related Object of an SD Document'
    SDDocRelatedObjectSystem : String(60);
    @sap.label : 'Reltd Obj. Reference'
    @sap.quickinfo : 'Reference of the Related Object of an SD Document'
    SDDocRelatedObjectReference1 : String(60);
    @sap.label : 'Reltd Obj. Reference'
    @sap.quickinfo : 'Reference of the Related Object of an SD Document'
    SDDocRelatedObjectReference2 : String(60);
    to_SalesOrder : Association to A_SalesOrder {  };
    to_SalesOrderItem : Association to A_SalesOrderItem {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Item Text'
  entity A_SalesOrderItemText {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item'
    @sap.quickinfo : 'Sales Order Item'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrderItem : String(6) not null;
    @sap.label : 'Language Key'
    key Language : String(2) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Text ID'
    key LongTextID : String(4) not null;
    @sap.label : 'String'
    @sap.heading : ''
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    LongText : String;
    to_SalesOrder : Association to A_SalesOrder {  };
    to_SalesOrderItem : Association to A_SalesOrderItem {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Item Preceding Process Flow'
  entity A_SalesOrderItmPrecdgProcFlow {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Subsequent Document'
    @sap.quickinfo : 'Subsequent Sales and Distribution Document'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Subsequent Item'
    @sap.quickinfo : 'Subsequent Item of an SD Document'
    key SalesOrderItem : String(6) not null;
    @sap.label : 'DocRelationshipUUID'
    @sap.quickinfo : 'SD Unique Document Relationship Identification'
    key DocRelationshipUUID : UUID not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Preceding Document'
    @sap.quickinfo : 'Preceding sales and distribution document'
    PrecedingDocument : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Preceding Item'
    @sap.quickinfo : 'Preceding Item of an SD Document'
    PrecedingDocumentItem : String(6);
    @sap.label : 'Preceding Doc.Categ.'
    @sap.quickinfo : 'Document Category of Preceding SD Document'
    PrecedingDocumentCategory : String(4);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Level'
    @sap.quickinfo : 'Level of the document flow record'
    ProcessFlowLevel : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Field Name'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    RelatedProcFlowDocStsFieldName : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Overall Status'
    @sap.quickinfo : 'Overall Processing Status (Item)'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    SDProcessStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Posting Status'
    @sap.quickinfo : 'Status for Transfer to Accounting'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    AccountingTransferStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Status'
    @sap.quickinfo : 'Preliminary Billing Document Status'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    PrelimBillingDocumentStatus : String(1);
    @sap.display.format : 'Date'
    @sap.label : 'Created On'
    @sap.quickinfo : 'Record Creation Date'
    CreationDate : Date;
    @sap.label : 'Time'
    @sap.quickinfo : 'Entry time'
    CreationTime : Time;
    @sap.display.format : 'Date'
    @sap.label : 'Changed On'
    @sap.quickinfo : 'Last Changed On'
    LastChangeDate : Date;
    @sap.label : 'UIM Info'
    @sap.visible : 'false'
    @sap.updatable : 'false'
    UIM_INFO : String;
    to_SalesOrder : Association to A_SalesOrder {  };
    to_SalesOrderItem : Association to A_SalesOrderItem {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Item Subsequent Process Flow'
  entity A_SalesOrderItmSubsqntProcFlow {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Preceding Document'
    @sap.quickinfo : 'Preceding sales and distribution document'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Preceding Item'
    @sap.quickinfo : 'Preceding Item of an SD Document'
    key SalesOrderItem : String(6) not null;
    @sap.label : 'DocRelationshipUUID'
    @sap.quickinfo : 'SD Unique Document Relationship Identification'
    key DocRelationshipUUID : UUID not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Subsequent Document'
    @sap.quickinfo : 'Subsequent Sales and Distribution Document'
    SubsequentDocument : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Subsequent Item'
    @sap.quickinfo : 'Subsequent Item of an SD Document'
    SubsequentDocumentItem : String(6);
    @sap.label : 'Subsequent Doc. Cat.'
    @sap.quickinfo : 'Document Category of Subsequent Document'
    SubsequentDocumentCategory : String(4);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Level'
    @sap.quickinfo : 'Level of the document flow record'
    ProcessFlowLevel : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Field Name'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    RelatedProcFlowDocStsFieldName : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Overall Status'
    @sap.quickinfo : 'Overall Processing Status (Item)'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    SDProcessStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Posting Status'
    @sap.quickinfo : 'Status for Transfer to Accounting'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    AccountingTransferStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Status'
    @sap.quickinfo : 'Preliminary Billing Document Status'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    PrelimBillingDocumentStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Preceding Document'
    @sap.quickinfo : 'Preceding sales and distribution document'
    SubsqntDocItmPrecdgDocument : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Preceding Item'
    @sap.quickinfo : 'Preceding Item of an SD Document'
    SubsqntDocItmPrecdgDocItem : String(6);
    @sap.label : 'Preceding Doc.Categ.'
    @sap.quickinfo : 'Document Category of Preceding SD Document'
    SubsqntDocItmPrecdgDocCategory : String(4);
    @sap.display.format : 'Date'
    @sap.label : 'Created On'
    @sap.quickinfo : 'Record Creation Date'
    CreationDate : Date;
    @sap.label : 'Time'
    @sap.quickinfo : 'Entry time'
    CreationTime : Time;
    @sap.display.format : 'Date'
    @sap.label : 'Changed On'
    @sap.quickinfo : 'Last Changed On'
    LastChangeDate : Date;
    @sap.label : 'UIM Info'
    @sap.visible : 'false'
    @sap.updatable : 'false'
    UIM_INFO : String;
    to_SalesOrder : Association to A_SalesOrder {  };
    to_SalesOrderItem : Association to A_SalesOrderItem {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Header Partner Address'
  entity A_SalesOrderPartnerAddress {
    @sap.display.format : 'UpperCase'
    @sap.label : 'SD Document'
    @sap.quickinfo : 'Sales and Distribution Document Number'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Partner Function'
    key PartnerFunction : String(2) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Address Version'
    @sap.quickinfo : 'Version ID for International Addresses'
    key AddressRepresentationCode : String(1) not null;
    @sap.label : 'Language Key'
    CorrespondenceLanguage : String(2);
    @sap.label : 'Full Name'
    @sap.quickinfo : 'Full Name of Person'
    AddresseeFullName : String(80);
    @sap.label : 'Name'
    @sap.quickinfo : 'Name 1'
    OrganizationName1 : String(40);
    @sap.label : 'Name 2'
    OrganizationName2 : String(40);
    @sap.label : 'Name 3'
    OrganizationName3 : String(40);
    @sap.label : 'Name 4'
    OrganizationName4 : String(40);
    @sap.label : 'City'
    CityName : String(40);
    @sap.label : 'District'
    DistrictName : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Postal Code'
    @sap.quickinfo : 'City postal code'
    PostalCode : String(10);
    @sap.label : 'Street Address Non-Deliverable Reason'
    @sap.quickinfo : 'Street 2'
    StreetPrefixName1 : String(40);
    @sap.label : 'Street 3'
    StreetPrefixName2 : String(40);
    @sap.label : 'Street'
    StreetName : String(60);
    @sap.label : 'Street 4'
    StreetSuffixName1 : String(40);
    @sap.label : 'Street 5'
    StreetSuffixName2 : String(40);
    @sap.label : 'House Number'
    HouseNumber : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region Key'
    Country : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Region'
    @sap.quickinfo : 'Region (State, Province, County)'
    Region : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Title Key'
    @sap.quickinfo : 'Form-of-Address Key'
    FormOfAddress : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Jurisdiction'
    TaxJurisdiction : String(15);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Transportation Zone'
    @sap.quickinfo : 'Transportation zone to or from which the goods are delivered'
    TransportZone : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'PO Box'
    POBox : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'PO Box Postal Code'
    POBoxPostalCode : String(10);
    @sap.label : 'E-Mail Address'
    EmailAddress : String(241);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region'
    @sap.quickinfo : 'Country/Region for Telephone/Fax Number'
    MobilePhoneCountry : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Telephone'
    @sap.quickinfo : 'Telephone No.: Dialing Code and Number'
    MobileNumber : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region'
    @sap.quickinfo : 'Country/Region for Telephone/Fax Number'
    PhoneNumberCountry : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Telephone'
    @sap.quickinfo : 'Telephone No.: Dialing Code and Number'
    PhoneNumber : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Extension'
    @sap.quickinfo : 'Telephone no.: Extension'
    PhoneExtensionNumber : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region'
    @sap.quickinfo : 'Country/Region for Telephone/Fax Number'
    FaxNumberCountry : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Fax'
    @sap.quickinfo : 'Fax Number: Dialing Code and Number'
    FaxAreaCodeSubscriberNumber : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Extension'
    @sap.quickinfo : 'Fax no.: Extension'
    FaxExtensionNumber : String(10);
    to_Partner : Association to A_SalesOrderHeaderPartner {  };
    to_SalesOrder : Association to A_SalesOrder {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Header Preceding Process Flow'
  entity A_SalesOrderPrecdgProcFlow {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Subsequent Document'
    @sap.quickinfo : 'Subsequent Sales and Distribution Document'
    key SalesOrder : String(10) not null;
    @sap.label : 'DocRelationshipUUID'
    @sap.quickinfo : 'SD Unique Document Relationship Identification'
    key DocRelationshipUUID : UUID not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Preceding Document'
    @sap.quickinfo : 'Preceding sales and distribution document'
    PrecedingDocument : String(10);
    @sap.label : 'Preceding Doc.Categ.'
    @sap.quickinfo : 'Document Category of Preceding SD Document'
    PrecedingDocumentCategory : String(4);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Level'
    @sap.quickinfo : 'Level of the document flow record'
    ProcessFlowLevel : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Overall Status'
    @sap.quickinfo : 'Overall Processing Status (Header/All Items)'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    OverallSDProcessStatus : String(1);
    @sap.display.format : 'Date'
    @sap.label : 'Created On'
    @sap.quickinfo : 'Record Creation Date'
    CreationDate : Date;
    @sap.label : 'Time'
    @sap.quickinfo : 'Entry time'
    CreationTime : Time;
    @sap.display.format : 'Date'
    @sap.label : 'Changed On'
    @sap.quickinfo : 'Last Changed On'
    LastChangeDate : Date;
    to_SalesOrder : Association to A_SalesOrder {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.updatable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Header Related Object'
  entity A_SalesOrderRelatedObject {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Sequence Number'
    @sap.quickinfo : 'Sequence Number of the Related Object of an SD Document'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SDDocRelatedObjectSequenceNmbr : String(4) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Related Object Type'
    @sap.quickinfo : 'Type of the Related Object of an SD Document'
    SDDocumentRelatedObjectType : String(5);
    @sap.label : 'System of Reltd Obj.'
    @sap.quickinfo : 'System of the Related Object of an SD Document'
    SDDocRelatedObjectSystem : String(60);
    @sap.label : 'Reltd Obj. Reference'
    @sap.quickinfo : 'Reference of the Related Object of an SD Document'
    SDDocRelatedObjectReference1 : String(60);
    @sap.label : 'Reltd Obj. Reference'
    @sap.quickinfo : 'Reference of the Related Object of an SD Document'
    SDDocRelatedObjectReference2 : String(60);
    to_SalesOrder : Association to A_SalesOrder {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Item Schedule Line'
  entity A_SalesOrderScheduleLine {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Document'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Sales Document Item'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrderItem : String(6) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Schedule Line Number'
    key ScheduleLine : String(4) not null;
    @sap.display.format : 'Date'
    @sap.label : 'Delivery Date'
    @sap.quickinfo : 'Requested Delivery Date'
    RequestedDeliveryDate : Date;
    @sap.display.format : 'Date'
    @sap.label : 'Delivery Date'
    @sap.quickinfo : 'Confirmed Delivery Date'
    ConfirmedDeliveryDate : Date;
    @sap.label : 'Sales Unit'
    @sap.semantics : 'unit-of-measure'
    OrderQuantityUnit : String(3);
    @sap.label : 'SAP Order Quantity'
    @sap.quickinfo : 'SAP Unit Code for Order Quantity'
    @sap.semantics : 'unit-of-measure'
    OrderQuantitySAPUnit : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'ISO Order Quantity'
    @sap.quickinfo : 'ISO Unit Code for Order Quantity'
    OrderQuantityISOUnit : String(3);
    @sap.unit : 'OrderQuantitySAPUnit'
    @sap.label : 'Order Quantity'
    @sap.quickinfo : 'Order Quantity in Sales Units'
    ScheduleLineOrderQuantity : Decimal(13, 3);
    @sap.unit : 'OrderQuantitySAPUnit'
    @sap.label : 'Confirmed Quantity'
    ConfdOrderQtyByMatlAvailCheck : Decimal(13, 3);
    @sap.unit : 'OrderQuantitySAPUnit'
    @sap.label : 'Delivered Quantity'
    DeliveredQtyInOrderQtyUnit : Decimal(13, 3);
    @sap.unit : 'OrderQuantitySAPUnit'
    @sap.label : 'Open Quantity'
    @sap.quickinfo : 'Open Confirmed Delivery Quantity'
    OpenConfdDelivQtyInOrdQtyUnit : Decimal(13, 3);
    @sap.unit : 'OrderQuantitySAPUnit'
    @sap.label : 'Corr.qty'
    @sap.quickinfo : 'Corrected quantity in sales unit'
    CorrectedQtyInOrderQtyUnit : Decimal(13, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Delivery Block'
    @sap.quickinfo : 'Schedule Line Blocked for Delivery'
    DelivBlockReasonForSchedLine : String(2);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Header Subsequent Process Flow'
  entity A_SalesOrderSubsqntProcFlow {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Preceding Document'
    @sap.quickinfo : 'Preceding sales and distribution document'
    key SalesOrder : String(10) not null;
    @sap.label : 'DocRelationshipUUID'
    @sap.quickinfo : 'SD Unique Document Relationship Identification'
    key DocRelationshipUUID : UUID not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Subsequent Document'
    @sap.quickinfo : 'Subsequent Sales and Distribution Document'
    SubsequentDocument : String(10);
    @sap.label : 'Subsequent Doc. Cat.'
    @sap.quickinfo : 'Document Category of Subsequent Document'
    SubsequentDocumentCategory : String(4);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Level'
    @sap.quickinfo : 'Level of the document flow record'
    ProcessFlowLevel : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Overall Status'
    @sap.quickinfo : 'Overall Processing Status (Header/All Items)'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    OverallSDProcessStatus : String(1);
    @sap.display.format : 'Date'
    @sap.label : 'Created On'
    @sap.quickinfo : 'Record Creation Date'
    CreationDate : Date;
    @sap.label : 'Time'
    @sap.quickinfo : 'Entry time'
    CreationTime : Time;
    @sap.display.format : 'Date'
    @sap.label : 'Changed On'
    @sap.quickinfo : 'Last Changed On'
    LastChangeDate : Date;
    to_SalesOrder : Association to A_SalesOrder {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Header Text'
  entity A_SalesOrderText {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.label : 'Language Key'
    key Language : String(2) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Text ID'
    key LongTextID : String(4) not null;
    @sap.label : 'String'
    @sap.heading : ''
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    LongText : String;
    to_SalesOrder : Association to A_SalesOrder {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Item Billing Plan Item'
  entity A_SlsOrderItemBillingPlanItem {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item'
    @sap.quickinfo : 'Sales Order Item'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrderItem : String(6) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Bill. Plan No.'
    @sap.quickinfo : 'Billing/Invoicing Plan Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key BillingPlan : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item'
    @sap.quickinfo : 'Item for billing plan/invoice plan/payment cards'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key BillingPlanItem : String(6) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Date Category'
    BillingPlanDateCategory : String(2);
    @sap.display.format : 'Date'
    @sap.label : 'Billing Date'
    BillingPlanBillingDate : Date;
    @sap.unit : 'TransactionCurrency'
    @sap.label : 'Billing Value'
    @sap.quickinfo : 'Value to be billed/calc. on date in billing/invoice plan'
    BillingPlanAmount : Decimal(16, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Currency'
    @sap.quickinfo : 'Currency Key'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'currency-code'
    TransactionCurrency : String(5);
    @sap.label : 'Invoice Percentage'
    @sap.quickinfo : 'Percentage of value to be invoiced'
    BillingPlanAmountPercent : Decimal(5, 2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Terms of Payment'
    @sap.quickinfo : 'Terms of Payment Key'
    CustomerPaymentTerms : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Type'
    @sap.quickinfo : 'Proposed Billing Type for an Order-Related Billing Document'
    ProposedBillingDocumentType : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Date Description'
    BillingPlanDateDescriptionCode : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Block'
    @sap.quickinfo : 'Billing Block for Billing/Invoicing Plan Date'
    BillingBlockReason : String(2);
    @sap.display.format : 'Date'
    @sap.label : 'Settlement Start Date'
    @sap.quickinfo : 'Settlement Start Date of Billing/Invoicing Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanServiceStartDate : Date;
    @sap.display.format : 'Date'
    @sap.label : 'Settlement End Date'
    @sap.quickinfo : 'Settlement End Date of Billing/Invoicing Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanServiceEndDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Status'
    @sap.quickinfo : 'Billing Status for Billing/Invoicing Plan Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanRelatedBillgStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Plan Type'
    @sap.quickinfo : 'Billing/Invoicing Plan Type'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanType : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Fixed Date'
    @sap.quickinfo : 'ID for Adopting Billing/Invoicing Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    AdoptingBillingDateID : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Rule'
    @sap.quickinfo : 'Rule in billing plan/invoice plan'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanBillingRule : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Usage'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingPlanMilestoneUsage : String(5);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Correction Date'
    @sap.quickinfo : 'Indicator for Correction Date in Billing Plan'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillgPlnDteCorrectionRfndType : String(1);
    @sap.label : 'Accounting Exchange Rate'
    @sap.quickinfo : 'Exchange Rate for FI Postings'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    AccountingExchangeRate : Decimal(9, 5);
    @sap.label : 'Reason'
    @sap.quickinfo : 'Reason for Postponement'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PostponementReason : String(255);
    to_BillingPlan : Association to A_SalesOrderItemBillingPlan {  };
    to_SalesOrder : Association to A_SalesOrder {  };
    to_SalesOrderItem : Association to A_SalesOrderItem {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  @sap.label : 'Header Payment Plan'
  entity A_SlsOrdPaymentPlanItemDetails {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Sales Order'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SalesOrder : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item'
    @sap.quickinfo : 'Item for billing plan/invoice plan/payment cards'
    key PaymentPlanItem : String(6) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Bill. Plan No.'
    @sap.quickinfo : 'Billing Plan Number / Invoicing Plan Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PaymentPlan : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'EPayt Type'
    @sap.quickinfo : 'Electronic Payment: Payment Type'
    ElectronicPaymentType : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Account Number'
    @sap.quickinfo : 'Electronic Payment: Account Number'
    ElectronicPayment : String(25);
    @sap.display.format : 'Date'
    @sap.label : 'EPayt Valid from'
    @sap.quickinfo : 'Electronic Payment: Valid from'
    EPaytValidityStartDate : Date;
    @sap.display.format : 'Date'
    @sap.label : 'EPayt Valid to'
    @sap.quickinfo : 'Electronic Payment: Valid to'
    EPaytValidityEndDate : Date;
    @sap.label : 'Account Holder'
    @sap.quickinfo : 'Electronic Payment: Name of Account Holder'
    ElectronicPaymentHolderName : String(40);
    @sap.unit : 'AuthorizationCurrency'
    @sap.label : 'Authorized Amount'
    @sap.quickinfo : 'Electronic Payment: Authorized Amount'
    AuthorizedAmountInAuthznCrcy : Decimal(16, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Currency'
    @sap.quickinfo : 'Currency Key'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.semantics : 'currency-code'
    AuthorizationCurrency : String(5);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Auth. Number'
    @sap.quickinfo : 'Electronic Payment: Authorization Number'
    AuthorizationByDigitalPaytSrvc : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Auth. Ref. Code'
    @sap.quickinfo : 'Electronic Payment: Authorization Reference Code'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    AuthorizationByAcquirer : String(15);
    @sap.display.format : 'Date'
    @sap.label : 'EPayt Auth. Date'
    @sap.quickinfo : 'Electronic Payment: Authorization Date'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    AuthorizationDate : Date;
    @sap.label : 'EPayt Auth. Time'
    @sap.quickinfo : 'Electronic Payment: Authorization Time'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    AuthorizationTime : Time;
    @sap.label : 'Text'
    @sap.quickinfo : 'Payment cards: Result text'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    AuthorizationStatusName : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'EPayt Token'
    @sap.quickinfo : 'Token for Digital Payment Integration in SD'
    EPaytByDigitalPaymentSrvc : String(25);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Call Status'
    @sap.quickinfo : 'Electronic Payment: Call Status'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ElectronicPaymentCallStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Rsp to Auth. Check'
    @sap.quickinfo : 'Electronic Payment: Response to Authorization Checks'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    EPaytAuthorizationResult : String(1);
    @sap.unit : 'AuthorizationCurrency'
    @sap.label : 'Amt to Be Auth.'
    @sap.quickinfo : 'Electronic Payment: Amount to Be Authorized'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    EPaytToBeAuthorizedAmount : Decimal(16, 3);
    @sap.label : 'Auth. Expired'
    @sap.quickinfo : 'Electronic Payment: Authorization Expired'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    EPaytAuthorizationIsExpired : Boolean;
    @sap.label : 'Amount Changed'
    @sap.quickinfo : 'Electronic Payment: Amount Changed'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    EPaytAmountIsChanged : Boolean;
    @sap.label : 'Preauthorization'
    @sap.quickinfo : 'Electronic Payment: Preauthorization'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PreauthorizationIsRequested : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Paymnt Serv. Provid.'
    @sap.quickinfo : 'Payment Service Provider for Digital Payments'
    PaymentServiceProvider : String(4);
    @sap.label : 'Payment Identifier'
    @sap.quickinfo : 'Digital Payments: Payment ID from Payment Service Provider'
    PaymentByPaymentServicePrvdr : String(40);
    @sap.label : 'PSP Transaction ID'
    @sap.quickinfo : 'SAP Digital Payments: Transaction ID of PSP'
    TransactionByPaytSrvcPrvdr : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Merchant ID'
    @sap.quickinfo : 'Electronic Payment: Merchant ID at Clearing House'
    MerchantByClearingHouse : String(15);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Auth. Rel. ID'
    @sap.quickinfo : 'Unique identifier of a previous successful authorization'
    PaymentCardAuthznRelationID : String(44);
    @sap.unit : 'AuthorizationCurrency'
    @sap.label : 'Billing Value'
    @sap.quickinfo : 'Value to be billed/calc. on date in billing/invoice plan'
    MaximumToBeAuthorizedAmount : Decimal(16, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Higher-level plan'
    @sap.quickinfo : 'Higher-level payment card plan number for billing'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PaytPlnForAuthorizationItem : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Higher-level item'
    @sap.quickinfo : 'Higher-level item in billing plan'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    PaytPlnItmForAuthorizationItem : String(6);
    to_SalesOrder : Association to A_SalesOrder {  };
  };

  @cds.external : true
  type FunctionResult {
    @sap.label : 'Indicator'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    Boolean : Boolean not null;
  };

  @cds.external : true
  action rejectApprovalRequest(
    SalesOrder : String(11000)
  ) returns FunctionResult;

  @cds.external : true
  action releaseApprovalRequest(
    SalesOrder : String(11000)
  ) returns FunctionResult;
};

