/* checksum : ed14a889129fc4926a5a0960f2708191 */
@cds.external : true
@CodeList.UnitsOfMeasure.Url : '../../../../default/iwbep/common/0001/$metadata'
@CodeList.UnitsOfMeasure.CollectionPath : 'UnitsOfMeasure'
@Aggregation.ApplySupported.Transformations : [ 'aggregate', 'groupby', 'filter' ]
@Aggregation.ApplySupported.Rollup : #None
@Common.ApplyMultiUnitBehaviorForSortingAndFiltering : true
@Capabilities.FilterFunctions : [
  'eq',
  'ne',
  'gt',
  'ge',
  'lt',
  'le',
  'and',
  'or',
  'contains',
  'startswith',
  'endswith',
  'any',
  'all'
]
@Capabilities.SupportedFormats : [ 'application/json', 'application/pdf' ]
@PDF.Features.DocumentDescriptionReference : '../../../../default/iwbep/common/0001/$metadata'
@PDF.Features.DocumentDescriptionCollection : 'MyDocumentDescriptions'
@PDF.Features.ArchiveFormat : true
@PDF.Features.Border : true
@PDF.Features.CoverPage : true
@PDF.Features.FitToPage : true
@PDF.Features.FontName : true
@PDF.Features.FontSize : true
@PDF.Features.Margin : true
@PDF.Features.Padding : true
@PDF.Features.Signature : true
@PDF.Features.HeaderFooter : true
@PDF.Features.ResultSizeDefault : 20000
@PDF.Features.ResultSizeMaximum : 20000
@Capabilities.KeyAsSegmentSupported : true
@Capabilities.AsynchronousRequestsSupported : true
service ZSD_VCM_AUTOMATIONFLW0001 {
  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'custom entity for Accounting document'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.ReadRestrictions.Readable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.FilterRestrictions.FilterExpressionRestrictions : [ { Property: ReferenceQuan, AllowedExpressions: 'MultiValue' } ]
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity AccDoc {
    @Core.Computed : true
    key AP_Dummy : String(10) not null;
    PurchaseOrder : String(10) not null;
    @Common.IsDigitSequence : true
    PurchaseOrderItem : String(5) not null;
    @Measures.Unit : ReferenceUnit
    ReferenceQuan : Decimal(23, 3) not null;
    @Common.IsUnit : true
    ReferenceUnit : String(2) not null;
    AccountingDocument : String(10) not null;
    @Common.IsDigitSequence : true
    FiscalYear : String(4) not null;
    AssignmentReference : String(18) not null;
    @odata.Precision : 0
    @odata.Type : 'Edm.DateTimeOffset'
    @Common.Label : 'Short Time Stamp'
    @Common.Heading : 'Short Form of Time Stamp'
    @Common.QuickInfo : 'UTC Time Stamp in Short Form (YYYYMMDDhhmmss)'
    lastchangedatetime : DateTime;
    CompanyCode : String(4) not null;
    _root : Association to one BatchAP on _root.AP_Dummy = AP_Dummy;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Root entiity for AP invoice'
  @Capabilities.NavigationRestrictions.RestrictedProperties : [
    { NavigationProperty: _header, InsertRestrictions: { Insertable: true } }
  ]
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.ReadRestrictions.Readable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity BatchAP {
    @Core.Computed : true
    key AP_Dummy : String(10) not null;
    @Common.Composition : true
    _header : Composition of many AccDoc on _header._root = $self;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'root entity for goods reciept'
  @Capabilities.NavigationRestrictions.RestrictedProperties : [
    { NavigationProperty: _header, InsertRestrictions: { Insertable: true } }
  ]
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.ReadRestrictions.Readable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity BatchGR {
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Purchasing Document'
    @Common.Heading : 'Pur. Doc.'
    @Common.QuickInfo : 'Purchasing Document Number'
    key PurchaseDummy : String(10) not null;
    @Common.Composition : true
    _header : Composition of many MatDoc on _header._root = $self;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Custom cds to get BP from Customer'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity CustomertoBP {
    @Common.Label : 'BP GUID'
    @Common.Heading : 'Business Partner GUID'
    @Common.QuickInfo : 'Business Partner GUID'
    key BusinessPartnerUUID : UUID not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Customer'
    @Common.QuickInfo : 'Customer Number'
    Customer : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Business Partner'
    @Common.QuickInfo : 'Business Partner Number'
    BusinessPartner : String(10) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Custom service for KNVP table'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity knvp {
    @Common.IsUpperCase : true
    @Common.Label : 'Customer'
    @Common.QuickInfo : 'Customer Number'
    key Customer : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Organization'
    @Common.Heading : 'SOrg.'
    key SalesOrganization : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Distribution Channel'
    @Common.Heading : 'DChl'
    key DistributionChannel : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Division'
    @Common.Heading : 'Dv'
    key Division : String(2) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Partner counter'
    @Common.Heading : 'ParC'
    key PartnerCounter : String(3) not null;
    key PartnerFunction : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Partner Type'
    @Common.Heading : 'NoTy.'
    @Common.QuickInfo : 'Type of partner number'
    PartnerFunctionType : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier'
    @Common.QuickInfo : 'Account Number of Supplier'
    BPCustomerNumber : String(10) not null;
    @Common.Label : 'Partner description'
    @Common.Heading : 'Part'
    @Common.QuickInfo : 'Customer description of partner (plant, storage location)'
    CustomerPartnerDescription : String(30) not null;
    @Common.Label : 'Default Partner'
    @Common.Heading : 'D'
    DefaultPartner : Boolean not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Supplier'
    @Common.QuickInfo : 'Account Number of Supplier'
    Supplier : String(10) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Personnel Number'
    @Common.Heading : 'Pers.No.'
    PersonnelNumber : String(8) not null;
    @Common.IsDigitSequence : true
    @Common.Label : 'Contact Person'
    @Common.Heading : 'Partner'
    @Common.QuickInfo : 'Number of Contact Person'
    ContactPerson : String(10) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Address Number'
    @Common.Heading : 'Business Partner Address Number (from BUT020)'
    @Common.QuickInfo : 'Business Partner Address Number (from BUT020)'
    AddressID : String(10) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'custom entity formatdoc'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.ReadRestrictions.Readable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity MatDoc {
    @Core.Computed : true
    @Common.IsUpperCase : true
    @Common.Label : 'Purchasing Document'
    @Common.Heading : 'Pur. Doc.'
    @Common.QuickInfo : 'Purchasing Document Number'
    key PurchaseDummy : String(10) not null;
    PurchaseOrder : String(10) not null;
    @Common.IsDigitSequence : true
    PurchaseOrderItem : String(5) not null;
    GoodsMovementType : String(3) not null;
    DeliveryDocument : String(10) not null;
    @Common.IsDigitSequence : true
    DeliveryDocumentItem : String(6) not null;
    MaterialDocument : String(10) not null;
    @Common.IsDigitSequence : true
    MaterialDocumentYear : String(4) not null;
    PostingDate : Date;
    CreationDate : Date;
    CreationTime : Time not null;
    _root : Association to one BatchGR on _root.PurchaseDummy = PurchaseDummy;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @Common.Label : 'Wrapper on table TVKWZ'
  @Capabilities.SearchRestrictions.Searchable : false
  @Capabilities.InsertRestrictions.Insertable : false
  @Capabilities.DeleteRestrictions.Deletable : false
  @Capabilities.UpdateRestrictions.Updatable : false
  @Capabilities.UpdateRestrictions.QueryOptions.SelectSupported : true
  entity TVKWZ {
    @Common.IsUpperCase : true
    @Common.Label : 'Sales Organization'
    @Common.Heading : 'SOrg.'
    key Vkorg : String(4) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'RefDistCh-Cust/Mat.'
    @Common.Heading : 'DCh-Cust/Mt'
    @Common.QuickInfo : 'Reference distrib.channel for cust.and material masters'
    key Vtweg : String(2) not null;
    @Common.IsUpperCase : true
    @Common.Label : 'Plant'
    @Common.Heading : 'Plnt'
    @Common.QuickInfo : 'Plant (Own or External)'
    key Werks : String(4) not null;
  };
};

