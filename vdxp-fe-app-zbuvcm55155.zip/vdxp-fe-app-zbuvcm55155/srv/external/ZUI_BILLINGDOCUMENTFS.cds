/* checksum : 460b04159f7bc8f6cf091e441e1a6b38 */
@cds.external : true
@m.IsDefaultEntityContainer : 'true'
@sap.message.scope.supported : 'true'
@sap.supported.formats : 'atom json xlsx pdf'
service ZUI_BILLINGDOCUMENTFS {
  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Billing Document Fact Sheet'
  entity C_BillingDocumentFs {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Document'
    key BillingDocument : String(10) not null;
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_BillingDocumentType/BillingDocumentType_Text'
    @sap.label : 'Billing Type'
    @sap.value.list : 'standard'
    BillingDocumentType : String(4);
    @sap.label : 'Description'
    BillingDocumentTypeName : String(40);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_PayerParty/CustomerName'
    @sap.label : 'Payer'
    @sap.value.list : 'standard'
    PayerParty : String(10);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_OverallBillingStatus/OverallBillingStatus_Text'
    @sap.label : 'Status'
    @sap.quickinfo : 'SD Billing Status'
    @sap.value.list : 'fixed-values'
    OverallBillingStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_BillToPartyName/CustomerName'
    @sap.label : 'Bill-to Party'
    @sap.value.list : 'standard'
    BillToParty : String(10);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_SoldToParty/CustomerName'
    @sap.label : 'Sold-to Party'
    @sap.value.list : 'standard'
    SoldToParty : String(10);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_CompanyCode/CompanyCodeName'
    @sap.label : 'Company Code'
    @sap.value.list : 'standard'
    CompanyCode : String(4);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_SalesOrganization/SalesOrganization_Text'
    @sap.label : 'Sales Organization'
    @sap.value.list : 'standard'
    SalesOrganization : String(4);
    @sap.display.format : 'Date'
    @sap.label : 'Billing Date'
    BillingDocumentDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_CustomerPaymentTerms/CustomerPaymentTerms_Text'
    @sap.label : 'Terms of Payment'
    @sap.quickinfo : 'Terms of Payment Key'
    @sap.value.list : 'standard'
    CustomerPaymentTerms : String(4);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_IncotermsClassification/IncotermsClassification_Text'
    @sap.label : 'Incoterms'
    @sap.quickinfo : 'Incoterms (Part 1)'
    @sap.value.list : 'standard'
    IncotermsClassification : String(3);
    @sap.label : 'Incoterms Location 1'
    IncotermsLocation1 : String(70);
    @sap.label : 'Incoterms Location 2'
    IncotermsLocation2 : String(70);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_BillingIssueType/BillingIssueType_Text'
    @sap.label : 'Issue Type'
    @sap.quickinfo : 'Billing Issue Type'
    @sap.value.list : 'fixed-values'
    BillingIssueType : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Reference'
    @sap.quickinfo : 'Reference Document Number'
    DocumentReferenceID : String(16);
    @sap.unit : 'TransactionCurrency'
    @sap.variable.scale : 'true'
    @sap.label : 'Tax Amount'
    @sap.quickinfo : 'Tax Amount in Document Currency'
    TaxAmount : Decimal(13, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.variable.scale : 'true'
    @sap.label : 'Net Value'
    @sap.quickinfo : 'Net Value in Document Currency'
    TotalNetAmount : Decimal(15, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.variable.scale : 'true'
    @sap.label : 'Total Amount'
    TotalGrossAmount : Decimal(15, 3);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_TransactionCurrency/Currency_Text'
    @sap.label : 'Document Currency'
    @sap.quickinfo : 'SD Document Currency'
    @sap.value.list : 'standard'
    @sap.semantics : 'currency-code'
    TransactionCurrency : String(5);
    @sap.text : 'to_SDDocumentCategory/SDDocumentCategory_Text'
    @sap.label : 'SD Document Category'
    @sap.value.list : 'standard'
    SDDocumentCategory : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer'
    @sap.quickinfo : 'Customer Number'
    BillToPartyName : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Canceled Bill. Doc.'
    @sap.quickinfo : 'Number of canceled billing document'
    @sap.value.list : 'standard'
    CancelledBillingDocument : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Document'
    ProcessFlowNodeDocument : String(10);
    @odata.Type : 'Edm.Byte'
    @sap.label : 'Overall Billing Status Criticality'
    OvrlBillingStatusCriticality : Integer;
    to_BillingDocumentType : Association to I_BillingDocumentType {  };
    to_BillingIssueType : Association to I_BillingIssueType {  };
    to_BillToPartyName : Association to I_Customer {  };
    to_CompanyCode : Association to I_CompanyCode {  };
    to_CustomerPaymentTerms : Association to I_CustomerPaymentTerms {  };
    to_IncotermsClassification : Association to I_IncotermsClassification {  };
    to_Item : Composition of many C_BillingDocumentItemFs {  };
    to_OverallBillingStatus : Association to I_OverallBillingStatus {  };
    to_Partner : Association to many C_SDDocumentPartnerCard {  };
    to_PayerParty : Association to I_Customer {  };
    to_SalesOrganization : Association to I_SalesOrganization {  };
    to_SDDocumentCategory : Association to I_SDDocumentCategory {  };
    to_SoldToParty : Association to I_Customer {  };
    to_TransactionCurrency : Association to I_Currency {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Billing Document Item Fact Sheet'
  entity C_BillingDocumentItemFs {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Document'
    @sap.value.list : 'standard'
    key BillingDocument : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.text : 'BillingDocumentItemText'
    @sap.label : 'Item'
    @sap.quickinfo : 'Billing Item'
    key BillingDocumentItem : String(6) not null;
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_Product/Product_Text'
    @sap.label : 'Product'
    @sap.quickinfo : 'Product Number'
    @sap.value.list : 'standard'
    Material : String(18);
    @sap.unit : 'BillingQuantityUnit'
    @sap.label : 'Invoiced Quantity'
    @sap.quickinfo : 'Actual Invoiced Quantity'
    BillingQuantity : Decimal(13, 3);
    @sap.text : 'to_BillingQuantityUnit/UnitOfMeasure_Text'
    @sap.label : 'Sales Unit'
    @sap.value.list : 'standard'
    @sap.semantics : 'unit-of-measure'
    BillingQuantityUnit : String(3);
    @sap.unit : 'TransactionCurrency'
    @sap.variable.scale : 'true'
    @sap.label : 'Net Value'
    @sap.quickinfo : 'Net Value of Billing item in Document Currency'
    NetAmount : Decimal(15, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.variable.scale : 'true'
    @sap.label : 'Tax Amount'
    @sap.quickinfo : 'Tax Amount in Document Currency'
    TaxAmount : Decimal(13, 3);
    @sap.unit : 'TransactionCurrency'
    @sap.variable.scale : 'true'
    @sap.label : 'Gross Value'
    @sap.quickinfo : 'Gross Value of the Billing Item in Document Currency'
    GrossAmount : Decimal(15, 3);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_TransactionCurrency/Currency_Text'
    @sap.label : 'Document Currency'
    @sap.quickinfo : 'SD Document Currency'
    @sap.value.list : 'standard'
    @sap.semantics : 'currency-code'
    TransactionCurrency : String(5);
    @sap.label : 'Item Description'
    @sap.quickinfo : 'Short text for sales order item'
    BillingDocumentItemText : String(40);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_ServiceDocumentType/ServiceDocumentType_Text'
    @sap.label : 'Service Doc. Type'
    @sap.quickinfo : 'Service Document Type'
    @sap.value.list : 'standard'
    ServiceDocumentType : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Service Document'
    @sap.quickinfo : 'Service Document ID'
    ServiceDocument : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Service Doc. Item'
    @sap.quickinfo : 'Service Document Item ID'
    ServiceDocumentItem : String(6);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Solution Order'
    BusinessSolutionOrder : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Solution Order Item'
    BusinessSolutionOrderItem : String(6);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Provider Contract'
    @sap.quickinfo : 'Identification of a Provider Contract'
    ProviderContract : String(20);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Provider Contract Item'
    ProviderContractItem : String(6);
    to_BillingDocument : Association to C_BillingDocumentFs {  };
    to_BillingQuantityUnit : Association to I_UnitOfMeasure {  };
    to_Product : Association to I_ProductStdVH {  };
    to_ServiceDocumentType : Association to I_ServiceDocumentType {  };
    to_TransactionCurrency : Association to I_Currency {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Business Partner for Fact Sheets'
  entity C_SDDocumentPartnerCard {
    @sap.display.format : 'UpperCase'
    @sap.label : 'SD Document'
    @sap.quickinfo : 'Sales and Distribution Document Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SDDocument : String(10) not null;
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item (SD)'
    @sap.quickinfo : 'Item number of the SD document'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    key SDDocumentItem : String(6) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Partner Function'
    key PartnerFunction : String(2) not null;
    @sap.label : 'Name'
    PartnerFunctionName : String(20);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer'
    @sap.quickinfo : 'Customer Number'
    BusinessPartner : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer'
    @sap.quickinfo : 'Customer Number'
    Customer : String(10);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Personnel Number'
    Personnel : String(8);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Contact Person'
    @sap.quickinfo : 'Number of Contact Person'
    ContactPerson : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Address Number'
    AddressID : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Person Number'
    AddressPersonID : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Address Type'
    @sap.quickinfo : 'Address type (1=Organization, 2=Person, 3=Contact person)'
    AddressObjectType : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Address indicator'
    SDDocPartnerAddressRefType : String(1);
    @sap.label : 'Full Name'
    @sap.quickinfo : 'Full Name of Person'
    FullName : String(80);
    @sap.display.format : 'UpperCase'
    @sap.text : 'FormattedPostalAddressDesc'
    @sap.label : 'Telephone number'
    @sap.quickinfo : 'Complete Number: Dialing Code+Number+Extension'
    @sap.semantics : 'tel'
    InternationalPhoneNumber : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Telephone number'
    @sap.quickinfo : 'Complete Number: Dialing Code+Number+Extension'
    @sap.semantics : 'tel'
    InternationalMobilePhoneNumber : String(30);
    @sap.label : 'E-Mail Address'
    @sap.semantics : 'email'
    EmailAddress : String(241);
    @sap.display.format : 'UpperCase'
    @sap.label : 'One-line short form of formatted address'
    @sap.heading : ''
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    FormattedPostalAddressDesc : String(80);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Billing Document Basic'
  @sap.value.list : 'true'
  entity I_BillingDocumentBasicStdVH {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Document'
    key BillingDocument : String(10) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Billing Document'
  @sap.value.list : 'true'
  entity I_BillingDocumentStdVH {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Document'
    key BillingDocument : String(10) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Billing Document Type'
  entity I_BillingDocumentType {
    @sap.display.format : 'UpperCase'
    @sap.text : 'BillingDocumentType_Text'
    @sap.label : 'Billing Type'
    key BillingDocumentType : String(4) not null;
    @sap.label : 'Description'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingDocumentType_Text : String(40);
    @sap.text : 'to_SDDocumentCategory/SDDocumentCategory_Text'
    @sap.label : 'SD Document Category'
    @sap.value.list : 'standard'
    SDDocumentCategory : String(4);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Item No. Increment'
    @sap.quickinfo : 'Item Number Increment of SD Documents'
    IncrementItemNumber : String(6);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing Category'
    BillingDocumentCategory : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Text Determ Proced'
    @sap.quickinfo : 'Text Determination Procedure for Billing Process Doc Header'
    BillgProcDocTxtDetnProcedure : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Item Text Determ. Proc.'
    @sap.quickinfo : 'Text Determination Procedure for Billing Process Doc. Item'
    BillgProcDocItmTxtDetnProced : String(2);
    to_SDDocumentCategory : Association to I_SDDocumentCategory {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Billing Issue Type'
  entity I_BillingIssueType {
    @sap.display.format : 'UpperCase'
    @sap.text : 'BillingIssueType_Text'
    @sap.label : 'Issue Type'
    @sap.quickinfo : 'Billing Issue Type'
    key BillingIssueType : String(1) not null;
    @sap.label : 'Short Description'
    @sap.quickinfo : 'Short Text for Fixed Values'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    BillingIssueType_Text : String(60);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Company Code'
  entity I_CompanyCode {
    @sap.display.format : 'UpperCase'
    @sap.text : 'CompanyCodeName'
    @sap.label : 'Company Code'
    key CompanyCode : String(4) not null;
    @sap.label : 'Company Name'
    @sap.quickinfo : 'Name of Company Code or Company'
    CompanyCodeName : String(25);
    @sap.label : 'City'
    CityName : String(25);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region Key'
    Country : String(3);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_Currency/Currency_Text'
    @sap.label : 'Currency'
    @sap.quickinfo : 'Currency Key'
    @sap.value.list : 'standard'
    @sap.semantics : 'currency-code'
    Currency : String(5);
    @sap.label : 'Language Key'
    Language : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Chart of Accounts'
    ChartOfAccounts : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Fiscal Year Variant'
    FiscalYearVariant : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Company'
    Company : String(6);
    @sap.display.format : 'UpperCase'
    @sap.text : 'CreditControlArea_Text'
    @sap.label : 'Credit Control Area'
    @sap.value.list : 'standard'
    CreditControlArea : String(4);
    @sap.label : 'Description'
    @sap.quickinfo : 'Description of the credit control area'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CreditControlArea_Text : String(35);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Alternative COA'
    @sap.quickinfo : 'Alternative Chart of Accounts'
    CountryChartOfAccounts : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'FM Area'
    @sap.quickinfo : 'Financial Management Area'
    FinancialManagementArea : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Address'
    AddressID : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Taxes on Sls/Purc.'
    @sap.quickinfo : 'Taxes on Sales/Purchases Group'
    TaxableEntity : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'VAT Registration No.'
    @sap.quickinfo : 'VAT Registration Number'
    VATRegistration : String(20);
    @sap.label : 'Extended WTax Active'
    @sap.quickinfo : 'Indicator: Extended Withholding Tax Active'
    ExtendedWhldgTaxIsActive : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.text : 'ControllingArea_Text'
    @sap.label : 'Controlling Area'
    @sap.value.list : 'standard'
    ControllingArea : String(4);
    @sap.label : 'Controlling Area Name'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ControllingArea_Text : String(25);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Field status variant'
    @sap.quickinfo : 'Field Status Variant'
    FieldStatusVariant : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Output Tax Code'
    @sap.quickinfo : 'Output Tax Code for Non-Taxable Transactions'
    NonTaxableTransactionTaxCode : String(2);
    @sap.label : 'Tax Determ.with Doc.Date'
    @sap.quickinfo : 'Indicator: Document Date As the Basis for Tax Determination'
    DocDateIsUsedForTaxDetn : Boolean;
    @sap.label : 'Tax Date'
    @sap.quickinfo : 'Tax Reporting Date Active in Documents'
    TaxRptgDateIsActive : Boolean;
    @sap.label : 'Net Discount Base'
    @sap.quickinfo : 'Indicator: Discount base amount is the net value'
    CashDiscountBaseAmtIsNetAmt : Boolean;
    to_Currency : Association to I_Currency {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Company Code'
  @sap.value.list : 'true'
  entity I_CompanyCodeStdVH {
    @sap.display.format : 'UpperCase'
    @sap.text : 'CompanyCodeName'
    @sap.label : 'Company Code'
    key CompanyCode : String(4) not null;
    @sap.label : 'Company Name'
    @sap.quickinfo : 'Name of Company Code or Company'
    CompanyCodeName : String(25);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Controlling Area'
  @sap.value.list : 'true'
  entity I_ControllingAreaStdVH {
    @sap.display.format : 'UpperCase'
    @sap.text : 'ControllingAreaName'
    @sap.label : 'Controlling Area'
    key ControllingArea : String(4) not null;
    @sap.label : 'Controlling Area Name'
    ControllingAreaName : String(25);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Credit Control Area'
  @sap.value.list : 'true'
  entity I_CreditControlAreaStdVH {
    @sap.display.format : 'UpperCase'
    @sap.text : 'CreditControlArea_Text'
    @sap.label : 'Credit Control Area'
    key CreditControlArea : String(4) not null;
    @sap.label : 'Description'
    @sap.quickinfo : 'Description of the credit control area'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CreditControlArea_Text : String(35);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Currency'
  entity I_Currency {
    @sap.display.format : 'UpperCase'
    @sap.text : 'Currency_Text'
    @sap.label : 'Currency'
    @sap.quickinfo : 'Currency Key'
    @sap.semantics : 'currency-code'
    key Currency : String(5) not null;
    @sap.label : 'Description'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    Currency_Text : String(40);
    @odata.Type : 'Edm.Byte'
    @sap.label : 'Decimal Places'
    @sap.quickinfo : 'Number of decimal places'
    Decimals : Integer;
    @sap.display.format : 'UpperCase'
    @sap.label : 'ISO Code'
    @sap.quickinfo : 'ISO Currency Code'
    CurrencyISOCode : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Alternative Key'
    AlternativeCurrencyKey : String(3);
    @sap.label : 'Primary'
    @sap.quickinfo : 'Primary SAP Currency Code for ISO Code'
    IsPrimaryCurrencyForISOCrcy : Boolean;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Customer'
  entity I_Customer {
    @sap.display.format : 'UpperCase'
    @sap.text : 'CustomerName'
    @sap.label : 'Customer'
    @sap.quickinfo : 'Customer Number'
    key Customer : String(10) not null;
    @sap.label : 'Name of Customer'
    CustomerName : String(80);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Name'
    @sap.quickinfo : 'Customer Full Name'
    CustomerFullName : String(220);
    @sap.label : 'Name of Customer'
    @sap.quickinfo : 'Customer Name'
    BPCustomerName : String(81);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Customer Name'
    @sap.quickinfo : 'Customer Full Name'
    BPCustomerFullName : String(220);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Created by'
    @sap.quickinfo : 'Name of Person who Created the Object'
    CreatedByUser : String(12);
    @sap.display.format : 'Date'
    @sap.label : 'Created On'
    @sap.quickinfo : 'Record Created On'
    CreationDate : Date;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Address'
    AddressID : String(10);
    @sap.display.format : 'UpperCase'
    @sap.text : 'CustomerClassification_Text'
    @sap.label : 'Customer Classific.'
    @sap.quickinfo : 'Customer Classification'
    CustomerClassification : String(2);
    @sap.label : 'Customer Classification Description'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CustomerClassification_Text : String(20);
    @sap.display.format : 'UpperCase'
    @sap.label : 'VAT Registration No.'
    @sap.quickinfo : 'VAT Registration Number'
    VATRegistration : String(20);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Account group'
    @sap.quickinfo : 'Customer Account Group'
    CustomerAccountGroup : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Authorization'
    @sap.quickinfo : 'Authorization Group'
    AuthorizationGroup : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Delivery block'
    @sap.quickinfo : 'Central delivery block for the customer'
    DeliveryIsBlocked : String(2);
    @sap.label : 'Posting Block'
    @sap.quickinfo : 'Central posting block'
    PostingIsBlocked : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Billing block'
    @sap.quickinfo : 'Central billing block for customer'
    BillingIsBlockedForCustomer : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Order block'
    @sap.quickinfo : 'Central order block for customer'
    OrderIsBlockedForCustomer : String(2);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Int. location no. 1'
    @sap.quickinfo : 'International Location Number (Part 1)'
    InternationalLocationNumber1 : String(7);
    @sap.label : 'One-time account'
    @sap.quickinfo : 'Indicator: Is the account a one-time account?'
    IsOneTimeAccount : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Jurisdiction'
    TaxJurisdiction : String(15);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Industry'
    @sap.quickinfo : 'Industry Key'
    Industry : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax number type'
    @sap.quickinfo : 'Tax Number Type'
    TaxNumberType : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Number 1'
    TaxNumber1 : String(16);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Number 2'
    TaxNumber2 : String(11);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Number 3'
    TaxNumber3 : String(18);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Number 4'
    TaxNumber4 : String(18);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Number 5'
    TaxNumber5 : String(60);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Number 6'
    TaxNumber6 : String(20);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Group key'
    CustomerCorporateGroup : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Supplier'
    @sap.quickinfo : 'Account Number of Supplier'
    Supplier : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Nielsen indicator'
    @sap.quickinfo : 'Nielsen ID'
    NielsenRegion : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Industry code 1'
    IndustryCode1 : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Industry code 2'
    IndustryCode2 : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Industry code 3'
    IndustryCode3 : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Industry code 4'
    IndustryCode4 : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Industry code 5'
    IndustryCode5 : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region Key'
    Country : String(3);
    @sap.label : 'Name'
    @sap.quickinfo : 'Name 1'
    OrganizationBPName1 : String(35);
    @sap.label : 'Name 2'
    OrganizationBPName2 : String(35);
    @sap.label : 'City'
    CityName : String(35);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Postal Code'
    PostalCode : String(10);
    @sap.label : 'Street'
    @sap.quickinfo : 'Street and House Number'
    StreetName : String(35);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Search term'
    @sap.quickinfo : 'Sort field'
    SortField : String(10);
    @sap.label : 'Fax Number'
    FaxNumber : String(31);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Suframa Code'
    BR_SUFRAMACode : String(9);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Region'
    @sap.quickinfo : 'Region (State, Province, County)'
    Region : String(3);
    @sap.label : 'Telephone 1'
    @sap.quickinfo : 'First telephone number'
    TelephoneNumber1 : String(16);
    @sap.label : 'Telephone 2'
    @sap.quickinfo : 'Second telephone number'
    TelephoneNumber2 : String(16);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Alternative Payer'
    @sap.quickinfo : 'Account Number of an Alternative Payer'
    AlternativePayerAccount : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'DME Recipient Code'
    @sap.quickinfo : 'Recipient Code for Data Medium Exchange'
    DataMediumExchangeIndicator : String(1);
    @sap.label : 'Liable for VAT'
    VATLiability : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Purpose Completed'
    @sap.quickinfo : 'Business Purpose Completed Flag'
    IsBusinessPurposeCompleted : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Tax Type'
    ResponsibleType : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Fiscal address'
    @sap.quickinfo : 'Account number of the master record with the fiscal address'
    FiscalAddress : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Natural Person'
    NFPartnerIsNaturalPerson : String(1);
    @sap.label : 'Deletion Flag'
    @sap.quickinfo : 'Central Deletion Flag for Master Record'
    DeletionIndicator : Boolean;
    @sap.label : 'Language Key'
    Language : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Trading Partner No.'
    @sap.quickinfo : 'Company ID of Trading Partner'
    TradingPartner : String(6);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Deliv Date Rule'
    @sap.quickinfo : 'Delivery Date Rule'
    DeliveryDateTypeRule : String(1);
    @sap.label : 'Express station'
    @sap.quickinfo : 'Express train station'
    ExpressTrainStationName : String(25);
    @sap.label : 'Train station'
    TrainStationName : String(25);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Int. location no. 2'
    @sap.quickinfo : 'International Location Number (Part 2)'
    InternationalLocationNumber2 : String(5);
    @sap.display.format : 'NonNegative'
    @sap.label : 'Check digit'
    @sap.quickinfo : 'Check digit for the international location number'
    InternationalLocationNumber3 : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'City Code'
    CityCode : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'County Code'
    County : String(3);
    @sap.label : 'Unloading points'
    @sap.quickinfo : 'Indicator: Unloading points exist'
    CustomerHasUnloadingPoint : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Working times'
    @sap.quickinfo : 'Working Time Calendar'
    CustomerWorkingTimeCalendar : String(2);
    @sap.label : 'Competitors'
    @sap.quickinfo : 'Indicator: Competitor'
    IsCompetitor : Boolean;
    @sap.label : 'Rep''s Name'
    @sap.quickinfo : 'Name of Representative'
    TaxInvoiceRepresentativeName : String(10);
    @sap.label : 'Type of Business'
    BusinessType : String(30);
    @sap.label : 'Type of Industry'
    IndustryType : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Consolidated Invoic.'
    @sap.quickinfo : 'Consolidated Invoicing for Taiwan'
    TW_CollvBillingIsSupported : String(1);
    @sap.label : 'Alt.payer in doc?'
    @sap.quickinfo : 'Indicator: Is an alternative payer allowed in document?'
    AlternativePayeeIsAllowed : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Attribute 1'
    FreeDefinedAttribute01 : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Attribute 2'
    FreeDefinedAttribute02 : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Attribute 3'
    FreeDefinedAttribute03 : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Attribute 4'
    FreeDefinedAttribute04 : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Attribute 5'
    FreeDefinedAttribute05 : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Attribute 6'
    FreeDefinedAttribute06 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Attribute 7'
    FreeDefinedAttribute07 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Attribute 8'
    FreeDefinedAttribute08 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Attribute 9'
    FreeDefinedAttribute09 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Attribute 10'
    FreeDefinedAttribute10 : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Payment Reason'
    PaymentReason : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition group 1'
    @sap.quickinfo : 'Customer condition group 1'
    CustomerConditionGroup1 : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition group 2'
    @sap.quickinfo : 'Customer condition group 2'
    CustomerConditionGroup2 : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition group 3'
    @sap.quickinfo : 'Customer condition group 3'
    CustomerConditionGroup3 : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition group 4'
    @sap.quickinfo : 'Customer condition group 4'
    CustomerConditionGroup4 : String(2);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Condition group 5'
    @sap.quickinfo : 'Customer condition group 5'
    CustomerConditionGroup5 : String(2);
    @sap.label : 'Prospect'
    @sap.quickinfo : 'Indicator: Sales prospect'
    IsSalesProspect : Boolean;
    @sap.label : 'Payment block'
    @sap.quickinfo : 'Payment Block'
    PaymentIsBlockedForCustomer : Boolean;
    @sap.label : 'Consumer'
    @sap.quickinfo : 'Indicator: Consumer'
    IsConsumer : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Ctrlr. Set'
    @sap.quickinfo : 'BP: Data Controller Set Flag'
    DataControllerSet : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController1 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController2 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController3 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController4 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController5 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController6 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController7 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController8 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController9 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController10 : String(30);
    @sap.label : 'Name'
    @sap.quickinfo : 'Name 1'
    BusinessPartnerName1 : String(40);
    @sap.label : 'Name 2'
    BusinessPartnerName2 : String(40);
    @sap.label : 'Name 3'
    BusinessPartnerName3 : String(40);
    @sap.label : 'Name 4'
    BusinessPartnerName4 : String(40);
    @sap.label : 'City'
    BPAddrCityName : String(40);
    @sap.label : 'Street'
    BPAddrStreetName : String(60);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Search Term 1'
    AddressSearchTerm1 : String(20);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Search Term 2'
    AddressSearchTerm2 : String(20);
    @sap.label : 'District'
    DistrictName : String(40);
    @sap.label : 'PO Box City'
    @sap.quickinfo : 'PO Box city'
    POBoxDeviatingCityName : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Title Key'
    @sap.quickinfo : 'Form-of-Address Key'
    BusinessPartnerFormOfAddress : String(4);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Customer Payment Terms'
  entity I_CustomerPaymentTerms {
    @sap.display.format : 'UpperCase'
    @sap.text : 'CustomerPaymentTerms_Text'
    @sap.label : 'Terms of Payment'
    @sap.quickinfo : 'Terms of Payment Key'
    key CustomerPaymentTerms : String(4) not null;
    @sap.label : 'Description'
    @sap.quickinfo : 'Description of terms of payment'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    CustomerPaymentTerms_Text : String(30);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Customer'
  @sap.value.list : 'true'
  entity I_Customer_VH {
    @sap.display.format : 'UpperCase'
    @sap.text : 'BPCustomerName'
    @sap.label : 'Customer'
    @sap.quickinfo : 'Customer Number'
    key Customer : String(10) not null;
    @sap.label : 'Customer Name 1'
    @sap.quickinfo : 'Name 1'
    OrganizationBPName1 : String(35);
    @sap.label : 'Business Partner Name 1'
    @sap.quickinfo : 'Name 1'
    BusinessPartnerName1 : String(40);
    @sap.label : 'Customer Name 2'
    @sap.quickinfo : 'Name 2'
    OrganizationBPName2 : String(35);
    @sap.label : 'Business Partner Name 2'
    @sap.quickinfo : 'Name 2'
    BusinessPartnerName2 : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Country/Region'
    @sap.quickinfo : 'Country/Region Key'
    Country : String(3);
    @sap.label : 'City'
    CityName : String(35);
    @sap.label : 'Business Partner Address City'
    @sap.quickinfo : 'City'
    BPAddrCityName : String(40);
    @sap.label : 'Street'
    @sap.quickinfo : 'Street and House Number'
    StreetName : String(35);
    @sap.label : 'Business Partner Address Street'
    @sap.quickinfo : 'Street'
    BPAddrStreetName : String(60);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Postal Code'
    PostalCode : String(10);
    @sap.label : 'Customer Name'
    @sap.quickinfo : 'Name of Customer'
    CustomerName : String(80);
    @sap.label : 'Business Partner Customer Name'
    @sap.quickinfo : 'Customer Name'
    BPCustomerName : String(81);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Account group'
    @sap.quickinfo : 'Customer Account Group'
    CustomerAccountGroup : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Authorization'
    @sap.quickinfo : 'Authorization Group'
    AuthorizationGroup : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Purpose Complete Flag'
    @sap.quickinfo : 'Business Purpose Completed Flag'
    IsBusinessPurposeCompleted : String(1);
    @sap.label : 'Competitors'
    @sap.quickinfo : 'Indicator: Competitor'
    IsCompetitor : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Business Partner'
    @sap.quickinfo : 'Business Partner Number'
    BusinessPartner : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Business Partner Type'
    BusinessPartnerType : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Ctrlr. Set'
    @sap.quickinfo : 'BP: Data Controller Set Flag'
    DataControllerSet : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController1 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController2 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController3 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController4 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController5 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController6 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController7 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController8 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController9 : String(30);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Data Controller'
    @sap.quickinfo : 'BP: Data Controller (Internal Use Only)'
    DataController10 : String(30);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Incoterms Classification'
  entity I_IncotermsClassification {
    @sap.display.format : 'UpperCase'
    @sap.text : 'IncotermsClassification_Text'
    @sap.label : 'Incoterms'
    @sap.quickinfo : 'Incoterms (Part 1)'
    key IncotermsClassification : String(3) not null;
    @sap.label : 'Incoterms Classification Description'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    IncotermsClassification_Text : String(30);
    @sap.label : 'Location Mandatory'
    @sap.quickinfo : 'Location is mandatory'
    LocationIsMandatory : Boolean;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Overall Billing Status'
  entity I_OverallBillingStatus {
    @sap.display.format : 'UpperCase'
    @sap.text : 'OverallBillingStatus_Text'
    @sap.label : 'Status'
    @sap.quickinfo : 'SD Billing Status'
    key OverallBillingStatus : String(1) not null;
    @sap.label : 'Short Description'
    @sap.quickinfo : 'Short Text for Fixed Values'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    OverallBillingStatus_Text : String(60);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Product Value Help'
  entity I_ProductStdVH {
    @sap.display.format : 'UpperCase'
    @sap.text : 'Product_Text'
    @sap.label : 'Product'
    @sap.quickinfo : 'Product Number'
    key Product : String(18) not null;
    @sap.label : 'Product Description'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    Product_Text : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'External Product ID'
    @sap.quickinfo : 'External Representation of Material Number'
    ProductExternalID : String(40);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Sales Organization'
  entity I_SalesOrganization {
    @sap.display.format : 'UpperCase'
    @sap.text : 'SalesOrganization_Text'
    @sap.label : 'Sales Organization'
    key SalesOrganization : String(4) not null;
    @sap.label : 'Sales Organization Description'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    SalesOrganization_Text : String(20);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Statistics Currency'
    @sap.quickinfo : 'Statistics currency'
    @sap.semantics : 'currency-code'
    SalesOrganizationCurrency : String(5);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_CompanyCode/CompanyCodeName'
    @sap.label : 'Company Code'
    @sap.quickinfo : 'Company code of the sales organization'
    @sap.value.list : 'standard'
    CompanyCode : String(4);
    @sap.display.format : 'UpperCase'
    @sap.text : 'to_IntercompanyBillingCustomer/CustomerName'
    @sap.label : 'Customer Interc. Bl.'
    @sap.quickinfo : 'Customer Number for Intercompany Billing'
    @sap.value.list : 'standard'
    IntercompanyBillingCustomer : String(10);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Address'
    AddressID : String(10);
    to_CompanyCode : Association to I_CompanyCode {  };
    to_IntercompanyBillingCustomer : Association to I_Customer {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'SD Document Category'
  entity I_SDDocumentCategory {
    @sap.text : 'SDDocumentCategory_Text'
    @sap.label : 'SD Document Category'
    key SDDocumentCategory : String(4) not null;
    @sap.label : 'SD Document Category Description'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    SDDocumentCategory_Text : String(60);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Service Transaction Type'
  entity I_ServiceDocumentType {
    @sap.display.format : 'UpperCase'
    @sap.text : 'ServiceDocumentType_Text'
    @sap.label : 'Transaction Type'
    @sap.quickinfo : 'Business Transaction Type'
    key ServiceDocumentType : String(4) not null;
    @sap.label : 'Description'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ServiceDocumentType_Text : String(40);
    @sap.display.format : 'UpperCase'
    @sap.text : 'ServiceObjectType_Text'
    @sap.label : 'Trans. Category'
    @sap.quickinfo : 'Leading Business Transaction Category'
    ServiceObjectType : String(10);
    @sap.label : 'Name'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    ServiceObjectType_Text : String(20);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Team Profile'
    @sap.quickinfo : 'Service Team Profile'
    CustMgmtServiceTeamProfile : String(12);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Process Profile'
    @sap.quickinfo : 'Profile for Process Step Overview'
    SrvcProcessStepOverviewProfile : String(8);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Template Type'
    @sap.quickinfo : 'Service Transaction: Template Type'
    ServiceDocumentTemplateType : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Inactive'
    @sap.quickinfo : 'Active Indicator: Transaction'
    SrvcDocTypeBlockingStatus : String(1);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Status Profile'
    StatusProfile : String(8);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Rejection Profile'
    @sap.quickinfo : 'Rejection Profile Name'
    SrvcRejectionReasonProfile : String(8);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.searchable : 'true'
  @sap.content.version : '1'
  @sap.label : 'Unit of Measure'
  entity I_UnitOfMeasure {
    @sap.text : 'UnitOfMeasure_Text'
    @sap.label : 'Unit of Measure'
    @sap.semantics : 'unit-of-measure'
    key UnitOfMeasure : String(3) not null;
    @sap.label : 'Meas. Unit Text'
    @sap.quickinfo : 'Unit of Measurement Text (Maximum 30 Characters)'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    UnitOfMeasure_Text : String(30);
    @sap.label : 'Internal SAP Code'
    @sap.quickinfo : 'Unit of Measurement, Internal SAP Code (No Conversion)'
    UnitOfMeasureSAPCode : String(3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'ISO Code'
    @sap.quickinfo : 'ISO Code for Unit of Measurement'
    UnitOfMeasureISOCode : String(3);
    @sap.label : 'Primary code'
    @sap.quickinfo : 'Selection field for conversion from ISO code to int. code'
    IsPrimaryUnitForISOCode : Boolean;
    @sap.label : 'Decimal Rounding'
    @sap.quickinfo : 'No. of decimal places for rounding'
    UnitOfMeasureNumberOfDecimals : Integer;
    @sap.label : 'Commercial Unit'
    @sap.quickinfo : 'Commercial measurement unit ID'
    UnitOfMeasureIsCommercial : Boolean;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Dimension'
    @sap.quickinfo : 'Dimension key'
    UnitOfMeasureDimension : String(6);
    @sap.label : 'Numerator'
    @sap.quickinfo : 'Numerator for conversion to SI unit'
    SIUnitCnvrsnRateNumerator : Integer;
    @sap.label : 'Denominator'
    @sap.quickinfo : 'Denominator for conversion into SI unit'
    SIUnitCnvrsnRateDenominator : Integer;
    @sap.label : 'Exponent'
    @sap.quickinfo : 'base ten exponent for conversion to SI unit'
    SIUnitCnvrsnRateExponent : Integer;
    @sap.label : 'Additive constant'
    @sap.quickinfo : 'Additive constant for conversion to SI unit'
    SIUnitCnvrsnAdditiveValue : Decimal(9, 6);
    @sap.label : 'Exp. 10 Floating Pt'
    @sap.quickinfo : 'Exponent of 10 for Floating Point Format'
    UnitOfMeasureDspExponent : Integer;
    @sap.label : 'Decimal Places'
    @sap.quickinfo : 'Number of Decimal Places for Number Display'
    UnitOfMeasureDspNmbrOfDcmls : Integer;
    @sap.unit : 'UnitOfMeasureTemperatureUnit'
    @sap.label : 'Temperature'
    UnitOfMeasureTemperature : Double;
    @sap.label : 'Temperature unit'
    @sap.semantics : 'unit-of-measure'
    UnitOfMeasureTemperatureUnit : String(3);
    @sap.unit : 'UnitOfMeasurePressureUnit'
    @sap.label : 'Pressure Value'
    UnitOfMeasurePressure : Double;
    @sap.label : 'Unit of Pressure'
    @sap.semantics : 'unit-of-measure'
    UnitOfMeasurePressureUnit : String(3);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  entity SAP__Currencies {
    @sap.label : 'Currency'
    @sap.semantics : 'currency-code'
    key CurrencyCode : String(5) not null;
    @sap.label : 'ISO code'
    ISOCode : String(3) not null;
    @sap.label : 'Short text'
    Text : String(15) not null;
    @odata.Type : 'Edm.Byte'
    @sap.label : 'Decimals'
    DecimalPlaces : Integer not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  entity SAP__UnitsOfMeasure {
    @sap.label : 'Internal UoM'
    @sap.semantics : 'unit-of-measure'
    key UnitCode : String(3) not null;
    @sap.label : 'ISO Code'
    ISOCode : String(3) not null;
    @sap.label : 'Commercial'
    ExternalCode : String(3) not null;
    @sap.label : 'Meas. Unit Text'
    Text : String(30) not null;
    @sap.label : 'Decimal Places'
    DecimalPlaces : Integer;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  entity SAP__MyDocumentDescriptions {
    @sap.label : 'UUID'
    key Id : UUID not null;
    CreatedBy : String(12) not null;
    @odata.Type : 'Edm.DateTime'
    @sap.label : 'Time Stamp'
    CreatedAt : DateTime not null;
    FileName : String(256) not null;
    Title : String(256) not null;
    Format : Association to SAP__FormatSet {  };
    TableColumns : Association to many SAP__TableColumnsSet {  };
    CoverPage : Association to many SAP__CoverPageSet {  };
    Signature : Association to SAP__SignatureSet {  };
    PDFStandard : Association to SAP__PDFStandardSet {  };
    Hierarchy : Association to SAP__HierarchySet {  };
    Header : Association to SAP__PDFHeaderSet {  };
    Footer : Association to SAP__PDFFooterSet {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity SAP__FormatSet {
    @sap.label : 'UUID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Id : UUID not null;
    FitToPage : SAP__FitToPage not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    FontSize : Integer not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    Orientation : String(10) not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    PaperSize : String(10) not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    BorderSize : Integer not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    MarginSize : Integer not null;
    @sap.label : 'Font Name'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    FontName : String(255) not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    Padding : Integer not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity SAP__PDFStandardSet {
    @sap.label : 'UUID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Id : UUID not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    UsePDFAConformance : Boolean not null;
    @sap.label : 'Indicator'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    DoEnableAccessibility : Boolean not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity SAP__TableColumnsSet {
    @sap.label : 'UUID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Id : UUID not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Name : String(256) not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Header : String(256) not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    HorizontalAlignment : String(10) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity SAP__CoverPageSet {
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Title : String(256) not null;
    @sap.label : 'UUID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Id : UUID not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Name : String(256) not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    Value : String(256) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity SAP__SignatureSet {
    @sap.label : 'UUID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Id : UUID not null;
    @sap.label : 'Indicator'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    DoSign : Boolean not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    Reason : String(256) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity SAP__HierarchySet {
    @sap.label : 'UUID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Id : UUID not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    DistanceFromRootElement : String(256) not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    DrillStateElement : String(256) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity SAP__PDFHeaderSet {
    @sap.label : 'UUID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Id : UUID not null;
    Right : SAP__HeaderFooterField not null;
    Left : SAP__HeaderFooterField not null;
    Center : SAP__HeaderFooterField not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity SAP__PDFFooterSet {
    @sap.label : 'UUID'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Id : UUID not null;
    Right : SAP__HeaderFooterField not null;
    Left : SAP__HeaderFooterField not null;
    Center : SAP__HeaderFooterField not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.content.version : '1'
  entity SAP__ValueHelpSet {
    key VALUEHELP : String not null;
    FIELD_VALUE : String(10) not null;
    DESCRIPTION : String;
  };

  @cds.external : true
  type SAP__FitToPage {
    @sap.label : 'Error behavior'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    ErrorRecoveryBehavior : String(8) not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    IsEnabled : Boolean not null;
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    MinimumFontSize : Integer not null;
  };

  @cds.external : true
  type SAP__HeaderFooterField {
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    Type : String(256) not null;
  };
};

