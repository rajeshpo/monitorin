// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Value Chain Monitoring App
// Object Id       : ZBUVCM55155
// Release         : 1
// Version         : 0.01
// Description     : Value Chain Monitoring App
// ----------------------------------------------------------------------------*
// Descriptions:  Provides service definitions, data model projections, and custom actions for managing Value Chain Monitoring App.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   | masterDataErrorDesciption  Change Id   |  Change Description
// ----------------------------------------------------------------------------*

using jnj.com.zbuvcm55155 as db from '../db/zbuvcm55155schema';
using ZSD_VCM_PRODUCTFLOW from './external/ZSD_VCM_PRODUCTFLOW';
using ZUI_BILLINGDOCUMENTFS from './external/ZUI_BILLINGDOCUMENTFS';


@path    : '/zbuvcm55155'
@requires: 'authenticated-user'
service zbuvcm55155Service {

    //Hana DB table
    @cds.redirection.target
    entity ShippingRequest                      as projection on db.ShippingRequest;

    @cds.redirection.target
    entity EntityDocs                           as projection on db.ShippingRequestEntityDocs;

    entity ShippingRequestItem                  as projection on db.ShippingRequestItem;

    entity ShippingRequestErrors                as projection on db.ShippingRequestErrors;

    entity ShippingRequestWithErrors            as projection on db.ShippingRequestWithErrors;

    //Open Items JGHJ-87133 R2.2 change start
    @readonly
    entity asnOrphanDocs                        as projection on db.asnOrphanDocs;
    //Open Items JGHJ-87133 R2.2 change end

    entity ShippingRequestPrereqStatus          as projection on db.ShippingRequestPrereqStatus;


    entity ShippingRequestEntityLocationSummary as projection on db.ShippingRequestEntityLocationSummary;

    entity ShippingRequestQueue                   as projection on db.ShippingRequestQueue;

    entity QueueRequestErrors               as projection on db.QueueRequestErrors;
        

    // start - R2.2 Non VCA 76044
    entity NonVCAScenarioConfig                 as projection on db.NonVCAScenarioConfig;

    // start - R2.2 Non VCA 76044
    @readonly
    @restrict: [
        {
            grant: ['*'],
            to   : [
                'XS2-VCM-APP-MONIT-DSP-SCA',
                'XS2-VCM-APP-MONIT-SCA'
            ],
            where: 'shippingReqNo like ''S%'''
        },
        {
            grant: ['*'],
            to   : [
                'XS3-VCM-APP-MONIT-DSP',
                'XS2-VCM-APP-MONIT-MNT'
            ],
            where: 'shippingReqNo like ''V%'''
        }
    ]
    entity ShippingRequestView                  as projection on db.ShippingRequestWithLocations

        actions {
            //  @(restrict: [{to: 'XS2-VCM-APP-MONIT-MNT'}])
            @(
                cds.odata.bindingparameter.name: '_it',
                Common.SideEffects             : {TargetEntities: ['_it']}
            )
            action Reprocess();

            action addComment(
                              @UI.MultiLineText: true
                              comment: String @title: '{i18n>comment}' ) returns String;

        }

    entity emailNotifyEntity                    as projection on db.EmailNotify;

    // @odata.draft.enabled
    @(restrict: [{to: [
        'XS3-VCM-MONDL-SUP',
        'XS2-VCM-MONDL-IT'
    ]}])
    entity emailNotifyEntityForUI               as projection on db.EmailNotify;


    entity I_BP_VH                              as
        projection on ZSD_VCM_PRODUCTFLOW.Massbpplantcntrykey {
            key BusinessPartner,
                BusinessPartnerName,
            key Plant,
            key Country as CountryCode,
        };

    entity I_P_VH                               as
        projection on ZSD_VCM_PRODUCTFLOW.Massplantbpcntrykey {
            key Plant,
                PlantName,
                BusinessPartner,
                Country as CountryCode
        };


    entity ShippingRequest_VH                   as
        projection on db.ShippingRequest_VH {
            key shippingReqNo
        };

    entity ShippingRequest_VH1                  as
        projection on db.ShippingRequest_VH1 {
            key initialDocumentNo
        };

    entity ShippingRequest_VH2                  as
        projection on db.ShippingRequest_VH2 {
            key referenceDocumentNo @(Common.Label: '{i18n>Referencedocumentno}'),
        };

    entity I_ProcessingStage_VH {
        key Desc : String
    }

    entity I_Type_VH {
        key Type : String;
    }

    type VirtualEntityInput    : {
        SeqNo         : Integer;
        VirtualEntity : String(20); //missing
        legalEntity   : String(20); //legalEntity
    }

    type ShippingLineItemInput : {
        initialDocumentNo     : String(30); //initialDocumentNo
        DocLineItem           : String(10); //documentNumber
        CreationDate          : Date; // errorCreationDate
        DocType               : String(10); //documentType
        referenceDocumentNo   : String(35); //referenceDocumentNo
        requestedDeliveryDate : Date; //requestedDeliveryDate
        productFlowCatalogID  : String(20); //productFlowCatalogID
        productFlowID         : String(20); //productFlowID
        UserId                : String(50); //ID
        SF_BP                 : String(20); //businessPartnerId
        SF_P                  : String(10); //plant
        SF_Er                 : String(10); //ecoRegion
        ST_BP                 : String(20); //businessPartnerId
        ST_P                  : String(10); //plant
        ST_Er                 : String(10); //ecoRegion
        VirtualEntity         : many VirtualEntityInput;
        materialNumber        : String(30); //materialNumber
        materialBrand         : String(30); //materialBrand
        quantity              : String(10); //quantity
        uom                   : String(10); //uom
        batchNumber           : String(30); //batchNumber
    }

    type OutputPayload         : {
        productFlowCatalogID : String(20);
        shippingReqNo        : String(18);
        initialDocumentNo    : String(10);
    }

    type item {
        materialNumber      : String;
        itemNo              : String;
        materialType        : String;
        materialBrand       : String;
        materialDescription : String;
        quantity            : String;
        uom                 : String;
        status              : String;
        batchNumber         : String;
        requestedDeliveryDate : String;
    }

    type InputPayload {
        initialDocumentNo       : String(30);
        initialDocumentType     : String(50);
        referenceDocumentNo     : String(35);
        requestedDeliveryDate   : Date;
        creationDate            : Date;
        userName                : String(20);
        shipFromBusinessPartner : String(10);
        shipFromPlant           : String(10);
        shipToBusinessPartner   : String(10);
        shipToPlant             : String(10);
        shipFromEr              : String;
        shipToEr                : String;
        soType                  : String;
        items                   : many item;

    }

    type veitems {
        VirtualEntity : String(18);
        legalEntity   : String(10);
        SeqNo         : String(18);
        VE_BP         : String;
    }

    type UpdatePFCCheck {
        ID            : String;
        PfcCatId      : String(18);
        ProdId        : String;
        BpSFrom       : String(18);
        PlantSFrom    : String(10);
        ErSFrom       : String(18);
        BpSTo         : String(10);
        PlantSTo      : String(18);
        ErSTo         : String(10);
        Matnr         : String(18);
        MatBrand      : String(10);
        itemNo        : String;

        VirtualEntity : many veitems;
    }

    type UpdateHeaderData {
        ID                                  : String;
        initialDocumentType                 : String(50);
        referenceDocumentNo                 : String(35);
        followOnDocumentNo                  : String(20);
        status                              : String(11);
        requestedDeliveryDate               : Date;
        scenarioID                          : String(20);
        masterDataStatus                    : String(20);
        masterDataErrorDesciption           : String;
        scenarioDeterminationCheckStatus    : String(20);
        scenarioCheckStatusErrorDescription : String;
        docFlowStateCheckStatus             : String(20);
        pfcCheckStatus                      : String(20);
        pfcCheckErrorDescription            : String;
        wfInstanceId                        : String(80);
        productFlowCatalogID                : String(14);
        productFlowID                       : String;
        creationDate                        : Date;
        userName                            : String(9);
        shipFromBusinessPartner             : String(10);
        shipFromPlant                       : String(10);
        shipToBusinessPartner               : String(10);
        shipToPlant                         : String(10);
        pfcCheckErrorResolutionDate         : Timestamp;
        scenarioCheckErrorResolutionDate    : Timestamp;
        masterDataErrorResolutionDate       : Timestamp;
    }

    type UpdateErrorTable {
        ID               : String;
        documentSequence : Integer;
        wfInstanceId     : String(80);
        errorStatus      : String(20);
        errorDescription : String;
        vcaErrorStatus   : String;
        vcaErrorType     : String(100);
    }

    type UpdateEntityTable {
        ID                 : String;
        creationDate       : Date;
        followOnDocumentNo : String(20);
        plant              : String(10);
        documentType       : String(30);
        documentNumber     : String(20);
        errorDescription   : String;
        documentYear       : String;
        legalEntity        : String(20);

    }

    type UpdateCancellation {
        ID               : String;
        errorDescription : String;
        errorStatus      : String;
    }

    type docs {
        Action          : String;
        ArchType        : String;
        Description     : String;
        Entity          : String;
        Pair            : String;
        Sequence        : Integer;
        Steps           : String;
        transactionDesc : String;
        System          : String;
        Variation       : Integer;
        EntityType      : String;
        //R2.2 Start
        vcaAction       : String(1);
        vcaDocSystem    : String(12);
        stepID          : String;
    //R2.2 END
    }

    type ScenarioSteps {
        ID                : String;
        shippingReqNo     : String(18);
        initialDocumentNo : String(18);
        SID               : String(20);
        steps             : many docs

    }

    type ExceptionalDocs {
        EntityType      : String;
        Sequence        : Integer;
        Steps           : String;
        transactionDesc : String;
        plant           : String;
        legalEntity     : String;
        status          : String;
        stepID          : String;
    }

    type ExceptionalDocsPayload {
        ID    : String; //headerID
        steps : many ExceptionalDocs;
    }

    type retainBagDocsPayload {
        ID : String; //headerID
    }

    type EntityForAt {
        soNumber                         : String(20); // Initial document number
        cquenceNumber                    : String(20); // Reference document number
        entityRank                       : Integer;
        legalEntity                      : String(20);
        plant                            : String(10);
        plantName                        : String(50);
        businessPartnerId                : String(10);
        businessPartnerName              : String(50);
        batchNo                          : String(20);
        subconPO                         : String(20);
        subconPOType                     : String(4);
        subconPODescription              : String(20);
        apPO                             : String(20);
        apPOType                         : String(4);
        apPODescription                  : String(20);
        ibd                              : String(20);
        flashSO                          : String(20);
        obd                              : String(20);
        arInvoice                        : String(20);
        flashPO                          : String(20);
        flashPOType                      : String(4);
        flashPODescription               : String(20);
        apInvoice                        : String(20);
        BT_FP                            : String(20);
        salesOrderCreationDate           : Date;
        purchaseOrderCreationDate        : Date;
        outboundDeliveryCreationDate     : Date;
        customerInvoiceCreationDate      : Date;
        btfpCreationDate                 : Date;
        salesOrderStatus                 : String(20);
        purchaseOrderStatus              : String(20);
        ibdStatus                        : String(20);
        outboundDeliveryStatus           : String(20);
        customerInvoiceStatus            : String(20);
        btfpStatus                       : String(20);
        salesOrderErrorDescription       : String;
        purchaseOrderErrorDescription    : String;
        outboundDeliveryErrorDescription : String;
        customerInvoiceErrorDescription  : String;
    }

    type HeaderReqAT           : many {
        initialDocumentNo   : String(30);
        referenceDocumentNo : String(35);
    }

    type HeaderForAt {
        initialDocumentNo   : String(30);
        referenceDocumentNo : String(35);
        batchNumber         : String;
        subconPO_V1         : String(20);
        AFPO_V1             : String(20);
        IBD_V1              : String(20);
        IBD_Status          : String(10);
        OBD_V3              : String(20);
        AR_V3               : String(20);
        Status              : String(11);
        PGI_Date            : Date;
        Error               : String;
    }

    type updateItemData1 {
        ID                  : UUID;
        followOnDocumentNo  : String;
        itemNo              : String;
        materialNumber      : String;
        materialType        : String;
        materialBrand       : String;
        materialDescription : String;
        quantity            : String;
        uom                 : String;
        batchNumber         : String;
        AF_FZ_Mat           : String(20);
        RETAINBAG_Mat       : String(20);
        AF_FRSH_Mat         : String(20);
    }

    type updateItemDataCancellationAndPoChange {
        purchaseOrder           : String;
        purchaseOrderItem       : String;
        status                  : String;
        type                    : String;
        quantity                : String;
        deliveryDate            : String;
    }

    type processLegacyOutboundPayload {
        OBD            : String;
        ref_SO         : String;
        itemNo         : String;
        quantity       : String;
        materialNumber : String;
        batch          : String;
        unit           : String;
        wfID           : String; ////Open Items JGHJ-87133 R2.2 change
        portId         : String;
    }

    @Capabilities: {SearchRestrictions: {
        $Type     : 'Capabilities.SearchRestrictionsType',
        Searchable: false
    }, }
    entity I_BPST_VH                            as
        projection on ZUI_BILLINGDOCUMENTFS.I_Customer {
            key Customer,
                BPCustomerName,
                Country,
        };

    action   updateShippingRequestItem(payload: updateItemData1)                                   returns ShippingRequestItem;
    action   ShippingRequestItemCancellationAndPoChange(payload: updateItemDataCancellationAndPoChange)                  returns ShippingRequestItem;

    action   updateheaderdata(payload: UpdateHeaderData)                                           returns String;
    action   updateErrorTable(payload: UpdateErrorTable)                                           returns String;
    action   updateEntitytable(payload: UpdateEntityTable)                                         returns String;
    action   updatePFCCheck(payload: UpdatePFCCheck)                                               returns String;
    action   updateScenarioSteps(payload: ScenarioSteps)                                           returns String;
    action   updateScenario3Steps(payload: ScenarioSteps)                                          returns String;
    action   processLegacyOutbound(payload: array of processLegacyOutboundPayload)                 returns String;

    action   createShippingRequest(payload: InputPayload)                                          returns String;
    action   getHeaderDetailsWithRef(referenceDocumentNo: String(35))                              returns String;
    action   getLocationSummary(shippingReqNo: String)                                             returns array of ShippingRequestEntityLocationSummary;
    action   updateExceptionalDocs(payload: ExceptionalDocsPayload)                                returns String;
    action   remanufacturingDocs(payload: ExceptionalDocsPayload)                                  returns String;
    action   retainBagDocs(payload: ExceptionalDocsPayload)                                        returns String;


    // AT Calls this function to get the legal entities and their documents
    function getLegalEntityDetails(initialDocumentNo: String(30), referenceDocumentNo: String(35)) returns array of EntityForAt;

    // AT Calls this action to get the header details
    action   getHeaderDetails(payload: HeaderReqAT)                                                returns array of HeaderForAt;

    action   getMaterialData(initialDocumentNo: String,
                             shippingReqNo: String)                                                returns String;

    action   updateCancellation(payload: UpdateCancellation)                                            returns String;
    action   QueueCompleted(queueId: String, flag: String)                                              returns String;

    @(
        cds.odata.bindingparameter.name: '_it',
        Common.SideEffects             : {TargetEntities: ['_it']}
    )
    action   reprocessQueueItem(PO: String)                                                                 returns String;
    action   QueueInError(queueId: String)                                                                 returns String;
    action   QueueSuccessMsg(queueID: String, errorMessage: String, documentNumber: String)                                         returns String;


    @odata.singleton

    entity FeatureControl {
        operationHidden : Boolean;
    }

    // entity ShippingRequestEntityFollowOnDocs as projection on db.ShippingRequestEntityFollowOnDocs;
    entity ShippingRequestEntityFollowOnDocs    as projection on db.ShippingRequestEntityFollowOnDocs
                                                   order by
                                                       itemNo asc;

    // start - R2.2 Non VCA 76044
    action   createscashippingRequest(payload: InputPayload)                                       returns String;
//End - R2.2 Non VCA 76044

}

//R2.2 Start
@path: '/zbuvcm55155job'
// @requires: 'system-user'
service zbuvcm55155JobService {

    function runShippingRequestReprocessJob()                                                      returns String;

    // GR Batch Job
    function runGRBatchJob()                                                                       returns String;

    //AP Batch Job

    function runAPBatchJob()                                                                       returns String;
    
    //Open Items JGHJ-87133 R2.2 change start
    function runASNBatchJob()                                                                      returns String;
    //Open Items JGHJ-87133 R2.2 change end
}
//R2.2 END
