// --------------------------------------------------------------------------------------------------------------------*
// Application Name : Value Chain Monitoring App
// Object Id       : ZBUVCM55155
// Release         : 1
// Version         : 0.01
// Description     : Value Chain Monitoring App
// ----------------------------------------------------------------------------*
// Descriptions: Constant values for all node js files
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
// ----------------------------------------------------------------------------*

module.exports = Object.freeze({
    "ProcessingStage": [
        { Desc: 'In Progress' },
        { Desc: 'Completed' },
        { Desc: 'Error' },
    ],
    "definitionId": "us10.jnj-im-dev-na.zvcm47419productflowapprovalproject.zVCM47419_ProductFlowApprovalProcess",
    "workflowURL": "/public/workflow/rest/v1/workflow-instances/",
    "BTPLoging": 'BTP Logging:- ',
    "SFError": "Error connecting to ABAP Service",
    "TypeDL": [
        { "Type": "AT" },
        { "Type": "VCM" }
    ],
    "ATMAPPING": {
        'Subcontracting PO': 'subconPO',
        'Apheresis PO': 'apPO',
        'AP INVOICE': 'apInvoice',
        'INTERCOMPANY SO': 'flashSO',
        'Finished Product Batch': 'BT_FP',
        'INTERCOMPANY PO': 'flashPO',
        'OUTBOUND DELIVERY': 'obd',
        'AR INVOICE': 'arInvoice'
    },
    "ATMETA": {
        BT_FP: { dateCol: 'btfpCreationDate', statusCol: 'btfpStatus', descriptionCol: 'btfpErrorDescription' },
        apPO: { dateCol: 'apPOCreationDate', statusCol: 'apPOStatus', descriptionCol: 'apPOErrorDescription' },
        flashSO: { dateCol: 'salesOrderCreationDate', statusCol: 'salesOrderStatus', descriptionCol: 'salesOrderErrorDescription' },
        flashPO: { dateCol: 'purchaseOrderCreationDate', statusCol: 'purchaseOrderStatus', descriptionCol: 'purchaseOrderErrorDescription' },
        obd: { dateCol: 'outboundDeliveryCreationDate', statusCol: 'outboundDeliveryStatus', descriptionCol: 'outboundDeliveryErrorDescription' },
        // ibd: { dateCol: 'ibdCreationDate', statusCol: 'inbPurchaseOrderStatus', descriptionCol: 'inbPurchaseOrderErrorDescription' },
        arInvoice: { dateCol: 'customerInvoiceCreationDate', statusCol: 'customerInvoiceStatus', descriptionCol: 'customerInvoiceErrorDescription' },
        apInvoice: { dateCol: 'supplierInvoiceCreationDate', statusCol: 'supplierInvoiceStatus', descriptionCol: 'supplierInvoiceErrorDescription' }
    },
    "ATHEADERS": [
        'soNumber',
        'cquenceNumber',
        'entityRank',
        'legalEntity',
        'plant',
        'plantName',
        'businessPartnerId',
        'businessPartnerName',
        'BT_FP',
        'batchNo',
        'subconPO',
        'apPO',
        'apPOCreationDate',
        'apPOStatus',
        'apPOErrorDescription',
        'ibd',
        'flashSO',
        'obd',
        'arInvoice',
        'flashPO',
        'apInvoice',
        'supplierInvoiceStatus',
        'btfpCreationDate',
        'salesOrderCreationDate',
        'purchaseOrderCreationDate',
        'outboundDeliveryCreationDate',
        'ibdCreationDate',
        'customerInvoiceCreationDate',
        'supplierInvoiceCreationDate',
        'salesOrderStatus',
        'purchaseOrderStatus',
        'ibdStatus',
        'outboundDeliveryStatus',
        'customerInvoiceStatus',
        'btfpStatus',
        'salesOrderError',
        'purchaseOrderError',
        'ibdError',
        'outboundDeliveryError',
        'customerInvoiceError',
        'btfpError',
        'btfpErrorDescription',
        'salesOrderErrorDescription',
        'purchaseOrderErrorDescription',
        'outboundDeliveryErrorDescription',
        'customerInvoiceErrorDescription',
        'supplierInvoiceErrorDescription',
    ],

    "ReprocessJobStarted": "Reprocess Job Started",
    "SR_REPROCESS_JOB": "SR_REPROCESS_JOB",
    "NoShippingRequestsinError": "No Shipping Requests in Error",
    "Processingbatch": "Processing batch",
    "ReprocessingSR": "Reprocessing SR",
    "reprocessedsuccessfully": "reprocessed successfully",
    "failed": "failed",
    "TotalSRstoreprocess": "Total SRs to reprocess",

    'GR': 'GR',
    'M': 'M',
    "Waiting": "Waiting",
    "NoValidGRRecordsarepresent": "No Valid GR Records are present",
    'value': '109',
    //Open Items JGHJ-87133 R2.2 change start
    'stepID_OBD': 'L_OBD',
    'successStatus': 'Success',
    'activeStatus': 'A',
    'statusS': 'S',
    'statusF': 'F',
    //Open Items JGHJ-87133 R2.2 change end
    'errorStatus': 'Success',
    'errordescription': 'Goods Receipt updated successfully - ',
    'Nogrfound': 'No successful GR updates found:',
    'recordsfromS4': 'records sent from S4',
    'updated': 'Updated',
    'recordsuccessfull': 'records successfully in HANA DB',
    'NoAPfound': 'No successful AP updates found:',
    'API': 'API',
    'I': 'I',
    'NoAPrecord': 'No Valid AP records are present',
    'L_ARI': 'L_ARI',
    'errordescriptionAP': 'AP Invoice Updated successfully - ',
    'errordescriptionAR': 'AR Invoice Updated successfully - ',
    'BatchAP': '/BatchAP',
    'ZSD_VCM_AUTOMATIONFLW': 'ZSD_VCM_AUTOMATIONFLW0001',
    'ICPO' : 'ICPO',
    'ICFPO': 'ICFPO',
    'BatchGR': '/BatchGR',
    // JGHJ-89513
    "PO_WORKFLOW_CANCEL":"us10.jnj-im-dev-na.zvcm55144cancellationofdocumentsinautomationproject.zVCM55144_CancellationOfDocumentsInAutomationProcess",
    "PO_WORKFLOW_CHANGE":"us10.jnj-im-dev-na.zvcm47421potriggerflowproject.zVCM47421_POChangeTriggerFlowProcess",
    "PO_DELIVERYDATE_CHANGE":"us10.jnj-im-dev-na.zvcm47421pochangeflowproject.deleveryDateChange",
    "PO_QUANTITY_CHANGE":"us10.jnj-im-dev-na.zvcm47421pochangeflowproject.qUantityChangeProcess",
    "LINE_ITEM_ADDITION":"us10.jnj-im-dev-na.zvcm47421pochangeflowproject.zVCM47421_NewLineItemAddition",
    "CPI_EMAIL_DESTINATION": "APIPORTAL-BTP_Iflow",
    "CPI_DESTPATH": "/http/User/EmailNotification/btp/time",
    "VCM": "VCM",
    //Defect JGHJ-107546
    "IBD": "IBD",
    "itemNo": "itemNo",


});