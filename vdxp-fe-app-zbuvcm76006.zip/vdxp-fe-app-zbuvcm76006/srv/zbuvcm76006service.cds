// --------------------------------------------------------------------------------------------------------------------*
// Application Name : VCM Error Log Report App
// Object Id       : zbuvcm76006
// Release         : 1
// Version         : 0.01
// Description     : VCM Error Log Report App
// ----------------------------------------------------------------------------*
// Descriptions:  Provides service definitions, data model projections, and custom actions for managing Value Chain Monitoring App.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
//  19-12-2025       PJadav2      JGHJ-76034     Initial Version
// ----------------------------------------------------------------------------*

using jnj.com.zbuvcm76006 as db from '../db/zbuvcm76006schema';

@path    : '/zbuvcm76006'
@requires: 'authenticated-user'
service zbuvcm76006Service {

    // @readonly
     @restrict: [
        {
            grant: 'READ',
            to   : 'XS3-VCM-APP-ERRLOGRPT-DSP-SCA',
            where: 'ShipmentID like ''S%'''
        },
        {
            grant: 'READ',
            to   : 'XS3-VCM-APP-ERRLOGRPT-DSP-VCA',
            where: 'ShipmentID like ''V%'''
        }
    ]
  
    entity ErrorReport          as projection on db.ZI_VCM_ErrorLogMonitoring {*, null as FilterDate: Date}
                                   order by
                                       ShipmentID desc;
      

    @readonly
    entity initialDocumentNo_VH as projection on db.initialDocumentNo_VH;

    action getMaterialData(initialDocumentNo: String,
                           shippingReqNo: String)

    //  UNBOUND ACTION (Correct for List Report Export)
    
    action CreateErrorLogExcel(
        FilterConditions : LargeString
    ) returns {
        FileName    : String;
        FileContent : LargeBinary @Core.MediaType:'octet-stream';
    };

}
