// --------------------------------------------------------------------------------------------------------------------*
// Application Name : VCM Error Log Report App
// Object Id       : zbuvcm76006
// Release         : 1
// Version         : 0.01
// Description     : VCM Error Log Report App
// ----------------------------------------------------------------------------*
// Descriptions:  Provides service definitions, data model projections, and custom actions for managing Value Chain Monitoring App.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
//  19-12-2025      PJadav2      JGHJ-76034     Initial Version
//  04-06-2025      SJaffer3     JGHJ-92608     Removed date restrictions and improved the data fetching process for Excel export
// ----------------------------------------------------------------------------*
const cds = require("@sap/cds");
const logger = cds.log("zbuvcm76006-program");
const constants = require("./config/constants.js");
const utils = require("./utils/utils.js");
const XLSX = require("xlsx");
const { DELETE } = require("@sap/cds/lib/ql/cds-ql.js");
const res = require("express/lib/response.js");
const { common } = require("hdb/lib/protocol/index.js");
const archiver = require("archiver");

module.exports = async (srv) => {

    const { ErrorReport } = srv.entities;

    // ============================================================
    // Before READ Handler for ErrorReport
    // ============================================================
    srv.before("READ", "ErrorReport", async (req, next) => {

        req.query.SELECT.where = utils.normalizeDateFilters(req.query.SELECT.where, 'FilterDate');
        req.query.SELECT.where = utils.remapField(req.query.SELECT.where, 'FilterDate', 'ErrorDate');
        const { where, limit } = req.query.SELECT;
        logger.info("Before READ handler for ErrorReport", JSON.stringify({ where, top: limit?.rows?.val, skip: limit?.offset?.val }));
    })

    // ============================================================
    // READ Handler for ErrorReport
    // ============================================================
    srv.on("READ", "ErrorReport", async (req, next) => {

        // FIX: Always fetch hidden fields even if FE doesn't request it

        if (req.query?.SELECT?.columns) {

            const aCols = req.query.SELECT.columns;

            const requiredFields = ["SubsequentDocYear", "stepID"];

            requiredFields.forEach(field => {
                const exists = aCols.some(c => c.ref && c.ref[0] === field);

                if (!exists) {
                    aCols.push({ ref: [field] });
                }
            });
        }

        const where = req.query?.SELECT?.where;
        let fromDate, toDate;

        // Extract ErrorDate ge / le values from OData $filter
        if (Array.isArray(where)) {
            for (let i = 0; i < where.length; i++) {
                if (where[i]?.ref?.[0] === "ErrorDate") {

                    if (where[i + 1] === ">=" || where[i + 1] === "ge") {
                        fromDate = new Date(where[i + 2]?.val);
                    }

                    if (where[i + 1] === "<=" || where[i + 1] === "le") {
                        toDate = new Date(where[i + 2]?.val);
                    }
                }
            }
        }

        // Validate maximum allowed period of six months (inclusive)
        if (fromDate && toDate) {
            const months =
                (toDate.getFullYear() - fromDate.getFullYear()) * 12 +
                (toDate.getMonth() - fromDate.getMonth()) + 1;

        }

        // Extract WHERE clause filters from the incoming CDS SELECT query
        const filter = req.query.SELECT.where;

        // Determine execution mode (foreground vs background) from Processing filter
        const execMode = utils.getProcessing(filter);

        if (execMode === constants.BG) {

            logger.info(constants.Background_Processing_Requested);

            // Immediately notify caller that background processing has started
            req.notify(201, constants.BackgroundProcessingText);

            // Remove Processing filter to avoid affecting actual data query execution
            utils.popProcessing(filter);

            // Defer background job execution
            setTimeout(() => {
                utils.runBackgroundJob(req.query, req.user.id, logger, req);
            }, 100);

            return;

        } else {

            // Remove Processing filter for normal synchronous execution
            utils.popProcessing(filter);

            // Continue standard request processing flow
            return await next();
        }
    });

    function cleanDateTimeOffset(val) {
        if (val === null || val === undefined) return null;
        if (val === "") return null;
        if (typeof val === "string" && val.trim() === "") return null;

        const d = new Date(val);
        if (isNaN(d.getTime())) return null;

        return d.toISOString();
    }

    /**
  * Service handler for getting material
  * URL:https://{host}:{port}/zbuvcm55155/ShippingRequestView()/getMaterialData()
 */
    srv.on('getMaterialData', async (req) => {
        const { ShippingRequestItem } = cds.entities;

        let { initialDocumentNo, shippingReqNo } = req.data
        // Fetch entity doc record
        const getMaterialData = await SELECT.one.from(ShippingRequestItem).where({ "parent_initialDocumentNo": initialDocumentNo, "parent_shippingReqNo": shippingReqNo });
        if (!getMaterialData) {
            throw new Error(bundle.getText('NoDataFound'));
        }
        return getMaterialData
    })

    // ============================================================
    // ACTION: CreateErrorLogExcel
    // Export ALL records from DB using filter values
    // ============================================================
    srv.on("CreateErrorLogExcel", async (req) => {

        const tx = cds.tx(req);
        const { FilterConditions } = req.data;

        let conditions = {};
        try {
            conditions = FilterConditions ? JSON.parse(FilterConditions) : {};
        } catch (e) {
            logger.warn("CreateErrorLogExcel: could not parse FilterConditions", e.message);
        }

        let query = SELECT.from("jnj.com.zbuvcm76006.ZI_VCM_ErrorLogMonitoring");

        // Determine what shipment prefixes this user is allowed to see via roles
        let allowS = req.user.is('XS3-VCM-APP-ERRLOGRPT-DSP-SCA');
        let allowV = req.user.is('XS3-VCM-APP-ERRLOGRPT-DSP-VCA');

        // Intersect with RequestTypeID filter selection: "0"=All, "1"=S only, "2"=V only
        const reqTypeConds = conditions["RequestTypeID"];
        if (Array.isArray(reqTypeConds) && reqTypeConds.length > 0) {
            const selectedKey = String(reqTypeConds[0].values?.[0] ?? "0");
            if (selectedKey === "1") allowV = false; // user selected S only
            if (selectedKey === "2") allowS = false; // user selected V only
            // "0" = All → keep whatever roles permit
        }

        if (!allowS && !allowV) {
            // No role access for the selected combination - return empty file
            return { FileName: "ErrorLog.xlsx", FileContent: "" };
        } else if (allowS && allowV) {
            // Both prefixes allowed - OR condition
            query.where([{
                xpr: [
                    { ref: ['ShipmentID'] }, 'like', { val: 'S%' },
                    'or',
                    { ref: ['ShipmentID'] }, 'like', { val: 'V%' }
                ]
            }]);
        } else if (allowS) {
            query.where({ ShipmentID: { like: 'S%' } });
        } else {
            query.where({ ShipmentID: { like: 'V%' } });
        }

        // Helpers: convert a YYYY-MM-DD (or full ISO) string to start/end of day ISO with ms
        // This matches what normalizeDateFilters does in the READ handler (proven to work with HANA)
        const startOfDay = d => {
            const x = new Date(String(d).length === 10 ? d + "T00:00:00Z" : d);
            x.setUTCHours(0, 0, 0, 0);
            return x.toISOString(); // e.g. "2026-05-14T00:00:00.000Z"
        };
        const endOfDay = d => {
            const x = new Date(String(d).length === 10 ? d + "T00:00:00Z" : d);
            x.setUTCHours(23, 59, 59, 999);
            return x.toISOString(); // e.g. "2026-05-14T23:59:59.999Z"
        };

        // Collect all date xpr token arrays — MDC multiple conditions on same field are OR-ed
        const allDateXprs = [];

        const collectDateXpr = (fromISO, toISO) => {
            const tokens = [];
            if (fromISO) { tokens.push({ ref: ['ErrorDate'] }, '>=', { val: fromISO }); }
            if (fromISO && toISO) tokens.push('and');
            if (toISO) { tokens.push({ ref: ['ErrorDate'] }, '<=', { val: toISO }); }
            if (tokens.length) allDateXprs.push(tokens);
        };

        // FilterDate → ErrorDate  (FilterDate is the virtual date field from the filter bar)
        const dateConds = conditions["FilterDate"];
        if (Array.isArray(dateConds)) {
            for (const cond of dateConds) {
                const op = (cond.operator || "").toUpperCase();
                const v0 = cond.values?.[0] != null ? String(cond.values[0]) : null;
                const v1 = cond.values?.[1] != null ? String(cond.values[1]) : null;

                if (op === "BT" && v0 && v1) collectDateXpr(startOfDay(v0), endOfDay(v1));
                else if (op === "EQ" && v0) collectDateXpr(startOfDay(v0), endOfDay(v0));
                else if (op === "GE" && v0) collectDateXpr(startOfDay(v0), null);
                else if (op === "LE" && v0) collectDateXpr(null, endOfDay(v0));
                else if (op === "GT" && v0) collectDateXpr(endOfDay(v0), null);
                else if (op === "LT" && v0) collectDateXpr(null, startOfDay(v0));
                else if (op === "NE" && v0) {
                    // not on that day → before start OR after end
                    allDateXprs.push([
                        { ref: ['ErrorDate'] }, '<', { val: startOfDay(v0) },
                        'or',
                        { ref: ['ErrorDate'] }, '>', { val: endOfDay(v0) }
                    ]);
                }
            }
        }

        // Apply all date conditions OR-ed together (matches MDC FilterBar behaviour)
        if (allDateXprs.length === 1) {
            query.where([{ xpr: allDateXprs[0] }]);
        } else if (allDateXprs.length > 1) {
            const combined = [];
            allDateXprs.forEach((tokens, i) => {
                if (i > 0) combined.push('or');
                combined.push({ xpr: tokens });
            });
            query.where([{ xpr: combined }]);
        }

        // InitiatingDocumentNumber — multiple EQ entries are OR-ed (IN list)
        const docConds = conditions["InitiatingDocumentNumber"];
        if (Array.isArray(docConds) && docConds.length > 0) {
            const vals = docConds.flatMap(c => c.values || []).filter(Boolean);
            if (vals.length === 1) {
                query.where({ InitiatingDocumentNumber: vals[0] });
            } else if (vals.length > 1) {
                query.where({ InitiatingDocumentNumber: { in: vals } });
            }
        }
        logger.info("Executing query for CreateErrorLogExcel", { query: query.toString() });

        // Defect JGHJ-105637 -- START
        try {
            const result = await Promise.race([
                (async () => {
                    const aData = await tx.run(query);
                    //  Required column order
                    const aCols = [
                        { label: "Initiating doc#", property: "InitiatingDocumentNumber" },
                        { label: "Initiating Doc Type", property: "InitiatingDocumentType" },
                        { label: "Creation Date Shipment ID #", property: "ShipmentCreationDate" },
                        { label: "Shipment ID #", property: "ShipmentID" },
                        { label: "Product Flow Catalog ID#", property: "ProductFlowCatalogID" },
                        { label: "PFL ID#", property: "ProductFlowID" },
                        { label: "Overall Status", property: "status" },
                        { label: "Subsequent Doc", property: "SubsequentDoc" },
                        { label: "Process Step", property: "ProcessStep" },
                        { label: "Legal Entity", property: "LegalEntity" },
                        { label: "Plant", property: "Plant" },
                        { label: "Error Date", property: "ErrorDate" },
                        { label: "Resolution Date", property: "ResolutionDate" },
                        { label: "Error Message", property: "ErrorMessage" }
                    ];

                    //  Case-insensitive property fetch
                    function getValue(row, property) {
                        const key = Object.keys(row).find(k => k.toLowerCase() === property.toLowerCase());
                        return key ? row[key] : "";
                    }

                    //  Build final filtered dataset ONLY with required columns
                    const finalData = (aData || []).map(row => {
                        let obj = {};

                        aCols.forEach(col => {
                            let value = getValue(row, col.property);

                            if (col.property === "ErrorDate" || col.property === "ResolutionDate") {
                                value = value ? new Date(value).toISOString() : "";
                            }

                            obj[col.label] = value ?? "";
                        });

                        return obj;
                    });

                    //  Convert to sheet (ONLY these columns will appear)
                    const ws = XLSX.utils.json_to_sheet(finalData, {
                        header: aCols.map(c => c.label)
                    });

                    //  Set column width
                    ws["!cols"] = aCols.map(() => ({ wch: 30 }));

                    const wb = XLSX.utils.book_new();
                    XLSX.utils.book_append_sheet(wb, ws, "ErrorLog");

                    const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
                    // Zip the xlsx buffer into a Buffer (collect chunks)
                    const zipBuffer = await new Promise((resolve, reject) => {
                        const archive = archiver("zip", { zlib: { level: 9 } });
                        const chunks = []; archive.on("data", chunk => chunks.push(chunk));
                        archive.on("error", err => reject(err));
                        archive.on("end", () => resolve(Buffer.concat(chunks)));

                        archive.append(buffer, { name: "ErrorLog.zip" });
                        archive.finalize().catch(reject);
                    });
                    const res = req.http.res; res.setHeader('Content-Type', 'octet-stream');
                    res.setHeader('Content-Disposition', 'attachment; filename="ErrorLog.zip"');
                    res.setHeader('Transfer-Encoding', 'chunked'); // Return base64 string (safest across OData) return { FileName: "ErrorLog.zip", FileContent: zipBuffer.toString("base64") };


                    return {
                        FileName: "ErrorLog.xlsx",
                        FileContent: zipBuffer.toString("base64")
                    };
                })(),
                createTimeout(60000, constants.TIMEOUT_ERROR_MESSAGE)
            ]);
            return result;
        } catch (err) {
            if (
                err.message === constants.TIMEOUT_ERROR_MESSAGE
            ) {
                return req.reject(
                    408,
                    constants.TIMEOUT_ERROR_MESSAGE
                );
            }
            throw err;
        }
        // Defect JGHJ-105637 -- END
    });

    // JGHJ-105637: Create a timeout promise that rejects after a specified time
    function createTimeout(ms, message) {
        return new Promise((_, reject) => {
            setTimeout(() => {
                reject(new Error(message));
            }, ms);
        });
    }
};


