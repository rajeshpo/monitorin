// --------------------------------------------------------------------------------------------------------------------*
// Application Name : VCM Error Log Report App
// Object Id       : ZBUVCM76006
// Release         : 1
// Version         : 0.01
// Description     : VCM Error Log Report App
// ----------------------------------------------------------------------------*
// Descriptions: Provides utility functions for the VCM Error Log Report Application.
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
//  19-12-2025     PJadav2      JGHJ-55488     Initial Version
// ----------------------------------------------------------------------------*
const cds = require('@sap/cds');
const { getHTML, getErrorHTML } = require('./html');
const ExcelJS = require('exceljs');
const constants = require('../config/constants');
const logger = cds.log('utils')

module.exports = {
  
  /**
   * Normalizes date filter tokens in a CDS where clause for a given field.
   * Converts MDC FilterBar date conditions into proper xpr tokens compatible with HANA DateTime comparison.
   * @param {Array} where
   * @param {String} field
   * @return {Array}
   */
  normalizeDateFilters: function (where, field) {
    if (!where) return where;

    // ---------- helpers ----------
    const isDateOnly = v => typeof v === 'string' && v.length === 10;

    const startOfDay = d => {
      const x = new Date(d);
      x.setHours(0, 0, 0, 0);
      return x;
    };

    const nextDay = d => {
      const x = new Date(d);
      x.setDate(x.getDate() + 1);
      x.setHours(0, 0, 0, 0);
      return x;
    };

    const endOfDay = d => {
      const x = new Date(d);
      x.setHours(23, 59, 59, 999);
      return x;
    };

    const same = (a, b) =>
      (a?.getTime?.() ?? null) === (b?.getTime?.() ?? null);

    const dedupeRanges = ranges => {
      const out = [];

      for (const r of ranges) {
        if (!out.some(o => same(o.start, r.start) && same(o.end, r.end))) {
          out.push(r);
        }
      }

      return out;
    };

    const mergeRanges = ranges => {
      const bounded = ranges
        .filter(r => r.start && r.end)
        .sort((a, b) => a.start - b.start);

      const merged = [];

      for (const r of bounded) {
        if (!merged.length) {
          merged.push(r);
          continue;
        }

        const last = merged[merged.length - 1];

        if (r.start <= last.end) {
          last.end = new Date(Math.max(last.end, r.end));
        } else {
          merged.push(r);
        }
      }

      ranges.forEach(r => {
        if (!r.start || !r.end) merged.push(r);
      });

      return merged;
    };

    const buildXpr = ranges => {
      const parts = [];

      ranges.forEach((r, i) => {
        if (i > 0) parts.push('or');

        const endOp = r.endOp ?? '<=';

        if (r.start && r.end) {
          parts.push({
            xpr: [
              { ref: [field] }, '>=', { val: r.start.toISOString() },
              'and',
              { ref: [field] }, endOp, { val: r.end.toISOString() }
            ]
          });
        } else if (!r.start) {
          parts.push(
            { ref: [field] }, endOp, { val: r.end.toISOString() }
          );
        } else {
          parts.push(
            { ref: [field] }, '>=', { val: r.start.toISOString() }
          );
        }
      });

      return { xpr: parts };
    };

    const clean = arr => {
      return arr.filter((item, i, a) => {
        if (item === 'and' || item === 'or') {
          const prev = a[i - 1];
          const next = a[i + 1];

          return prev && next && prev !== 'and' && prev !== 'or';
        }

        return true;
      });
    };

    const toRanges = (op, v1, v2) => {
      op = op.toLowerCase();

      const s = startOfDay(v1);
      const n = nextDay(v1);

      switch (op) {
        case '=':
          // >= start-of-day AND <= end-of-day (inclusive both sides)
          return [{ start: s, end: endOfDay(v1) }];

        case '!=':
          // strictly before v1's day OR from next day onward
          return [
            { start: null, end: s, endOp: '<' },
            { start: n, end: null }
          ];

        case '>=':
          return [{ start: s, end: null }];

        case '>':
          return [{ start: n, end: null }];

        case '<':
          // strictly before v1's day start
          return [{ start: null, end: s, endOp: '<' }];

        case '<=':
          // up to and including the last millisecond of v1's day
          return [{ start: null, end: endOfDay(v1) }];

        case 'between':
          // >= start-of-v1 AND <= end-of-v2 (inclusive)
          return [{
            start: startOfDay(v1),
            end: endOfDay(v2)
          }];

        default:
          return null;
      }
    };

    // ---------- recursive parser ----------
    function walk(tokens) {
      let result = [];

      for (let i = 0; i < tokens.length; i++) {
        const t = tokens[i];

        // recursion
        if (t?.xpr) {
          result.push({ xpr: walk(t.xpr) });
          continue;
        }

        // match field condition
        if (
          t?.ref?.[0] === field &&
          typeof tokens[i + 1] === 'string'
        ) {
          const op = tokens[i + 1].toLowerCase();
          const v1 = tokens[i + 2]?.val;

          const isBetween =
            op === 'between' &&
            tokens[i + 3] === 'and' &&
            isDateOnly(v1) &&
            isDateOnly(tokens[i + 4]?.val);

          const isSimpleDateOp =
            op !== 'between' &&
            isDateOnly(v1);

          if (isBetween || isSimpleDateOp) {
            const v2 = isBetween ? tokens[i + 4].val : undefined;
            let ranges = toRanges(op, v1, v2);

            if (ranges) {
              ranges = dedupeRanges(ranges);
              ranges = mergeRanges(ranges);

              result.push(buildXpr(ranges));
              i += isBetween ? 4 : 2;
              continue;
            }
          }
        }

        result.push(t);
      }

      return clean(result);
    }

    return walk(where);
  },

  /**
   * Recursively renames all refs to fromField as toField in CDS where tokens.
   * Used to remap a virtual filter field onto the real DB field before query execution.
   * @param {Array} tokens
   * @param {String} fromField
   * @param {String} toField
   * @return {Array}
   */
  remapField: function (tokens, fromField, toField) {
    if (!Array.isArray(tokens)) return tokens;

    return tokens.map(t => {
      if (t?.xpr) return { xpr: this.remapField(t.xpr, fromField, toField) };
      if (t?.ref?.[0] === fromField) return { ref: [toField] };
      return t;
    });
  },

  /**
   * Extracts the value of the Processing filter from CDS query tokens
   * @param {Array} tokens
   * @return {String|null}
   */
  getProcessing: function (tokens) {
    for (let i = 0; i < tokens?.length; i++) {
      if (tokens[i]?.ref?.[0] === constants.Processing && tokens[i + 1] === "=") {
        return tokens[i + 2]?.val;
      }
    }
    return null;
  },

  /**
   * Removes the Processing filter condition from CDS query tokens
   * @param {Array} tokens
   * @return {Array}
   */
  popProcessing: function (tokens) {
    for (let i = 0; i < tokens?.length; i++) {
      if (tokens[i]?.ref?.[0] === constants.Processing && tokens[i + 1] === "=") {
        // Remove Processing = value
        tokens.splice(i, 3);

        // Remove a preceding "and/or"
        if (tokens[i - 1] === "and" || tokens[i - 1] === "or") {
          tokens.splice(i - 1, 1);
        }
        // Or remove a trailing "and/or" if it was dangling
        else if (tokens[i] === "and" || tokens[i] === "or") {
          tokens.splice(i, 1);
        }
        break;
      }
    }
    return tokens;
  },

  /**
   * Executes a long-running background job to fetch error log data,
   * generate Excel reports in batches, and send them via email
   * @param {Object} query
   * @param {String} user
   * @param {Object} logger
   * @param {Object} req
   * @return {Promise}
   */
  runBackgroundJob: async function (query, user, logger, req) {
    // Log background job initiation with triggering user
    logger.info(`Background Job intiated by ${user}`)

    // Connect to CPI destination for email notification integration
    const cpi = await cds.connect.to("CPI")

    try {
      // Batch size for paginated DB read to avoid memory overload
      const BATCH_SIZE = constants.BATCH_SIZE; // safe default (tune later)

      // Maximum rows allowed per generated Excel file
      const MAX_ROWS_PER_FILE = constants.MAX_ROWS_PER_FILE;

      // Pagination control variables
      let offset = 0;
      let hasMore = true;

      // Accumulator for all fetched database rows
      let allRows = [];

      // Fetch data in batches until no more records are returned
      while (hasMore) {
        // Clone original query and apply limit + offset
        const batchQuery = query.clone().limit(BATCH_SIZE, offset);
        
        // Execute batch query
        const batchData = await cds.run(batchQuery);
        batchData.map(x => delete x.ErrorID)
        batchData.map(x => delete x.SubsequentDocYear)
        batchData.map(x => delete x.stepID)
        
        // Exit loop when no more data is available
        if (!batchData.length) {
          hasMore = false;
          break;
        }

        // Append fetched records to accumulator
        allRows.push(...batchData);

        // Move offset for next batch
        offset += BATCH_SIZE;

        // Log progress for monitoring long-running job
        logger.info(`Fetched ${offset} rows`);
      }
      // let dbdata = await cds.run(query) 

      // Container for generated Excel files (single or split)
      let excelFiles = [];

      // Generate a single Excel file if data size is within limit
      if (allRows.length <= MAX_ROWS_PER_FILE) {
        // Create Excel from complete dataset
        const excel = await generateExcel(allRows);
        excelFiles.push({
          index: 1,
          excel
        });
      } else {
        // Split large dataset into multiple Excel files
        let fileIndex = 1;

        for (let i = 0; i < allRows.length; i += MAX_ROWS_PER_FILE) {
          // Slice data chunk for current file
          const chunk = allRows.slice(i, i + MAX_ROWS_PER_FILE);

          // Generate Excel for current chunk
          const excel = await generateExcel(chunk);

          excelFiles.push({
            index: fileIndex,
            excel
          });

          fileIndex++;
        }
      }
      // let excel = await generateExcel(allRows)

      // Iterate over each generated Excel file and send via email
      for (const file of excelFiles) {
        // Convert Excel buffer to Base64 for CPI attachment
        const base64String = Buffer.from(file.excel).toString(constants.base64);

        // Build success email HTML
        let html = getHTML(req)

        // Escape quotes to avoid CPI payload parsing issues
        function escapeQuotes(str) {
          return str.replace(/"/g, '///"');
        }

        // Prepare final HTML body
        let mainhtml = escapeQuotes(html)

        // Calculate attachment size in MB to enforce CPI limits
        const sizeInMB = Buffer.byteLength(base64String, 'base64') / (1024 * 1024);
        logger.info('sizeInMB', sizeInMB)

        // Abort if attachment exceeds allowed size
        if (sizeInMB > 24) {
          throw new Error(`Attachment size ${sizeInMB.toFixed(2)} MB exceeds limit`);
        }

        try {
          // Send email with Excel attachment via CPI
          await cpi.send({
            method: "POST",
            path: constants.EmailNotificationtime,
            data: {
              "CLIENT": "",
              "SYSTEM": "",
              "Email_DepartmentTransfer": "",
              "Email_CurrentJJEDSManager": "",
              "Email_UserWWID": "",
              "Email_UserName": "",
              "Email_Subject": constants.Error_Log_Report,
              "Email_Recipients": user || constants.No_Reply_Mail,
              "Email_Body": mainhtml,
              "Email_Attachment": base64String,
              "Email_Attachment_Name": `${constants.ErrorLogReport_}_${file.index}_${new Date().toISOString().split('T')[0]}.${constants.xlsx}`
            },
            headers: {
              "Accept": "*/*"
            }
          })

          // Log successful email dispatch
          logger.info(constants.Background_Job_Success_Mail_Sent)
        } catch (error) {
          // Log CPI email send failure for this file
          logger.error(error)
        }
      }

    }
    catch (error) {
      // Log any unexpected failure during background processing
      logger.error(error)

      // Build failure email HTML
      let errorHtml = getErrorHTML(req)

      // Escape quotes for CPI compatibility
      errorHtml = errorHtml.replace(/"/g, '///"');

      // Send failure notification email without attachment
      await cpi.send({
        method: "POST",
        path: constants.EmailNotificationtime,
        responseType: 'text',
        data: {
          "Email_Subject": constants.Error_Log_Report,
          "Email_Recipients": user,
          "Email_Body": Buffer.from(errorHtml, 'utf-8').toString('base64'),
        },
        headers: {
          "Content-Type": "application/json",
          "Accept": "*/*"
        }
      })

      // Log failure email notification status
      logger.info(constants.Background_Job_Error_Mail_Sent)
    }
  }

}

/**
 * Generates an Excel report from database result data
 * @param {Array} dbData
 * @return {Promise<Buffer>}
 */
async function generateExcel(dbData) {
  try {

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Error Report");

    // No data case
    if (!dbData || dbData.length === 0) {
      sheet.addRow(["No data found"]);
      return await workbook.xlsx.writeBuffer();
    }

  // Label Mapping
    const labelMap = {
      InitiatingDocumentNumber: "Initiating doc#",
      InitiatingDocumentType: "Initiating Doc Type",
      ShipmentCreationDate: "Creation Date Shipment ID #",
      ShipmentID: "Shipment ID #",
      ProductFlowCatalogID: "Product Flow Catalog ID#",
      ProductFlowID:"PFL ID#",
      status: "Overall Status",
      SubsequentDoc: "Subsequent Doc",
      ProcessStep: "Process Step",
      LegalEntity: "Legal Entity",
      Plant:"Plant",
      ErrorDate: "Error Date",
      ResolutionDate: "Resolution Date",
      ErrorMessage: "Error Message"
    };

    // Column order (adjust if needed)
    const desiredOrder = [
      "InitiatingDocumentNumber",
      "InitiatingDocumentType",
      "ShipmentCreationDate",
      "ShipmentID",
      "ProductFlowCatalogID",
      "ProductFlowID",
      "status",
      "SubsequentDoc",
      "ProcessStep",
      "LegalEntity",
      "Plant",  
      "ErrorDate",
      "ResolutionDate",
      "ErrorMessage"
    ];
    

    const recordKeys = Object.keys(dbData[0]);

    // Append extra DB columns safely
    const extraKeys = recordKeys
      .filter(k => !desiredOrder.includes(k))
      .sort((a, b) => a.localeCompare(b));

    const finalOrder = [...desiredOrder, ...extraKeys];

    //Use labelMap instead of prettyHeader
    sheet.columns = finalOrder.map(key => ({
      header: labelMap[key] || key,   // fallback to key if not in labelMap
      key,
      width: 22
    }));

    // function prettyHeader(key) {
    //   return key
    //     .replace(/_/g, " ")
    //     .replace(/([a-z])([A-Z])/g, "$1 $2")
    //     .replace(/\b\w/g, c => c.toUpperCase());
    // }
    // // Define columns
    // sheet.columns = finalOrder.map(key => ({
    //   header: prettyHeader(key),
    //   key,
    //   width: 22
    // }));

    // Add rows
    dbData.forEach(row => {
      const sanitized = {};
      finalOrder.forEach(k => {
        sanitized[k] = row[k] ?? "";
      });
      sheet.addRow(sanitized);
    });

    // Header styling
    sheet.getRow(1).eachCell(cell => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: "center" };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FFE6E6E6" }
      };
    });

    // Freeze header
    sheet.views = [{ state: "frozen", ySplit: 1 }];

    return await workbook.xlsx.writeBuffer();
  } catch (err) {
    logger.error(constants.Errorgenerating_Excel, err);
    throw err;
  }
}