const constants = require('../config/constants');
const fs = require('fs');
const path = require('path');

/* ---------- Helpers ---------- */

// Read logo
const LOGO_BASE64 = fs
    .readFileSync(path.join(__dirname, '..', 'assets', 'JNJ.png'))
    .toString('base64');

// Get Current User Details
function getUserName(req) {
    const givenName = req.user?.authInfo?.getGivenName();
    const familyName = req.user?.authInfo?.getFamilyName();
    return givenName && familyName ? `${givenName} ${familyName}` : 'User';
}

/* ---------- Core HTML Builder ---------- */

function buildEmailHTML({ userName, message }) {
    const htmlParts = [];

    htmlParts.push(`<!DOCTYPE html>`);
    htmlParts.push(`<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">`);

    htmlParts.push(`<head>`);
    htmlParts.push(`<meta charset="UTF-8">`);
    htmlParts.push(`<meta name="viewport" content="width=device-width,initial-scale=1">`);
    htmlParts.push(`<meta name="x-apple-disable-message-reformatting">`);
    htmlParts.push(`<title>Error Log Report</title>`);

    htmlParts.push(`<!--[if mso]>`);
    htmlParts.push(`<noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript>`);
    htmlParts.push(`<![endif]-->`);

    htmlParts.push(`</head>`);

    htmlParts.push(`<body style="margin:0;padding:0;background-color:#f4f4f4;font-family:'Segoe UI',Arial,sans-serif;">`);
    htmlParts.push(`<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f4;padding:20px;">`);
    htmlParts.push(`<tr><td align="center">`);

    htmlParts.push(`<table role="presentation" width="600" cellpadding="0" cellspacing="0"
        style="background:#ffffff;border-radius:8px;overflow:hidden;
               box-shadow:0 4px 6px rgba(0,0,0,0.1);max-width:100%;">`);

    /* ---------- Header ---------- */
    htmlParts.push(`<tr><td style="padding:24px;text-align:center;">`);
    htmlParts.push(`<img src='data:image/png;base64,${LOGO_BASE64}'
        alt="Johnson & Johnson"
        style="display:block;margin:0 auto;border:0;max-width:180px;height:auto;">`);
    htmlParts.push(`</td></tr>`);

    /* ---------- Body ---------- */
    htmlParts.push(`<tr><td style="padding:24px;font-size:16px;color:#374151;line-height:1.6;">`);
    htmlParts.push(`<p style="margin:0 0 16px;"><b>Dear ${userName},</b></p>`);
    htmlParts.push(`<p style="margin:0 0 16px;">${message}</p>`);

    htmlParts.push(`<p style="margin:0;">Best Regards,</p>`);
    htmlParts.push(`<p style="margin:0;"><b>IM TRANSCEND VCM Process Team</b></p>`);
    htmlParts.push(`</td></tr>`);

    /* ---------- Footer ---------- */
    htmlParts.push(`<tr><td style="padding:20px;background:#f9f8f7;
        text-align:center;font-size:13px;color:#6b7280;">`);
    htmlParts.push(`This is an automated J&amp;J email. Please do not reply.`);
    htmlParts.push(`</td></tr>`);

    htmlParts.push(`</table>`);
    htmlParts.push(`</td></tr></table>`);
    htmlParts.push(`</body></html>`);

    return htmlParts.join('');
}

module.exports = {
    /**
     * Builds success email HTML content for the Error Log Report
     * @param {Object} req
     * @return {String}
     */
    getHTML(req) {
        return buildEmailHTML({
            userName: getUserName(req),
            message: constants.ERROR_LOG_REPORT_SUCCESS_MESSAGE
        });
    },

    /**
     * Builds failure email HTML content for the Error Log Report
     * @param {Object} req
     * @return {String}
     */
    getErrorHTML(req) {
        return buildEmailHTML({
            userName: getUserName(req),
            message: constants.ERROR_LOG_REPORT_FAILURE_MESSAGE
        });
    }
};
