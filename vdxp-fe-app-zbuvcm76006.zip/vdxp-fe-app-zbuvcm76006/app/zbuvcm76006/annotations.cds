using zbuvcm76006Service as service from '../../srv/zbuvcm76006service';
annotate service.ErrorReport with @(
     Capabilities.DeleteRestrictions: {
        Deletable: false
    },
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Label : 'InitiatingDocumentNumber',
                Value : InitiatingDocumentNumber,
            },
            {
                $Type : 'UI.DataField',
                Label : 'InitiatingDocumentType',
                Value : InitiatingDocumentType,
            },
            {
                $Type : 'UI.DataField',
                Label : 'ShipmentCreationDate',
                Value : ShipmentCreationDate,
            },
            {
                $Type : 'UI.DataField',
                Label : 'ShipmentID',
                Value : ShipmentID,
            },
            {
                $Type : 'UI.DataField',
                Label : 'ProductFlowCatalogID',
                Value : ProductFlowCatalogID,
            },
            {
                $Type : 'UI.DataField',
                Label : 'ProcessStep',
                Value : ProcessStep,
            },
            {
                $Type : 'UI.DataField',
                Label : 'LegalEntity',
                Value : LegalEntity,
            },
            {
                $Type : 'UI.DataField',
                Label : 'ErrorDate',
                Value : ErrorDate,
            },
            {
                $Type : 'UI.DataField',
                Label : 'ResolutionDate',
                Value : ResolutionDate,
            },
            {
                $Type : 'UI.DataField',
                Label : 'ErrorMessage',
                Value : ErrorMessage,
            },
            {
                $Type : 'UI.DataField',
                Label : 'ErrorType',
                Value : ErrorType,
            },
        ],
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : 'General Information',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
    ],
    UI.LineItem : [
        {
            $Type : 'UI.DataField',
            Label : '{i18n>Initiatingdocumentnumber1}',
            Value : InitiatingDocumentNumber,
        },
        {
            $Type : 'UI.DataField',
            Label : '{i18n>Initiatingdocumenttype}',
            Value : InitiatingDocumentType,
        },
        {
            $Type : 'UI.DataField',
            Label : '{i18n>Shipmentcreationdate}',
            Value : ShipmentCreationDate,
        },
        {
            $Type : 'UI.DataField',
            Label : '{i18n>Shipmentid}',
            Value : ShipmentID,
        },
        {
            $Type : 'UI.DataField',
            Label : '{i18n>Productflowcatalogid}',
            Value : ProductFlowCatalogID,
        },
        {
            $Type : 'UI.DataField',
            Value : ProductFlowID,
            Label : '{i18n>PflId}',
            
        },
        {
            $Type : 'UI.DataField',
            Value : status,
            Label : '{i18n>ProcessingStage}',
        },
        {
            $Type : 'UI.DataField',
            Value : ProcessStep,
            Label : '{i18n>Processstep}',
        },
        {
            $Type : 'UI.DataField',
            Value : LegalEntity,
            Label : '{i18n>Legalentity}',
        },
        {
            $Type : 'UI.DataField',
            Value : Plant,
            Label : '{i18n>Plant}',
        },
        {
            $Type : 'UI.DataField',
            Value : ErrorDate,
            Label : '{i18n>Errordate1}',
        },
        {
            $Type : 'UI.DataField',
            Value : ResolutionDate,
            Label : '{i18n>Resolutiondate1}',
        },
        {
            $Type : 'UI.DataField',
            Value : ErrorMessage,
            Label : '{i18n>Errormessage}',
        },
        {
            $Type : 'UI.DataField',
            Value : SubsequentDocYear,
            Label : '{i18n>Subsequentdocyear}',
        },
        {
            $Type : 'UI.DataField',
            Value : stepID,
            Label : '{i18n>Stepid}',
        },
    ],
    UI.SelectionFields : [
        InitiatingDocumentNumber,
        FilterDate,
    ],
    UI.HeaderInfo : {
        TypeName : '{i18n>ErrorLogs}',
        TypeNamePlural : '{i18n>ErrorLogs}',
        Title : {
            $Type : 'UI.DataField',
            Value : InitiatingDocumentNumber,
        },
        Description : {
            $Type : 'UI.DataField',
            Value : ProcessStep,
        },
    },
);

// /**
//  * Semantic Object Mapping for SubsequentDoc navigation
//  * Used by BTP Work Zone / FLP to resolve S/4HANA apps
//  */
// annotate service.ErrorReport with {
//   SubsequentDoc @Common.SemanticObject : 'S4Document';
//   SubsequentDoc @Common.SemanticObjectMapping : [
//     {
//       $Type : 'Common.SemanticObjectMappingType',
//       LocalProperty : SubsequentDoc,
//       SemanticObjectProperty : 'DocumentNumber'
//     },
//     {
//       $Type : 'Common.SemanticObjectMappingType',
//       LocalProperty : ProcessStep,
//       SemanticObjectProperty : 'DocumentType'
//     }
//   ];
// };



annotate service.ErrorReport with {
    ErrorDate @Common.Label   : '{i18n>Errordate}'
              @Common.Timezone: 'UTC';
};
annotate service.ErrorReport with @Capabilities.SearchRestrictions: {
    Searchable: false
};

annotate service.ErrorReport with @(Capabilities: {FilterRestrictions: {
    $Type             : 'Capabilities.FilterRestrictionsType',
    RequiredProperties: [
        FilterDate
    ],
}});
annotate service.ErrorReport with {
    InitiatingDocumentNumber @(
        Common.ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'initialDocumentNo_VH',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : InitiatingDocumentNumber,
                    ValueListProperty : 'initialDocumentNo',
                },
            ],
            Label : 'Initiation Document No. ',
        },
        Common.ValueListWithFixedValues : false,
        Common.Label : '{i18n>InitiatingDocumentNumber}',
)};
annotate service.ErrorReport with {
    SubsequentDocYear @UI.Hidden : true;
};
annotate service.ErrorReport with {
    FilterDate @Common.Label : '{i18n>Errordate}'
};
annotate service.ErrorReport with {
    ResolutionDate @Common.Label   : '{i18n>Resolutiondate1}'
                   @Common.Timezone: 'UTC';
};

