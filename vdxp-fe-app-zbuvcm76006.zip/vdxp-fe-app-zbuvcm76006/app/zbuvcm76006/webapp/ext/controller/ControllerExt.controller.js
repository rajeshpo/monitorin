sap.ui.define([
    "sap/ui/core/mvc/ControllerExtension",
    "sap/m/MessageBox",
    "sap/ui/core/BusyIndicator",
], function (ControllerExtension, MessageBox,BusyIndicator) {
    "use strict";
    return ControllerExtension.extend("jnj.com.zbuvcm76006.ext.controller.ControllerExt", {
 
        override: {
            /**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf jnj.com.zbuvcm76006.ext.controller.ControllerExt
			 */
            onInit: function () { 
                // Background Processing Message
                this.getView().byId("jnj.com.zbuvcm76006::ErrorReportList--fe::FilterBar::ErrorReport-btnSearch")
                    .attachPress(function () {
                        const oFilterBar = sap.ui.getCore().byId(
                            "jnj.com.zbuvcm76006::ErrorReportList--fe::FilterBar::ErrorReport"
                        );
                        const oExecutionModeField = oFilterBar.getFilterItems()
                            .filter(x => x.sId === "jnj.com.zbuvcm76006::ErrorReportList--fe::FilterBar::ErrorReport::CustomFilterField::Processing")[0];
                        if (oExecutionModeField &&
                            oExecutionModeField.getProperty("conditions") &&
                            oExecutionModeField.getProperty("conditions")[0] &&
                            oExecutionModeField.getProperty("conditions")[0].values.includes("BG")) {
                            setTimeout(function () {
                                MessageBox.information("Background Processing Started. You will receive the report in the mail.");
                            }, 500);
                        }
                         if (oExecutionModeField &&
                            oExecutionModeField.getProperty("conditions") &&
                            oExecutionModeField.getProperty("conditions")[0] &&
                            oExecutionModeField.getProperty("conditions")[0].values.includes("FG")) {
                            setTimeout(function () {
                                MessageBox.information("For larger date range please select background processing to avoid time out errors");
                            }, 500);
                        }
                    });
            },

            // Defect JGHJ-105637: Track Go button press and filter changes to enable/disable Excel Export button
            onAfterRendering: function () {
                const oFilterBar = this.getView().byId("jnj.com.zbuvcm76006::ErrorReportList--fe::FilterBar::ErrorReport");
                oFilterBar.attachSearch(this._onFilterSearch.bind(this));
            }
        },

        // Enable/Disable Excel Export button based on filter conditions
        
        _onFilterSearch: function (oEvent) {
            let oView = this.getView();
            let oExtApi = this.base.getExtensionAPI();
            let excelExportButton = oView.byId("jnj.com.zbuvcm76006::ErrorReportList--fe::table::ErrorReport::LineItem::CustomAction::ExcelId");
            let aFilterParams = oExtApi.getFilters().filters;
            if (oExtApi.getFilters().filters[0].aFilters) {
                aFilterParams = oExtApi.getFilters().filters[0].aFilters;
            }
            let processingFilter = aFilterParams.find(filter => filter.sPath === "Processing");
            if (processingFilter && processingFilter.oValue1 === "BG") {
                excelExportButton.setEnabled(false);
            } else {
                excelExportButton.setEnabled(true);
            }
        },
       
        // Excel Export Button Handler
    
        Excelexport: async function () {
            try {
                BusyIndicator.show(0);
                const oModel = this.getView().getModel();
                // Get FilterBar
                const oFilterBar = sap.ui.getCore().byId(
                    "jnj.com.zbuvcm76006::ErrorReportList--fe::FilterBar::ErrorReport"
                );

                // Pass all filter bar conditions to the backend as-is
                const mConditions = oFilterBar.getFilterConditions();

                const oActionBinding = oModel.bindContext("/CreateErrorLogExcel(...)");
                oActionBinding.setParameter("FilterConditions", JSON.stringify(mConditions)); 
                await oActionBinding.invoke();
                const oResult = oActionBinding.getBoundContext().getObject();
                console.log("Excel Result:", oResult);
                if (!oResult || !oResult.FileContent) {
                     BusyIndicator.hide();
                       if(oResult && oResult.message){
                            MessageBox.information(oResult.message);
                            return;
                        }
                    sap.m.MessageBox.error("No file returned from backend");
                    return;
                }
                // Convert base64 → binary
                const byteCharacters = atob(oResult.FileContent);
                const len = byteCharacters.length;
                const bytes = new Uint8Array(len);
                for (let i = 0; i < len; i++) bytes[i] = byteCharacters.charCodeAt(i);

                // Load JSZip: prefer dynamic import, fallback to global window.JSZip
    let JSZipLib;
    try {
    //   JSZipLib = (await import('jszip')).default; 
      JSZipLib = new JSZip(); // Use the globally loaded JSZip from the script tag
    } catch (e) {
      JSZipLib = window.JSZip; // fallback if you added a <script> for jszip
    }
    if (!JSZipLib) {
    //   MessageBox.error("JSZip library not available. Install 'jszip' or include it via a script tag.");
      return;
    }

    // Parse zip and find XLSX entry
    const zip = await JSZipLib.loadAsync(bytes);
    const files = Object.values(zip.files).filter(f => !f.dir);
    const xlsxEntry = files.find(f => f.name && f.name.toLowerCase().endsWith('.xlsx')) || files[0];

    if (!xlsxEntry) {
      MessageBox.error("No file found inside ZIP.");
      return;
    }

    // Extract XLSX as arraybuffer
    const arrayBuffer = await xlsxEntry.async('arraybuffer');

                const blob = new Blob([arrayBuffer], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                });
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement("a");
                link.href = url;
                link.download = oResult.FileName || "ErrorLog.xlsx";
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link); 
                window.URL.revokeObjectURL(url);
                // Popup after download
                sap.m.MessageBox.information("Error Logs Excel downloaded successfully.");
            } catch (err) {
                console.error("Excel Export Error:", err);
                sap.m.MessageBox.error(err.message);
            }
            finally {
            BusyIndicator.hide(); //  ALWAYS hide
            }
        }
    });
});
 
 