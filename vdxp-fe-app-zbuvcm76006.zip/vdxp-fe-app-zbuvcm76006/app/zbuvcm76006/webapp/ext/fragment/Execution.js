sap.ui.define(["sap/ui/model/Filter", "sap/ui/model/FilterOperator"], function(Filter, FilterOperator) {
    "use strict";
    return {
        filterItems: function(sValue) {
            switch (sValue) {
                case "BG":
                    return new Filter({ path: "Processing", operator: FilterOperator.EQ, value1: "BG" });
                case "FG":
                    return new Filter({ path: "Processing", operator: FilterOperator.EQ, value1: "FG" });
            }
        }
    };
});
