sap.ui.define([
    "sap/m/MessageToast"
], function (MessageToast) {
    'use strict';

    async function navigateToCrossApp(semanticObject, action, params = {}) {
        try {
            if (!sap.ushell || !sap.ushell.Container) {
                MessageToast.show("Not running inside Fiori Launchpad");
                return;
            }

            const oCrossAppNavigator = await sap.ushell.Container.getServiceAsync("Navigation");
            await oCrossAppNavigator.navigate({
                target: {
                    semanticObject: semanticObject,
                    action: action
                },
                params: params
            });

        } catch (e) {
            MessageToast.show("Cross-App navigation failed");
            console.error("Cross-app nav error:", e);
        }
    }

    return {


        onDocLinkPress: async function (oEvent) {
            const oContext = oEvent.getSource().getBindingContext();
            const rawDocType = (oContext.getProperty("stepID") || "").trim();
            // const rawDocType = (oContext.getProperty("ProcessStep") || "").trim();
            const documentYear = (oContext.getProperty("SubsequentDocYear") || "").trim();

            const hash = sap.ui.core.routing.HashChanger.getInstance().getHash();
            console.log("FLP Hash:", hash);

            // Extract query params from the hash
            const paramsString = hash.match(/\((.*)\)/)?.[1];
            console.log("Params string:", paramsString);

            const params = {};
            if (paramsString) {
                paramsString.split(",").forEach(pair => {
                    const [key, rawValue] = pair.split("=");
                    // Remove quotes (')
                    const value = rawValue.replace(/^'(.*)'$/, "$1");
                    params[key] = value;
                });
            }


            const docNum = oContext.getProperty("SubsequentDoc") || oEvent.getProperty("text");
            const docTypeMap = {
                "BT_FP": "BATCH",
                "BT_APH": "BATCH",
                "BT_RT": "BATCH",
                "BT_FRZ": "BATCH",
                "PO_SUB": "PO",
                "PO_APH": "PO",
                "ICSO": "PO",
                "IM_TR": "IM_TR",  // no mapping given → keep as-is
                "ICSO": "SO",
                "TSO": "SO",
                "OBD": "OD",
                "GI": "GI",
                "ARI": "ARINV",
                "ICPO": "PO",
                "GR": "GR",
                "IBD_PGR": "GR",
                "API": "APINV"
            };

            const docType = docTypeMap[rawDocType] || rawDocType; // default: pass through

            let sSemanticObject, sAction, oParams;

            switch (docType) {
                //BATCH MSC3N
                case "BATCH":
                    sSemanticObject = "Batch";
                    sAction = "display";
                    let sMaterial = "";
                    const odataModel = this._view.getModel();
                    let oModelBindingContext = odataModel.bindContext("/getMaterialData(...)");
                    oModelBindingContext.setParameter("initialDocumentNo", params.initialDocumentNo);
                    oModelBindingContext.setParameter("shippingReqNo", params.shippingReqNo);
                    await oModelBindingContext.invoke();

                    const response = oModelBindingContext.getBoundContext().getObject()
                    if (rawDocType === "BT_FP") {
                        sMaterial = response.materialNumber;
                    } else if (rawDocType === "BT_APH") {
                        sMaterial = response.AF_FRSH_Mat;
                    } else if (rawDocType === "BT_RT") {
                        sMaterial = response.RETAINBAG_Mat;
                    } else if (rawDocType === "BT_FRZ") {
                        sMaterial = response.AF_FZ_Mat
                    }
                    oParams = { Batch: [docNum], Material: sMaterial };
                    break;
                case "SO": // Sales Order: F1814
                    sSemanticObject = "SalesOrder";
                    sAction = "displayFactSheet";
                    oParams = { SalesOrder: [docNum] };
                    break;

                case "GI": // Goods Issue (Material Document) F1077
                    sSemanticObject = "MaterialDocument";
                    sAction = "displayFactSheet";
                    // oParams = { MaterialDocument: [docNum], MaterialDocumentYear: documentYear };
                    oParams = { MaterialDocument: [docNum] };
                    break;

                case "OD": // Outbound Delivery: F0233A
                    sSemanticObject = "OutboundDelivery";
                    sAction = "displayFactSheet";
                    oParams = { OutboundDelivery: [docNum] };
                    break;

                case "APINV": // Accounts Payable Invoice: MIR4
                    sSemanticObject = "SupplierInvoice";
                    sAction = "displayAdvanced";
                    oParams = { SupplierInvoice: [docNum], FiscalYear: documentYear };
                    break;

                case "PO": // Purchase Order: F0348A
                    sSemanticObject = "PurchaseOrder";
                    sAction = "displayFactSheet";
                    oParams = { PurchaseOrder: [docNum] };
                    break;

                case "IBD": // Inbound Delivery: F0232A
                    sSemanticObject = "InboundDelivery";
                    sAction = "displayFactSheet";
                    oParams = { InboundDelivery: [docNum] };
                    break;

                case "ARINV": // Accounts Receivable Invoice: F0797
                    sSemanticObject = "BillingDocument";
                    sAction = "displayBillingDocument";
                    oParams = { BillingDocument: [docNum] };
                    break;

                case "GR": // Accounts Receivable Invoice: F1077
                    sSemanticObject = "MaterialDocument";
                    sAction = "displayFactSheet";
                    // oParams = { MaterialDocument: [docNum], MaterialDocumentYear: documentYear };
                    oParams = { MaterialDocument: [docNum] };

                    break;

                default:
                    MessageToast.show("No navigation mapping for document type: " + docType);
                    return;
            }

            navigateToCrossApp(sSemanticObject, sAction, oParams);
        }
    };
});
