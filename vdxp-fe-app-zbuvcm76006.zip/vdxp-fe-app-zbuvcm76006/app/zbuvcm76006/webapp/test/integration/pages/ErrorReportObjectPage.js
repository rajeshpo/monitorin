sap.ui.define(['sap/fe/test/ObjectPage'], function(ObjectPage) {
    'use strict';

    var CustomPageDefinitions = {
        actions: {},
        assertions: {}
    };

    return new ObjectPage(
        {
            appId: 'jnj.com.zbuvcm76006',
            componentId: 'ErrorReportObjectPage',
            contextPath: '/ErrorReport'
        },
        CustomPageDefinitions
    );
});