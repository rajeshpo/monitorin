sap.ui.define(['sap/fe/test/ListReport'], function(ListReport) {
    'use strict';

    var CustomPageDefinitions = {
        actions: {},
        assertions: {}
    };

    return new ListReport(
        {
            appId: 'jnj.com.zbuvcm76006',
            componentId: 'ErrorReportList',
            contextPath: '/ErrorReport'
        },
        CustomPageDefinitions
    );
});