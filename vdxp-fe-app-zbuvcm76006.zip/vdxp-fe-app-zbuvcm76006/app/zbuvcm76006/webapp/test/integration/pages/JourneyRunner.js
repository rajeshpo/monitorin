sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"jnj/com/zbuvcm76006/test/integration/pages/ErrorReportList",
	"jnj/com/zbuvcm76006/test/integration/pages/ErrorReportObjectPage"
], function (JourneyRunner, ErrorReportList, ErrorReportObjectPage) {
    'use strict';

    var runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('jnj/com/zbuvcm76006') + '/test/flp.html#app-preview',
        pages: {
			onTheErrorReportList: ErrorReportList,
			onTheErrorReportObjectPage: ErrorReportObjectPage
        },
        async: true
    });

    return runner;
});

