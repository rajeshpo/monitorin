sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("jnj.com.zbuvcm76006.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);