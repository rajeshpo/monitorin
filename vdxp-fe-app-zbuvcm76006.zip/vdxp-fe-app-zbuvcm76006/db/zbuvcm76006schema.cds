// Application Name : VCM Error Log Report App
// Object Id       : zbuvcm76006
// Release         : 1
// Version         : 0.01
// Description     : VCM Error Log Report App
// ----------------------------------------------------------------------------*
// Descriptions: Table and Views
// ----------------------------------------------------------------------------*
// Change Log:
//    Date     |     Author   |   Change Id   |  Change Description
//  19-12-2025      PJadav2      JGHJ-76034     Initial Version
// ----------------------------------------------------------------------------*
namespace jnj.com.zbuvcm76006;

/**
 * This entity represents the header-level data of a Shipping Request.
 * It is mapped to an existing persistence table in the database(@cds.persistence.exists).
 * It acts as the master entity controlling shipping scenarios,
 * including validation status, workflow details, and links to
 * related line items, generated documents
 */
@cds.persistence.exists
entity syn_ShippingRequest {
    key ID                                  : UUID;
    key shippingReqNo                       : String(18)  @description: 'Unique identifier for the Shipping Request (system generated)';
    key initialDocumentNo                   : String(10)  @description: 'Document number of the initial triggering document';
        initialDocumentType                 : String(10)  @description: 'Type of the initial document (e.g., Sales Order, Purchase Order)';
        referenceDocumentNo                 : String(20)  @description: 'Reference document number linked to the shipping request';
        followOnDocumentNo                  : String(20)  @description: 'Follow-on document number created during processing';
        status                              : String(11)  @description: 'Overall processing status of the Shipping Request';

        shipFromBusinessPartner             : String(10)  @description: 'Business Partner ID of the Ship-From location';
        shipFromPlant                       : String(10)  @description: 'Plant code of the Ship-From location';
        shipToBusinessPartner               : String(10)  @description: 'Business Partner ID of the Ship-To location';
        shipToPlant                         : String(10)  @description: 'Plant code of the Ship-To location';

        requestedDeliveryDate               : Date        @description: 'Requested delivery date for the shipment';
        scenarioID                          : String(20)  @description: 'Scenario identifier used for determination logic';

        masterDataStatus                    : String(20)  @description: 'Validation status of master data';
        masterDataErrorDesciption           : String(400) @description: 'Detailed error message for master data validation';
        masterDataErrorCreationDate         : Timestamp   @description : 'Represents when error occured for master data check';
        masterDataErrorResolutionDate       : Timestamp  @description : 'Master Data Error Resolution Date';

        pfcCheckErrorDescription            : String(400) @description: 'Error message related to Product Flow Catalog validation';
        pfcCheckErrorResolutionDate         : Timestamp   @description: 'Represents when PFC check error got resolved';

        scenarioCheckStatusErrorDescription : String(400) @description: 'Error message related to scenario determination';
        scenarioCheckErrorResolutionDate    : Timestamp   @description: 'Represents when scenario check error got resolved';

        wfInstanceId                        : String(80)  @description: 'Workflow instance ID triggered for this shipping request';
        productFlowCatalogID                : String(14)  @description: 'Identifier of the Product Flow Catalog linked to this request';
        productFlowID                       : String      @description: 'Unique Product Flow ID associated with the scenario';

        creationDate                        : Date        @description: 'Date when the shipping request was created';
        userName                            : String(9)   @description: 'User ID of the person who created the request';

        // --- Compositions ---
        items                               : Composition of many syn_ShippingRequestItem
                                                  on items.parent = $self
                                                          @description: 'List of Material details for this Shipping Request';
        entity                              : Composition of many syn_ShippingRequestEntityDocs
                                                  on entity.parent = $self
                                                          @description: 'List of documents generated for this request';
        

}

/**
 * Represents item-level details of a Shipping Request.
 * Captures material-specific information such as type, brand, quantity,
 * and batch. Acts as a child entity of ShippingRequest, holding
 * transactional line items for each request.
 */
@cds.persistence.exists
entity syn_ShippingRequestItem {
    key ID                  : UUID;
        parent              : Association to syn_ShippingRequest;
        followOnDocumentNo  : String(20) @description: 'Reference GR or follow-on document number';
        itemNo              : String(20) @description: 'Item number';
        materialNumber      : String     @description: 'Material Number';
        materialType        : String     @description: 'Type/category of the material';
        materialBrand       : String     @description: 'Brand associated with the material';
        materialDescription : String     @description: 'Detailed description of the material';
        quantity            : String     @description: 'Quantity of material requested/shipped';
        uom                 : String     @description: 'Unit of Measure (e.g., EA, KG, L)';
        batchNumber         : String     @description: 'Batch number for traceability of the material';

}

/**
 * Represents document-level data linked to a Shipping Request.
 * Captures follow-on documents, business entities, statuses, and errors
 * that form part of the overall shipping request process.
 * Acts as a child entity of ShippingRequest and stores transactional
 * and validation details such as error logs, document sequences,
 * and associated business partners, plants, and eco-regions.
 */
@cds.persistence.exists
entity syn_ShippingRequestEntityDocs {
    key ID                    : UUID;
        parent                : Association to syn_ShippingRequest;
        followOnDocumentNo    : String(20)  @description: 'Reference GR or follow-on document number';
        documentType          : String(30)  @description: 'Document Type (e.g., Sales Order, Purchase Order)';
        documentNumber        : String(20)  @description: 'Document Number';
        errorStatus           : String(20)  @description: 'Error Status Code';
        errorDescription      : String(255) @description: 'Document error description or remarks';
        wfInstanceId          : String(80)  @description: 'Workflow Instance ID for tracking and retriggering the flow';
        errorCreationDate     : Date        @description: 'Date when the error was created';
        // creationDate           : Date;
        // Defect JGHJ-98095 --- START
        errorResolutionDate   : Timestamp   @description: 'Date when the document error was resolved';
        // Defect JGHJ-98095 --- END
        entityType            : String(20)  @description: 'Type of business entity (e.g., SF, ST)';
        entityRank            : Integer     @description: 'Rank or order of the entity within the flow';
        documentSequence      : Integer     @description: 'Sequence of the document in the process flow';
        ecoRegion             : String(10)  @description: 'Eco region or regional code';
        businessPartnerId     : String(10)  @description: 'Business Partner ID (customer/vendor)';
        plant                 : String(10)  @description: 'Plant identifier';
        bpName                : String(20)  @description: 'Business Partner name';
        plantName             : String(20)  @description: 'Plant name';
        ecoRegionName         : String(20)  @description: 'Eco region descriptive name';
        documentYear          : Date        @description: 'Document year (used in reporting/partitioning)';
        legalEntity           : String(10)  @description: 'Legal entity';
        isAT                  : Boolean     @description: 'Flag for AT documents (if applicable)';
        isExceptionalDocument : Boolean     @Common.FieldControl: #Hidden  @description: 'Flag for exceptional documents (hidden in UI)';
        stepID                 : String;
}

/**
 * Represents error log details for a Shipping Request document.
 * Captures error status, type, and workflow instance information.
 * Acts as a child entity of ShippingRequestEntityDocs,
 * allowing multiple errors to be tracked for a single document.
 */
@cds.persistence.exists
entity syn_ShippingRequestErrors {
    key     ID                : UUID;
            parent            : Association to syn_ShippingRequestEntityDocs @description: 'Reference to the parent Shipping Request Entity Document';
            vcaErrorStatus    : String                                       @description: 'Error status of the document flow (e.g., Pending, Error, Resolved)';
            vcaErrorType      : String(100)                                  @description: 'Type or category of the error (e.g., Master Data, PFC Check, Scenario)';
            vcaErrorTimeStamp : Timestamp                                    @description: 'Timestamp indicating when the error was logged';
            wfInstanceId      : String(80)                                   @description: 'Workflow Instance ID associated with this error, if available';
    virtual Criticality       : Integer                                      @description: 'UI criticality indicator for highlighting error severity';
}

/**
 * Consolidated prerequisite status view for a Shipping Request.
 * This view normalizes multiple validation checks (PFC, Scenario, Master Data)
 * into a single consumable structure using UNION ALL.
 *
 * Each row represents a single prerequisite check with:
 * - Check label and type
 * - Current status
 * - Error description (if any)
 *
 * Primarily used for UI display and reporting in a sorted manner
 * to show prerequisite validation progress per Shipping Request.
 */
@cds.persistence.exists
view syn_ShippingRequestPrereqStatus as
        // select from syn_ShippingRequest {
        //     key shippingReqNo                         @(title: '{i18n>Shippingreqno}'),

        //     key cast(
        //             'pfcCheck' as String(30)
        //         )                        as checkType @UI.Hidden,
        //         cast(
        //             'PFC Check' as String(50)
        //         )                        as checkLabel,
        //         pfcCheckStatus           as status,
        //         pfcCheckErrorDescription as errorDescription,

        //         cast(
        //             1 as Integer
        //         )                        as sortOrder @UI.Hidden
        // }
    // union all
    //     select from syn_ShippingRequest {
    //         key shippingReqNo,
    //         key cast(
    //                 'scenarioCheck' as String(30)
    //             )                                   as checkType @UI.Hidden,
    //             cast(
    //                 'Scenario Check' as String(50)
    //             )                                   as checkLabel,
    //             scenarioDeterminationCheckStatus    as status,
    //             scenarioCheckStatusErrorDescription as errorDescription,

    //             cast(
    //                 2 as Integer
    //             )                                   as sortOrder @UI.Hidden
    //     }
    // union all
        select from syn_ShippingRequest {
            key shippingReqNo,
            key cast(
                    'masterdataCheck' as String(30)
                )                         as checkType @UI.Hidden,
                cast(
                    'Master Data Check' as String(50)
                )                         as checkLabel,
                masterDataStatus          as status,
                masterDataErrorDesciption as errorDescription,

                cast(
                    3 as Integer
                )                         as sortOrder @UI.Hidden
        }
        order by
            sortOrder;

/**
 * Value Help (VH) view for Initial Document Number.
 * Provides a distinct list of initial document numbers
 * derived from Shipping Requests.
 *
 * Used mainly for filter dropdowns and value helps
 * in UI applications to support user selection.
 */
view initialDocumentNo_VH as
    select from syn_ShippingRequest {
        key initialDocumentNo
    }
    where
        initialDocumentNo is not null
    group by
        initialDocumentNo;

/**
 * View for Error Log Monitoring.
 * This view joins Shipping Request headers, entity documents,
 * and error records to provide a flattened, report-friendly
 * structure for error analysis.
 *
 * It exposes:
 * - Shipment and initiating document context
 * - Process and follow-on document details
 * - Error status, type, timestamps, and severity
 *
 * Designed specifically for:
 * - Error Log Report generation
 * - Excel exports
 * - Monitoring
 */
entity ZI_VCM_ErrorLogMonitoring as
        select from syn_ShippingRequestErrors as ERR
        inner join syn_ShippingRequestEntityDocs as DOC
            on ERR.parent.ID = DOC.ID
        inner join syn_ShippingRequest as HDR
            on DOC.parent.ID = HDR.ID

        {
                /* ------------------- Key ------------------- */
            key ERR.ID                   as ErrorID,

                /* ------------------- Initiating Document ------------------- */
                HDR.initialDocumentNo    as InitiatingDocumentNumber,
                HDR.initialDocumentType  as InitiatingDocumentType,

                /* ------------------- Shipment ------------------- */
                HDR.creationDate         as ShipmentCreationDate,
                HDR.shippingReqNo        as ShipmentID,
                HDR.productFlowCatalogID as ProductFlowCatalogID,
                HDR.productFlowID        as ProductFlowID,
                HDR.status               as status, //  NEW FIELD ADDED
                // HDR.masterDataErrorResolutionDate as ResolutionDate,

                /* ------------------- Process ------------------- */
                DOC.documentNumber       as SubsequentDoc,
                DOC.documentType         as ProcessStep,
                DOC.documentYear         as SubsequentDocYear,
                DOC.documentSequence     as ProcessSequence,
                DOC.legalEntity          as LegalEntity,
                DOC.plant                as Plant,
                DOC.stepID               as stepID,
                /* ------------------- Dates ------------------- */
                ERR.vcaErrorTimeStamp    as ErrorDate,
                DOC.errorResolutionDate  as ResolutionDate,

                /* ------------------- Status ------------------- */
                ERR.vcaErrorStatus       as ErrorMessage,
                ERR.vcaErrorType         as ErrorType,
                ERR.Criticality          as Criticality,

                virtual Processing : String
        }
        where
            ERR.vcaErrorType = 'Error'


    union all

        /* ================= MASTER DATA CHECK ================= */
        select from syn_ShippingRequest as HDR
        inner join syn_ShippingRequestErrors as ERR
            on ERR.parent.ID = HDR.ID
        {
                /* ------------------- Key ------------------- */
            key ERR.ID                            as ErrorID,

                /* ------------------- Initiating Document ------------------- */
                HDR.initialDocumentNo             as InitiatingDocumentNumber,
                HDR.initialDocumentType           as InitiatingDocumentType,

                /* ------------------- Shipment ------------------- */
                HDR.creationDate                  as ShipmentCreationDate,
                HDR.shippingReqNo                 as ShipmentID,
                HDR.productFlowCatalogID          as ProductFlowCatalogID,
                HDR.productFlowID                 as ProductFlowID,
                HDR.status                        as status,

                /* ------------------- Process ------------------- */
                cast(
                    null as String(20)
                )                                 as SubsequentDoc,
                case
                    when ERR.vcaErrorStatus = HDR.pfcCheckErrorDescription             then 'PFC Check'
                    when ERR.vcaErrorStatus = HDR.scenarioCheckStatusErrorDescription  then 'Scenario Check'
                    when ERR.vcaErrorStatus like '%PFC%'                         then 'PFC Check'
                    when ERR.vcaErrorStatus like '%ScenarioDetermination%'             then 'Scenario Check'
                    else 'Master Data Check'
                end                               as ProcessStep,
                cast(
                    null as String
                )                                 as SubsequentDocYear,
                cast(
                    0 as Integer
                )                                 as ProcessSequence,
                cast(
                    null as String(10)
                )                                 as LegalEntity,
                cast(
                    null as String(10)
                )                                 as Plant,
                case
                    when ERR.vcaErrorStatus = HDR.pfcCheckErrorDescription             then 'PFCCHECK'
                    when ERR.vcaErrorStatus = HDR.scenarioCheckStatusErrorDescription  then 'SCENARIO'
                    when ERR.vcaErrorStatus like '%PFC%'                         then 'PFCCHECK'
                    when ERR.vcaErrorStatus like '%ScenarioDetermination%'             then 'SCENARIO'
                    else 'MASTERDATA'
                end                               as stepID,

                /* ------------------- Dates ------------------- */
                ERR.vcaErrorTimeStamp             as ErrorDate,
                case
                    when ERR.vcaErrorStatus = HDR.pfcCheckErrorDescription             then HDR.pfcCheckErrorResolutionDate
                    when ERR.vcaErrorStatus = HDR.scenarioCheckStatusErrorDescription  then HDR.scenarioCheckErrorResolutionDate
                    when ERR.vcaErrorStatus like '%PFC%'                         then HDR.pfcCheckErrorResolutionDate
                    when ERR.vcaErrorStatus like '%ScenarioDetermination%'             then HDR.scenarioCheckErrorResolutionDate
                    else HDR.masterDataErrorResolutionDate
                end                               as ResolutionDate,

                /* ------------------- Status ------------------- */
                ERR.vcaErrorStatus                as ErrorMessage,
                ERR.vcaErrorType                  as ErrorType,

                case
                    when HDR.masterDataStatus = 'Error'
                         then 1
                    when HDR.masterDataStatus = 'In Progress'
                         then 2
                    else 3
                end                               as Criticality,

                cast(
                    null as String
                )                                 as Processing
        }
        where
               ERR.vcaErrorType = 'Error'
            or ERR.vcaErrorType = 'Warning'